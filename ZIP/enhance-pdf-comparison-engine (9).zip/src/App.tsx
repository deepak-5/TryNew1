import Lab from './components/Lab';
import Source from './components/Source';
import { Findings, Footer, Hero, Modes, Nav, SectionHead, Verify } from './components/Sections';

export default function App() {
  return (
    <div className="min-h-screen bg-canvas text-body">
      <Nav />
      <main>
        <Hero />

        <section className="shell pb-20 pt-16 md:pb-24 md:pt-20">
          <SectionHead
            id="lab"
            eyebrow="01 — The lab"
            title={<>A working engine, <em>not a demo reel.</em></>}
            aside={<span className="tag tag-accent">interactive</span>}
          >
            Open two PDFs, two Word files, or one of each — or start from a sample. Every view is computed in this tab as
            you type. With two PDFs, the engine builds a side-by-side and an overlay review PDF you can download.
          </SectionHead>
          <Lab />
        </section>

        <Findings />
        <Modes />

        <section className="border-t border-line">
          <div className="shell py-20 md:py-28">
            <SectionHead
              id="source"
              eyebrow="04 — C# source"
              title={<>Drop-in files for <em>PdfComparer.</em></>}
            >
              Four files replace yours, six are added, four of your files stay untouched. Start with the integration
              guide. The badge on each file says how far it has been verified.
            </SectionHead>
            <Source />
          </div>
        </section>

        <Verify />
      </main>
      <Footer />
    </div>
  );
}
