import diffEngine from '../csharp/PdfComparer.DiffEngine.cs?raw';
import diffRefine from '../csharp/PdfComparer.DiffRefine.cs?raw';
import normalization from '../csharp/PdfComparer.Normalization.cs?raw';
import pageAlignment from '../csharp/PdfComparer.PageAlignment.cs?raw';
import rasterDiff from '../csharp/PdfComparer.RasterDiff.cs?raw';
import options from '../csharp/PdfComparisonOptions.cs?raw';
import words from '../csharp/PdfComparer.Words.cs?raw';
import pipeline from '../csharp/PdfComparer.Pipeline.cs?raw';
import renderers from '../csharp/PdfComparer.Renderers.cs?raw';
import modes from '../csharp/PdfComparer.Modes.cs?raw';
import guide from '../csharp/INTEGRATION.md?raw';
import fuzz from '../csharp/tests/EngineFuzz.cs?raw';
import assumed from '../csharp/tests/AssumedApi.cs?raw';
import csproj from '../csharp/tests/EngineCheck.csproj?raw';

/** tested = compiled AND exercised by the test harness; compiled = type-checked against API stand-ins only. */
export type Assurance = 'tested' | 'compiled' | 'support';

export interface SourceFile {
  path: string;
  action: 'Replace' | 'Add' | 'Guide' | 'Tests';
  assurance: Assurance;
  blurb: string;
  code: string;
}

export const SOURCES: SourceFile[] = [
  { path: 'INTEGRATION.md', action: 'Guide', assurance: 'support', code: guide,
    blurb: 'Which file replaces what, two optional one-line edits, what is verified and what is not.' },
  { path: 'PdfComparer.DiffEngine.cs', action: 'Replace', assurance: 'tested', code: diffEngine,
    blurb: 'Diff core: maximal unique phrase anchors with heaviest-chain selection, patience anchors, linear-space Myers bisection with heuristic split.' },
  { path: 'PdfComparer.DiffRefine.cs', action: 'Add', assurance: 'tested', code: diffRefine,
    blurb: 'Boundary shifting, semantic cleanup, block-move detection, word pairing, character-level diff.' },
  { path: 'PdfComparer.Normalization.cs', action: 'Add', assurance: 'tested', code: normalization,
    blurb: 'Seven match modes built from composable flags; safe number canonicalisation.' },
  { path: 'PdfComparer.PageAlignment.cs', action: 'Add', assurance: 'tested', code: pageAlignment,
    blurb: 'Content-based page pairing from word-alignment votes.' },
  { path: 'PdfComparer.RasterDiff.cs', action: 'Add', assurance: 'tested', code: rasterDiff,
    blurb: 'Raster core: perceptual YIQ distance, registration, anti-aliasing tolerance, box clustering.' },
  { path: 'PdfComparisonOptions.cs', action: 'Replace', assurance: 'compiled', code: options,
    blurb: 'Options, enums and result records. All v2 members unchanged; v3 members are additive.' },
  { path: 'PdfComparer.Words.cs', action: 'Replace', assurance: 'compiled', code: words,
    blurb: 'Word model, punctuation-aware tokens, vocabulary-aware dehyphenation, alignment, change classification.' },
  { path: 'PdfComparer.Pipeline.cs', action: 'Replace', assurance: 'compiled', code: pipeline,
    blurb: 'CompareVisual: page slots, mode dispatch, raster glue, summary, bookmark fix, change records.' },
  { path: 'PdfComparer.Renderers.cs', action: 'Add', assurance: 'compiled', code: renderers,
    blurb: 'Side-by-side and overlay renderers that take a (before, after) page pair; move and formatting marks.' },
  { path: 'PdfComparer.Modes.cs', action: 'Add', assurance: 'compiled', code: modes,
    blurb: 'New output modes: Annotated, OnionSkin, ChangeMap, RedlineText, ChangeReport; summary add-ons.' },
  { path: 'tests/EngineFuzz.cs', action: 'Tests', assurance: 'support', code: fuzz,
    blurb: 'Console harness: 24,000 randomised cases plus targeted tests. dotnet run -c Release.' },
  { path: 'tests/AssumedApi.cs', action: 'Tests', assurance: 'support', code: assumed,
    blurb: 'Stand-ins for your library, inferred from your source. Not for your project — it is the checklist of assumed signatures.' },
  { path: 'tests/EngineCheck.csproj', action: 'Tests', assurance: 'support', code: csproj,
    blurb: 'Project file for the harness.' },
];
