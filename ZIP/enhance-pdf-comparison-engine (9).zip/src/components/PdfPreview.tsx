import { useCallback, useEffect, useRef, useState } from 'react';
import type { PDFDocumentProxy, RenderTask } from 'pdfjs-dist/legacy/build/pdf.mjs';
import { getPdfJs } from '../engine/files';

type Zoom = 'fit' | 1 | 1.5 | 2;
interface PageDim { w: number; h: number }

interface PageSlotProps {
  doc: PDFDocumentProxy;
  pageNumber: number;
  totalPages: number;
  cssW: number;
  cssH: number;
  cssScale: number;
  shouldRender: boolean;
  keepBitmap: boolean;
  registerSlot: (page: number, el: HTMLDivElement | null) => void;
  onError: (msg: string) => void;
}

function PdfPageSlot({
  doc,
  pageNumber,
  totalPages,
  cssW,
  cssH,
  cssScale,
  shouldRender,
  keepBitmap,
  registerSlot,
  onError,
}: PageSlotProps) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const taskRef = useRef<RenderTask | null>(null);
  const serialRef = useRef<Promise<void>>(Promise.resolve());
  const renderedKeyRef = useRef('');
  const [painted, setPainted] = useState(false);

  const dpr = typeof window !== 'undefined' ? Math.min(2, window.devicePixelRatio || 1) : 1;
  const renderKey = `${pageNumber}|${Math.round(cssScale * 1000)}|${dpr}`;

  useEffect(() => {
    registerSlot(pageNumber, wrapRef.current);
    return () => registerSlot(pageNumber, null);
  }, [pageNumber, registerSlot]);

  // Reset painted flag when document instance changes
  useEffect(() => {
    renderedKeyRef.current = '';
    setPainted(false);
  }, [doc]);

  useEffect(() => {
    const c = canvasRef.current;
    if (!c) return;

    if (!shouldRender) {
      if (!keepBitmap && renderedKeyRef.current) {
        if (taskRef.current) taskRef.current.cancel();
        c.width = 0;
        c.height = 0;
        renderedKeyRef.current = '';
        setPainted(false);
      }
      return;
    }

    if (renderedKeyRef.current === renderKey) return;

    let cancelled = false;
    if (taskRef.current) {
      taskRef.current.cancel();
    }

    const job = serialRef.current.then(async () => {
      if (cancelled) return;
      if (renderedKeyRef.current === renderKey) return;

      const p = await doc.getPage(pageNumber);
      if (cancelled) return;

      const vp = p.getViewport({ scale: cssScale * dpr });
      const targetW = Math.max(1, Math.floor(vp.width));
      const targetH = Math.max(1, Math.floor(vp.height));

      c.width = targetW;
      c.height = targetH;
      c.style.width = `${cssW}px`;
      c.style.height = `${cssH}px`;

      const ctx = c.getContext('2d');
      if (!ctx) return;
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, targetW, targetH);

      const task = p.render({ canvas: c, canvasContext: ctx, viewport: vp });
      taskRef.current = task;
      try {
        await task.promise;
        if (!cancelled) {
          renderedKeyRef.current = renderKey;
          setPainted(true);
        }
      } catch (e) {
        if ((e as { name?: string })?.name !== 'RenderingCancelledException' && !cancelled) {
          onError(e instanceof Error ? e.message : String(e));
        }
      } finally {
        if (taskRef.current === task) taskRef.current = null;
      }
    });

    serialRef.current = job.catch(() => undefined);

    return () => {
      cancelled = true;
      if (taskRef.current) taskRef.current.cancel();
    };
  }, [doc, pageNumber, cssScale, cssW, cssH, dpr, renderKey, shouldRender, keepBitmap, onError]);

  return (
    <div
      ref={wrapRef}
      data-pdf-page={pageNumber}
      className="flex flex-none flex-col items-center"
    >
      <div className="mb-1.5 flex w-full items-center justify-between px-0.5 font-mono text-[10px] uppercase tracking-[0.12em] text-faint">
        <span>Page {pageNumber} of {totalPages}</span>
      </div>
      <div
        className="relative overflow-hidden bg-white shadow-[0_2px_8px_rgba(15,14,10,0.12),0_24px_48px_-24px_rgba(15,14,10,0.36)]"
        style={{ width: cssW, height: cssH }}
      >
        {!painted && <div className="skeleton absolute inset-0" aria-hidden="true" />}
        <canvas
          ref={canvasRef}
          className="relative block"
          style={{ width: cssW, height: cssH }}
          aria-label={`PDF page ${pageNumber}`}
        />
      </div>
    </div>
  );
}

/** Continuous scrollable PDF viewer (bytes in memory) with on-demand rendering, live scroll tracking, bookmark jumps, and zoom. */
export default function PdfPreview({ bytes }: { bytes: Uint8Array }) {
  const [doc, setDoc] = useState<PDFDocumentProxy | null>(null);
  const [dims, setDims] = useState<PageDim[]>([]);
  const [err, setErr] = useState('');
  const [page, setPage] = useState(1);
  const [pageDraft, setPageDraft] = useState('1');
  const [editingPage, setEditingPage] = useState(false);
  const [zoom, setZoom] = useState<Zoom>('fit');
  const [outline, setOutline] = useState<{ title: string; page: number }[]>([]);
  const [innerWidth, setInnerWidth] = useState(0);
  const [visibleSet, setVisibleSet] = useState<Set<number>>(() => new Set([1, 2, 3]));

  const boxRef = useRef<HTMLDivElement>(null);
  const slotMapRef = useRef<Map<number, HTMLDivElement>>(new Map());
  const observerRef = useRef<IntersectionObserver | null>(null);
  const scrollLockUntilRef = useRef(0);
  const rafRef = useRef<number | null>(null);

  // Sync draft input when current page changes externally or via scrolling
  useEffect(() => {
    if (!editingPage) setPageDraft(String(page));
  }, [page, editingPage]);

  // Load PDF document, page dimensions, and outline bookmarks
  useEffect(() => {
    let dead = false;
    let d: PDFDocumentProxy | null = null;
    setErr('');
    setDoc(null);
    setDims([]);
    setPage(1);
    setPageDraft('1');
    setOutline([]);
    setVisibleSet(new Set([1, 2, 3]));
    if (boxRef.current) boxRef.current.scrollTop = 0;

    (async () => {
      const lib = await getPdfJs();
      d = await lib.getDocument({ data: bytes.slice(), isEvalSupported: false }).promise;
      if (dead) { void d.destroy(); return; }

      const pageDims: PageDim[] = new Array(d.numPages);
      const chunk = 20;
      for (let start = 1; start <= d.numPages; start += chunk) {
        const end = Math.min(d.numPages, start + chunk - 1);
        const batch = await Promise.all(
          Array.from({ length: end - start + 1 }, async (_, k) => {
            const p = await d!.getPage(start + k);
            const vp = p.getViewport({ scale: 1 });
            p.cleanup();
            return { w: vp.width, h: vp.height };
          }),
        );
        if (dead) { void d.destroy(); return; }
        batch.forEach((dm, k) => { pageDims[start - 1 + k] = dm; });
      }

      const items: { title: string; page: number }[] = [];
      try {
        for (const o of (await d.getOutline()) ?? []) {
          const dest = typeof o.dest === 'string' ? await d.getDestination(o.dest) : o.dest;
          if (dest && dest[0] && typeof dest[0] === 'object') {
            items.push({ title: o.title, page: (await d.getPageIndex(dest[0] as never)) + 1 });
          }
        }
      } catch { /* no outline */ }

      if (dead) { void d.destroy(); return; }
      setDims(pageDims);
      setOutline(items);
      setDoc(d);
    })().catch(e => {
      if (!dead) setErr(e instanceof Error ? e.message : String(e));
    });

    return () => {
      dead = true;
      void d?.destroy();
    };
  }, [bytes]);

  // Measure scroll viewport inner content width consistently (excluding padding)
  useEffect(() => {
    const el = boxRef.current;
    if (!el) return;
    const measure = () => {
      const cs = getComputedStyle(el);
      const pad = parseFloat(cs.paddingLeft) + parseFloat(cs.paddingRight);
      setInnerWidth(Math.max(120, Math.floor(el.clientWidth - pad - 2)));
    };
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    measure();
    return () => ro.disconnect();
  }, []);

  // Observe which pages are inside or near the scrollable viewport
  useEffect(() => {
    const root = boxRef.current;
    if (!root || !doc) return;
    const io = new IntersectionObserver(
      entries => {
        setVisibleSet(prev => {
          let changed = false;
          const next = new Set(prev);
          for (const entry of entries) {
            const pg = Number((entry.target as HTMLElement).dataset.pdfPage);
            if (!pg) continue;
            if (entry.isIntersecting) {
              if (!next.has(pg)) { next.add(pg); changed = true; }
            } else if (next.has(pg)) {
              next.delete(pg);
              changed = true;
            }
          }
          return changed ? next : prev;
        });
      },
      { root, rootMargin: '700px 0px', threshold: 0 },
    );
    observerRef.current = io;
    slotMapRef.current.forEach(el => io.observe(el));
    return () => {
      io.disconnect();
      if (observerRef.current === io) observerRef.current = null;
    };
  }, [doc, dims.length]);

  const registerSlot = useCallback((pg: number, el: HTMLDivElement | null) => {
    const prev = slotMapRef.current.get(pg);
    if (prev && observerRef.current) observerRef.current.unobserve(prev);
    if (el) {
      slotMapRef.current.set(pg, el);
      observerRef.current?.observe(el);
    } else {
      slotMapRef.current.delete(pg);
    }
  }, []);

  // Track which page is currently centered in view while scrolling
  const handleScroll = () => {
    if (performance.now() < scrollLockUntilRef.current) return;
    if (rafRef.current !== null) return;
    rafRef.current = requestAnimationFrame(() => {
      rafRef.current = null;
      const box = boxRef.current;
      if (!box || !dims.length) return;
      const probeY = box.scrollTop + box.clientHeight * 0.35;
      let bestPage = 1;
      let bestDist = Infinity;
      slotMapRef.current.forEach((el, pg) => {
        const top = el.offsetTop;
        const bottom = top + el.offsetHeight;
        if (probeY >= top && probeY <= bottom) {
          bestPage = pg;
          bestDist = 0;
          return;
        }
        const dist = Math.min(Math.abs(probeY - top), Math.abs(probeY - bottom));
        if (dist < bestDist) {
          bestDist = dist;
          bestPage = pg;
        }
      });
      setPage(p => (p === bestPage ? p : bestPage));
    });
  };

  useEffect(() => () => { if (rafRef.current !== null) cancelAnimationFrame(rafRef.current); }, []);

  const n = doc?.numPages ?? 0;

  const scrollToPage = (target: number) => {
    const clamped = Math.min(Math.max(1, target), Math.max(1, n));
    setPage(clamped);
    setPageDraft(String(clamped));
    const el = slotMapRef.current.get(clamped);
    const box = boxRef.current;
    if (el && box) {
      const cs = getComputedStyle(box);
      const padTop = parseFloat(cs.paddingTop) || 0;
      scrollLockUntilRef.current = performance.now() + 700;
      box.scrollTo({ top: Math.max(0, el.offsetTop - padTop), behavior: 'smooth' });
    }
  };

  const commitPageDraft = () => {
    setEditingPage(false);
    const parsed = Number(pageDraft.replace(/\D/g, ''));
    if (parsed >= 1) scrollToPage(parsed);
    else setPageDraft(String(page));
  };

  const btn = 'btn btn-secondary btn-sm';

  return (
    <div>
      <div className="flex flex-wrap items-center gap-2 border-b border-line bg-surface-2 px-3 py-2">
        <button className={btn} disabled={page <= 1} onClick={() => scrollToPage(page - 1)} aria-label="Previous page" title="Scroll to previous page">↑</button>
        <span className="flex items-center gap-1.5 whitespace-nowrap font-mono text-[11.5px] text-ink-300">
          <input
            value={pageDraft}
            onFocus={() => setEditingPage(true)}
            onBlur={commitPageDraft}
            onChange={e => setPageDraft(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter') { (e.target as HTMLInputElement).blur(); } }}
            inputMode="numeric"
            aria-label="Page number"
            className="field w-11 px-1 py-0.5 text-center"
          />
          <span>/ {n || '–'}</span>
        </span>
        <button className={btn} disabled={page >= n} onClick={() => scrollToPage(page + 1)} aria-label="Next page" title="Scroll to next page">↓</button>
        {outline.length > 0 && (
          <select
            value=""
            onChange={e => {
              if (e.target.value) {
                scrollToPage(Number(e.target.value));
                e.target.value = '';
              }
            }}
            className="field w-auto max-w-[16rem] truncate px-2 py-1 text-[12px]"
            aria-label="Jump to bookmark"
          >
            <option value="">Jump to…</option>
            {outline.map((o, i) => <option key={i} value={o.page}>{o.title}</option>)}
          </select>
        )}
        <span className="hidden font-mono text-[10px] uppercase tracking-[0.12em] text-faint lg:inline">
          Scroll to read all pages
        </span>
        <div className="seg ml-auto">
          {([['fit', 'Fit width'], [1, '100%'], [1.5, '150%'], [2, '200%']] as [Zoom, string][]).map(([z, l]) => (
            <button
              key={String(z)}
              onClick={() => setZoom(z)}
              className={`seg-item !h-6 !px-2 !text-[11px] ${zoom === z ? 'is-on' : ''}`}
            >
              {l}
            </button>
          ))}
        </div>
      </div>

      <div
        ref={boxRef}
        onScroll={handleScroll}
        className="viewer scroll-ink relative max-h-[78vh] min-h-[18rem] overflow-auto p-3 md:p-6"
      >
        {err ? (
          <div className="rounded-lg border border-del/40 bg-del/10 p-4 text-[13px] text-del">
            Could not display this PDF: {err}
          </div>
        ) : !doc || !innerWidth ? (
          <div className="py-20 text-center text-[13px] text-muted">Loading preview…</div>
        ) : (
          <div className="flex flex-col items-center gap-6">
            {dims.map((dm, idx) => {
              const pNum = idx + 1;
              const cssScale = zoom === 'fit' ? Math.max(0.1, innerWidth / dm.w) : zoom;
              const cssW = Math.max(1, Math.floor(dm.w * cssScale));
              const cssH = Math.max(1, Math.floor(dm.h * cssScale));
              const nearCurrent = Math.abs(pNum - page) <= 2;
              const shouldRender = visibleSet.has(pNum) || nearCurrent;
              const keepBitmap = n <= 24 || nearCurrent;

              return (
                <PdfPageSlot
                  key={pNum}
                  doc={doc}
                  pageNumber={pNum}
                  totalPages={n}
                  cssW={cssW}
                  cssH={cssH}
                  cssScale={cssScale}
                  shouldRender={shouldRender}
                  keepBitmap={keepBitmap}
                  registerSlot={registerSlot}
                  onError={setErr}
                />
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
