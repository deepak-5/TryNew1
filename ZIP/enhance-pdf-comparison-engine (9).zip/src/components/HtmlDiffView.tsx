import { useEffect, useRef, useState } from 'react';
import type { HtmlDiffResult } from '../engine/markdown';
import { buildStandaloneHtmlReport } from '../engine/markdown';
import { download } from './Panels';

type SubMode = 'redline' | 'sidebyside' | 'htmlsrc' | 'mdsrc';

interface Props {
  diff: HtmlDiffResult;
  mdA: string;
  mdB: string;
  htmlA: string;
  htmlB: string;
  titleA: string;
  titleB: string;
  active: number;
  onPick: (id: number) => void;
}

function HtmlSurface({ html, active, onPick, className = '' }: { html: string; active: number; onPick: (id: number) => void; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    el.querySelectorAll('.tk-active').forEach(n => n.classList.remove('tk-active'));
    if (active >= 0) {
      el.querySelectorAll(`[data-ch="${active}"]`).forEach(n => n.classList.add('tk-active'));
    }
  }, [active, html]);

  return (
    <div
      ref={ref}
      className={`html-doc ${className}`}
      onClick={e => {
        const target = (e.target as HTMLElement | null)?.closest<HTMLElement>('[data-ch]');
        if (target) {
          const id = Number(target.dataset.ch);
          if (Number.isFinite(id)) onPick(id);
        }
      }}
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
}

export default function HtmlDiffView({ diff, mdA, mdB, htmlA, htmlB, titleA, titleB, active, onPick }: Props) {
  const [sub, setSub] = useState<SubMode>('redline');
  const [copied, setCopied] = useState('');

  const copyText = async (label: string, text: string) => {
    try { await navigator.clipboard.writeText(text); }
    catch {
      const ta = document.createElement('textarea');
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      ta.remove();
    }
    setCopied(label);
    setTimeout(() => setCopied(''), 1500);
  };

  const tabBtn = (id: SubMode, label: string) => (
    <button
      key={id}
      type="button"
      onClick={() => setSub(id)}
      className={`rounded-md px-2.5 py-1 text-[12px] transition ${sub === id ? 'bg-ink-100 font-medium text-surface' : 'text-ink-300 hover:bg-ink-700 hover:text-ink'}`}
    >
      {label}
    </button>
  );

  const reportHtml = () => buildStandaloneHtmlReport(titleA, titleB, diff.redlineHtml, diff.res.stats.similarity, diff.res.changes.length);

  return (
    <div className="bg-ink-900">
      <div className="flex flex-wrap items-center gap-2 border-b border-line bg-surface-2 px-4 py-2">
        <div className="flex flex-wrap gap-1">
          {tabBtn('redline', 'HTML Redline')}
          {tabBtn('sidebyside', 'HTML Side by Side')}
          {tabBtn('htmlsrc', 'Pure HTML Source')}
          {tabBtn('mdsrc', 'Markdown Source')}
        </div>
        <div className="ml-auto flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => void copyText('html', diff.redlineHtml)}
            className="btn btn-secondary btn-sm"
          >
            {copied === 'html' ? 'Copied HTML ✓' : 'Copy Redline HTML'}
          </button>
          <button
            type="button"
            onClick={() => download('comparison-report.html', reportHtml(), 'text/html')}
            className="btn btn-secondary btn-sm"
          >
            Download HTML ↓
          </button>
          <button
            type="button"
            onClick={() => download('modified.md', mdB, 'text/markdown')}
            className="btn btn-secondary btn-sm"
          >
            Download .md ↓
          </button>
        </div>
      </div>

      {sub === 'redline' && (
        <div className="paper px-6 py-6 md:px-10">
          {diff.redlineHtml.trim()
            ? <HtmlSurface html={diff.redlineHtml} active={active} onPick={onPick} />
            : <div className="py-10 text-center font-sans text-sm text-paper-mute">Nothing to compare yet — load two PDFs, Word files or Markdown/text.</div>}
        </div>
      )}

      {sub === 'sidebyside' && (
        <div className="paper overflow-x-auto">
          <div className="grid min-w-[700px] grid-cols-2">
            <div className="border-r border-paper-edge">
              <div className="sticky top-0 z-10 border-b border-paper-edge bg-paper/95 px-5 py-2 font-mono text-[10px] uppercase tracking-[0.14em] text-paper-mute backdrop-blur">
                Original · Pure HTML
              </div>
              <div className="px-5 py-5">
                <HtmlSurface html={diff.leftHtml} active={active} onPick={onPick} />
              </div>
            </div>
            <div>
              <div className="sticky top-0 z-10 border-b border-paper-edge bg-paper/95 px-5 py-2 font-mono text-[10px] uppercase tracking-[0.14em] text-paper-mute backdrop-blur">
                Modified · Pure HTML
              </div>
              <div className="px-5 py-5">
                <HtmlSurface html={diff.rightHtml} active={active} onPick={onPick} />
              </div>
            </div>
          </div>
        </div>
      )}

      {sub === 'htmlsrc' && (
        <div className="grid divide-y divide-ink-700 md:grid-cols-2 md:divide-x md:divide-y-0">
          <div className="min-w-0">
            <div className="flex items-center justify-between border-b border-ink-700 bg-ink-850 px-4 py-2 font-mono text-[10.5px] uppercase tracking-wider text-ink-400">
              <span>Original · Pure HTML</span>
              <button onClick={() => void copyText('ha', htmlA)} className="rounded border border-ink-600 px-2 py-0.5 text-[11px] normal-case text-ink-200 hover:border-ink-400">
                {copied === 'ha' ? 'Copied ✓' : 'Copy'}
              </button>
            </div>
            <pre className="code scroll-ink m-0 max-h-[60vh] overflow-auto bg-surface-2 p-4 leading-relaxed whitespace-pre-wrap">{htmlA}</pre>
          </div>
          <div className="min-w-0">
            <div className="flex items-center justify-between border-b border-ink-700 bg-ink-850 px-4 py-2 font-mono text-[10.5px] uppercase tracking-wider text-ink-400">
              <span>Modified · Pure HTML</span>
              <button onClick={() => void copyText('hb', htmlB)} className="rounded border border-ink-600 px-2 py-0.5 text-[11px] normal-case text-ink-200 hover:border-ink-400">
                {copied === 'hb' ? 'Copied ✓' : 'Copy'}
              </button>
            </div>
            <pre className="code scroll-ink m-0 max-h-[60vh] overflow-auto bg-surface-2 p-4 leading-relaxed whitespace-pre-wrap">{htmlB}</pre>
          </div>
        </div>
      )}

      {sub === 'mdsrc' && (
        <div className="grid divide-y divide-ink-700 md:grid-cols-2 md:divide-x md:divide-y-0">
          <div className="min-w-0">
            <div className="flex items-center justify-between border-b border-ink-700 bg-ink-850 px-4 py-2 font-mono text-[10.5px] uppercase tracking-wider text-ink-400">
              <span>Original · Extracted Markdown</span>
              <button onClick={() => void copyText('ma', mdA)} className="rounded border border-ink-600 px-2 py-0.5 text-[11px] normal-case text-ink-200 hover:border-ink-400">
                {copied === 'ma' ? 'Copied ✓' : 'Copy'}
              </button>
            </div>
            <pre className="code scroll-ink m-0 max-h-[60vh] overflow-auto bg-surface-2 p-4 leading-relaxed whitespace-pre-wrap">{mdA}</pre>
          </div>
          <div className="min-w-0">
            <div className="flex items-center justify-between border-b border-ink-700 bg-ink-850 px-4 py-2 font-mono text-[10.5px] uppercase tracking-wider text-ink-400">
              <span>Modified · Extracted Markdown</span>
              <button onClick={() => void copyText('mb', mdB)} className="rounded border border-ink-600 px-2 py-0.5 text-[11px] normal-case text-ink-200 hover:border-ink-400">
                {copied === 'mb' ? 'Copied ✓' : 'Copy'}
              </button>
            </div>
            <pre className="code scroll-ink m-0 max-h-[60vh] overflow-auto bg-surface-2 p-4 leading-relaxed whitespace-pre-wrap">{mdB}</pre>
          </div>
        </div>
      )}
    </div>
  );
}
