import { Fragment, useMemo } from 'react';
import type { CompareResult } from '../engine/compare';
import { EQ, DEL, INS, Seg, buildRedline, buildRows, buildOverlay } from '../engine/views';

export interface ViewProps {
  res: CompareResult;
  active: number;
  onPick: (id: number) => void;
  collapse: boolean;
}

function segClass(s: Seg): string {
  if (s.kind === INS) return s.move >= 0 ? 'tk tk-mvto' : 'tk tk-ins';
  return s.move >= 0 ? 'tk tk-mvfrom' : 'tk tk-del';
}

export function SegSpan({ s, active, onPick }: { s: Seg; active: number; onPick: (id: number) => void }) {
  if (s.kind === EQ) return <>{s.sp ? ' ' : ''}{s.text}</>;
  return (
    <>
      {s.sp ? ' ' : ''}
      <span
        data-ch={s.change}
        className={segClass(s) + (active === s.change ? ' tk-active' : '')}
        onClick={() => onPick(s.change)}
        title={s.move >= 0 ? (s.kind === INS ? 'Moved here' : 'Moved from here') : s.kind === INS ? 'Added' : 'Deleted'}
      >
        {s.text}
      </span>
    </>
  );
}

type Collapsed<T> = { row: T; i: number } | { skip: number };

/** Keep changed rows plus one row of context; fold the rest. */
function collapseRows<T>(rows: T[], changed: (r: T) => boolean, on: boolean): Collapsed<T>[] {
  if (!on) return rows.map((row, i) => ({ row, i }));
  const keep = new Uint8Array(rows.length);
  rows.forEach((r, i) => {
    if (!changed(r)) return;
    keep[i] = 1;
    if (i > 0) keep[i - 1] = 1;
    if (i + 1 < rows.length) keep[i + 1] = 1;
  });
  const out: Collapsed<T>[] = [];
  let skip = 0;
  rows.forEach((row, i) => {
    if (!keep[i]) { skip++; return; }
    if (skip) { out.push({ skip }); skip = 0; }
    out.push({ row, i });
  });
  if (skip) out.push({ skip });
  return out;
}

function Skip({ n, dark }: { n: number; dark?: boolean }) {
  return (
    <div className={`my-1 flex items-center gap-3 px-4 font-mono text-[10px] uppercase tracking-[0.14em] ${dark ? 'text-[#7d838d]' : 'text-paper-mute'}`}>
      <span className={`h-px flex-1 ${dark ? 'bg-[#262b33]' : 'bg-paper-edge'}`} />
      {n} unchanged {n === 1 ? 'line' : 'lines'}
      <span className={`h-px flex-1 ${dark ? 'bg-[#262b33]' : 'bg-paper-edge'}`} />
    </div>
  );
}

function Empty() {
  return <div className="p-10 text-center font-sans text-sm text-paper-mute">Nothing to compare yet — paste text into both panes.</div>;
}

// ── 1. Redline ───────────────────────────────────────────────────────────────

export function RedlineView({ res, active, onPick, collapse }: ViewProps) {
  const lines = useMemo(() => buildRedline(res.items), [res]);
  const rows = useMemo(() => collapseRows(lines, l => l.changed, collapse), [lines, collapse]);
  if (!lines.length) return <div className="paper"><Empty /></div>;
  let page = -1;
  return (
    <div className="paper py-4">
      {rows.map((r, k) => {
        if ('skip' in r) return <Skip key={k} n={r.skip} />;
        const l = r.row;
        const newPage = l.lineNo >= 0 && l.page !== page;
        if (l.lineNo >= 0) page = l.page;
        return (
          <Fragment key={k}>
            {newPage && <div className="page-rule">Page {l.page + 1}</div>}
            <div className={`doc-line ${l.gap && !newPage ? 'mt-3' : ''}`}>
              <span className="ln">{l.lineNo >= 0 ? l.lineNo : ''}</span>
              <span className="min-w-0 flex-1">{l.segs.map((s, i) => <SegSpan key={i} s={s} active={active} onPick={onPick} />)}</span>
            </div>
          </Fragment>
        );
      })}
    </div>
  );
}

// ── 2. Side by side ──────────────────────────────────────────────────────────

export function SideBySideView({ res, active, onPick, collapse }: ViewProps) {
  const all = useMemo(() => buildRows(res.items, res.tokA, res.tokB), [res]);
  const rows = useMemo(() => collapseRows(all, r => r.changed, collapse), [all, collapse]);
  if (!all.length) return <div className="paper"><Empty /></div>;
  return (
    <div className="paper overflow-x-auto">
      <div className="min-w-[680px]">
        <div className="sticky top-0 z-10 grid grid-cols-2 border-b border-paper-edge bg-paper/95 font-mono text-[10px] uppercase tracking-[0.14em] text-paper-mute backdrop-blur">
          <div className="px-4 py-2">Original</div>
          <div className="border-l border-paper-edge px-4 py-2">Modified</div>
        </div>
        {rows.map((r, k) => {
          if ('skip' in r) return <Skip key={k} n={r.skip} />;
          const row = r.row;
          return (
            <div key={k} className={`grid grid-cols-2 ${row.gap ? 'mt-2' : ''} ${row.changed ? 'bg-[#efe7d6]' : ''}`}>
              <div className="doc-line py-0.5">
                <span className="ln">{row.la >= 0 ? row.la : ''}</span>
                <span className="min-w-0 flex-1">
                  {row.left.map((s, i) => <SegSpan key={i} s={s} active={active} onPick={onPick} />)}
                </span>
              </div>
              <div className="doc-line border-l border-paper-edge py-0.5">
                <span className="ln">{row.lb >= 0 ? row.lb : ''}</span>
                <span className="min-w-0 flex-1">
                  {row.right.map((s, i) => <SegSpan key={i} s={s} active={active} onPick={onPick} />)}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── 3. Unified ───────────────────────────────────────────────────────────────

export function UnifiedView({ res, active, onPick, collapse }: ViewProps) {
  const all = useMemo(() => buildRows(res.items, res.tokA, res.tokB), [res]);
  const rows = useMemo(() => collapseRows(all, r => r.changed, collapse), [all, collapse]);
  if (!all.length) return <div className="bg-ink-900 p-10 text-center text-sm text-ink-400">Nothing to compare yet.</div>;
  const line = (key: string, sign: string, no: number, segs: Seg[], tone: string) => (
    <div key={key} className={`flex gap-3 px-3 ${tone}`}>
      <span className="w-10 flex-none select-none text-right text-[#5d6169]">{no >= 0 ? no : ''}</span>
      <span className="w-3 flex-none select-none text-center">{sign}</span>
      <span className="min-w-0 flex-1 whitespace-pre-wrap break-words">{segs.map((s, i) => <SegSpan key={i} s={s} active={active} onPick={onPick} />)}</span>
    </div>
  );
  return (
    <div className="term py-3 text-[12.5px] leading-6">
      {rows.map((r, k) => {
        if ('skip' in r) return <Skip key={k} n={r.skip} dark />;
        const row = r.row;
        if (!row.changed) return line(`${k}`, ' ', row.lb, row.right, '');
        return (
          <Fragment key={k}>
            {row.left.length > 0 && line(`${k}a`, '−', row.la, row.left, 'bg-del/10 text-ink-100')}
            {row.right.length > 0 && line(`${k}b`, '+', row.lb, row.right, 'bg-ins/10 text-ink-100')}
          </Fragment>
        );
      })}
    </div>
  );
}

// ── 4. Overlay (mirrors the PDF VisualOverlay mode) ──────────────────────────

export function OverlayView({ res, active, onPick, collapse }: ViewProps) {
  const lines = useMemo(() => buildOverlay(res.items), [res]);
  const rows = useMemo(
    () => collapseRows(lines, l => l.callouts.length > 0 || l.segs.some(s => s.kind !== EQ), collapse),
    [lines, collapse],
  );
  if (!lines.length) return <div className="paper"><Empty /></div>;
  let page = -1;
  return (
    <div className="paper overflow-x-auto py-4">
      <div className="min-w-[640px]">
        {rows.map((r, k) => {
          if ('skip' in r) return <Skip key={k} n={r.skip} />;
          const l = r.row;
          const newPage = l.lineNo >= 0 && l.page !== page;
          if (l.lineNo >= 0) page = l.page;
          return (
            <Fragment key={k}>
              {newPage && <div className="page-rule">Page {l.page + 1} · modified document</div>}
              <div className={`grid grid-cols-[minmax(0,1fr)_230px] ${l.gap && !newPage ? 'mt-3' : ''}`}>
                <div className="doc-line">
                  <span className="ln">{l.lineNo >= 0 ? l.lineNo : ''}</span>
                  <span className="min-w-0 flex-1">
                    {l.segs.map((s, i) =>
                      s.kind === DEL ? (
                        <span
                          key={i}
                          data-ch={s.change}
                          className={`caret ${s.move >= 0 ? 'mv' : ''}`}
                          onClick={() => onPick(s.change)}
                          title="Text was removed here"
                        />
                      ) : (
                        <SegSpan key={i} s={s} active={active} onPick={onPick} />
                      ),
                    )}
                  </span>
                </div>
                <div className="flex flex-col gap-1 border-l border-dashed border-paper-edge py-0.5 pl-3 pr-3">
                  {l.callouts.map((c, i) => (
                    <button
                      key={i}
                      onClick={() => onPick(c.change)}
                      className={`w-fit max-w-full rounded border px-1.5 py-0.5 text-left font-sans text-[11px] leading-snug line-through decoration-1 ${
                        c.moved ? 'border-move/50 bg-[#e6ecff] text-[#3a55a8]' : 'border-del/50 bg-[#fde8e8] text-[#9b1c1f]'
                      } ${active === c.change ? 'outline outline-2 outline-signal' : ''}`}
                      title={c.moved ? 'Moved away from here' : 'Deleted'}
                    >
                      {c.text.length > 140 ? c.text.slice(0, 137) + '…' : c.text}
                    </button>
                  ))}
                </div>
              </div>
            </Fragment>
          );
        })}
      </div>
    </div>
  );
}
