import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import type { CompareOptions, CompareResult } from '../engine/compare';
import { MATCH_MODES } from '../engine/normalize';
import type { LoadedDoc } from '../engine/files';
import { analyzeVisuals, buildComparisonPdf, type DocPdf, type PdfLayout, type PdfOutput, type SlotVisual } from '../engine/pdfcompare';
import { openRenderer, type PageRenderer } from '../engine/rasterize';
import PdfPreview from './PdfPreview';
import { download } from './Panels';

const QUALITY = { fast: 72, balanced: 110, fine: 150 } as const;
type Quality = keyof typeof QUALITY;
const AUTO_MAX_PAGES = 40;

interface Built extends PdfOutput { name: string; ms: number }
type Outputs = Partial<Record<PdfLayout, Built>>;

const LAYOUTS: { id: PdfLayout; label: string; blurb: string }[] = [
  { id: 'sidebyside', label: 'Side-by-side PDF', blurb: 'Original on the left, modified on the right — every page next to its real counterpart. Deleted text: red tint with a red line through it. Added text: green tint with a green line under it.' },
  { id: 'overlay', label: 'Overlay PDF', blurb: 'The modified page at 1:1. Additions are marked in place; each deletion leaves a red caret where the text was removed and a struck-through callout in the right margin, joined by a dotted leader.' },
];

function Check({ on, set, label, hint }: { on: boolean; set: (v: boolean) => void; label: string; hint?: string }) {
  return (
    <label className="flex cursor-pointer items-center gap-2 text-[12.5px] text-ink-200 hover:text-ink" title={hint}>
      <input type="checkbox" checked={on} onChange={e => set(e.target.checked)} className="h-3.5 w-3.5 accent-[var(--accent)]" />
      {label}
    </label>
  );
}

function Legend() {
  const sw = (c: string) => <i className={`mr-1.5 inline-block h-2.5 w-2.5 rounded-[2px] ${c}`} />;
  return (
    <div className="flex flex-wrap gap-x-5 gap-y-1 font-mono text-[10.5px] text-ink-400">
      <span>{sw('bg-del')}deleted · red line through</span>
      <span>{sw('bg-ins')}added · green line under</span>
      <span>{sw('bg-move')}moved · blue dashed</span>
      <span>{sw('bg-mod')}image / graphic change · amber frame</span>
    </div>
  );
}

function Empty({ onDemo, busy, docs }: { onDemo: () => void; busy: string; docs: [LoadedDoc | null, LoadedDoc | null] }) {
  const kinds = docs.map(d => (d ? d.kind.toUpperCase() : '—'));
  const mixed = docs[0] && docs[1] && !(docs[0].kind === 'pdf' && docs[1].kind === 'pdf');
  return (
    <div className="grid gap-8 bg-surface p-6 md:grid-cols-[minmax(0,1.1fr)_minmax(0,1fr)] md:p-10">
      <div>
        <h3 className="display-sm text-[30px] md:text-[34px]">Compare two PDFs directly.<span className="block italic text-accent">Get two review PDFs back.</span></h3>
        <p className="mt-4 max-w-xl text-[14px] leading-relaxed text-ink-300">
          Open an <b className="font-medium text-ink-100">original</b> and a <b className="font-medium text-ink-100">modified</b> PDF in the boxes above (drop them or use the button).
          The words are read together with their exact position on the page, compared, and then marked <i>on the real pages</i> — not on extracted text.
          You get a <b className="font-medium text-ink-100">side-by-side</b> PDF and an <b className="font-medium text-ink-100">overlay</b> PDF, each with an executive summary, a classified change log and bookmarks.
        </p>
        {mixed && <p className="mt-4 max-w-xl rounded-lg border border-mod/30 bg-mod-bg px-3.5 py-2.5 text-[12.5px] leading-relaxed text-mod">Currently loaded: original = {kinds[0]}, modified = {kinds[1]}. The PDF output needs a PDF on both sides — Word files can still be compared in the other views.</p>}
        <button onClick={onDemo} disabled={!!busy && !busy.startsWith('Demo failed')} className="btn btn-accent btn-lg mt-6">
          {busy && !busy.startsWith('Demo failed') ? busy : 'Try it with two generated PDFs'}
        </button>
        <p className="mt-2 text-[12px] text-faint">Typesets a 3-page contract twice — the second version re-flows its text, moves a clause, and changes a logo colour and a chart bar.</p>
      </div>
      <ul className="grid content-start gap-3 text-[13px] leading-relaxed text-ink-300">
        {[
          ['Original pages stay original', 'Pages are embedded as vector pages: text stays selectable and sharp at any zoom.'],
          ['Re-flow is not a change', 'Words are aligned across the whole document, so a different line wrap or an inserted paragraph does not mark everything after it.'],
          ['Images and graphics too', 'A pixel comparison finds changed pictures, charts and table rules that no text diff can see; scanned pages are compared as images.'],
          ['Everything stays in your browser', 'Nothing is uploaded. Large files are fine — a 22-page document takes a few seconds.'],
        ].map(([t, d]) => (
          <li key={t} className="rounded-xl border border-line bg-surface-2 p-3.5"><div className="font-medium text-ink-100">{t}</div><div className="mt-0.5 text-ink-400">{d}</div></li>
        ))}
      </ul>
    </div>
  );
}

function Btn({ children, on, ...p }: { children: ReactNode; on?: boolean } & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button {...p} className={'btn btn-sm ' + (on ? 'btn-primary' : 'btn-secondary')}>{children}</button>
  );
}

const baseName = (n: string) => n.replace(/\.[^.]+$/, '').replace(/[^\w.-]+/g, '_');

export default function PdfRedline({ docs, res, opts, geo, onDemo, demoBusy }: {
  docs: [LoadedDoc | null, LoadedDoc | null]; res: CompareResult | null; opts: CompareOptions; geo: boolean; onDemo: () => void; demoBusy: string;
}) {
  const [summary, setSummary] = useState(true);
  const [onlyChanged, setOnlyChanged] = useState(false);
  const [banners, setBanners] = useState(true);
  const [bars, setBars] = useState(true);
  const [graphics, setGraphics] = useState(true);
  const [quality, setQuality] = useState<Quality>('balanced');
  const [layout, setLayout] = useState<PdfLayout>('sidebyside');
  const [out, setOut] = useState<Outputs>({});
  const [busy, setBusy] = useState<{ label: string; frac: number } | null>(null);
  const [error, setError] = useState('');
  const run = useRef(0);
  const cache = useRef<{ res: CompareResult; key: string; v: (SlotVisual | null)[] } | null>(null);

  const [a, b] = docs;
  const ready = !!(a?.kind === 'pdf' && b?.kind === 'pdf' && a.bytes && b.bytes && a.raw && b.raw && a.pdf && b.pdf && geo && res);
  const totalPages = Math.max(a?.pages ?? 0, b?.pages ?? 0);
  const optKey = [summary, onlyChanged, banners, bars, graphics, quality].join('|');

  const generate = async (which: PdfLayout[]) => {
    if (!ready || !res || !a || !b) return;
    const id = ++run.current;
    const A: DocPdf = { name: a.name, bytes: a.bytes!, pages: a.pdf!, raw: a.raw! }, B: DocPdf = { name: b.name, bytes: b.bytes!, pages: b.pdf!, raw: b.raw! };
    const renderers: (PageRenderer | null)[] = [null, null];
    const getR = async (k: 0 | 1) => (renderers[k] ??= await openRenderer(k === 0 ? A.bytes : B.bytes));
    setError('');
    setBusy({ label: 'Preparing…', frac: 0 });
    try {
      const vkey = `${graphics}|${quality}`;
      let visuals = cache.current?.res === res && cache.current.key === vkey ? cache.current.v : null;
      if (!visuals) {
        visuals = await analyzeVisuals(res, A, B, async (d, p, s) => (await getR(d)).rgba(p, s),
          { enabled: graphics, dpi: QUALITY[quality], threshold: 16, antiAlias: true, maxShift: 2 },
          (done, total) => { if (run.current === id && total) setBusy({ label: `Comparing page images ${Math.min(done + 1, total)} of ${total}`, frac: 0.4 * (done / total) }); });
        cache.current = { res, key: vkey, v: visuals };
      }
      const next: Outputs = {};
      for (let i = 0; i < which.length; i++) {
        const lay = which[i];
        if (run.current !== id) return;
        const t0 = performance.now();
        const built = await buildComparisonPdf(res, A, B, visuals, {
          layout: lay, includeSummary: summary, onlyChangedPages: onlyChanged, banners, marginBars: bars, matchLabel: MATCH_MODES.find(m => m.id === opts.matchMode)?.label ?? opts.matchMode,
        }, { jpegA: async p => (await getR(0)).jpeg(p), jpegB: async p => (await getR(1)).jpeg(p) },
        (label, frac) => { if (run.current === id) setBusy({ label: `${lay === 'sidebyside' ? 'Side-by-side' : 'Overlay'}: ${label}`, frac: 0.4 + 0.6 * ((i + frac) / which.length) }); });
        next[lay] = { ...built, name: `${baseName(A.name)}_vs_${baseName(B.name)}_${lay === 'sidebyside' ? 'side-by-side' : 'overlay'}.pdf`, ms: performance.now() - t0 };
      }
      if (run.current === id) setOut(o => ({ ...o, ...next }));
    } catch (e) {
      if (run.current === id) setError(e instanceof Error ? e.message : String(e));
    } finally {
      renderers.forEach(r => r?.close());
      if (run.current === id) setBusy(null);
    }
  };
  const genRef = useRef(generate);
  genRef.current = generate;

  // Any change of input, comparison options or output options invalidates the PDFs; small documents rebuild automatically.
  useEffect(() => {
    run.current++;
    setOut({}); setBusy(null);
    if (!ready || totalPages > AUTO_MAX_PAGES) return;
    const t = setTimeout(() => void genRef.current(['sidebyside', 'overlay']), 350);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ready, res, optKey]);

  const cur = out[layout];
  const dl = (l: PdfLayout) => { const o = out[l]; if (o) download(o.name, o.bytes, 'application/pdf'); };
  const sizeKb = (n: number) => (n > 1048576 ? `${(n / 1048576).toFixed(1)} MB` : `${Math.round(n / 1024)} KB`);
  const stat = useMemo(() => cur?.stats, [cur]);

  if (!ready) return <Empty onDemo={onDemo} busy={demoBusy} docs={docs} />;

  return (
    <div className="bg-surface">
      {/* Controls */}
      <div className="grid gap-5 border-b border-ink-700 px-4 py-4 md:grid-cols-[minmax(0,1fr)_auto] md:px-6">
        <div>
          <div className="flex flex-wrap items-center gap-x-5 gap-y-2.5">
            <Check on={summary} set={setSummary} label="Executive summary + change log" />
            <Check on={banners} set={setBanners} label="Page banners" />
            <Check on={bars} set={setBars} label="Margin change bars" />
            <Check on={onlyChanged} set={setOnlyChanged} label="Only changed pages" />
            <Check on={graphics} set={setGraphics} label="Detect image / graphic changes" hint="Renders every page and compares the pixels; regions that text does not explain are framed in amber" />
            {graphics && (
              <label className="flex items-center gap-2 text-[12.5px] text-ink-300">
                Precision
                <select value={quality} onChange={e => setQuality(e.target.value as Quality)} className="field w-auto px-1.5 py-0.5 text-[12px]">
                  <option value="fast">Fast · 72 dpi</option><option value="balanced">Balanced · 110 dpi</option><option value="fine">Fine · 150 dpi</option>
                </select>
              </label>
            )}
          </div>
          <div className="mt-3"><Legend /></div>
        </div>
        <div className="flex flex-wrap items-start gap-2 md:justify-end">
          <button onClick={() => void generate(['sidebyside', 'overlay'])} disabled={!!busy}
            className="btn btn-accent">
            {busy ? 'Generating…' : out.sidebyside || out.overlay ? 'Regenerate both' : 'Generate both PDFs'}
          </button>
          <button onClick={() => { dl('sidebyside'); setTimeout(() => dl('overlay'), 450); }} disabled={!out.sidebyside || !out.overlay}
            className="btn btn-secondary">
            Download both ↓
          </button>
        </div>
      </div>

      {busy && (
        <div className="border-b border-ink-700 px-4 py-3 md:px-6" role="status">
          <div className="mb-1.5 flex justify-between font-mono text-[11px] text-ink-300"><span>{busy.label}</span><span>{Math.round(busy.frac * 100)}%</span></div>
          <div className="h-1.5 overflow-hidden rounded-full bg-line"><div className="h-full bg-accent transition-all" style={{ width: `${Math.max(3, busy.frac * 100)}%` }} /></div>
        </div>
      )}
      {error && <div className="border-b border-del/40 bg-del/10 px-6 py-3 text-[13px] text-del">Could not build the PDF: {error}</div>}
      {totalPages > AUTO_MAX_PAGES && !out.sidebyside && !busy && <div className="border-b border-ink-700 px-6 py-3 text-[12.5px] text-ink-400">{totalPages} pages — press “Generate both PDFs” (large documents are not built automatically).</div>}

      {/* Layout tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-ink-700 bg-ink-850 px-4 py-2.5 md:px-6">
        {LAYOUTS.map(l => <Btn key={l.id} on={layout === l.id} onClick={() => setLayout(l.id)}>{l.label}{out[l.id] ? '' : busy ? ' …' : ''}</Btn>)}
        {cur && (
          <button onClick={() => dl(layout)} className="btn btn-secondary btn-sm ml-auto">
            Download {layout === 'sidebyside' ? 'side-by-side' : 'overlay'} PDF ↓
          </button>
        )}
      </div>
      <p className="border-b border-ink-700 px-4 py-2.5 text-[12.5px] leading-relaxed text-ink-400 md:px-6">{LAYOUTS.find(l => l.id === layout)!.blurb}</p>

      {cur && stat && (
        <div className="flex flex-wrap gap-x-6 gap-y-1 border-b border-ink-700 px-4 py-2.5 font-mono text-[11px] text-ink-400 md:px-6">
          <span><b className="font-medium text-ink-100">{cur.pages}</b> pages · {sizeKb(cur.bytes.length)}</span>
          <span><b className="font-medium text-ink-100">{stat.changedSheets}</b> of {stat.sheets} sheets changed</span>
          <span className="text-del">−{stat.deleted} words</span>
          <span className="text-ins">+{stat.added} words</span>
          <span className="text-move">{stat.moved} moved</span>
          <span className="text-mod">{stat.visual} visual region{stat.visual === 1 ? '' : 's'}</span>
          <span>{cur.modeA === 'vector' && cur.modeB === 'vector' ? 'vector pages' : 'image fallback used'} · built in {(cur.ms / 1000).toFixed(1)} s</span>
        </div>
      )}
      {cur?.warnings.map((w, i) => <p key={i} className="border-b border-ink-700 px-4 py-2 text-[12px] leading-snug text-mod md:px-6">⚠ {w}</p>)}

      {cur ? <PdfPreview bytes={cur.bytes} /> : (
        <div className="viewer flex min-h-[14rem] items-center justify-center px-6 text-center text-[13px] text-muted">
          {busy ? 'Building the PDFs…' : 'Press “Generate both PDFs” to build them.'}
        </div>
      )}
    </div>
  );
}
