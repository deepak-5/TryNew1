import { useDeferredValue, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { compare, compareRaw, DEFAULT_OPTIONS, type CompareOptions, type Granularity } from '../engine/compare';
import { MATCH_MODES, type MatchMode } from '../engine/normalize';
import { SAMPLES } from '../samples';
import { RedlineView, SideBySideView, UnifiedView, OverlayView } from './Views';
import { ChangeLogView, AlignmentView, PageMapView, InsightsView, download } from './Panels';
import PdfRedline from './PdfRedline';
import HtmlDiffView from './HtmlDiffView';
import { makeDemoPdfs } from '../engine/demo';
import { loadDocument, type LoadedDoc } from '../engine/files';
import { textToPdf } from '../engine/pdf';
import { textToDocx, redlineDocx, DOCX_MIME } from '../engine/docx';
import { compareHtml, markdownToPureHtml } from '../engine/markdown';

/** Demo pair: the contract sample's original as a PDF and its revision as a Word file. */
function demoBytes(): { pdf: Uint8Array; docx: Uint8Array } {
  const [a, b] = SAMPLES[0].make();
  return { pdf: textToPdf(a), docx: textToDocx(b) };
}

type ExtractFormat = 'text' | 'html';
type ViewId = 'pdf' | 'html' | 'redline' | 'sbs' | 'unified' | 'overlay' | 'log' | 'align' | 'pages' | 'insights';

const VIEWS: { id: ViewId; label: string; hint: string }[] = [
  { id: 'pdf', label: 'PDF redline', hint: 'Direct PDF → PDF comparison: side-by-side and overlay PDFs' },
  { id: 'html', label: 'Formatted HTML', hint: 'Markdown → pure HTML comparison preserving headings, tables, lists and styles' },
  { id: 'redline', label: 'Redline', hint: 'Inline track changes' },
  { id: 'sbs', label: 'Side by side', hint: 'Synchronised rows' },
  { id: 'unified', label: 'Unified', hint: 'Patch-style −/+ lines' },
  { id: 'overlay', label: 'Overlay', hint: 'Modified text with deletion callouts' },
  { id: 'log', label: 'Change log', hint: 'Classified, filterable, exportable' },
  { id: 'align', label: 'Alignment map', hint: 'Matched runs and moves' },
  { id: 'pages', label: 'Page map', hint: 'Page pairing and heat strip' },
  { id: 'insights', label: 'Insights', hint: 'Statistics and engine internals' },
];
const DOC_VIEWS: ViewId[] = ['html', 'redline', 'sbs', 'unified', 'overlay'];

const V2_STYLE: Partial<CompareOptions> = { splitPunctuation: false, detectMoves: false, cleanup: 0, shiftBoundaries: false };

function Toggle({ on, onChange, label, hint }: { on: boolean; onChange: (v: boolean) => void; label: string; hint?: string }) {
  return (
    <button type="button" role="switch" aria-checked={on} onClick={() => onChange(!on)} title={hint} className="group flex items-center gap-2 text-left text-[12.5px] text-body transition-colors hover:text-ink">
      <span className={`relative h-4 w-7 flex-none rounded-full transition-colors ${on ? 'bg-signal' : 'bg-ink-600'}`}>
        <span className={`absolute top-0.5 h-3 w-3 rounded-full bg-white transition-all ${on ? 'left-3.5' : 'left-0.5'}`} />
      </span>
      {label}
    </button>
  );
}

function Segmented<T extends string | number>({ value, options, onChange }: { value: T; options: { v: T; label: string }[]; onChange: (v: T) => void }) {
  return (
    <div className="inline-flex rounded-md border border-ink-600 p-0.5">
      {options.map(o => (
        <button
          key={String(o.v)} type="button" onClick={() => onChange(o.v)}
          className={`rounded px-2.5 py-1 text-[12px] transition ${value === o.v ? 'bg-ink-100 text-surface' : 'text-ink-300 hover:text-ink'}`}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

function Group({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div>
      <div className="mb-2 font-mono text-[10px] uppercase tracking-[0.14em] text-ink-500">{title}</div>
      <div className="flex flex-col gap-2.5">{children}</div>
    </div>
  );
}

const KIND_LABEL = { pdf: 'PDF', docx: 'WORD', text: 'TEXT' } as const;

function Pane({ label, tone, value, doc, onChange, onLoaded }: {
  label: string; tone: string; value: string; doc: LoadedDoc | null;
  onChange: (v: string) => void; onLoaded: (d: LoadedDoc) => void;
}) {
  const file = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState('');
  const [error, setError] = useState('');
  const [drag, setDrag] = useState(false);
  const words = useMemo(() => (value.match(/\S+/g) ?? []).filter(w => !/^={3,}$/.test(w) && w !== 'PAGE').length, [value]);
  const load = async (f: File | undefined) => {
    if (!f) return;
    setError('');
    setBusy(`Reading ${f.name}…`);
    try { onLoaded(await loadDocument(f, setBusy)); }
    catch (e) { setError(e instanceof Error ? e.message : String(e)); }
    finally { setBusy(''); }
  };
  return (
    <div
      className="flex min-w-0 flex-col"
      onDragOver={e => { e.preventDefault(); setDrag(true); }}
      onDragLeave={e => { if (!e.currentTarget.contains(e.relatedTarget as Node | null)) setDrag(false); }}
      onDrop={e => { e.preventDefault(); setDrag(false); void load(e.dataTransfer.files?.[0]); }}
    >
      <div className="mb-1.5 flex items-center justify-between gap-2">
        <span className="flex items-center gap-2 text-[12px] font-medium text-ink-200"><i className={`h-2 w-2 rounded-full ${tone}`} />{label}</span>
        <span className="flex items-center gap-3 font-mono text-[10.5px] text-ink-500">
          {words.toLocaleString()} words
          <button type="button" disabled={!!busy} onClick={() => file.current?.click()}
            className="rounded border border-ink-600 px-2 py-0.5 text-ink-200 hover:border-signal hover:text-signal disabled:opacity-50">
            Open PDF / Word / text
          </button>
          <input ref={file} type="file" className="hidden"
            accept=".pdf,.docx,.docm,.txt,.md,.csv,.json,.xml,.html,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document,text/*"
            onChange={e => { void load(e.target.files?.[0]); e.target.value = ''; }} />
        </span>
      </div>
      {doc && (
        <div className="mb-1.5 flex min-w-0 items-center gap-2 rounded-md border border-ink-700 bg-ink-850 px-2.5 py-1.5 text-[11.5px]">
          <span className={`flex-none rounded px-1.5 py-px font-mono text-[10px] ${doc.kind === 'pdf' ? 'bg-del/20 text-del' : doc.kind === 'docx' ? 'bg-move/20 text-move' : 'bg-ink-700 text-ink-300'}`}>{KIND_LABEL[doc.kind]}</span>
          <span className="min-w-0 truncate text-ink-100" title={doc.name}>{doc.name}</span>
          <span className="ml-auto flex-none text-ink-500">{doc.details} · {doc.words.toLocaleString()} words</span>
        </div>
      )}
      <div className="relative">
        <textarea
          value={value} onChange={e => onChange(e.target.value)} spellCheck={false}
          placeholder={`Paste the ${label.toLowerCase()} text, or drop a PDF / Word file here…`}
          className="field scroll-ink h-44 w-full resize-y p-3 font-mono text-[12px] leading-relaxed placeholder:text-faint"
        />
        {(busy || drag) && (
          <div className="pointer-events-none absolute inset-0 flex items-center justify-center rounded-lg border-2 border-dashed border-signal bg-ink-950/85 px-4 text-center text-[12.5px] text-ink-100">
            {busy || 'Drop a PDF, Word (.docx) or text file'}
          </div>
        )}
      </div>
      {doc?.warnings.map((w, i) => <p key={i} className="mt-1.5 text-[11.5px] leading-snug text-mod">⚠ {w}</p>)}
      {error && <p className="mt-1.5 text-[11.5px] leading-snug text-del">✕ {error}</p>}
    </div>
  );
}

function Stat({ label, value, tone }: { label: string; value: ReactNode; tone?: string }) {
  return (
    <div className="metric !px-5 !py-4">
      <div className={`metric-value !text-[26px] ${tone ?? ''}`}>{value}</div>
      <div className="metric-label">{label}</div>
    </div>
  );
}

export default function Lab() {
  const [sample, setSample] = useState(SAMPLES[0].id);
  const [texts, setTexts] = useState<[string, string]>(() => SAMPLES[0].make());
  const [opts, setOpts] = useState<CompareOptions>(DEFAULT_OPTIONS);
  const [view, setView] = useState<ViewId>('redline');
  const [collapse, setCollapse] = useState(false);
  const [active, setActive] = useState(-1);
  const [showInputs, setShowInputs] = useState(true);
  const [advanced, setAdvanced] = useState(false);
  const [docs, setDocs] = useState<[LoadedDoc | null, LoadedDoc | null]>([null, null]);
  const [extractFormat, setExtractFormat] = useState<ExtractFormat>('text');
  const [demo, setDemo] = useState('');
  const paneRef = useRef<HTMLDivElement>(null);

  const docInputText = (d: LoadedDoc, fmt: ExtractFormat) => (fmt === 'html' ? (d.markdown ?? d.text) : d.text);

  const switchFormat = (fmt: ExtractFormat) => {
    setExtractFormat(fmt);
    setTexts(prev => [
      docs[0] ? docInputText(docs[0], fmt) : prev[0],
      docs[1] ? docInputText(docs[1], fmt) : prev[1],
    ]);
  };

  const runDemo = async () => {
    setDemo('Generating a PDF and a Word file…');
    try {
      const { pdf, docx } = demoBytes();
      const fa = new File([pdf as unknown as BlobPart], 'service-agreement-v1.pdf', { type: 'application/pdf' });
      const fb = new File([docx as unknown as BlobPart], 'service-agreement-v2.docx', { type: DOCX_MIME });
      const da = await loadDocument(fa, setDemo);
      const db = await loadDocument(fb, setDemo);
      setSample('');
      setDocs([da, db]);
      setTexts([docInputText(da, extractFormat), docInputText(db, extractFormat)]);
      setCollapse(false);
      setShowInputs(true);
      setDemo('');
    } catch (e) {
      setDemo('Demo failed: ' + (e instanceof Error ? e.message : String(e)));
    }
  };
  const runPdfDemo = async () => {
    setDemo('Typesetting two PDFs…');
    try {
      const { v1, v2 } = await makeDemoPdfs();
      const da = await loadDocument(new File([v1 as unknown as BlobPart], 'service-agreement-v1.pdf', { type: 'application/pdf' }), setDemo);
      const db = await loadDocument(new File([v2 as unknown as BlobPart], 'service-agreement-v2.pdf', { type: 'application/pdf' }), setDemo);
      setSample('');
      setDocs([da, db]);
      setTexts([docInputText(da, extractFormat), docInputText(db, extractFormat)]);
      setCollapse(false);
      setShowInputs(true);
      setDemo('');
      setView('pdf');
    } catch (e) {
      setDemo('Demo failed: ' + (e instanceof Error ? e.message : String(e)));
    }
  };
  const downloadDemo = async () => {
    const { v1, v2 } = await makeDemoPdfs();
    download('service-agreement-v1.pdf', v1, 'application/pdf');
    setTimeout(() => download('service-agreement-v2.pdf', v2, 'application/pdf'), 400);
    setTimeout(() => download('service-agreement-v2.docx', demoBytes().docx, DOCX_MIME), 800);
  };

  const dA = useDeferredValue(texts[0]), dB = useDeferredValue(texts[1]);
  const bothPdf = !!(docs[0]?.kind === 'pdf' && docs[1]?.kind === 'pdf');

  // Direct PDF → PDF comparison always uses exact word geometry, independent of text-extraction format.
  const pdfGeo = !!(bothPdf && docs[0]!.raw && docs[1]!.raw);
  const pdfGeoRes = useMemo(() => {
    if (!pdfGeo) return null;
    try { return compareRaw(docs[0]!.raw!, docs[1]!.raw!, opts); }
    catch { return null; }
  }, [pdfGeo, docs, opts]);

  // Markdown → Pure HTML comparison (active when extractFormat === 'html' or when viewing the Formatted HTML tab).
  const mdA = extractFormat === 'html' ? dA : (docs[0]?.markdown && dA === docs[0].text ? docs[0].markdown : dA);
  const mdB = extractFormat === 'html' ? dB : (docs[1]?.markdown && dB === docs[1].text ? docs[1].markdown : dB);
  const useHtmlPipeline = extractFormat === 'html' || view === 'html';

  const htmlBundle = useMemo(() => {
    if (!useHtmlPipeline) return null;
    try {
      const htmlA = markdownToPureHtml(mdA);
      const htmlB = markdownToPureHtml(mdB);
      const diff = compareHtml(htmlA, htmlB, opts);
      return { mdA, mdB, htmlA, htmlB, diff, error: '' };
    } catch (e) {
      return { mdA, mdB, htmlA: '', htmlB: '', diff: null, error: e instanceof Error ? e.message : String(e) };
    }
  }, [useHtmlPipeline, mdA, mdB, opts]);

  // Unedited PDFs in plain-text mode use their geometry-aware RawDoc; Markdown→HTML uses HTML-block comparison; else plain text.
  const geo = !!(pdfGeo && extractFormat === 'text' && docs[0]!.text === dA && docs[1]!.text === dB);
  const { res, error } = useMemo(() => {
    if (htmlBundle) {
      return { res: htmlBundle.diff?.res ?? null, error: htmlBundle.error };
    }
    try { return { res: geo && pdfGeoRes ? pdfGeoRes : compare(dA, dB, opts), error: '' }; }
    catch (e) { return { res: null, error: e instanceof Error ? e.message : String(e) }; }
  }, [htmlBundle, geo, pdfGeoRes, dA, dB, opts]);
  const wasBoth = useRef(false);
  useEffect(() => { if (bothPdf && !wasBoth.current) setView('pdf'); wasBoth.current = bothPdf; }, [bothPdf]);

  useEffect(() => setActive(-1), [res]);

  // Bring the active change into view inside the result pane (never scrolls the page itself).
  useEffect(() => {
    const pane = paneRef.current;
    if (active < 0 || !pane) return;
    const el = pane.querySelector<HTMLElement>(`[data-ch="${active}"]`);
    if (!el) return;
    const er = el.getBoundingClientRect(), pr = pane.getBoundingClientRect();
    pane.scrollTo({ top: pane.scrollTop + er.top - pr.top - pane.clientHeight / 2 + er.height / 2, behavior: 'smooth' });
  }, [active, view]);

  const set = <K extends keyof CompareOptions>(k: K, v: CompareOptions[K]) => setOpts(o => ({ ...o, [k]: v }));
  const loadSample = (id: string) => {
    const s = SAMPLES.find(x => x.id === id)!;
    setSample(id);
    setDocs([null, null]);
    setTexts(s.make());
    setCollapse(id === 'stress' || id === 'page');
  };
  const step = (dir: 1 | -1) => {
    const n = res?.changes.length ?? 0;
    if (!n) return;
    setActive(a => (a < 0 ? (dir > 0 ? 0 : n - 1) : (a + dir + n) % n));
  };
  const locate = (id: number) => { setView('redline'); setActive(id); };
  const pick = (id: number) => setActive(a => (a === id ? -1 : id));

  const current = SAMPLES.find(s => s.id === sample);
  const isV2 = !opts.splitPunctuation && !opts.detectMoves && opts.cleanup === 0 && !opts.shiftBoundaries;
  const s = res?.stats;
  const activeChange = res && active >= 0 ? res.changes[active] : undefined;

  return (
    <div className="panel panel-raised overflow-hidden">
      {/* Samples */}
      <div className="border-b border-ink-700 px-4 py-4 md:px-6">
        <div className="flex flex-wrap items-center gap-2">
          <span className="mono-label mr-1">Start from</span>
          {SAMPLES.map(x => (
            <button
              key={x.id} onClick={() => loadSample(x.id)}
              className={`rounded-full border px-3 py-1 text-[12.5px] transition ${sample === x.id ? 'border-accent bg-accent-soft text-accent' : 'border-ink-600 text-ink-300 hover:border-ink-400 hover:text-ink'}`}
            >
              {x.label}
            </button>
          ))}
          <span className="mx-1 hidden h-5 w-px bg-line sm:block" />
          <button onClick={() => void runPdfDemo()} disabled={!!demo && !demo.startsWith('Demo failed')}
            className={`rounded-full border px-3 py-1 text-[12.5px] transition disabled:opacity-60 ${bothPdf && docs[0]?.name.startsWith('service-agreement') && !sample ? 'border-accent bg-accent-soft text-accent' : 'border-ink-600 text-ink-300 hover:border-ink-400 hover:text-ink'}`}
            title="Typesets two real PDFs (the second re-flows its text and changes a logo and a chart) and builds the side-by-side and overlay review PDFs">
            PDF ↔ PDF demo
          </button>
          <button onClick={() => void runDemo()} disabled={!!demo && !demo.startsWith('Demo failed')}
            className={`rounded-full border px-3 py-1 text-[12.5px] transition disabled:opacity-60 ${docs[0]?.kind === 'pdf' && docs[1]?.kind === 'docx' && !sample ? 'border-accent bg-accent-soft text-accent' : 'border-ink-600 text-ink-300 hover:border-ink-400 hover:text-ink'}`}
            title="Generates a real PDF and a real .docx from the contract sample and runs them through the file readers">
            PDF ↔ Word demo
          </button>
          <button onClick={() => void downloadDemo()} className="text-[12px] text-ink-500 underline-offset-4 hover:text-ink-200 hover:underline" title="Download the demo files (two PDFs and a Word file) to try them yourself">
            get demo files
          </button>
          <button onClick={() => setShowInputs(v => !v)} className="ml-auto text-[12px] text-ink-400 underline-offset-4 hover:text-ink hover:underline">
            {showInputs ? 'Hide inputs' : 'Edit inputs'}
          </button>
        </div>
        {demo && <p className={`mt-2 text-[12.5px] ${demo.startsWith('Demo failed') ? 'text-del' : 'text-signal'}`}>{demo}</p>}
        {!sample && docs[0]?.kind === 'pdf' && docs[1]?.kind === 'docx' && docs[0].name.startsWith('service-agreement') && (
          <p className="mt-2.5 max-w-4xl text-[13px] leading-relaxed text-ink-400">
            Original = a generated <b className="font-medium text-ink-200">PDF</b> (read with pdf.js), modified = a generated <b className="font-medium text-ink-200">Word document</b> (read from its XML).
            Different formats, different line wrapping — the comparison still finds exactly the content changes. Try “Word redline” below to get the result back as tracked changes.
          </p>
        )}
        {current && <p className="mt-2.5 max-w-4xl text-[13px] leading-relaxed text-ink-400">{current.blurb}</p>}
        {showInputs && (
          <>
            <div className="mt-4 grid gap-4 lg:grid-cols-2">
              <Pane label="Original" tone="bg-del" value={texts[0]} doc={docs[0]}
                onLoaded={d => { setSample(''); setDocs(x => [d, x[1]]); setTexts(t => [docInputText(d, extractFormat), t[1]]); }}
                onChange={v => { setSample(''); setDocs(x => [null, x[1]]); setTexts(t => [v, t[1]]); }} />
              <Pane label="Modified" tone="bg-ins" value={texts[1]} doc={docs[1]}
                onLoaded={d => { setSample(''); setDocs(x => [x[0], d]); setTexts(t => [t[0], docInputText(d, extractFormat)]); }}
                onChange={v => { setSample(''); setDocs(x => [x[0], null]); setTexts(t => [t[0], v]); }} />
            </div>
            <div className="mt-3 flex flex-wrap items-center gap-3 rounded-xl border border-line bg-surface-2 px-3 py-2.5">
              <span className="font-mono text-[10px] uppercase tracking-[0.14em] text-ink-400">Text comparison format</span>
              <Segmented<ExtractFormat>
                value={extractFormat}
                onChange={switchFormat}
                options={[{ v: 'text', label: 'Plain text' }, { v: 'html', label: 'Markdown → Pure HTML' }]}
              />
              <span className="text-[12px] text-ink-400">
                {extractFormat === 'html'
                  ? 'PDF / Word layout extracted as Markdown (headings, bold/italic, lists, tables) → formatted to pure HTML before comparing. Direct PDF-to-PDF output is unchanged.'
                  : 'Switch to “Markdown → Pure HTML” to preserve headings, lists, bold/italic and tables when comparing extracted PDF text.'}
              </span>
            </div>
            <p className="mt-2 font-mono text-[10.5px] leading-relaxed text-ink-500">
              Drop or open <span className="text-ink-300">PDF</span>, <span className="text-ink-300">Word (.docx)</span> or text files — any combination, e.g. a PDF against a Word file.
              Files are read in this tab; nothing is uploaded. The extracted content appears in the box, so you can check or edit what is compared.
              In pasted text, separate pages with <span className="text-ink-300">=== PAGE ===</span>.
            </p>
          </>
        )}
      </div>

      {/* Options */}
      <div className="grid gap-6 border-b border-ink-700 px-4 py-5 sm:grid-cols-2 md:px-6 lg:grid-cols-4">
        <Group title="Matching">
          <select
            value={opts.matchMode} onChange={e => set('matchMode', e.target.value as MatchMode)}
            className="field w-full px-2.5 py-1.5 text-[12.5px]"
          >
            {MATCH_MODES.map(m => <option key={m.id} value={m.id}>{m.label}</option>)}
          </select>
          <p className="text-[11.5px] leading-snug text-ink-500">{MATCH_MODES.find(m => m.id === opts.matchMode)?.hint}</p>
        </Group>
        <Group title="Granularity">
          <Segmented<Granularity> value={opts.granularity} onChange={v => set('granularity', v)}
            options={[{ v: 'word', label: 'Word' }, { v: 'sentence', label: 'Sentence' }, { v: 'line', label: 'Line' }]} />
          <Toggle on={opts.splitPunctuation} onChange={v => set('splitPunctuation', v)} label="Punctuation as own tokens" hint="“agreement,” → “agreement.” flags only the comma" />
          <Toggle on={opts.dehyphenate} onChange={v => set('dehyphenate', v)} label="Resolve line-break hyphens" hint="Vocabulary-aware: keeps the hyphen in real compounds" />
        </Group>
        <Group title="Document structure">
          <Toggle on={opts.alignAcrossPages} onChange={v => set('alignAcrossPages', v)} label="Align across pages" hint="One word stream for the whole document + content-based page pairing" />
          <Toggle on={opts.ignoreHeadersFooters} onChange={v => set('ignoreHeadersFooters', v)} label="Ignore running headers / footers" />
          <Toggle on={opts.detectMoves} onChange={v => set('detectMoves', v)} label="Detect moved text" />
          <label className="flex items-center gap-2 text-[12.5px] text-ink-300">
            Min. move length
            <input type="number" min={2} max={50} value={opts.minMoveLength} disabled={!opts.detectMoves}
              onChange={e => set('minMoveLength', Math.max(2, Math.min(50, Number(e.target.value) || 2)))}
              className="field w-14 px-1.5 py-0.5 text-center font-mono text-[12px] disabled:opacity-40" />
          </label>
        </Group>
        <Group title="Refinement">
          <div className="flex items-center gap-2">
            <Segmented<number> value={opts.cleanup} onChange={v => set('cleanup', v)}
              options={[{ v: 0, label: 'Off' }, { v: 1, label: 'Conservative' }, { v: 2, label: 'Aggressive' }]} />
          </div>
          <p className="-mt-1 text-[11.5px] leading-snug text-ink-500">Semantic cleanup: absorb stray matches between two edits.</p>
          <Toggle on={opts.shiftBoundaries} onChange={v => set('shiftBoundaries', v)} label="Snap changes to sentence boundaries" />
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[12px]">
            <button onClick={() => setOpts(o => ({ ...o, ...(isV2 ? { splitPunctuation: true, detectMoves: true, cleanup: 1, shiftBoundaries: true } : V2_STYLE) }))}
              className="btn btn-secondary btn-sm"
              title="Switch the v3 refinements off / on to compare the results">
              {isV2 ? 'Back to v3 defaults' : 'Compare with v2-style output'}
            </button>
            <button onClick={() => setAdvanced(v => !v)} className="text-ink-500 underline-offset-4 hover:text-ink-200 hover:underline">{advanced ? 'Hide engine' : 'Engine'}</button>
          </div>
        </Group>
        {advanced && (
          <div className="flex flex-wrap items-center gap-x-6 gap-y-3 rounded-lg border border-dashed border-ink-700 p-3 sm:col-span-2 lg:col-span-4">
            <span className="font-mono text-[10px] uppercase tracking-[0.14em] text-ink-500">Engine</span>
            <Toggle on={opts.phraseAnchors} onChange={v => set('phraseAnchors', v)} label="Maximal phrase anchors" />
            <Toggle on={opts.tokenAnchors} onChange={v => set('tokenAnchors', v)} label="Patience anchors" />
            <label className="flex items-center gap-2 text-[12.5px] text-ink-300">
              Max cost per bisection
              <input type="number" min={2} max={10000} value={opts.maxCost}
                onChange={e => set('maxCost', Math.max(2, Math.min(10000, Number(e.target.value) || 2)))}
                className="field w-20 px-1.5 py-0.5 text-center font-mono text-[12px]" />
            </label>
            <span className="text-[11.5px] text-ink-500">Set max cost to 5 and both anchors off: the diff stays valid and fine-grained instead of collapsing to “everything replaced”.</span>
          </div>
        )}
      </div>

      {error && <div className="border-b border-del/40 bg-del/10 px-6 py-3 text-sm text-del">Comparison failed: {error}</div>}

      {/* Stats */}
      {s && (
        <div className="metrics border-b border-line">
          <Stat label="Similarity" value={<>{(s.similarity * 100).toFixed(1)}<span className="ml-0.5 text-[14px] font-normal text-faint">%</span></>} />
          <Stat label="Changes" value={res!.changes.length} />
          <Stat label="Added" value={`+${s.inserted}`} tone="text-ins" />
          <Stat label="Deleted" value={`−${s.deleted}`} tone="text-del" />
          <Stat label="Moved blocks" value={res!.moves.length} tone="text-move" />
          <Stat label="Critical" value={s.byRisk.critical ?? 0} tone={(s.byRisk.critical ?? 0) > 0 ? 'text-signal' : undefined} />
          <Stat label="Engine time" value={<>{s.msTotal < 10 ? s.msTotal.toFixed(1) : Math.round(s.msTotal)}<span className="ml-0.5 text-[14px] font-normal text-faint"> ms</span></>} />
        </div>
      )}

      {/* View tabs */}
      <div className="flex flex-wrap items-center gap-x-1 gap-y-2 border-b border-ink-700 bg-ink-850 px-3 py-2 md:px-4">
        <div className="scroll-ink flex min-w-0 flex-1 gap-1 overflow-x-auto">
          {VIEWS.map(v => (
            <button
              key={v.id} onClick={() => setView(v.id)} title={v.hint}
              className={`flex-none rounded-md px-3 py-1.5 text-[12.5px] transition ${view === v.id ? 'bg-ink-100 font-medium text-surface' : 'text-ink-300 hover:bg-ink-700 hover:text-ink'}`}
            >
              {v.label}
            </button>
          ))}
        </div>
        <div className="flex flex-none items-center gap-2 pl-2">
          {DOC_VIEWS.includes(view) && view !== 'html' && <Toggle on={collapse} onChange={setCollapse} label="Only changes" />}
          <button
            disabled={!res}
            onClick={() => res && download('docuzen-redline.docx',
              redlineDocx(res.items, `Redline: ${docs[0]?.name ?? 'Original'} → ${docs[1]?.name ?? 'Modified'}`), DOCX_MIME)}
            className="rounded-md border border-ink-600 px-2.5 py-1 text-[12px] text-ink-200 transition hover:border-move hover:text-move disabled:opacity-40"
            title="Download a .docx with native Word tracked changes (Review → Accept / Reject)"
          >
            Word redline ↓
          </button>
          {view !== 'pdf' && (
          <div className="flex items-center rounded-md border border-ink-600">
            <button onClick={() => step(-1)} className="px-2 py-1 text-ink-300 hover:text-ink" aria-label="Previous change">↑</button>
            <span className="min-w-[4.5rem] border-x border-ink-600 px-2 py-1 text-center font-mono text-[11px] text-ink-300">
              {res?.changes.length ? `${active >= 0 ? active + 1 : '–'} / ${res.changes.length}` : '0'}
            </span>
            <button onClick={() => step(1)} className="px-2 py-1 text-ink-300 hover:text-ink" aria-label="Next change">↓</button>
          </div>
          )}
        </div>
      </div>

      {activeChange && DOC_VIEWS.includes(view) && (
        <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1 border-b border-ink-700 bg-ink-800 px-4 py-2 text-[12.5px] md:px-6">
          <span className="font-mono text-[11px] text-signal">#{activeChange.id + 1}</span>
          <span className="capitalize text-ink-100">{activeChange.type}</span>
          <span className="text-ink-400">priority {activeChange.risk}</span>
          {activeChange.type === 'move'
            ? <span className="text-move">page {activeChange.pageA + 1} → page {activeChange.pageB + 1}</span>
            : <>
                {activeChange.delText && <span className="max-w-[28rem] truncate text-del line-through">{activeChange.delText}</span>}
                {activeChange.insText && <span className="max-w-[28rem] truncate text-ins">{activeChange.insText}</span>}
              </>}
          {activeChange.note && <span className="font-mono text-[11px] text-mod">{activeChange.note}</span>}
        </div>
      )}

      {/* Result */}
      {view === 'pdf' ? (
        <PdfRedline docs={docs} res={pdfGeoRes} opts={opts} geo={pdfGeo} onDemo={() => void runPdfDemo()} demoBusy={demo} />
      ) : (
      <div ref={paneRef} className="scroll-ink max-h-[72vh] min-h-[16rem] overflow-auto">
        {view === 'html' && htmlBundle?.diff && (
          <HtmlDiffView
            diff={htmlBundle.diff}
            mdA={htmlBundle.mdA}
            mdB={htmlBundle.mdB}
            htmlA={htmlBundle.htmlA}
            htmlB={htmlBundle.htmlB}
            titleA={docs[0]?.name ?? 'Original'}
            titleB={docs[1]?.name ?? 'Modified'}
            active={active}
            onPick={pick}
          />
        )}
        {res && view === 'redline' && <RedlineView res={res} active={active} onPick={pick} collapse={collapse} />}
        {res && view === 'sbs' && <SideBySideView res={res} active={active} onPick={pick} collapse={collapse} />}
        {res && view === 'unified' && <UnifiedView res={res} active={active} onPick={pick} collapse={collapse} />}
        {res && view === 'overlay' && <OverlayView res={res} active={active} onPick={pick} collapse={collapse} />}
        {res && view === 'log' && <ChangeLogView res={res} active={active} onPick={pick} onLocate={locate} />}
        {res && view === 'align' && <AlignmentView res={res} active={active} onPick={pick} onLocate={locate} />}
        {res && view === 'pages' && <PageMapView res={res} onLocate={locate} />}
        {res && view === 'insights' && <InsightsView res={res} />}
      </div>
      )}

      {view !== 'pdf' && (
      <div className="flex flex-wrap items-center gap-x-5 gap-y-1 border-t border-ink-700 bg-ink-850 px-4 py-2.5 font-mono text-[10.5px] text-ink-400 md:px-6">
        <span><span className="tk tk-ins !cursor-default font-sans">added</span></span>
        <span><span className="tk tk-del !cursor-default font-sans">deleted</span></span>
        <span><span className="tk tk-mvto !cursor-default font-sans">moved here</span></span>
        <span><span className="tk tk-mvfrom !cursor-default font-sans">moved from</span></span>
        <span className="ml-auto hidden sm:inline">click any mark to select it · ↑ ↓ steps through changes</span>
      </div>
      )}
    </div>
  );
}
