import { useEffect, useState, type ReactNode } from 'react';
import { runSelfTest, type SelfTestReport } from '../engine/selftest';

// ── Small primitives ─────────────────────────────────────────────────────────

function Logo() {
  return (
    <span className="flex items-center gap-2.5">
      <svg width="25" height="25" viewBox="0 0 26 26" fill="none" aria-hidden="true">
        <rect x="2.4" y="2.4" width="13" height="19.2" rx="2.6" stroke="var(--ink)" strokeWidth="1.4" />
        <rect x="10.6" y="6.4" width="13" height="17.2" rx="2.6" fill="var(--surface)" stroke="var(--line-strong)" strokeWidth="1.4" />
        <path d="M14.2 11.2h5.8M14.2 14.8h5.8M14.2 18.4h3.8" stroke="var(--accent)" strokeWidth="1.4" strokeLinecap="round" />
      </svg>
      <span className="text-[15px] font-semibold tracking-[-0.025em] text-ink">Docuzen</span>
      <span className="hidden rounded-[4px] border border-line bg-surface-2 px-[5px] py-[1px] font-mono text-[9px] uppercase tracking-[0.1em] text-faint sm:inline">
        Compare
      </span>
    </span>
  );
}

function Arrow({ className = '' }: { className?: string }) {
  return (
    <svg width="13" height="13" viewBox="0 0 14 14" fill="none" aria-hidden="true" className={className}>
      <path d="M3 11 11 3M4.5 3H11v6.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function Check({ tone = 'ins' }: { tone?: 'ins' | 'mod' | 'muted' }) {
  const color = tone === 'ins' ? 'var(--ins)' : tone === 'mod' ? 'var(--mod)' : 'var(--faint)';
  return (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" aria-hidden="true" className="mt-[3px] flex-none">
      <circle cx="8" cy="8" r="7" stroke={color} strokeOpacity="0.35" />
      {tone === 'mod'
        ? <path d="M8 4.6v4.2M8 11.2v.2" stroke={color} strokeWidth="1.5" strokeLinecap="round" />
        : <path d="M4.8 8.2l2.1 2.1 4.3-4.4" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />}
    </svg>
  );
}

function SunIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <circle cx="10" cy="10" r="3.6" stroke="currentColor" strokeWidth="1.5" />
      <path d="M10 2v1.6M10 16.4V18M2 10h1.6M16.4 10H18M4.3 4.3l1.1 1.1M14.6 14.6l1.1 1.1M15.7 4.3l-1.1 1.1M5.4 14.6l-1.1 1.1" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  );
}
function MoonIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <path d="M16.2 12.1A6.8 6.8 0 0 1 7.9 3.8 7 7 0 1 0 16.2 12.1Z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" />
    </svg>
  );
}

type Theme = 'light' | 'dark';

function ThemeToggle() {
  const [theme, setTheme] = useState<Theme>('light');
  useEffect(() => {
    const t = document.documentElement.dataset.theme;
    setTheme(t === 'dark' ? 'dark' : 'light');
  }, []);
  const apply = (t: Theme) => {
    setTheme(t);
    document.documentElement.dataset.theme = t;
    try { localStorage.setItem('docuzen-theme', t); } catch { /* private mode */ }
  };
  const next: Theme = theme === 'light' ? 'dark' : 'light';
  return (
    <button
      type="button"
      onClick={() => apply(next)}
      className="icon-btn"
      aria-label={`Switch to ${next} theme`}
      title={`Switch to ${next} theme`}
    >
      {theme === 'light' ? <MoonIcon /> : <SunIcon />}
    </button>
  );
}

// ── Navigation ───────────────────────────────────────────────────────────────

export function Nav() {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const on = () => setScrolled(window.scrollY > 620);
    on();
    window.addEventListener('scroll', on, { passive: true });
    return () => window.removeEventListener('scroll', on);
  }, []);
  const links: [string, string][] = [
    ['The lab', '#lab'],
    ['The engine', '#findings'],
    ['Review modes', '#modes'],
    ['C# source', '#source'],
  ];
  return (
    <header className="nav">
      <div className="shell flex h-[60px] items-center gap-8">
        <a href="#top" aria-label="Docuzen Compare home" className="flex-none">
          <Logo />
        </a>
        <nav className="hidden items-center gap-7 lg:flex" aria-label="Sections">
          {links.map(([label, href]) => <a key={href} href={href} className="nav-link">{label}</a>)}
        </nav>
        <div className="ml-auto flex items-center gap-1.5">
          <a href="#verify" className="nav-link mr-2 hidden md:inline">Verification</a>
          <ThemeToggle />
          <a href="#lab" className="btn btn-primary btn-sm ml-1">
            Open the lab <Arrow />
          </a>
        </div>
      </div>
      <div className={`overflow-hidden border-t border-line bg-surface-2 transition-[max-height,opacity] duration-300 ${scrolled ? 'max-h-12 opacity-100' : 'max-h-0 opacity-0'}`} aria-hidden={!scrolled}>
        <div className="shell flex h-10 items-center gap-3 text-[11.5px]">
          <span className="flex items-center gap-1.5 font-medium text-ink"><span className="h-1.5 w-1.5 rounded-full bg-ins" />Comparison engine ready</span>
          <span className="h-3 w-px bg-line" />
          <span className="hidden text-muted sm:inline">PDF · Word · Markdown · runs locally</span>
          <div className="ml-auto flex items-center gap-2">
            <a href="#lab" className="text-muted hover:text-ink">Open a comparison</a>
            <a href="#source" className="btn btn-secondary btn-sm !h-7">Get the C#</a>
          </div>
        </div>
      </div>
    </header>
  );
}

// ── Hero ─────────────────────────────────────────────────────────────────────

function ProductPreview() {
  const stat = (value: string, label: string, tone?: string) => (
    <div className="min-w-0">
      <div className={`text-[15px] font-medium tracking-[-0.02em] tabular-nums ${tone ?? 'text-ink'}`}>{value}</div>
      <div className="mt-0.5 font-mono text-[8.5px] uppercase tracking-[0.1em] text-faint">{label}</div>
    </div>
  );
  return (
    <div className="preview rise rise-3">
      <div className="preview-bar">
        <span className="flex items-center gap-1.5 font-mono text-[10px] text-muted">
          <span className="flex h-5 w-5 items-center justify-center rounded-[4px] bg-del-bg font-sans text-[8px] font-semibold text-del">PDF</span>
          v1
        </span>
        <span className="text-faint">→</span>
        <span className="flex items-center gap-1.5 font-mono text-[10px] text-muted">
          <span className="flex h-5 w-5 items-center justify-center rounded-[4px] bg-ins-bg font-sans text-[8px] font-semibold text-ins">PDF</span>
          v2
        </span>
        <span className="ml-auto hidden items-center gap-1.5 sm:flex">
          <span className="tag tag-accent">12 changes</span>
        </span>
        <span className="seg ml-2 hidden md:inline-flex">
          <span className="seg-item is-on">Side-by-side</span>
          <span className="seg-item">Overlay</span>
        </span>
      </div>

      <div className="grid grid-cols-2 gap-px bg-line">
        {[
          { label: 'Original', tone: 'text-del', body: (
            <>
              <p className="mb-1 text-[8px] font-semibold uppercase tracking-[0.12em] text-[#8a8373]">2 · Fees and payment</p>
              <p className="text-[11px] leading-[1.65]">
                The Customer <span className="tk tk-ins !cursor-default">shall</span> pay the annual fee of{' '}
                <span className="tk tk-del !cursor-default">$25,000</span> within <span className="tk tk-del !cursor-default">30</span> days of the date of
                each invoice. Late payments accrue interest at 1.5% per month.
              </p>
              <div className="mt-2 flex gap-[3px]">
                {[38, 62, 74, 58, 70, 46].map((h, i) => <span key={i} className="w-[7px] rounded-[1px] bg-[#1c3358]" style={{ height: h / 4 }} />)}
              </div>
            </>
          ) },
          { label: 'Modified', tone: 'text-ins', body: (
            <>
              <p className="mb-1 text-[8px] font-semibold uppercase tracking-[0.12em] text-[#8a8373]">2 · Fees and payment</p>
              <p className="text-[11px] leading-[1.65]">
                The Customer <span className="tk tk-ins !cursor-default">may</span> pay the annual fee of{' '}
                <span className="tk tk-ins !cursor-default">$52,000</span> within <span className="tk tk-ins !cursor-default">45</span> days of the date of
                each invoice. Late payments accrue interest at 1.5% per month.
              </p>
              <div className="mt-2 flex gap-[3px]">
                {[38, 62, 30, 58, 70, 46].map((h, i) => <span key={i} className={`w-[7px] rounded-[1px] ${i === 2 ? 'bg-[#e08a2e]' : 'bg-[#0b6f47]'}`} style={{ height: h / 4 }} />)}
              </div>
            </>
          ) },
        ].map(col => (
          <div key={col.label} className="preview-page min-w-0 p-3.5">
            <div className="mb-2 flex items-center justify-between border-b border-[#eee8db] pb-1.5">
              <span className="font-sans text-[9px] font-semibold uppercase tracking-[0.12em] text-[#6d685d]">{col.label}</span>
              <span className="h-1 w-1 rounded-full bg-[#d7d1c2]" />
            </div>
            <div className="mb-2 font-mono text-[7.5px] uppercase tracking-[0.12em] text-[#9a9486]">Service agreement · p.1</div>
            {col.body}
          </div>
        ))}
      </div>

      <div className="flex flex-wrap items-center gap-x-6 gap-y-2 border-t border-line bg-surface-2 px-3.5 py-2.5">
        {stat('84.8%', 'Similarity')}
        {stat('+27,000', 'Fee change', 'text-del')}
        {stat('2', 'Visual regions', 'text-mod')}
        <div className="ml-auto flex min-w-0 items-center gap-2">
          <span className="truncate font-mono text-[9px] text-faint">…_v1_vs_v2_side-by-side.pdf</span>
          <span className="flex h-6 w-6 items-center justify-center rounded-[5px] border border-line bg-surface text-muted">
            <Arrow className="rotate-90" />
          </span>
        </div>
      </div>
    </div>
  );
}

export function Hero() {
  const proof: [string, string][] = [
    ['PDF ↔ PDF', 'vector-perfect'], ['Word ↔ Word', 'native OOXML'], ['PDF ↔ Word', 'cross-format'], ['Markdown → HTML', 'formatted'],
  ];
  return (
    <section id="top" className="hero">
      <div className="shell relative grid items-center gap-12 py-12 md:py-16 lg:py-[4.5rem] lg:grid-cols-[minmax(0,1.04fr)_minmax(0,0.96fr)] lg:gap-16">
        <div className="min-w-0">
          <p className="eyebrow rise">Document comparison studio</p>
          <h1 className="display rise rise-2 mt-5 text-[42px] sm:text-[50px] lg:text-[56px] xl:text-[60px]">
            Every change.<br />
            <em>In its place.</em>
          </h1>
          <p className="lede rise rise-3 mt-6 max-w-[54ch]">
            Compare PDFs and Word documents down to the word, then review them the way you actually work — a
            side-by-side PDF, a clean overlay, or a formatted HTML redline. Original pages stay vector-sharp.
            Nothing leaves your browser.
          </p>
          <div className="rise rise-3 mt-8 flex flex-wrap items-center gap-2.5">
            <a href="#lab" className="btn btn-primary btn-lg">Compare documents <Arrow /></a>
            <a href="#modes" className="btn btn-secondary btn-lg">Explore review modes</a>
          </div>
          <div className="rise rise-4 mt-8 flex flex-wrap gap-x-5 gap-y-2">
            {proof.map(([a, b]) => (
              <span key={a} className="inline-flex items-baseline whitespace-nowrap text-[11.5px]">
                <span className="font-medium text-ink">{a}</span>
                <span className="ml-1.5 text-faint">{b}</span>
              </span>
            ))}
          </div>
          <div className="rise rise-4 mt-6 flex flex-wrap items-center gap-x-5 gap-y-2 border-t border-line pt-5 text-[11.5px] text-faint">
            <span className="inline-flex items-center gap-1.5"><Check /> No upload · runs locally</span>
            <span className="inline-flex items-center gap-1.5"><Check /> No account required</span>
            <span className="inline-flex items-center gap-1.5"><Check /> C# source included</span>
          </div>
        </div>
        <div className="rise rise-2 min-w-0">
          <ProductPreview />
          <p className="mt-3 text-center font-mono text-[9.5px] uppercase tracking-[0.14em] text-faint">
            A real comparison · generated in this browser
          </p>
        </div>
      </div>
      <div className="shell pb-10">
        <div className="grid grid-cols-2 gap-px overflow-hidden rounded-xl border border-line bg-line md:grid-cols-4">
          {[
            ['Vector pages', 'Original pages embedded, text stays selectable.'],
            ['Word-accurate diff', 'Moves, numbering and re-wrap, handled.'],
            ['Beyond text', 'Logos, charts and scans compared as images.'],
            ['Private by design', 'Files never leave this tab.'],
          ].map(([t, d]) => (
            <div key={t} className="bg-surface px-4 py-3.5">
              <div className="flex items-center gap-1.5 text-[12.5px] font-medium text-ink"><span className="h-1 w-1 rounded-full bg-accent" />{t}</div>
              <p className="mt-1 text-[11.5px] leading-snug text-muted">{d}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ── Section heading ──────────────────────────────────────────────────────────

export function SectionHead({ id, eyebrow, title, aside, children }: { id: string; eyebrow: string; title: ReactNode; aside?: ReactNode; children?: ReactNode }) {
  return (
    <div id={id} className="mb-10 grid gap-6 md:mb-14 md:grid-cols-[minmax(0,1fr)_minmax(0,0.72fr)] md:items-end md:gap-14">
      <div>
        <p className="eyebrow">{eyebrow}</p>
        <h2 className="display-sm mt-3.5 text-[32px] sm:text-[38px] lg:text-[42px]">{title}</h2>
      </div>
      <div className={aside ? 'min-w-0' : 'min-w-0 md:pb-1'}>
        {children && <p className="lede text-[14.5px] md:text-[15px]">{children}</p>}
        {aside}
      </div>
    </div>
  );
}

// ── Findings ─────────────────────────────────────────────────────────────────

const FINDINGS: { tag: string; title: string; was: string; now: string }[] = [
  { tag: 'Accuracy', title: 'Hitting the cost cap no longer throws a region away',
    was: 'Myers stopped at D = MaxDiffCost and reported the whole region as “delete everything, insert everything”, keeping a snapshot per step on the way — up to roughly 64 MB at the default cap.',
    now: 'Linear-space bisection with two small arrays and no snapshots. At the cap it splits at the furthest point reached and keeps diffing, so you still get a fine-grained result plus a warning.' },
  { tag: 'Accuracy', title: 'Pages are paired by content, not by index',
    was: 'Side-by-side, overlay and the raster pass compared page i with page i. One inserted page put every later page next to the wrong partner.',
    now: 'Unchanged words vote for page pairs and the heaviest consistent chain wins. Inserted and deleted pages get their own slot; deletion callouts land on the page where their neighbours actually are.' },
  { tag: 'False positive', title: '“well-⏎known” is no longer turned into “wellknown”',
    was: 'Dehyphenation always fused the two halves, so a compound broken at its real hyphen stopped matching the same compound set on one line.',
    now: 'The vocabulary of both documents decides. If “well-known” exists as a word and “wellknown” does not, the hyphen stays.' },
  { tag: 'Precision', title: 'A changed comma flags only the comma',
    was: 'Tokens were whitespace-delimited, so “agreement,” → “agreement.” was reported as a replaced word.',
    now: 'Leading and trailing punctuation become separate tokens with their own boxes. Tokens containing digits are never split, so “(500)” and “−3.5%” stay atomic.' },
  { tag: 'Bug', title: 'Bookmarks no longer assume a one-page summary',
    was: 'After “Executive Summary” the page counter advanced by one. A long change log pushed every bookmark off target.',
    now: 'The counter advances by the summary’s real page count.' },
  { tag: 'Missed change', title: 'Graphic changes next to text are kept',
    was: 'A raster difference box was discarded as soon as it touched any word (±3 pt) — which hides a swapped image sitting beside its caption.',
    now: 'A box counts as explained by text only when words cover at least 30 % of it.' },
  { tag: 'Robustness', title: 'Image comparison tolerates noise without hiding changes',
    was: 'A per-channel threshold on every second pixel. One pixel of anti-aliasing shimmer or a small render offset either floods the page or forces a threshold that hides real changes.',
    now: 'Perceptual distance on every pixel, 3×3 anti-aliasing tolerance that still catches new hairlines, and estimation of a uniform page shift before comparing.' },
  { tag: 'Readability', title: 'Minimal is not the same as readable',
    was: 'A rewritten sentence came out as confetti because “the”, “of” and “,” happened to match in the middle; a moved paragraph showed up as one deletion and one unrelated insertion.',
    now: 'Semantic cleanup absorbs stranded matches, ambiguous blocks snap to sentence boundaries, and verbatim moves are reported once, as moves.' },
];

export function Findings() {
  return (
    <section className="border-t border-line">
      <div className="shell py-20 md:py-28">
        <SectionHead
          id="findings"
          eyebrow="02 — The engine"
          title={<>Precision is a series of <em>small decisions.</em></>}
        >
          Your v2 was already well built: interned tokens, anchoring before Myers, deterministic output. These are the
          places where it lost accuracy — and the concrete fix that now ships in the engine.
        </SectionHead>

        <div className="mb-12 grid grid-cols-2 gap-px overflow-hidden rounded-xl border border-line bg-line lg:grid-cols-4">
          {[['7', 'output modes'], ['7', 'match modes'], ['24,000', 'randomised cases · 0 failures'], ['< 0.1 s', '200k × 200k tokens']].map(([v, l]) => (
            <div key={l} className="bg-surface px-5 py-5">
              <div className="text-[26px] font-medium leading-none tracking-[-0.03em] text-ink tabular-nums">{v}</div>
              <div className="mt-2 font-mono text-[9.5px] uppercase tracking-[0.12em] text-faint">{l}</div>
            </div>
          ))}
        </div>

        <div className="ledger">
          {FINDINGS.map((f, i) => (
            <article key={f.title} className="ledger-row">
              <div className="flex items-start gap-3 lg:block">
                <span className="ledger-num">{String(i + 1).padStart(2, '0')}</span>
                <span className="tag lg:mt-3">{f.tag}</span>
              </div>
              <h3 className="ledger-title lg:pr-6">{f.title}</h3>
              <div className="grid gap-3">
                <p className="note-before"><span className="note-tag">Before</span>{f.was}</p>
                <p className="note-after"><span className="note-tag">Now</span>{f.now}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

// ── Modes ────────────────────────────────────────────────────────────────────

type ModeKind = 'sidebyside' | 'overlay' | 'annotated' | 'onion' | 'map' | 'text' | 'report';

function ModeGlyph({ kind }: { kind: ModeKind }) {
  const page = 'flex h-full w-full flex-col gap-[3px] rounded-[2px] border border-[#e7e2d6] bg-[#fffdf8] p-[5px]';
  const bar = (w: string, c = '#e3ded1') => <span className="block h-[2.5px] rounded-full" style={{ width: w, background: c }} />;
  const inner = () => {
    switch (kind) {
      case 'sidebyside':
        return <div className="flex h-full w-full gap-2 px-4 py-3"><div className={page}>{bar('80%')}{bar('94%', '#f3c9c5')}{bar('70%')}{bar('86%')}</div><div className={page}>{bar('80%')}{bar('94%', '#c9e8d6')}{bar('70%')}{bar('86%')}</div></div>;
      case 'overlay':
        return <div className="flex h-full w-full items-center gap-1.5 px-8 py-3"><div className={page}>{bar('80%')}{bar('92%', '#c9e8d6')}{bar('66%')}{bar('88%', '#f7e2b8')}</div><div className="flex flex-col gap-[3px]">{['#f3c9c5', '#f3c9c5', '#e7e2d6', '#f3c9c5'].map((c, i) => <span key={i} className="h-[3px] w-5 rounded-sm" style={{ background: c }} />)}</div></div>;
      case 'annotated':
        return <div className="relative h-full w-full px-10 py-3"><div className={page}>{bar('80%')}{bar('70%', '#f7e2b8')}{bar('86%')}{bar('62%')}</div><span className="absolute right-[26px] top-[16px] flex h-4 w-4 items-center justify-center rounded-full bg-[#f7e2b8] text-[8px] font-semibold text-[#96610b]">3</span></div>;
      case 'onion':
        return <div className="relative flex h-full w-full items-center justify-center py-3"><span className="absolute h-[72%] w-12 -translate-x-3 rotate-[-4deg] rounded-[3px] bg-[#f3c9c5] opacity-80" /><span className="absolute h-[72%] w-12 translate-x-3 rotate-[4deg] rounded-[3px] bg-[#bfe4ea] opacity-80" /><span className="relative h-[66%] w-10 rounded-[3px] border border-[#1b1913]/20 bg-[#2b2a26]/90" /></div>;
      case 'map':
        return <div className="grid h-full w-full grid-cols-3 gap-1.5 px-8 py-3">{[0, 1, 2, 3, 4, 5].map(i => <span key={i} className="rounded-[2px] border border-[#e7e2d6] bg-[#fffdf8] p-[2px]"><span className="block h-full w-full rounded-[1px]" style={{ background: i === 1 ? '#c9e8d6' : i === 4 ? '#f7e2b8' : '#f0ece2' }} /></span>)}</div>;
      case 'text':
        return <div className="flex h-full w-full flex-col justify-center gap-[4px] px-7"><span className="block h-[3px] w-[70%] rounded-full bg-[#d9d3c5]" /><span className="block h-[3px] w-[86%] rounded-full bg-[#c9e8d6]" /><span className="block h-[3px] w-[58%] rounded-full bg-[#f3c9c5]" /><span className="block h-[3px] w-[78%] rounded-full bg-[#d9d3c5]" /></div>;
      case 'report':
        return <div className="flex h-full w-full flex-col justify-center gap-[4px] px-9"><span className="block h-[8px] w-full rounded-[2px] bg-[#14130f]" /><span className="block h-[3px] w-[52%] rounded-full bg-[#d9d3c5]" /><span className="mt-1 flex gap-1.5"><span className="h-3 w-1/4 rounded-[2px] bg-[#f3c9c5]" /><span className="h-3 w-1/4 rounded-[2px] bg-[#c9e8d6]" /><span className="h-3 w-1/4 rounded-[2px] bg-[#f7e2b8]" /><span className="h-3 w-1/4 rounded-[2px] bg-[#e3ded1]" /></span></div>;
    }
  };
  return <div className="mode-glyph w-full">{inner()}</div>;
}

const OUTPUT_MODES: { name: string; kind: ModeKind; state: 'improved' | 'new'; text: string; preview: string }[] = [
  { name: 'VisualOverlay', kind: 'overlay', state: 'improved', text: 'Single-pane redline. Additions highlighted in place, deletions as margin callouts anchored to the right page, moved text in blue.', preview: 'PDF output' },
  { name: 'SideBySide', kind: 'sidebyside', state: 'improved', text: 'Original left, modified right — every page next to its real counterpart, even after inserted or deleted pages.', preview: 'PDF output' },
  { name: 'Annotated', kind: 'annotated', state: 'new', text: 'The modified PDF at 1:1 with native highlight and note annotations. The reader’s comment pane becomes the change list.', preview: 'PDF output' },
  { name: 'OnionSkin', kind: 'onion', state: 'new', text: 'Both pages blended as vector layers: red only in the original, cyan only in the modification, black unchanged.', preview: 'PDF output' },
  { name: 'ChangeMap', kind: 'map', state: 'new', text: 'A contact sheet of live page thumbnails with change marks. See where a 300-page document changed at a glance.', preview: 'PDF output' },
  { name: 'RedlineText', kind: 'text', state: 'new', text: 'Re-flowed track changes, independent of layout: underlined insertions, struck deletions, marked moves.', preview: 'Lab · Redline' },
  { name: 'ChangeReport', kind: 'report', state: 'new', text: 'Summary and the complete classified change log only — for filing, sign-off, or feeding another system.', preview: 'Lab · Change log' },
];

const MATCH_MODES: [string, string, 'v2' | 'new'][] = [
  ['Strict', 'Exact after NFKC', 'v2'],
  ['IgnoreCase', 'Case-insensitive', 'v2'],
  ['IgnoreCaseAndPunctuation', '+ edge punctuation (never around digits)', 'v2'],
  ['Typographic', '“ ” = " " · – — = -', 'new'],
  ['NumericAware', '1,000 = 1000 · $1.50 = $1.5 · 3.10 ≠ 3.1', 'new'],
  ['Loose', 'All of the above + diacritics', 'new'],
  ['OcrTolerant', '+ O/0, l/I/1, rn/m', 'new'],
];

export function Modes() {
  return (
    <section className="border-t border-line">
      <div className="shell py-20 md:py-28">
        <SectionHead
          id="modes"
          eyebrow="03 — Review modes"
          title={<>One comparison. Seven ways to <em>review it.</em></>}
        >
          The same analysed comparison can be delivered in the format the next person in the process needs. Every mode
          carries the summary, the classified change log and bookmarks.
        </SectionHead>

        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {OUTPUT_MODES.map(m => (
            <article key={m.name} className="mode-card">
              <ModeGlyph kind={m.kind} />
              <div className="flex items-start justify-between gap-3">
                <h3 className="font-mono text-[12.5px] font-medium text-ink">{m.name}</h3>
                <span className={`tag ${m.state === 'new' ? 'tag-accent' : ''}`}>{m.state}</span>
              </div>
              <p className="text-[13px] leading-relaxed text-muted">{m.text}</p>
              <div className="mt-auto border-t border-line pt-2.5 font-mono text-[9px] uppercase tracking-[0.12em] text-faint">{m.preview}</div>
            </article>
          ))}
          <article className="mode-card justify-between bg-surface-2">
            <div>
              <div className="mono-label">Shared output</div>
              <h3 className="display-sm mt-3 text-[26px]">Every mode, <em>one truth.</em></h3>
              <p className="mt-3 text-[13px] leading-relaxed text-muted">
                All seven are values of <span className="font-mono text-[12px] text-ink">PdfComparisonMode</span>. Every mode exposes the same
                <span className="font-mono text-[12px] text-ink"> result.Changes</span>, page map and similarity score.
              </p>
            </div>
            <a href="#source" className="mt-4 inline-flex items-center gap-1.5 text-[12.5px] font-medium text-ink hover:text-accent">
              Read the source <Arrow />
            </a>
          </article>
        </div>

        <div className="mt-14 grid gap-8 lg:grid-cols-[minmax(0,0.55fr)_minmax(0,1fr)] lg:gap-14">
          <div>
            <p className="eyebrow">Word matching</p>
            <h3 className="display-sm mt-4 text-[26px] md:text-[30px]">Seven rules for what counts as <em>the same word.</em></h3>
            <p className="mt-4 max-w-lg text-[13.5px] leading-relaxed text-muted">
              Presets are combinations of <span className="font-mono text-[12px] text-ink">PdfMatchFlags</span>. Set a custom mix when your
              documents deserve their own definition of equality. Three of the seven are new.
            </p>
          </div>
          <div className="overflow-hidden rounded-xl border border-line bg-surface">
            {MATCH_MODES.map(([name, what, state], i) => (
              <div key={name} className={`grid grid-cols-[minmax(0,1fr)_auto] items-baseline gap-4 px-4 py-3 ${i ? 'border-t border-line' : ''}`}>
                <div className="min-w-0">
                  <div className="font-mono text-[12px] text-ink">{name}</div>
                  <div className="mt-0.5 text-[12.5px] leading-snug text-muted">{what}</div>
                </div>
                <span className={`font-mono text-[9px] uppercase tracking-[0.12em] ${state === 'new' ? 'text-accent' : 'text-faint'}`}>{state}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

// ── Verification ─────────────────────────────────────────────────────────────

export function Verify() {
  const [rep, setRep] = useState<SelfTestReport | null>(null);
  const [busy, setBusy] = useState(false);
  const run = () => {
    setBusy(true);
    setTimeout(() => {
      setRep(runSelfTest(5000, (Math.random() * 1e9) | 0));
      setBusy(false);
    }, 40);
  };
  const Item = ({ ok, children }: { ok: boolean; children: ReactNode }) => (
    <li className="flex gap-3 text-[13.5px] leading-relaxed">
      <Check tone={ok ? 'ins' : 'mod'} />
      <span className="text-body">{children}</span>
    </li>
  );
  return (
    <section className="border-t border-line">
      <div className="shell py-20 md:py-28">
        <SectionHead
          id="verify"
          eyebrow="05 — Verification"
          title={<>Evidence, <em>not adjectives.</em></>}
        >
          The engine is tested as an algorithm and exercised end-to-end as a product. I also list exactly what was not
          tested, so you can judge the risk before adopting it.
        </SectionHead>

        <div className="grid gap-4 lg:grid-cols-2">
          <div className="card p-6 md:p-7">
            <div className="flex items-center justify-between gap-3">
              <h3 className="text-[15px] font-medium text-ink">What was checked</h3>
              <span className="tag tag-ins">verified</span>
            </div>
            <ul className="mt-5 grid gap-3.5">
              <Item ok><b className="font-medium text-ink">C# engine, .NET SDK 8.0.427.</b> All ten files compile together with 0 errors and 0 warnings. 24,000 randomised cases: every edit script valid, 9,405 proven minimal against an LCS table, 3,986 cap-hit cases still valid, every detected move verbatim and non-overlapping.</Item>
              <Item ok><b className="font-medium text-ink">Targeted C# tests</b> for the seven match modes (including 3.10 ≠ 3.1), page alignment with an inserted page, and the raster core on synthetic images: registration, hairline detection, tone drift.</Item>
              <Item ok><b className="font-medium text-ink">TypeScript reference engine</b>, the one running in this lab: the same 24,000 cases in Node with 0 failures, and 8,000 heaviest-chain results compared with brute force.</Item>
              <Item ok><b className="font-medium text-ink">Direct PDF → PDF (lab).</b> Two generated PDFs give the same 12 text changes and 1 move as the text sample; the recoloured logo and changed chart bar are framed while the identical table and re-flow are not. Highlight geometry was checked on normal, rotated and cropped pages; outputs re-open with bookmarks.</Item>
              <Item ok><b className="font-medium text-ink">Markdown → Pure HTML (lab).</b> PDFs and Word files extract to layout-preserving Markdown, convert to sanitized HTML, and compare without breaking headings, lists or table rows. Verified in Node and headless Chromium.</Item>
              <Item ok><b className="font-medium text-ink">Scale.</b> Two 200k-token documents with 2,500 edits and a moved block diff in under 0.1 s on a small build machine.</Item>
            </ul>
          </div>

          <div className="grid content-start gap-4">
            <div className="card p-6 md:p-7">
              <div className="flex items-center justify-between gap-3">
                <h3 className="text-[15px] font-medium text-ink">What was not</h3>
                <span className="tag tag-mod">read this</span>
              </div>
              <ul className="mt-5 grid gap-3.5">
                <Item ok={false}><b className="font-medium text-ink">Nothing ran against your real Docuzen.Pdf library.</b> The integration files are type-checked against stand-ins inferred from your source; no PDF was produced by the C#. <span className="font-mono text-[12px]">tests/AssumedApi.cs</span> lists every assumption.</Item>
                <Item ok={false}><b className="font-medium text-ink">The lab’s PDF output is not the C# output.</b> It is a browser (pdf-lib) implementation of the same layouts, tested on generated documents. Unusual producers may fall back to page images; not every real-world PDF was tested.</Item>
                <Item ok={false}><b className="font-medium text-ink">Annotated and OnionSkin need a real-document test</b> before shipping. They depend on your writer passing annotations and transparency groups through merge and bookmarking unchanged.</Item>
                <Item ok={false}><b className="font-medium text-ink">Review priority is a heuristic</b>: digits, and an English list of negation and obligation words. It orders a review queue; it is not a legal opinion.</Item>
              </ul>
            </div>

            <div className="card overflow-hidden">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line px-5 py-4">
                <div>
                  <h3 className="text-[14px] font-medium text-ink">Run the randomised self-test</h3>
                  <p className="mt-0.5 text-[12px] text-muted">Fresh seed, the exact engine build powering this lab.</p>
                </div>
                <button onClick={run} disabled={busy} className="btn btn-primary btn-sm">{busy ? 'Running…' : rep ? 'Run again' : 'Run 5,000 cases'}</button>
              </div>
              {rep ? (
                <div>
                  <div className={`flex items-center gap-2 border-b border-line px-5 py-3 text-[12.5px] ${rep.failures.length ? 'text-del' : 'text-ins'}`}>
                    <span className={`h-1.5 w-1.5 rounded-full ${rep.failures.length ? 'bg-del' : 'bg-ins'}`} />
                    {rep.failures.length ? `${rep.failures.length} failure(s)` : `All ${rep.cases.toLocaleString()} cases passed`} in {Math.round(rep.ms)} ms
                  </div>
                  <dl className="grid grid-cols-2 gap-px bg-line">
                    {([['Scripts validated', rep.cases], ['Minimal vs LCS', rep.optimalChecked], ['Cap hit, still valid', rep.cappedCases], ['Chains vs brute force', rep.chainChecked], ['Moves verified', rep.movesFound], ['Shifts verified', rep.shifts]] as [string, number][]).map(([k, v]) => (
                      <div key={k} className="bg-surface px-4 py-3">
                        <dd className="text-[18px] font-medium tracking-[-0.02em] text-ink tabular-nums">{v.toLocaleString()}</dd>
                        <dt className="mt-1 text-[10.5px] text-faint">{k}</dt>
                      </div>
                    ))}
                  </dl>
                  {rep.failures.length > 0 && <pre className="overflow-auto border-t border-line bg-surface-2 p-3 font-mono text-[11px] text-del">{rep.failures.join('\n')}</pre>}
                </div>
              ) : (
                <div className="px-5 py-4">
                  <pre className="overflow-auto rounded-lg border border-line bg-surface-2 px-3 py-2.5 font-mono text-[12px] leading-relaxed text-body">{`cd docuzen-compare-v3/tests
dotnet run -c Release`}</pre>
                  <p className="mt-2 text-[11.5px] text-faint">Prints the case counts and ALL PASSED; exits 1 on any failure.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ── Footer ───────────────────────────────────────────────────────────────────

export function Footer() {
  return (
    <footer className="border-t border-line bg-surface">
      <div className="shell">
        <div className="flex flex-col gap-8 py-14 md:flex-row md:items-end md:justify-between md:py-16">
          <div className="max-w-2xl">
            <p className="eyebrow">Docuzen Compare</p>
            <h2 className="display-sm mt-3.5 text-[30px] sm:text-[36px]">Built for documents that <em>matter.</em></h2>
            <p className="mt-3 max-w-xl text-[13.5px] leading-relaxed text-muted">
              An independent comparison studio and engine lab. Files are processed locally in your browser; nothing is
              uploaded, stored or logged.
            </p>
          </div>
          <a href="#lab" className="btn btn-primary self-start md:self-auto">Open the lab <Arrow /></a>
        </div>

        <div className="grid gap-8 border-t border-line py-10 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <div className="mono-label">Product</div>
            <ul className="mt-3 grid gap-2 text-[13px] text-muted">
              <li><a href="#lab" className="hover:text-ink">Comparison lab</a></li>
              <li><a href="#modes" className="hover:text-ink">Review modes</a></li>
              <li><a href="#verify" className="hover:text-ink">Verification</a></li>
            </ul>
          </div>
          <div>
            <div className="mono-label">Engine</div>
            <ul className="mt-3 grid gap-2 text-[13px] text-muted">
              <li><a href="#findings" className="hover:text-ink">What changed in v3</a></li>
              <li><a href="#source" className="hover:text-ink">C# source</a></li>
              <li><a href="#source" className="hover:text-ink">Integration guide</a></li>
            </ul>
          </div>
          <div>
            <div className="mono-label">Formats</div>
            <ul className="mt-3 grid gap-2 text-[13px] text-muted">
              <li>PDF · vector and scanned</li>
              <li>Word (.docx) · tracked changes</li>
              <li>Markdown · plain text</li>
            </ul>
          </div>
          <div>
            <div className="mono-label">Privacy</div>
            <ul className="mt-3 grid gap-2 text-[13px] text-muted">
              <li>No uploads</li>
              <li>No accounts</li>
              <li>No telemetry</li>
            </ul>
          </div>
        </div>

        <div className="flex flex-col gap-2 border-t border-line py-5 text-[11.5px] text-faint sm:flex-row sm:items-center sm:justify-between">
          <span>© 2026 Docuzen Compare · an independent reference implementation.</span>
          <span className="font-mono text-[10px] uppercase tracking-[0.12em]">Engine v3 · lab build</span>
        </div>
      </div>
    </footer>
  );
}
