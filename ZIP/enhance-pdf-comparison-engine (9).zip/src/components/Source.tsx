import { useMemo, useState, type ReactNode } from 'react';
import { strToU8, zipSync } from 'fflate';
import { SOURCES, type Assurance } from '../sources';
import { download } from './Panels';

const CS = new RegExp(
  [
    '(\\/\\/[^\\n]*|\\/\\*[\\s\\S]*?\\*\\/)',                                   // 1 comment
    '([@$]{0,2}"(?:[^"\\\\\\n]|\\\\.)*")',                                      // 2 string
    "('(?:[^'\\\\\\n]|\\\\.)')",                                                // 3 char
    '\\b(\\d[\\d_]*(?:\\.\\d+)?(?:UL|[fFdDmMuUlL])?)\\b',                       // 4 number
    '\\b(abstract|and|as|base|bool|break|byte|case|catch|char|class|const|continue|default|do|double|else|enum|false|finally|for|foreach|get|if|in|init|int|internal|is|long|namespace|new|not|null|or|out|override|params|partial|private|protected|public|readonly|record|ref|required|return|sealed|set|static|string|struct|switch|this|throw|true|try|typeof|uint|ulong|using|var|void|when|while|with)\\b', // 5 keyword
  ].join('|'),
  'g',
);

function highlight(code: string): ReactNode[] {
  const out: ReactNode[] = [];
  let last = 0, k = 0;
  CS.lastIndex = 0;
  for (let m = CS.exec(code); m; m = CS.exec(code)) {
    if (m.index > last) out.push(code.slice(last, m.index));
    out.push(<span key={k++} className={m[1] ? 'c' : m[2] || m[3] ? 's' : m[4] ? 'n' : 'k'}>{m[0]}</span>);
    last = m.index + m[0].length;
  }
  if (last < code.length) out.push(code.slice(last));
  return out;
}

const BADGE: Record<Assurance, { label: string; cls: string; hint: string }> = {
  tested: { label: 'compiled + tested', cls: 'border-ins/40 bg-ins-bg text-ins', hint: 'Compiled with .NET 8 and exercised by the randomised / targeted tests' },
  compiled: { label: 'compiled vs stand-ins', cls: 'border-mod/40 bg-mod-bg text-mod', hint: 'Type-checked against inferred API stand-ins; never run against the real Docuzen.Pdf library' },
  support: { label: 'support file', cls: 'border-ink-600 bg-ink-800 text-ink-300', hint: 'Documentation or test harness' },
};

const ACTION: Record<string, string> = {
  Replace: 'text-signal', Add: 'text-ins', Guide: 'text-move', Tests: 'text-ink-400',
};

export default function Source() {
  const [sel, setSel] = useState(0);
  const [copied, setCopied] = useState(false);
  const file = SOURCES[sel];
  const isCs = file.path.endsWith('.cs');
  const body = useMemo(() => (isCs ? highlight(file.code) : [file.code]), [file, isCs]);
  const lineCount = useMemo(() => file.code.split('\n').length, [file]);
  const numbers = useMemo(() => Array.from({ length: lineCount }, (_, i) => i + 1).join('\n'), [lineCount]);
  const totalLines = useMemo(() => SOURCES.filter(f => f.path.endsWith('.cs') && !f.path.startsWith('tests/')).reduce((n, f) => n + f.code.split('\n').length, 0), []);

  const copy = async () => {
    try { await navigator.clipboard.writeText(file.code); }
    catch {
      const ta = document.createElement('textarea');
      ta.value = file.code;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      ta.remove();
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };
  const zipAll = () => {
    const files: Record<string, Uint8Array> = {};
    for (const f of SOURCES) files['docuzen-compare-v3/' + f.path] = strToU8(f.code);
    download('docuzen-compare-v3.zip', zipSync(files, { level: 6 }), 'application/zip');
  };

  return (
    <div className="panel overflow-hidden">
      <div className="flex flex-wrap items-center gap-3 border-b border-line px-4 py-3 md:px-6">
        <div className="text-[13px] text-ink-300">
          <span className="font-medium text-ink-100">{SOURCES.length} files</span> · {totalLines.toLocaleString()} lines of engine C#
        </div>
        <button onClick={zipAll} className="btn btn-primary btn-sm ml-auto">
          Download all (.zip)
        </button>
      </div>

      <div className="grid md:grid-cols-[19rem_minmax(0,1fr)]">
        {/* File list */}
        <div className="scroll-ink max-h-56 overflow-auto border-b border-line md:max-h-[70vh] md:border-b-0 md:border-r">
          {SOURCES.map((f, i) => (
            <button
              key={f.path} onClick={() => setSel(i)}
              className={`block w-full border-b border-line px-4 py-2.5 text-left transition ${i === sel ? 'bg-surface-2 shadow-[inset_2px_0_0_var(--ink)]' : 'hover:bg-surface-2'}`}
            >
              <div className="flex items-baseline justify-between gap-2">
                <span className={`truncate font-mono text-[12px] ${i === sel ? 'text-ink' : 'text-ink-200'}`}>{f.path}</span>
                <span className={`flex-none font-mono text-[10px] uppercase tracking-wider ${ACTION[f.action]}`}>{f.action}</span>
              </div>
              <div className="mt-1 text-[11.5px] leading-snug text-ink-500">{f.blurb}</div>
            </button>
          ))}
        </div>

        {/* Viewer */}
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2 border-b border-line bg-surface-2 px-4 py-2">
            <span className="font-mono text-[12px] text-ink-100">{file.path}</span>
            <span className={`rounded border px-1.5 py-0.5 text-[10.5px] ${BADGE[file.assurance].cls}`} title={BADGE[file.assurance].hint}>{BADGE[file.assurance].label}</span>
            <span className="font-mono text-[10.5px] text-ink-500">{lineCount} lines</span>
            <div className="ml-auto flex gap-2">
              <button onClick={copy} className="btn btn-secondary btn-sm">{copied ? 'Copied ✓' : 'Copy'}</button>
              <button onClick={() => download(file.path.split('/').pop()!, file.code)} className="btn btn-secondary btn-sm">Download</button>
            </div>
          </div>
          <div className="scroll-ink code flex max-h-[70vh] overflow-auto bg-surface-2">
            <pre className="sticky left-0 m-0 flex-none select-none border-r border-line bg-surface-2 py-3 pl-3 pr-3 text-right text-faint">{numbers}</pre>
            <pre className="m-0 flex-1 py-3 pr-6 text-ink-200">{body}</pre>
          </div>
        </div>
      </div>
    </div>
  );
}
