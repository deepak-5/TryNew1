import { useMemo, useState } from 'react';
import type { Change, ChangeType, CompareResult, Risk } from '../engine/compare';
import { EQ, DEL, INS, buildRedline } from '../engine/views';

export const TYPE_META: Record<ChangeType, { label: string; cls: string }> = {
  insert: { label: 'Added', cls: 'border-ins/40 bg-ins-bg text-ins' },
  delete: { label: 'Deleted', cls: 'border-del/40 bg-del-bg text-del' },
  replace: { label: 'Replaced', cls: 'border-mod/40 bg-mod-bg text-mod' },
  move: { label: 'Moved', cls: 'border-move/40 bg-move-bg text-move' },
  number: { label: 'Number', cls: 'border-mod/40 bg-mod-bg text-mod' },
  spelling: { label: 'Spelling', cls: 'border-fmt/40 bg-fmt-bg text-fmt' },
  case: { label: 'Case', cls: 'border-line bg-surface-3 text-muted' },
  punctuation: { label: 'Punctuation', cls: 'border-line bg-surface-3 text-muted' },
  spacing: { label: 'Spacing', cls: 'border-line bg-surface-3 text-muted' },
};

export const RISK_META: Record<Risk, { label: string; dot: string; hint: string }> = {
  critical: { label: 'Critical', dot: 'bg-del', hint: 'numeric content changed' },
  high: { label: 'High', dot: 'bg-signal', hint: 'negation / obligation wording' },
  medium: { label: 'Medium', dot: 'bg-mod', hint: 'wording changed' },
  low: { label: 'Low', dot: 'bg-ink-400', hint: 'case, punctuation, one-letter fixes' },
  info: { label: 'Info', dot: 'bg-move', hint: 'moved, content unchanged' },
};
const RISK_ORDER: Risk[] = ['critical', 'high', 'medium', 'low', 'info'];

export function download(name: string, data: string | Uint8Array, type = 'text/plain'): void {
  const url = URL.createObjectURL(new Blob([data as unknown as BlobPart], { type }));
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

function Chip({ on, onClick, children }: { on: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={'chip !h-7 !px-2.5 !text-[11px] ' + (on ? 'is-on' : '')}
    >
      {children}
    </button>
  );
}

// ── 5. Change log ────────────────────────────────────────────────────────────

function PairChips({ c }: { c: Change }) {
  if (!c.pairs.length || c.pairs.length > 4) return null;
  return (
    <div className="mt-1.5 flex flex-wrap gap-1.5">
      {c.pairs.map((p, i) => (
        <span key={i} className="rounded bg-ink-950 px-1.5 py-0.5 font-mono text-[11px] text-ink-300 ring-1 ring-ink-700">
          {p.chars.map((s, j) =>
            s.k === EQ ? <span key={j}>{s.s}</span>
              : s.k === DEL ? <span key={j} className="bg-del/30 text-del line-through">{s.s}</span>
              : <span key={j} className="bg-ins/30 text-ins">{s.s}</span>)}
        </span>
      ))}
    </div>
  );
}

export function ChangeLogView({ res, active, onPick, onLocate }: { res: CompareResult; active: number; onPick: (id: number) => void; onLocate: (id: number) => void }) {
  const [types, setTypes] = useState<Set<string>>(new Set());
  const [risks, setRisks] = useState<Set<string>>(new Set());
  const toggle = (set: Set<string>, v: string, apply: (s: Set<string>) => void) => {
    const n = new Set(set);
    if (n.has(v)) n.delete(v); else n.add(v);
    apply(n);
  };
  const shown = res.changes.filter(c => (!types.size || types.has(c.type)) && (!risks.size || risks.has(c.risk)));
  const clip = (s: string) => (s.length > 260 ? s.slice(0, 257) + '…' : s);

  const exportJson = () => download('docuzen-changes.json', JSON.stringify({
    similarity: res.stats.similarity,
    pageMap: res.slots.map(s => ({ before: s.a + 1, after: s.b + 1, status: s.status })),
    changes: res.changes.map(c => ({
      id: c.id + 1, type: c.type, risk: c.risk, beforePage: c.pageA + 1, afterPage: c.pageB + 1,
      beforeLine: c.lineA, afterLine: c.lineB, deleted: c.delText, added: c.insText, note: c.note || undefined,
    })),
  }, null, 2), 'application/json');
  const exportCsv = () => {
    const q = (s: string | number) => `"${String(s).replace(/"/g, '""')}"`;
    const rows = [['id', 'type', 'risk', 'before_page', 'after_page', 'deleted', 'added', 'note'].join(',')];
    for (const c of res.changes) rows.push([c.id + 1, c.type, c.risk, c.pageA + 1, c.pageB + 1, q(c.delText), q(c.insText), q(c.note)].join(','));
    download('docuzen-changes.csv', rows.join('\n'), 'text/csv');
  };

  if (!res.changes.length) return <div className="bg-ink-900 p-10 text-center text-sm text-ink-400">No differences under the current match mode.</div>;

  return (
    <div className="bg-ink-900">
      <div className="flex flex-wrap items-center gap-2 border-b border-ink-700 px-4 py-3">
        <span className="mr-1 font-mono text-[10px] uppercase tracking-[0.14em] text-ink-500">Type</span>
        {(Object.keys(TYPE_META) as ChangeType[]).filter(t => res.stats.byType[t]).map(t => (
          <Chip key={t} on={types.has(t)} onClick={() => toggle(types, t, setTypes)}>{TYPE_META[t].label} · {res.stats.byType[t]}</Chip>
        ))}
        <span className="ml-3 mr-1 font-mono text-[10px] uppercase tracking-[0.14em] text-ink-500">Priority</span>
        {RISK_ORDER.filter(r => res.stats.byRisk[r]).map(r => (
          <Chip key={r} on={risks.has(r)} onClick={() => toggle(risks, r, setRisks)}>
            <span className={`mr-1.5 inline-block h-1.5 w-1.5 rounded-full ${RISK_META[r].dot}`} />{RISK_META[r].label} · {res.stats.byRisk[r]}
          </Chip>
        ))}
        <div className="ml-auto flex gap-2">
          <button onClick={exportJson} className="rounded-md border border-ink-600 px-2.5 py-1 text-[11px] text-ink-200 hover:border-ink-400">Export JSON</button>
          <button onClick={exportCsv} className="rounded-md border border-ink-600 px-2.5 py-1 text-[11px] text-ink-200 hover:border-ink-400">Export CSV</button>
        </div>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[720px] border-collapse text-[13px]">
          <thead>
            <tr className="text-left font-mono text-[10px] uppercase tracking-[0.14em] text-ink-500">
              <th className="w-12 px-4 py-2 font-normal">#</th>
              <th className="w-24 px-2 py-2 font-normal">Where</th>
              <th className="w-28 px-2 py-2 font-normal">Type</th>
              <th className="w-24 px-2 py-2 font-normal">Priority</th>
              <th className="px-2 py-2 font-normal">Original</th>
              <th className="px-2 py-2 font-normal">Modified</th>
              <th className="w-10 px-2 py-2" />
            </tr>
          </thead>
          <tbody>
            {shown.map(c => (
              <tr
                key={c.id}
                data-ch={c.id}
                onClick={() => onPick(c.id)}
                className={`cursor-pointer border-t border-ink-800 align-top transition hover:bg-ink-850 ${active === c.id ? 'bg-ink-800' : ''}`}
              >
                <td className="px-4 py-2.5 font-mono text-[11px] text-ink-500">{c.id + 1}</td>
                <td className="px-2 py-2.5 font-mono text-[11px] text-ink-400">
                  {c.type === 'move' ? <>p.{c.pageA + 1} → p.{c.pageB + 1}</> : <>p.{(c.ins.length ? c.pageB : c.pageA) + 1} · L{c.ins.length ? c.lineB : c.lineA}</>}
                </td>
                <td className="px-2 py-2.5"><span className={`rounded border px-1.5 py-0.5 text-[11px] ${TYPE_META[c.type].cls}`}>{TYPE_META[c.type].label}</span></td>
                <td className="px-2 py-2.5 text-[12px] text-ink-300" title={RISK_META[c.risk].hint}>
                  <span className={`mr-1.5 inline-block h-1.5 w-1.5 rounded-full ${RISK_META[c.risk].dot}`} />{RISK_META[c.risk].label}
                </td>
                <td className="px-2 py-2.5 font-display text-[14px] leading-snug text-del">
                  {c.type === 'move' ? <span className="text-move">{clip(c.delText)}</span> : c.delText ? clip(c.delText) : <span className="text-ink-600">—</span>}
                </td>
                <td className="px-2 py-2.5 font-display text-[14px] leading-snug text-ins">
                  {c.type === 'move' ? <span className="font-sans text-[12px] text-ink-400">same text, new position</span> : c.insText ? clip(c.insText) : <span className="text-ink-600">—</span>}
                  {c.note && <span className="ml-2 rounded bg-mod-bg px-1.5 py-0.5 font-mono text-[11px] text-mod">{c.note}</span>}
                  <PairChips c={c} />
                </td>
                <td className="px-2 py-2.5">
                  <button
                    onClick={e => { e.stopPropagation(); onLocate(c.id); }}
                    className="rounded border border-ink-600 px-1.5 py-0.5 text-[11px] text-ink-300 hover:border-signal hover:text-signal"
                    title="Show in redline view"
                  >
                    ↗
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {shown.length === 0 && <div className="p-8 text-center text-sm text-ink-500">No changes match the selected filters.</div>}
    </div>
  );
}

// ── 6. Alignment map ─────────────────────────────────────────────────────────

export function AlignmentView({ res, active, onPick, onLocate }: { res: CompareResult; active: number; onPick: (id: number) => void; onLocate: (id: number) => void }) {
  const nA = Math.max(1, res.tokA.length), nB = Math.max(1, res.tokB.length);
  const geo = useMemo(() => {
    const eq: [number, number, number][] = [];
    const dels: [number, number][] = [], ins: [number, number][] = [];
    let cur: [number, number, number] | null = null, dr: [number, number] | null = null, ir: [number, number] | null = null;
    for (const it of res.items) {
      if (it.kind === EQ) {
        const a = it.a!.i, b = it.b!.i;
        if (cur && cur[0] + cur[2] === a && cur[1] + cur[2] === b) cur[2]++; else { cur = [a, b, 1]; eq.push(cur); }
        dr = ir = null;
        continue;
      }
      cur = null;
      if (it.move >= 0) continue;
      if (it.kind === DEL) { if (dr && dr[0] + dr[1] === it.a!.i) dr[1]++; else { dr = [it.a!.i, 1]; dels.push(dr); } }
      else if (it.kind === INS) { if (ir && ir[0] + ir[1] === it.b!.i) ir[1]++; else { ir = [it.b!.i, 1]; ins.push(ir); } }
    }
    const min = eq.length > 1200 ? Math.ceil((nA + nB) / 3000) : 1;
    const pagesOf = (toks: typeof res.tokA) => toks.filter((t, i) => i > 0 && t.page !== toks[i - 1].page).map(t => t.i);
    return { eq: eq.filter(r => r[2] >= min), dels, ins, pa: pagesOf(res.tokA), pb: pagesOf(res.tokB) };
  }, [res, nA, nB]);

  const X = (i: number, n: number) => (i / n) * 1000;
  const band = (a0: number, b0: number, len: number) => {
    const x1 = X(a0, nA), x2 = X(a0 + len, nA), x3 = X(b0, nB), x4 = X(b0 + len, nB);
    return `M ${x1} 30 C ${x1} 100, ${x3} 100, ${x3} 170 L ${x4} 170 C ${x4} 100, ${x2} 100, ${x2} 30 Z`;
  };
  const moveChange = (id: number) => res.changes.find(c => c.moveId === id);

  return (
    <div className="bg-ink-900 p-4 md:p-6">
      <div className="mb-1 flex justify-between font-mono text-[10px] uppercase tracking-[0.14em] text-ink-400">
        <span>Original · {res.tokA.length.toLocaleString()} tokens</span>
        <span className="hidden gap-4 sm:flex">
          <span><i className="mr-1 inline-block h-2 w-2 rounded-sm bg-ink-500" />matched</span>
          <span><i className="mr-1 inline-block h-2 w-2 rounded-sm bg-move" />moved</span>
          <span><i className="mr-1 inline-block h-2 w-2 rounded-sm bg-del" />deleted</span>
          <span><i className="mr-1 inline-block h-2 w-2 rounded-sm bg-ins" />added</span>
        </span>
      </div>
      <svg viewBox="0 0 1000 200" preserveAspectRatio="none" className="h-56 w-full rounded-xl bg-surface-2 ring-1 ring-line">
        {geo.eq.map((r, i) => <path key={i} d={band(r[0], r[1], r[2])} fill="var(--ink)" opacity={0.2} />)}
        {res.moves.map(m => {
          const c = moveChange(m.id);
          return (
            <path
              key={m.id} d={band(m.aStart, m.bStart, m.len)} fill="var(--move)" opacity={c && c.id === active ? 0.95 : 0.65}
              stroke="#8fb0ff" strokeWidth={0.5} vectorEffect="non-scaling-stroke" className="cursor-pointer"
              onClick={() => c && onPick(c.id)}
            />
          );
        })}
        <rect x={0} y={18} width={1000} height={12} fill="var(--surface-3)" />
        <rect x={0} y={170} width={1000} height={12} fill="var(--surface-3)" />
        {geo.dels.map((d, i) => <rect key={i} x={X(d[0], nA)} y={18} width={Math.max(1.2, X(d[1], nA))} height={12} fill="var(--del)" />)}
        {geo.ins.map((d, i) => <rect key={i} x={X(d[0], nB)} y={170} width={Math.max(1.2, X(d[1], nB))} height={12} fill="var(--ins)" />)}
        {res.moves.map(m => (
          <g key={m.id}>
            <rect x={X(m.aStart, nA)} y={18} width={Math.max(1.2, X(m.len, nA))} height={12} fill="var(--move)" />
            <rect x={X(m.bStart, nB)} y={170} width={Math.max(1.2, X(m.len, nB))} height={12} fill="var(--move)" />
          </g>
        ))}
        {geo.pa.map((p, i) => <line key={i} x1={X(p, nA)} x2={X(p, nA)} y1={10} y2={30} stroke="var(--faint)" strokeWidth={1} vectorEffect="non-scaling-stroke" />)}
        {geo.pb.map((p, i) => <line key={i} x1={X(p, nB)} x2={X(p, nB)} y1={170} y2={190} stroke="var(--faint)" strokeWidth={1} vectorEffect="non-scaling-stroke" />)}
      </svg>
      <div className="mt-1 font-mono text-[10px] uppercase tracking-[0.14em] text-ink-400">Modified · {res.tokB.length.toLocaleString()} tokens · ticks mark page breaks</div>

      <h4 className="mb-2 mt-6 text-sm font-medium text-ink-100">
        {res.moves.length ? `${res.moves.length} moved block${res.moves.length > 1 ? 's' : ''}` : 'No moved blocks detected'}
      </h4>
      {!res.moves.length && <p className="max-w-xl text-[13px] text-ink-400">A move is text that was deleted in one place and inserted verbatim elsewhere (at least the minimum move length). A plain diff would report it twice — once as a deletion, once as an insertion.</p>}
      <div className="grid gap-2 md:grid-cols-2">
        {res.moves.map(m => {
          const c = moveChange(m.id);
          if (!c) return null;
          return (
            <button
              key={m.id}
              onClick={() => onLocate(c.id)}
              className={`rounded-lg border p-3 text-left transition hover:border-move ${c.id === active ? 'border-move bg-move/10' : 'border-ink-700 bg-ink-850'}`}
            >
              <div className="mb-1 flex items-center justify-between font-mono text-[11px] text-move">
                <span>p.{c.pageA + 1} · L{c.lineA} → p.{c.pageB + 1} · L{c.lineB}</span>
                <span className="text-ink-500">{m.len} tokens</span>
              </div>
              <div className="font-display text-[14px] leading-snug text-ink-200">{c.insText.length > 200 ? c.insText.slice(0, 197) + '…' : c.insText}</div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ── 7. Page map ──────────────────────────────────────────────────────────────

export function PageMapView({ res, onLocate }: { res: CompareResult; onLocate: (id: number) => void }) {
  const lines = useMemo(() => buildRedline(res.items), [res]);
  const tone = { same: 'border-ink-700', changed: 'border-mod/60', inserted: 'border-ins/70', deleted: 'border-del/70' } as const;
  const label = { same: 'Identical', changed: 'Changed', inserted: 'Inserted page', deleted: 'Deleted page' } as const;
  const cell = (l: (typeof lines)[number]) => {
    let d = 0, n = 0, m = 0;
    for (const s of l.segs) { if (s.kind === EQ) continue; if (s.move >= 0) m++; else if (s.kind === DEL) d++; else n++; }
    return d && n ? 'bg-mod' : n ? 'bg-ins' : d ? 'bg-del' : m ? 'bg-move' : 'bg-ink-700';
  };
  return (
    <div className="bg-ink-900 p-4 md:p-6">
      <p className="mb-4 max-w-2xl text-[13px] leading-relaxed text-ink-400">
        Pages are paired by content: every unchanged word votes for a (before, after) page pair and the heaviest consistent chain wins.
        An inserted or deleted page becomes its own slot instead of shifting every later comparison by one.
      </p>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        {res.slots.map((s, i) => (
          <div key={i} className={`rounded-lg border-2 bg-ink-850 p-3 ${tone[s.status]}`}>
            <div className="flex items-baseline justify-between font-mono text-[11px] text-ink-300">
              <span>{s.a >= 0 ? `p.${s.a + 1}` : '—'} <span className="text-ink-500">→</span> {s.b >= 0 ? `p.${s.b + 1}` : '—'}</span>
              <span className="text-ink-500">{Math.round(s.pct * 100)}%</span>
            </div>
            <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-ink-700">
              <div className="h-full bg-signal" style={{ width: `${Math.min(100, s.pct * 100)}%` }} />
            </div>
            <div className="mt-2 text-[12px] text-ink-200">{label[s.status]}</div>
            <div className="mt-0.5 flex gap-2 font-mono text-[11px]">
              {s.ins > 0 && <span className="text-ins">+{s.ins}</span>}
              {s.del > 0 && <span className="text-del">−{s.del}</span>}
              {s.moved > 0 && <span className="text-move">⇄{s.moved}</span>}
              {s.ins + s.del + s.moved === 0 && <span className="text-ink-500">{s.wordsB || s.wordsA} tokens</span>}
            </div>
          </div>
        ))}
      </div>

      <h4 className="mb-2 mt-7 text-sm font-medium text-ink-100">Line heat strip</h4>
      <p className="mb-3 text-[12px] text-ink-500">One cell per line of the redline, in reading order. Click a coloured cell to jump there.</p>
      <div className="flex flex-wrap gap-[2px]">
        {lines.map((l, i) => {
          const c = cell(l);
          const first = l.segs.find(s => s.kind !== EQ);
          return (
            <button
              key={i}
              disabled={!first}
              onClick={() => first && onLocate(first.change)}
              className={`h-3.5 w-1.5 rounded-[1px] ${c} ${first ? 'cursor-pointer hover:scale-y-150' : 'cursor-default'} ${i > 0 && l.page !== lines[i - 1].page && l.lineNo >= 0 ? 'ml-2' : ''}`}
              title={l.lineNo >= 0 ? `Page ${l.page + 1}, line ${l.lineNo}` : 'Deleted lines'}
            />
          );
        })}
      </div>
    </div>
  );
}

// ── 8. Insights ──────────────────────────────────────────────────────────────

export function InsightsView({ res }: { res: CompareResult }) {
  const s = res.stats;
  const pct = s.similarity * 100;
  const C = 2 * Math.PI * 52;
  const typeMax = Math.max(1, ...Object.values(s.byType));
  const ms = (v: number) => (v < 10 ? v.toFixed(1) : Math.round(v).toString()) + ' ms';
  const Row = ({ k, v, hint }: { k: string; v: React.ReactNode; hint?: string }) => (
    <div className="flex items-baseline justify-between gap-4 border-b border-ink-800 py-1.5 text-[13px]" title={hint}>
      <span className="text-ink-400">{k}</span>
      <span className="font-mono text-ink-100">{v}</span>
    </div>
  );
  return (
    <div className="grid gap-6 bg-ink-900 p-4 md:grid-cols-3 md:p-6">
      <div>
        <h4 className="mb-3 font-mono text-[10px] uppercase tracking-[0.14em] text-ink-500">In-place similarity</h4>
        <div className="flex items-center gap-5">
          <svg viewBox="0 0 120 120" className="h-28 w-28 -rotate-90">
            <circle cx="60" cy="60" r="52" fill="none" stroke="var(--line)" strokeWidth="10" />
            <circle cx="60" cy="60" r="52" fill="none" stroke="var(--accent)" strokeWidth="10" strokeLinecap="round" strokeDasharray={`${(pct / 100) * C} ${C}`} />
          </svg>
          <div>
            <div className="font-display text-4xl text-ink-100">{pct.toFixed(1)}<span className="text-xl text-ink-400">%</span></div>
            <div className="mt-1 text-[12px] leading-snug text-ink-400">2 × unchanged tokens ÷ all tokens. Moved text counts as changed here.</div>
          </div>
        </div>
        <div className="mt-5">
          <Row k="Tokens (original / modified)" v={`${s.wordsA.toLocaleString()} / ${s.wordsB.toLocaleString()}`} />
          <Row k="Unchanged" v={s.equal.toLocaleString()} />
          <Row k="Deleted / added" v={<><span className="text-del">−{s.deleted}</span> / <span className="text-ins">+{s.inserted}</span></>} />
          <Row k="Moved tokens" v={<span className="text-move">{s.moved}</span>} />
          <Row k="Pages (original / modified)" v={`${res.pagesA} / ${res.pagesB}`} />
        </div>
      </div>

      <div>
        <h4 className="mb-3 font-mono text-[10px] uppercase tracking-[0.14em] text-ink-500">Changes by type</h4>
        {(Object.keys(TYPE_META) as ChangeType[]).filter(t => s.byType[t]).map(t => (
          <div key={t} className="mb-2">
            <div className="mb-1 flex justify-between text-[12px]"><span className="text-ink-300">{TYPE_META[t].label}</span><span className="font-mono text-ink-100">{s.byType[t]}</span></div>
            <div className="h-1.5 rounded-full bg-ink-800"><div className="h-full rounded-full bg-ink-300" style={{ width: `${(s.byType[t] / typeMax) * 100}%` }} /></div>
          </div>
        ))}
        {!res.changes.length && <p className="text-[13px] text-ink-500">No changes.</p>}
        <h4 className="mb-2 mt-6 font-mono text-[10px] uppercase tracking-[0.14em] text-ink-500">Review priority</h4>
        {RISK_ORDER.filter(r => s.byRisk[r]).map(r => (
          <div key={r} className="flex items-center justify-between border-b border-ink-800 py-1.5 text-[13px]">
            <span className="text-ink-300"><span className={`mr-2 inline-block h-2 w-2 rounded-full ${RISK_META[r].dot}`} />{RISK_META[r].label} <span className="text-ink-500">· {RISK_META[r].hint}</span></span>
            <span className="font-mono text-ink-100">{s.byRisk[r]}</span>
          </div>
        ))}
        <p className="mt-3 text-[11px] leading-snug text-ink-500">Priority is a heuristic (digits, and an English list of negation / obligation words). It orders a review; it does not replace one.</p>
      </div>

      <div>
        <h4 className="mb-3 font-mono text-[10px] uppercase tracking-[0.14em] text-ink-500">Engine internals</h4>
        <Row k="Phrase anchor runs" v={s.phraseRuns} hint="Maximal unique matches chosen by the heaviest chain" />
        <Row k="Patience anchors" v={s.tokenAnchors} hint="Unique tokens kept by LIS" />
        <Row k="Myers bisections" v={s.bisections} hint="Linear-space middle-snake splits" />
        <Row k="Cap-limited regions" v={s.cappedRegions} hint="Regions that hit max cost and were split heuristically" />
        <Row k="Boundaries shifted" v={s.shifted} hint="Ambiguous insert/delete blocks moved to a sentence or paragraph boundary" />
        <Row k="Stranded matches absorbed" v={s.islandsMerged} hint="Semantic cleanup" />
        <Row k="Header / footer lines ignored" v={s.hfLines} />
        <Row k="Line-break hyphens resolved" v={s.dehyphenated} />
        <h4 className="mb-2 mt-6 font-mono text-[10px] uppercase tracking-[0.14em] text-ink-500">Timing (this browser)</h4>
        <Row k="Tokenise + normalise" v={ms(s.msParse)} />
        <Row k="Diff" v={ms(s.msDiff)} />
        <Row k="Refine, classify, page map" v={ms(s.msRefine)} />
        <Row k="Total" v={<span className="text-signal">{ms(s.msTotal)}</span>} />
      </div>
    </div>
  );
}
