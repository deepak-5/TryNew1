/*
 * Comparison orchestrator for the browser lab: text → tokens → DiffEngine v3 → refinement →
 * classified changes, moves, page map and statistics. The C# pipeline follows the same stages.
 */
import { diff, DiffOp, DiffOptions, EQ, DEL, INS, Kind, heaviestChain, normalizeBlocks } from './diff';
import { shiftBoundaries, semanticCleanup, detectMoves, Move, MoveResult, pairWords, levenshtein, similarity, charDiff, CharSeg } from './refine';
import { MatchMode, flagsFor, matchKey, foldTypography, normalizeNumber } from './normalize';
import { type Box, type GSeg, subBoxes, dropLastChar } from './geo';

/** `boxes` is set when the document came from a PDF: where this token sits on its page(s), display space. */
export interface Tok { i: number; text: string; page: number; line: number; glue: boolean; punct: boolean; gap: boolean; boxes: Box[] | null }
export type Granularity = 'word' | 'sentence' | 'line';

export interface CompareOptions {
  matchMode: MatchMode;
  granularity: Granularity;
  splitPunctuation: boolean;
  alignAcrossPages: boolean;
  ignoreHeadersFooters: boolean;
  dehyphenate: boolean;
  detectMoves: boolean;
  minMoveLength: number;
  cleanup: number;
  shiftBoundaries: boolean;
  phraseAnchors: boolean;
  tokenAnchors: boolean;
  maxCost: number;
}

export const DEFAULT_OPTIONS: CompareOptions = {
  matchMode: 'strict', granularity: 'word', splitPunctuation: true, alignAcrossPages: true,
  ignoreHeadersFooters: true, dehyphenate: true, detectMoves: true, minMoveLength: 5, cleanup: 1,
  shiftBoundaries: true, phraseAnchors: true, tokenAnchors: true, maxCost: 4000,
};

export type ChangeType = 'insert' | 'delete' | 'replace' | 'move' | 'number' | 'spelling' | 'case' | 'punctuation' | 'spacing';
export type Risk = 'critical' | 'high' | 'medium' | 'low' | 'info';
export interface WordPair { del: string; ins: string; chars: CharSeg[] }
export interface Change {
  id: number; type: ChangeType; risk: Risk; del: Tok[]; ins: Tok[]; delText: string; insText: string;
  pageA: number; pageB: number; lineA: number; lineB: number; pairs: WordPair[]; note: string; moveId: number; at: number;
}
export interface Item { kind: Kind; a: Tok | null; b: Tok | null; move: number; change: number }
export interface PageSlot { a: number; b: number; status: 'same' | 'changed' | 'inserted' | 'deleted'; del: number; ins: number; moved: number; wordsA: number; wordsB: number; pct: number }
export interface Stats {
  wordsA: number; wordsB: number; equal: number; deleted: number; inserted: number; moved: number; similarity: number;
  byType: Record<string, number>; byRisk: Record<string, number>;
  hfLines: number; dehyphenated: number; cappedRegions: number; phraseRuns: number; tokenAnchors: number; bisections: number;
  islandsMerged: number; shifted: number; msParse: number; msDiff: number; msRefine: number; msTotal: number;
}
export interface CompareResult {
  tokA: Tok[]; tokB: Tok[]; items: Item[]; changes: Change[]; moves: Move[]; slots: PageSlot[]; stats: Stats;
  pagesA: number; pagesB: number;
}

// ── Parsing ────────────────────────────────────────────────────────────────

/** `geo[i]` (optional, parallel to `words`) is the geometry of word i — present for PDF input. */
export interface RawLine { page: number; line: number; words: string[]; geo?: GSeg[][]; gap: boolean; hf: boolean }
export interface RawDoc { lines: RawLine[]; pages: number }

/** Pages are separated by a form feed or a line like "=== PAGE ===". */
const PAGE_SPLIT = /\n?[ \t]*(?:\f|={3,}[ \t]*page(?:[ \t]*break)?[ \t]*={3,})[ \t]*\n?/i;

export function readDoc(text: string): RawDoc {
  const pages = text.replace(/\r\n?/g, '\n').split(PAGE_SPLIT);
  const lines: RawLine[] = [];
  let line = 0;
  pages.forEach((pg, page) => {
    let gap = false;
    for (const raw of pg.split('\n')) {
      const words = raw.match(/\S+/g);
      line++;
      if (!words) { gap = true; continue; }
      lines.push({ page, line, words, gap, hf: false });
      gap = false;
    }
  });
  return { lines, pages: pages.length };
}

/** First/last line of a page is a header/footer when its digit-masked text repeats on ≥ 50 % of pages (min 3). */
function stripHeadersFooters(doc: RawDoc): number {
  if (doc.pages < 3) return 0;
  const first = new Map<number, RawLine>(), last = new Map<number, RawLine>();
  for (const l of doc.lines) { if (!first.has(l.page)) first.set(l.page, l); last.set(l.page, l); }
  const key = (l: RawLine, top: boolean) => (top ? 'T|' : 'B|') + l.words.join(' ').toLowerCase().replace(/\d+/g, '#');
  const count = new Map<string, number>();
  first.forEach(l => { const k = key(l, true); count.set(k, (count.get(k) ?? 0) + 1); });
  last.forEach(l => { const k = key(l, false); count.set(k, (count.get(k) ?? 0) + 1); });
  const min = Math.max(3, Math.ceil(doc.pages * 0.5));
  let n = 0;
  first.forEach(l => { if (!l.hf && (count.get(key(l, true)) ?? 0) >= min) { l.hf = true; n++; } });
  last.forEach(l => { if (!l.hf && (count.get(key(l, false)) ?? 0) >= min) { l.hf = true; n++; } });
  return n;
}

const edgeStrip = (w: string) => w.toLowerCase().replace(/^\p{P}+/u, '').replace(/\p{P}+$/u, '');

/**
 * Join words hyphenated across a line break. Vocabulary-aware: "well-⏎known" becomes "well-known"
 * (not "wellknown") when the hyphenated compound exists elsewhere in either document and the fused form does not.
 */
function dehyphenate(docs: RawDoc[]): number {
  const vocab = new Set<string>();
  for (const d of docs) for (const l of d.lines) if (!l.hf) for (const w of l.words) vocab.add(edgeStrip(w));
  let n = 0;
  for (const d of docs) {
    const ls = d.lines.filter(l => !l.hf);
    for (let i = 0; i + 1 < ls.length; i++) {
      const cur = ls[i], nxt = ls[i + 1];
      if (cur.page !== nxt.page || nxt.gap || !nxt.words.length || !cur.words.length) continue;
      const w1 = cur.words[cur.words.length - 1];
      if (w1.length < 3 || !/[-\u2010]$/.test(w1)) continue;
      const w2 = nxt.words[0];
      if (!/^\p{Ll}/u.test(w2)) continue;
      const stem = w1.slice(0, -1), joined = stem + w2, hyph = stem + '-' + w2;
      const keepHyphen = vocab.has(edgeStrip(hyph)) && !vocab.has(edgeStrip(joined));
      cur.words[cur.words.length - 1] = keepHyphen ? hyph : joined;
      if (cur.geo && nxt.geo) {
        const g1 = cur.geo[cur.words.length - 1], g2 = nxt.geo[0];
        cur.geo[cur.words.length - 1] = (keepHyphen ? g1 : dropLastChar(g1)).concat(g2);
        nxt.geo.shift();
      }
      nxt.words.shift();
      n++;
    }
  }
  return n;
}

const EDGE = /^(\p{P}*)([\s\S]*?)(\p{P}*)$/u;

/** Words → tokens. Edge punctuation becomes its own (glued) token so "agreement," → "agreement." flags only the comma. Numeric tokens are never split. */
function tokenize(doc: RawDoc, split: boolean): Tok[] {
  const out: Tok[] = [];
  for (const l of doc.lines) {
    if (l.hf) continue;
    let gap = l.gap;
    const mk = (text: string, glue: boolean, punct: boolean, boxes: Box[] | null) => {
      out.push({ i: out.length, text, page: l.page, line: l.line, glue, punct, gap, boxes });
      gap = false;
    };
    for (let wi = 0; wi < l.words.length; wi++) {
      const w = l.words[wi], g = l.geo?.[wi];
      const bx = (a: number, b: number): Box[] | null => (g ? subBoxes(g, a, b) : null);
      const m = split && !/\d/.test(w) ? EDGE.exec(w) : null;
      if (!m || !m[2]) { mk(w, false, !/[\p{L}\p{N}]/u.test(w), bx(0, w.length)); continue; }
      let glue = false, off = 0;
      for (const ch of m[1]) { mk(ch, glue, true, bx(off, off + ch.length)); off += ch.length; glue = true; }
      mk(m[2], glue, false, bx(off, off + m[2].length)); off += m[2].length;
      for (const ch of m[3]) { mk(ch, true, true, bx(off, off + ch.length)); off += ch.length; }
    }
  }
  return out;
}

export function joinToks(toks: Tok[]): string {
  let s = '';
  for (let k = 0; k < toks.length; k++) s += (k && !toks[k].glue ? ' ' : '') + toks[k].text;
  return s;
}

const CLOSER = /^["')\]\u201D\u2019]+$/;
function endsSentence(toks: Tok[], i: number): boolean {
  while (i > 0 && toks[i].glue && CLOSER.test(toks[i].text)) i--;
  return /[.!?]["')\]\u201D\u2019]*$/.test(toks[i].text);
}

/** brk[i] = how natural a change boundary is BEFORE token i. */
function breakScores(toks: Tok[]): Uint8Array {
  const n = toks.length, brk = new Uint8Array(n + 1);
  brk[0] = 6; brk[n] = 6;
  for (let i = 1; i < n; i++) {
    const p = toks[i - 1], t = toks[i];
    let s = 0;
    if (t.glue) s = 0;
    else if (t.page !== p.page) s = 6;
    else if (t.gap) s = 5;
    else {
      if (endsSentence(toks, i - 1)) s = 3; else if (/[,;:]$/.test(p.text)) s = 1;
      if (t.line !== p.line) s += 1;
    }
    brk[i] = s;
  }
  return brk;
}

function groupStarts(toks: Tok[], g: Granularity, lo: number, hi: number): number[] {
  const starts: number[] = [];
  for (let i = lo; i < hi; i++) {
    if (i === lo) { starts.push(i); continue; }
    const p = toks[i - 1], t = toks[i];
    const brk = g === 'line'
      ? t.line !== p.line
      : (!t.glue && endsSentence(toks, i - 1)) || t.gap || t.page !== p.page;
    if (brk) starts.push(i);
  }
  return starts;
}

function pageRanges(toks: Tok[], pages: number): [number, number][] {
  const r: [number, number][] = [];
  let i = 0;
  for (let p = 0; p < pages; p++) { const s = i; while (i < toks.length && toks[i].page === p) i++; r.push([s, i]); }
  return r;
}

// ── Classification ─────────────────────────────────────────────────────────

const RISK_WORDS = new Set(['not', 'no', 'never', 'neither', 'nor', 'none', 'without', 'except', 'unless', 'only',
  'shall', 'must', 'may', 'might', 'will', 'would', 'should', 'can', 'cannot', 'could']);
const STOP = new Set(['that', 'this', 'with', 'from', 'which', 'have', 'been', 'were', 'their', 'such', 'into', 'than']);
const hasDigit = (s: string) => /\d/.test(s);
const parseNum = (s: string): number | null => { const m = s.replace(/[,\s]/g, '').match(/\d+(?:\.\d+)?/); return m ? parseFloat(m[0]) : null; };
const fmtNum = (v: number) => (Math.abs(v) >= 100 ? Math.round(v).toLocaleString('en-US') : String(+v.toFixed(2)));

function classify(del: Tok[], ins: Tok[]): { type: ChangeType; risk: Risk; pairs: WordPair[]; note: string } {
  const pairs: WordPair[] = [];
  let note = '', type: ChangeType, minorEdit = false;
  if (!del.length) type = 'insert';
  else if (!ins.length) type = 'delete';
  else {
    const dT = joinToks(del), iT = joinToks(ins);
    const dW = del.filter(t => !t.punct), iW = ins.filter(t => !t.punct);
    for (const [x, y] of pairWords(dW.map(t => t.text), iW.map(t => t.text)))
      pairs.push({ del: dW[x].text, ins: iW[y].text, chars: charDiff(dW[x].text, iW[y].text) });
    const bare = (s: string) => foldTypography(s).toLowerCase().replace(/[\p{P}\s]/gu, '');
    if (dT.toLowerCase() === iT.toLowerCase()) type = 'case';
    else if (dT.replace(/\s+/g, '') === iT.replace(/\s+/g, '')) type = 'spacing';
    else if (bare(dT) === bare(iT)) type = 'punctuation';
    else if (dW.length > 0 && dW.length === iW.length &&
             dW.every((t, k) => hasDigit(t.text) && normalizeNumber(foldTypography(t.text)) === normalizeNumber(foldTypography(iW[k].text)))) {
      // "$1,250.50" → "$1250.5": the value is the same, only the formatting moved. ("3.1" → "3.10" does NOT land here.)
      type = 'punctuation';
      note = 'same value, different formatting';
    }
    else if (dW.length > 0 && dW.length === iW.length && dW.every(t => hasDigit(t.text)) && iW.every(t => hasDigit(t.text))) {
      type = 'number';
      if (dW.length === 1) {
        const x = parseNum(dW[0].text), y = parseNum(iW[0].text);
        if (x !== null && y !== null && x !== 0 && x !== y) {
          const d = y - x;
          note = `${d > 0 ? '+' : '−'}${fmtNum(Math.abs(d))} (${d > 0 ? '+' : '−'}${fmtNum(Math.abs(d / x) * 100)}%)`;
        }
      }
    } else if (dW.length === 1 && iW.length === 1 && levenshtein(dW[0].text, iW[0].text) <= 2 && similarity(dW[0].text, iW[0].text) >= 0.6) {
      type = 'spelling';
      minorEdit = levenshtein(dW[0].text, iW[0].text) <= 1;
    } else type = 'replace';
  }
  const all = del.concat(ins);
  let risk: Risk;
  if (type === 'case' || type === 'punctuation' || type === 'spacing') risk = 'low';
  else if (all.some(t => hasDigit(t.text))) risk = 'critical';
  else if (all.some(t => RISK_WORDS.has(t.text.toLowerCase()))) risk = 'high';
  else if (all.every(t => t.punct) || minorEdit) risk = 'low';
  else risk = 'medium';
  return { type, risk, pairs, note };
}

// ── Page map ───────────────────────────────────────────────────────────────

/**
 * Page alignment derived from the word alignment itself: every equal word votes for (beforePage, afterPage);
 * the heaviest monotone chain of page pairs wins; gaps with equal page counts are paired in order;
 * everything else is an inserted / deleted page.
 */
function buildSlots(items: Item[], tokA: Tok[], tokB: Tok[], pagesA: number, pagesB: number, align: boolean): PageSlot[] {
  const wA = new Int32Array(pagesA), wB = new Int32Array(pagesB);
  for (const t of tokA) wA[t.page]++;
  for (const t of tokB) wB[t.page]++;
  let pairs: [number, number][] = [];
  if (!align) {
    for (let p = 0; p < Math.min(pagesA, pagesB); p++) pairs.push([p, p]);
  } else {
    const votes = new Map<number, number>();
    for (const it of items) if (it.kind === EQ) { const k = it.a!.page * pagesB + it.b!.page; votes.set(k, (votes.get(k) ?? 0) + 1); }
    const aS: number[] = [], bS: number[] = [], one: number[] = [], w: number[] = [];
    votes.forEach((v, k) => {
      const i = Math.floor(k / pagesB), j = k % pagesB;
      if (v >= Math.max(1, 0.15 * Math.min(wA[i], wB[j]))) { aS.push(i); bS.push(j); one.push(1); w.push(v); }
    });
    pairs = heaviestChain(aS, bS, one, w).map(i => [aS[i], bS[i]] as [number, number]);
  }
  const seq: [number, number][] = [];
  let pi = 0, pj = 0;
  const gap = (i1: number, j1: number) => {
    const ca = i1 - pi, cb = j1 - pj;
    if (ca === cb) for (let k = 0; k < ca; k++) seq.push([pi + k, pj + k]);
    else { for (let k = pi; k < i1; k++) seq.push([k, -1]); for (let k = pj; k < j1; k++) seq.push([-1, k]); }
  };
  for (const [i, j] of pairs) { gap(i, j); seq.push([i, j]); pi = i + 1; pj = j + 1; }
  gap(pagesA, pagesB);

  const dA = new Int32Array(pagesA), mA = new Int32Array(pagesA), iB = new Int32Array(pagesB), mB = new Int32Array(pagesB);
  for (const it of items) {
    if (it.kind === DEL) (it.move >= 0 ? mA : dA)[it.a!.page]++;
    else if (it.kind === INS) (it.move >= 0 ? mB : iB)[it.b!.page]++;
  }
  return seq.map(([a, b]) => {
    const del = a >= 0 ? dA[a] : 0, ins = b >= 0 ? iB[b] : 0, moved = (a >= 0 ? mA[a] : 0) + (b >= 0 ? mB[b] : 0);
    const wordsA = a >= 0 ? wA[a] : 0, wordsB = b >= 0 ? wB[b] : 0;
    const status = a < 0 ? 'inserted' : b < 0 ? 'deleted' : del + ins + moved > 0 ? 'changed' : 'same';
    return { a, b, status, del, ins, moved, wordsA, wordsB, pct: (del + ins + moved) / Math.max(1, wordsA + wordsB) };
  });
}

// ── Main entry ─────────────────────────────────────────────────────────────

const now = () => performance.now();

export function compare(textA: string, textB: string, o: CompareOptions): CompareResult {
  return compareRaw(readDoc(textA), readDoc(textB), o);
}

const cloneDoc = (d: RawDoc): RawDoc => ({ pages: d.pages, lines: d.lines.map(l => ({ ...l, words: l.words.slice(), geo: l.geo?.slice() })) });

/** Same as compare() but on structured documents (e.g. read from PDFs with word geometry). The inputs are not modified. */
export function compareRaw(rawA: RawDoc, rawB: RawDoc, o: CompareOptions): CompareResult {
  const t0 = now();
  const flags = flagsFor(o.matchMode);
  const dA = cloneDoc(rawA), dB = cloneDoc(rawB);
  const hfLines = o.ignoreHeadersFooters ? stripHeadersFooters(dA) + stripHeadersFooters(dB) : 0;
  const dehyphenated = o.dehyphenate ? dehyphenate([dA, dB]) : 0;
  const split = o.splitPunctuation && !flags.edgePunct;
  const tokA = tokenize(dA, split), tokB = tokenize(dB, split);

  const intern = new Map<string, number>();
  const idOf = (key: string) => { let id = intern.get(key); if (id === undefined) intern.set(key, id = intern.size); return id; };
  const idsA = Int32Array.from(tokA, t => idOf(matchKey(t.text, flags)));
  const idsB = Int32Array.from(tokB, t => idOf(matchKey(t.text, flags)));
  const t1 = now();

  const dopts: DiffOptions = { maxCost: o.maxCost, phraseAnchors: o.phraseAnchors, tokenAnchors: o.tokenAnchors };
  let ops: DiffOp[] = [];
  let cappedRegions = 0, phraseRuns = 0, tokenAnchors = 0, bisections = 0;
  const groupIntern = new Map<string, number>();

  const run = (a0: number, a1: number, b0: number, b1: number) => {
    let r;
    if (o.granularity === 'word') {
      r = diff(idsA.subarray(a0, a1), idsB.subarray(b0, b1), dopts);
      for (const op of r.ops) ops.push({ kind: op.kind, a: op.a < 0 ? -1 : op.a + a0, b: op.b < 0 ? -1 : op.b + b0 });
    } else {
      const gA = groupStarts(tokA, o.granularity, a0, a1), gB = groupStarts(tokB, o.granularity, b0, b1);
      const comp = (ids: Int32Array, starts: number[], end: number) => Int32Array.from(starts, (s, k) => {
        const key = ids.subarray(s, k + 1 < starts.length ? starts[k + 1] : end).join(',');
        let id = groupIntern.get(key);
        if (id === undefined) groupIntern.set(key, id = groupIntern.size);
        return id;
      });
      r = diff(comp(idsA, gA, a1), comp(idsB, gB, b1), dopts);
      const endA = (k: number) => (k + 1 < gA.length ? gA[k + 1] : a1), endB = (k: number) => (k + 1 < gB.length ? gB[k + 1] : b1);
      for (const op of r.ops) {
        if (op.kind === EQ) for (let k = 0, n = endA(op.a) - gA[op.a]; k < n; k++) ops.push({ kind: EQ, a: gA[op.a] + k, b: gB[op.b] + k });
        else if (op.kind === DEL) for (let q = gA[op.a]; q < endA(op.a); q++) ops.push({ kind: DEL, a: q, b: -1 });
        else for (let q = gB[op.b]; q < endB(op.b); q++) ops.push({ kind: INS, a: -1, b: q });
      }
    }
    cappedRegions += r.cappedRegions; phraseRuns += r.phraseRuns; tokenAnchors += r.tokenAnchors; bisections += r.bisections;
  };

  if (o.alignAcrossPages) run(0, tokA.length, 0, tokB.length);
  else {
    const ra = pageRanges(tokA, dA.pages), rb = pageRanges(tokB, dB.pages);
    for (let p = 0; p < Math.max(dA.pages, dB.pages); p++) {
      const [a0, a1] = ra[p] ?? [tokA.length, tokA.length], [b0, b1] = rb[p] ?? [tokB.length, tokB.length];
      run(a0, a1, b0, b1);
    }
  }
  const t2 = now();

  let shifted = 0, islandsMerged = 0;
  if (o.granularity === 'word') {
    if (o.shiftBoundaries) shifted = shiftBoundaries(ops, idsA, idsB, breakScores(tokA), breakScores(tokB));
    if (o.cleanup > 0) {
      const low = (ai: number) => { const t = tokA[ai]; return t.punct || t.text.length <= 3 || STOP.has(t.text.toLowerCase()); };
      const c = semanticCleanup(ops, o.cleanup, low);
      ops = c.ops; islandsMerged = c.merged;
    }
  }
  normalizeBlocks(ops);
  const mv: MoveResult = o.detectMoves
    ? detectMoves(ops, idsA, idsB, o.minMoveLength)
    : { moves: [], moveOfA: new Int32Array(tokA.length).fill(-1), moveOfB: new Int32Array(tokB.length).fill(-1) };

  const items: Item[] = ops.map(op => ({
    kind: op.kind, a: op.a >= 0 ? tokA[op.a] : null, b: op.b >= 0 ? tokB[op.b] : null,
    move: op.kind === DEL ? mv.moveOfA[op.a] : op.kind === INS ? mv.moveOfB[op.b] : -1, change: -1,
  }));

  // Group into changes: one per contiguous block of non-moved edits, plus one per move.
  interface Proto { at: number; idx: number[]; del: Tok[]; ins: Tok[]; moveId: number; ctxA: Tok | null; ctxB: Tok | null }
  const protos: Proto[] = [];
  const moveProto = new Map<number, Proto>();
  let lastA: Tok | null = null, lastB: Tok | null = null;
  for (let i = 0; i < items.length;) {
    if (items[i].kind === EQ) { lastA = items[i].a; lastB = items[i].b; i++; continue; }
    const core: Proto = { at: i, idx: [], del: [], ins: [], moveId: -1, ctxA: lastA, ctxB: lastB };
    let j = i;
    for (; j < items.length && items[j].kind !== EQ; j++) {
      const x = items[j];
      let p = core;
      if (x.move >= 0) {
        p = moveProto.get(x.move)!;
        if (!p) { p = { at: j, idx: [], del: [], ins: [], moveId: x.move, ctxA: lastA, ctxB: lastB }; moveProto.set(x.move, p); protos.push(p); }
        if (x.kind === INS && !p.ins.length) p.at = j;
      }
      p.idx.push(j);
      if (x.kind === DEL) { p.del.push(x.a!); lastA = x.a; } else { p.ins.push(x.b!); lastB = x.b; }
    }
    if (core.idx.length) protos.push(core);
    i = j;
  }
  protos.sort((p, q) => p.at - q.at);
  const byType: Record<string, number> = {}, byRisk: Record<string, number> = {};
  const changes: Change[] = protos.map((p, id) => {
    for (const k of p.idx) items[k].change = id;
    const c = p.moveId >= 0 ? { type: 'move' as ChangeType, risk: 'info' as Risk, pairs: [], note: '' } : classify(p.del, p.ins);
    byType[c.type] = (byType[c.type] ?? 0) + 1;
    byRisk[c.risk] = (byRisk[c.risk] ?? 0) + 1;
    return {
      id, type: c.type, risk: c.risk, del: p.del, ins: p.ins, delText: joinToks(p.del), insText: joinToks(p.ins),
      pageA: p.del[0]?.page ?? p.ctxA?.page ?? 0, pageB: p.ins[0]?.page ?? p.ctxB?.page ?? 0,
      lineA: p.del[0]?.line ?? p.ctxA?.line ?? 0, lineB: p.ins[0]?.line ?? p.ctxB?.line ?? 0,
      pairs: c.pairs, note: c.note, moveId: p.moveId, at: p.at,
    };
  });

  let equal = 0, deleted = 0, inserted = 0, moved = 0;
  for (const it of items) {
    if (it.kind === EQ) equal++;
    else if (it.move >= 0) { if (it.kind === INS) moved++; }
    else if (it.kind === DEL) deleted++; else inserted++;
  }
  const slots = buildSlots(items, tokA, tokB, dA.pages, dB.pages, o.alignAcrossPages);
  const t3 = now();
  const total = tokA.length + tokB.length;

  return {
    tokA, tokB, items, changes, moves: mv.moves, slots, pagesA: dA.pages, pagesB: dB.pages,
    stats: {
      wordsA: tokA.length, wordsB: tokB.length, equal, deleted, inserted, moved,
      similarity: total ? (2 * equal) / total : 1, byType, byRisk, hfLines, dehyphenated,
      cappedRegions, phraseRuns, tokenAnchors, bisections, islandsMerged, shifted,
      msParse: t1 - t0, msDiff: t2 - t1, msRefine: t3 - t2, msTotal: t3 - t0,
    },
  };
}
