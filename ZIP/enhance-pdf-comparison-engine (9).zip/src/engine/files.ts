/*
 * Browser file loading: detects the format from magic bytes (extension as fallback), extracts text in the lab format.
 * pdf.js is loaded on first use; its worker source is inlined and started from a Blob URL so the single-file build
 * works offline without extra assets.
 */
import { docxXmlToText, extractDocxXml } from './docx';
import { extractPdf, extractToRaw, type PdfPageData } from './pdf';
import { docxXmlToMarkdown, markdownToPureHtml, pdfExtractToMarkdown } from './markdown';
import type { RawDoc } from './compare';

export type DocKind = 'pdf' | 'docx' | 'text';
export interface LoadedDoc {
  name: string; kind: DocKind; text: string; pages: number; words: number; warnings: string[]; details: string;
  /** Structured Markdown and Pure HTML extracted while preserving layout (headings, lists, tables, styles). */
  markdown?: string; html?: string;
  /** PDF only: original bytes (for the PDF writers), word geometry (for the comparison) and per-page layout info. */
  bytes?: Uint8Array; raw?: RawDoc; pdf?: PdfPageData[];
}

type PdfJs = typeof import('pdfjs-dist/legacy/build/pdf.mjs');
let pdfjsPromise: Promise<PdfJs> | null = null;

export function getPdfJs(): Promise<PdfJs> {
  pdfjsPromise ??= (async () => {
    const [lib, worker] = await Promise.all([
      import('pdfjs-dist/legacy/build/pdf.mjs'),
      import('pdfjs-dist/legacy/build/pdf.worker.min.mjs?raw'),
    ]);
    lib.GlobalWorkerOptions.workerSrc = URL.createObjectURL(new Blob([worker.default], { type: 'text/javascript' }));
    return lib;
  })().catch(e => { pdfjsPromise = null; throw e; });
  return pdfjsPromise;
}

const countWords = (t: string) => (t.match(/\S+/g) ?? []).filter(w => !/^={3,}$/.test(w) && w.toUpperCase() !== 'PAGE').length;
const plural = (n: number, w: string) => `${n} ${w}${n === 1 ? '' : 's'}`;
const MAX_BYTES = 150 * 1024 * 1024;

export async function loadDocument(file: File, onProgress?: (msg: string) => void): Promise<LoadedDoc> {
  if (file.size > MAX_BYTES) throw new Error(`File is ${(file.size / 1048576).toFixed(0)} MB — the browser lab accepts up to 150 MB.`);
  const buf = new Uint8Array(await file.arrayBuffer());
  const name = file.name, ext = (name.split('.').pop() ?? '').toLowerCase();
  const head = String.fromCharCode(...buf.subarray(0, 1024));
  const isPdf = head.includes('%PDF-');
  const isZip = buf[0] === 0x50 && buf[1] === 0x4b;
  const isOle = buf[0] === 0xd0 && buf[1] === 0xcf && buf[2] === 0x11 && buf[3] === 0xe0;

  if (isPdf || ext === 'pdf') {
    onProgress?.('Loading PDF engine…');
    const lib = await getPdfJs();
    let doc;
    try {
      doc = await lib.getDocument({ data: buf.slice(), isEvalSupported: false, stopAtErrors: false }).promise; // slice(): pdf.js transfers (detaches) the buffer it is given
    } catch (e) {
      const n = (e as { name?: string })?.name;
      if (n === 'PasswordException') throw new Error('This PDF is password-protected. Remove the password and load it again.');
      if (n === 'InvalidPDFException') throw new Error('This file is not a readable PDF (it may be damaged).');
      throw e;
    }
    try {
      const r = await extractPdf(doc, (d, t) => onProgress?.(`Reading page ${d} of ${t}`));
      const warnings: string[] = [];
      if (r.emptyPages.length === r.pages.length) warnings.push('No extractable text on any page — this looks like a scanned PDF. The browser lab does not run OCR; the C# engine compares such pages as images.');
      else if (r.emptyPages.length) warnings.push(`${plural(r.emptyPages.length, 'page')} without text (${r.emptyPages.slice(0, 12).join(', ')}${r.emptyPages.length > 12 ? ', …' : ''}) — probably scanned images or drawings. They stay in the page count but contribute no words.`);
      const markdown = pdfExtractToMarkdown(r);
      const html = markdownToPureHtml(markdown);
      return { name, kind: 'pdf', text: r.text, markdown, html, pages: r.pages.length, words: countWords(r.text), warnings, details: plural(r.pages.length, 'page'), bytes: buf, raw: extractToRaw(r), pdf: r.pages };
    } finally {
      void doc.destroy();
    }
  }

  if (isOle || ext === 'doc') throw new Error('Legacy .doc (Word 97–2003) files are not supported. Open the file in Word and save it as .docx.');

  if (isZip || ext === 'docx' || ext === 'docm') {
    onProgress?.('Reading Word document…');
    const xml = extractDocxXml(buf);
    const r = docxXmlToText(xml);
    const markdown = docxXmlToMarkdown(xml);
    const html = markdownToPureHtml(markdown);
    const warnings: string[] = [];
    if (r.trackedChanges) warnings.push(`Contains ${plural(r.trackedChanges, 'tracked change')} — read as if all were accepted.`);
    if (!r.text.trim()) warnings.push('The document body contains no text.');
    const details = [plural(r.pages, 'page') + (r.renderedBreaks || r.pages === 1 ? '' : ' (by page breaks)'), r.tables ? plural(r.tables, 'table') : ''].filter(Boolean).join(' · ');
    return { name, kind: 'docx', text: r.text, markdown, html, pages: r.pages, words: countWords(r.text), warnings, details };
  }

  // Plain text: honour UTF-16 byte-order marks, otherwise UTF-8.
  const enc = buf[0] === 0xff && buf[1] === 0xfe ? 'utf-16le' : buf[0] === 0xfe && buf[1] === 0xff ? 'utf-16be' : 'utf-8';
  const text = new TextDecoder(enc).decode(buf).replace(/^\uFEFF/, '');
  if (/[\u0000-\u0008\u000E-\u001A]/.test(text.slice(0, 4000))) throw new Error('Unsupported file type. Load a PDF, a Word .docx or a plain-text file.');
  const pages = text.split(/\n?[ \t]*(?:\f|={3,}[ \t]*page(?:[ \t]*break)?[ \t]*={3,})[ \t]*\n?/i).length;
  const html = markdownToPureHtml(text);
  return { name, kind: 'text', text, markdown: text, html, pages, words: countWords(text), warnings: [], details: plural(pages, 'page') };
}
