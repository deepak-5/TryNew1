/*
 * Post-processing passes that turn a minimal edit script into a human-grade one.
 * Mirrors csharp/PdfComparer.DiffRefine.cs.
 */
import { diff, DiffOp, EQ, DEL, INS, Kind, Seq, gramKey, normalizeBlocks } from './diff';

/**
 * Slide pure insert / pure delete blocks to the most natural boundary.
 * brk[i] scores the boundary BEFORE token i (length = tokens + 1): sentence start, paragraph start, …
 * Returns the number of blocks that moved.
 */
export function shiftBoundaries(ops: DiffOp[], a: Seq, b: Seq, brkA: Seq, brkB: Seq): number {
  const n = ops.length;
  let shifted = 0, i = 0;
  while (i < n) {
    if (ops[i].kind === EQ) { i++; continue; }
    const kind = ops[i].kind;
    let j = i, pure = true;
    while (j < n && ops[j].kind !== EQ) { if (ops[j].kind !== kind) pure = false; j++; }
    if (!pure) { i = j; continue; }

    const isIns = kind === INS;
    const t = isIns ? b : a, brk = isIns ? brkB : brkA;
    const len = j - i;
    const q0 = isIns ? ops[i].b : ops[i].a, q1 = q0 + len;
    let L = 0, R = 0;
    while (i - 1 - L >= 0 && ops[i - 1 - L].kind === EQ && t[q0 - 1 - L] === t[q1 - 1 - L]) L++;
    while (j + R < n && ops[j + R].kind === EQ && t[q0 + R] === t[q1 + R]) R++;
    if (L === 0 && R === 0) { i = j; continue; }

    let bestP = 0, bestS = brk[q0] + brk[q1];
    for (let p = -L; p <= R; p++) {
      const s = brk[q0 + p] + brk[q1 + p];
      if (s > bestS || (s === bestS && p > bestP)) { bestS = s; bestP = p; }
    }
    if (bestP === 0) { i = j; continue; }
    shifted++;

    const mk = (q: number): DiffOp => isIns ? { kind: INS, a: -1, b: q } : { kind: DEL, a: q, b: -1 };
    if (bestP < 0) {
      const s = -bestP;
      const moved = ops.slice(i - s, i);
      for (let k = 0; k < len; k++) ops[i - s + k] = mk(q0 - s + k);
      for (let k = 0; k < s; k++) {
        const m = moved[k];
        ops[j - s + k] = isIns ? { kind: EQ, a: m.a, b: m.b + len } : { kind: EQ, a: m.a + len, b: m.b };
      }
      i = j;
    } else {
      const p = bestP;
      const moved = ops.slice(j, j + p);
      for (let k = 0; k < p; k++) {
        const m = moved[k];
        ops[i + k] = isIns ? { kind: EQ, a: m.a, b: m.b - len } : { kind: EQ, a: m.a - len, b: m.b };
      }
      for (let k = 0; k < len; k++) ops[i + p + k] = mk(q0 + p + k);
      i = j + p;
    }
  }
  if (shifted) normalizeBlocks(ops);
  return shifted;
}

/**
 * Remove coincidental equalities ("the", "of", ",") stranded between two larger edits so a rewritten
 * phrase reads as ONE replacement instead of confetti.
 * level 1 (conservative): island ≤ 2 low-information tokens, both neighbours ≥ 2× the island.
 * level 2 (aggressive):   island ≤ 4 tokens, both neighbours ≥ the island.
 */
export function semanticCleanup(ops: DiffOp[], level: number, lowInfoA?: (aIndex: number) => boolean): { ops: DiffOp[]; merged: number } {
  let merged = 0;
  if (level <= 0) return { ops, merged };
  for (let pass = 0; pass < 4; pass++) {
    const segs: { eq: boolean; s: number; e: number; size: number }[] = [];
    for (let i = 0; i < ops.length;) {
      const eq = ops[i].kind === EQ;
      let j = i, d = 0, ins = 0;
      while (j < ops.length && (ops[j].kind === EQ) === eq) { if (ops[j].kind === DEL) d++; else if (ops[j].kind === INS) ins++; j++; }
      segs.push({ eq, s: i, e: j, size: Math.max(d, ins) });
      i = j;
    }
    const kill = new Uint8Array(segs.length);
    let any = false;
    for (let k = 1; k + 1 < segs.length; k++) {
      const g = segs[k];
      if (!g.eq) continue;
      const len = g.e - g.s, ls = segs[k - 1].size, rs = segs[k + 1].size;
      let ok: boolean;
      if (level === 1) {
        ok = len <= 2 && ls >= 2 * len && rs >= 2 * len;
        if (ok && lowInfoA) for (let q = g.s; q < g.e; q++) if (!lowInfoA(ops[q].a)) { ok = false; break; }
      } else ok = len <= 4 && len <= ls && len <= rs;
      if (ok) { kill[k] = 1; any = true; merged++; }
    }
    if (!any) break;
    const out: DiffOp[] = [];
    for (let k = 0; k < segs.length; k++) {
      const g = segs[k];
      if (!kill[k]) { for (let q = g.s; q < g.e; q++) out.push(ops[q]); continue; }
      for (let q = g.s; q < g.e; q++) out.push({ kind: DEL, a: ops[q].a, b: -1 });
      for (let q = g.s; q < g.e; q++) out.push({ kind: INS, a: -1, b: ops[q].b });
    }
    normalizeBlocks(out);
    ops = out;
  }
  return { ops, merged };
}

export interface Move { id: number; aStart: number; bStart: number; len: number }
export interface MoveResult { moves: Move[]; moveOfA: Int32Array; moveOfB: Int32Array }

/**
 * Block-move detection: deleted runs that reappear verbatim among the inserted tokens.
 * Seeds on k-grams (k = minLen) that lie entirely inside deleted / inserted runs, extends greedily,
 * takes the longest candidate, never claims a token twice.
 */
export function detectMoves(ops: DiffOp[], a: Seq, b: Seq, minLen: number): MoveResult {
  const moveOfA = new Int32Array(a.length).fill(-1), moveOfB = new Int32Array(b.length).fill(-1);
  const moves: Move[] = [];
  const K = Math.max(2, minLen);
  const isDel = new Uint8Array(a.length), isIns = new Uint8Array(b.length);
  for (const o of ops) { if (o.kind === DEL) isDel[o.a] = 1; else if (o.kind === INS) isIns[o.b] = 1; }
  const delRun = new Int32Array(a.length + 1), insRun = new Int32Array(b.length + 1);
  for (let i = a.length - 1; i >= 0; i--) delRun[i] = isDel[i] ? delRun[i + 1] + 1 : 0;
  for (let j = b.length - 1; j >= 0; j--) insRun[j] = isIns[j] ? insRun[j + 1] + 1 : 0;

  const index = new Map<number, number[]>();
  for (let j = 0; j + K <= b.length; j++) {
    if (insRun[j] < K) continue;
    const h = gramKey(b, j, K);
    let l = index.get(h);
    if (!l) index.set(h, l = []);
    if (l.length < 16) l.push(j);
  }
  if (!index.size) return { moves, moveOfA, moveOfB };

  for (let i = 0; i + K <= a.length;) {
    if (delRun[i] < K) { i++; continue; }
    const cands = index.get(gramKey(a, i, K));
    let bestLen = 0, bestJ = -1;
    if (cands) for (const j of cands) {
      let len = 0;
      while (i + len < a.length && j + len < b.length && isDel[i + len] && isIns[j + len] &&
             moveOfB[j + len] < 0 && a[i + len] === b[j + len]) len++;
      if (len > bestLen) { bestLen = len; bestJ = j; }
    }
    if (bestLen >= K) {
      const id = moves.length;
      moves.push({ id, aStart: i, bStart: bestJ, len: bestLen });
      for (let k = 0; k < bestLen; k++) { moveOfA[i + k] = id; moveOfB[bestJ + k] = id; }
      i += bestLen;
    } else i++;
  }
  return { moves, moveOfA, moveOfB };
}

export function levenshtein(s: string, t: string): number {
  if (s === t) return 0;
  if (!s.length) return t.length;
  if (!t.length) return s.length;
  let prev = new Int32Array(t.length + 1), cur = new Int32Array(t.length + 1);
  for (let j = 0; j <= t.length; j++) prev[j] = j;
  for (let i = 1; i <= s.length; i++) {
    cur[0] = i;
    const c = s.charCodeAt(i - 1);
    for (let j = 1; j <= t.length; j++) {
      const sub = prev[j - 1] + (c === t.charCodeAt(j - 1) ? 0 : 1);
      cur[j] = Math.min(sub, prev[j] + 1, cur[j - 1] + 1);
    }
    const tmp = prev; prev = cur; cur = tmp;
  }
  return prev[t.length];
}

export function similarity(s: string, t: string): number {
  const m = Math.max(s.length, t.length);
  return m === 0 ? 1 : 1 - levenshtein(s, t) / m;
}

export interface CharSeg { k: Kind; s: string }

/** Character-level diff of two words (used to highlight only the characters that changed). */
export function charDiff(s: string, t: string): CharSeg[] {
  const a = Array.from(s), b = Array.from(t);
  const r = diff(a.map(c => c.codePointAt(0)!), b.map(c => c.codePointAt(0)!), { phraseAnchors: false, tokenAnchors: false, maxCost: 512 });
  const out: CharSeg[] = [];
  for (const o of r.ops) {
    const ch = o.kind === INS ? b[o.b] : a[o.a];
    const last = out[out.length - 1];
    if (last && last.k === o.kind) last.s += ch; else out.push({ k: o.kind, s: ch });
  }
  return out;
}

/**
 * Order-preserving pairing of deleted words with inserted words inside one replacement block
 * (similarity-weighted alignment). Returns [delIndex, insIndex, similarity] triples.
 */
export function pairWords(dels: string[], ins: string[], minSim = 0.5): [number, number, number][] {
  const n = dels.length, m = ins.length;
  if (!n || !m || n * m > 4096) return [];
  const sim = new Float64Array(n * m);
  for (let i = 0; i < n; i++) for (let j = 0; j < m; j++) sim[i * m + j] = similarity(dels[i].toLowerCase(), ins[j].toLowerCase());
  const W = m + 1;
  const S = new Float64Array((n + 1) * W);
  for (let i = 1; i <= n; i++) for (let j = 1; j <= m; j++) {
    let v = Math.max(S[(i - 1) * W + j], S[i * W + j - 1]);
    const s = sim[(i - 1) * m + j - 1];
    if (s >= minSim) v = Math.max(v, S[(i - 1) * W + j - 1] + s);
    S[i * W + j] = v;
  }
  const out: [number, number, number][] = [];
  let i = n, j = m;
  while (i > 0 && j > 0) {
    const v = S[i * W + j], s = sim[(i - 1) * m + j - 1];
    if (s >= minSim && Math.abs(v - (S[(i - 1) * W + j - 1] + s)) < 1e-12) { out.push([i - 1, j - 1, s]); i--; j--; }
    else if (v === S[(i - 1) * W + j]) i--;
    else j--;
  }
  return out.reverse();
}
