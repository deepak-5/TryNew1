/*
 * View-model builders: turn the item stream into line / row structures for each comparison mode.
 */
import { EQ, DEL, INS, Kind } from './diff';
import { Item, Tok, joinToks } from './compare';

/** A run of adjacent tokens with identical styling. `sp` = render a space before it. */
export interface Seg { kind: Kind; move: number; change: number; text: string; sp: boolean; at: number }

function pushTok(segs: Seg[], it: Item, tok: Tok, at: number, kind: Kind): void {
  const last = segs[segs.length - 1];
  const sp = segs.length > 0 && !tok.glue;
  if (last && last.kind === kind && last.move === it.move && last.change === it.change && last.text !== '') {
    last.text += (sp ? ' ' : '') + tok.text;
  } else segs.push({ kind, move: it.move, change: it.change, text: tok.text, sp, at });
}

// ── Redline (inline track changes, flows along the AFTER document's lines) ──

export interface RedLine { page: number; lineNo: number; gap: boolean; segs: Seg[]; changed: boolean }

export function buildRedline(items: Item[]): RedLine[] {
  const lines: RedLine[] = [];
  let cur: RedLine | null = null, lastB = -1, lastA = -1, lastKind = -1;
  items.forEach((it, i) => {
    const tok = (it.b ?? it.a)!;
    const nl = it.b ? it.b.line !== lastB : (lastKind === DEL && it.a!.line !== lastA) || (it.a!.gap && cur !== null);
    if (!cur || nl) { cur = { page: tok.page, lineNo: it.b ? it.b.line : -1, gap: tok.gap, segs: [], changed: false }; lines.push(cur); }
    pushTok(cur.segs, it, tok, i, it.kind);
    if (it.kind !== EQ) cur.changed = true;
    if (it.b) lastB = it.b.line;
    if (it.kind === DEL) lastA = it.a!.line;
    lastKind = it.kind;
  });
  return lines;
}

// ── Side-by-side / unified rows ────────────────────────────────────────────

export interface Row { left: Seg[]; right: Seg[]; changed: boolean; la: number; lb: number; pa: number; pb: number; gap: boolean }

/**
 * Rows are synchronised line groups: a new row starts only where BOTH documents start a new line,
 * so pure re-wrapping collapses into paragraph-sized rows instead of producing misaligned lines.
 */
export function buildRows(items: Item[], tokA: Tok[], tokB: Tok[]): Row[] {
  const rows: Row[] = [];
  let cur: Row | null = null, lastA: Tok | null = null, lastB: Tok | null = null;
  const atEnd = (last: Tok | null, toks: Tok[]) => !last || last.i + 1 >= toks.length || toks[last.i + 1].line !== last.line;
  items.forEach((it, i) => {
    const aNew = !!it.a && (!lastA || it.a.line !== lastA.line);
    const bNew = !!it.b && (!lastB || it.b.line !== lastB.line);
    const brk = !cur || (it.kind === EQ ? aNew && bNew : it.kind === DEL ? aNew && atEnd(lastB, tokB) : bNew && atEnd(lastA, tokA));
    if (brk) {
      cur = { left: [], right: [], changed: false, la: -1, lb: -1, pa: -1, pb: -1, gap: !!(it.b ?? it.a)!.gap };
      rows.push(cur);
    }
    const row = cur!;
    if (it.a) { if (row.la < 0) { row.la = it.a.line; row.pa = it.a.page; } pushTok(row.left, it, it.a, i, it.kind); lastA = it.a; }
    if (it.b) { if (row.lb < 0) { row.lb = it.b.line; row.pb = it.b.page; } pushTok(row.right, it, it.b, i, it.kind); lastB = it.b; }
    if (it.kind !== EQ) row.changed = true;
  });
  return rows;
}

// ── Overlay (after-document with insertions in place and deletions as margin callouts) ──

export interface Callout { change: number; text: string; moved: boolean; at: number }
export interface OverlayLine { page: number; lineNo: number; gap: boolean; segs: Seg[]; callouts: Callout[] }

export function buildOverlay(items: Item[]): OverlayLine[] {
  const lines: OverlayLine[] = [];
  let cur: OverlayLine | null = null, lastB = -1;
  let pending: { callouts: Callout[]; carets: Seg[] } = { callouts: [], carets: [] };
  for (let i = 0; i < items.length; i++) {
    const it = items[i];
    if (it.kind === DEL) {
      let j = i;
      const toks: Tok[] = [];
      while (j < items.length && items[j].kind === DEL && items[j].change === it.change) toks.push(items[j++].a!);
      const callout: Callout = { change: it.change, text: joinToks(toks), moved: it.move >= 0, at: i };
      const caret: Seg = { kind: DEL, move: it.move, change: it.change, text: '', sp: false, at: i };
      if (cur) { cur.callouts.push(callout); cur.segs.push(caret); }
      else { pending.callouts.push(callout); pending.carets.push(caret); }
      i = j - 1;
      continue;
    }
    const b = it.b!;
    if (!cur || b.line !== lastB) {
      cur = { page: b.page, lineNo: b.line, gap: b.gap, segs: pending.carets, callouts: pending.callouts };
      pending = { callouts: [], carets: [] };
      lines.push(cur);
    }
    pushTok(cur.segs, it, b, i, it.kind);
    lastB = b.line;
  }
  if (pending.callouts.length) lines.push({ page: 0, lineNo: -1, gap: false, segs: pending.carets, callouts: pending.callouts });
  return lines;
}

export { EQ, DEL, INS };
