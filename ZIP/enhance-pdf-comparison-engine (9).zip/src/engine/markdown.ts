/*
 * Structured PDF / Word → Markdown → Pure HTML pipeline and HTML-aware diff stitching.
 *
 * Pipeline:
 *   1. pdfExtractToMarkdown(ex)  — reconstructs headings (#/##/###), **bold** / *italic* / `code`,
 *                                  bullet & numbered lists, blockquotes, GFM pipe tables, unwrapped
 *                                  paragraphs (with dehyphenation) and page breaks (<!-- page: N -->).
 *   2. markdownToPureHtml(md)    — converts Markdown → pure semantic HTML using `marked` (GFM) and
 *                                  sanitizes it (DOMPurify in browser, strict allowlist in Node).
 *   3. compareHtml(htmlA, htmlB) — parses both HTML documents into structural blocks, runs DiffEngine v3
 *                                  via compareRaw, and stitches <ins>/<del>/move highlights back into
 *                                  both the inline HTML Redline and Side-by-Side HTML views.
 */
import { marked } from 'marked';
import DOMPurify from 'dompurify';
import { compareRaw, joinToks, type CompareOptions, type CompareResult, type RawDoc, type RawLine, type Tok } from './compare';
import { DEL, EQ, INS } from './diff';
import type { PdfExtract, PdfLine, PdfWord } from './pdf';

// ── 1. PDF Extract → Markdown ───────────────────────────────────────────────

function wordBounds(w: PdfWord): { x0: number; x1: number; yb: number; h: number } {
  const seg = w.geo[0];
  if (!seg) return { x0: 0, x1: 0, yb: 0, h: w.h ?? 10 };
  let x0 = Infinity, x1 = -Infinity;
  for (const s of w.geo) {
    for (const x of s.xs) { if (x < x0) x0 = x; if (x > x1) x1 = x; }
  }
  const y0 = seg.y0, y1 = seg.y1;
  return { x0, x1, yb: y0 + (y1 - y0) * 0.8, h: w.h ?? Math.max(6, y1 - y0) };
}

interface RichWord {
  t: string; x0: number; x1: number; h: number; bold: boolean; italic: boolean; mono: boolean;
}

interface RichLine {
  page: number;
  words: RichWord[];
  x0: number;
  x1: number;
  h: number;
  gap: boolean;
  text: string;
  allBold: boolean;
  allMono: boolean;
}

function enrichLine(page: number, l: PdfLine): RichLine | null {
  if (!l.words.length) return null;
  const words: RichWord[] = [];
  let x0 = Infinity, x1 = -Infinity, hSum = 0, boldChars = 0, totalChars = 0, monoChars = 0;
  for (const w of l.words) {
    const b = wordBounds(w);
    const bold = !!w.bold, italic = !!w.italic, mono = !!w.mono;
    words.push({ t: w.t, x0: b.x0, x1: b.x1, h: b.h, bold, italic, mono });
    x0 = Math.min(x0, b.x0);
    x1 = Math.max(x1, b.x1);
    hSum += b.h;
    const len = w.t.length;
    totalChars += len;
    if (bold) boldChars += len;
    if (mono) monoChars += len;
  }
  return {
    page,
    words,
    x0,
    x1,
    h: hSum / words.length,
    gap: l.gap,
    text: words.map(w => w.t).join(' '),
    allBold: totalChars > 0 && boldChars / totalChars >= 0.85,
    allMono: totalChars > 0 && monoChars / totalChars >= 0.85,
  };
}

function formatInlineWords(words: RichWord[], allowStyle: boolean): string {
  if (!allowStyle) return words.map(w => w.t).join(' ');
  let out = '';
  let i = 0;
  while (i < words.length) {
    const w = words[i];
    const st = w.mono ? 3 : (w.bold ? 1 : 0) + (w.italic ? 2 : 0);
    let j = i + 1;
    while (j < words.length) {
      const n = words[j];
      const nst = n.mono ? 3 : (n.bold ? 1 : 0) + (n.italic ? 2 : 0);
      if (nst !== st) break;
      j++;
    }
    const chunk = words.slice(i, j).map(x => x.t).join(' ');
    if (out) out += ' ';
    if (st === 3 && !chunk.includes('`')) out += '`' + chunk + '`';
    else if (st === 1) out += '**' + chunk + '**';
    else if (st === 2) out += '*' + chunk + '*';
    else out += chunk;
    i = j;
  }
  return out;
}

interface TableCell { x0: number; x1: number; text: string }

function splitLineIntoCells(line: RichLine, bodySize: number): TableCell[] {
  const minGap = Math.max(15, bodySize * 1.45);
  const cells: TableCell[] = [];
  let cur: RichWord[] = [];
  let cx0 = 0, cx1 = 0;
  for (const w of line.words) {
    if (cur.length && w.x0 - cx1 > minGap) {
      cells.push({ x0: cx0, x1: cx1, text: cur.map(x => x.t).join(' ') });
      cur = [w]; cx0 = w.x0; cx1 = w.x1;
    } else {
      if (!cur.length) cx0 = w.x0;
      cx1 = Math.max(cx1, w.x1);
      cur.push(w);
    }
  }
  if (cur.length) cells.push({ x0: cx0, x1: cx1, text: cur.map(x => x.t).join(' ') });
  return cells;
}

function clusterColumns(rows: TableCell[][]): number[] {
  const starts: number[] = [];
  for (const r of rows) for (const c of r) starts.push(c.x0);
  starts.sort((a, b) => a - b);
  const cols: number[] = [];
  for (const x of starts) {
    if (!cols.length || x - cols[cols.length - 1] > 24) cols.push(x);
    else cols[cols.length - 1] = (cols[cols.length - 1] + x) / 2;
  }
  return cols;
}

function tryBuildTable(lines: RichLine[], start: number, bodySize: number): { md: string; end: number } | null {
  const firstCells = splitLineIntoCells(lines[start], bodySize);
  if (firstCells.length < 2) return null;
  // Require at least 2 consecutive multi-cell lines (or 1 multi-cell header + 1 aligned row)
  const rawRows: TableCell[][] = [firstCells];
  let end = start + 1;
  while (end < lines.length) {
    const cells = splitLineIntoCells(lines[end], bodySize);
    if (cells.length < 2) break;
    // Guard against merging two unrelated sections separated by a huge vertical gap unless it's a normal row step
    rawRows.push(cells);
    end++;
  }
  if (rawRows.length < 2) return null;

  const cols = clusterColumns(rawRows);
  if (cols.length < 2 || cols.length > 10) return null;

  // Verify consistency: most cells align close to a column start
  let aligned = 0, total = 0;
  for (const r of rawRows) {
    for (const c of r) {
      total++;
      const bestDist = Math.min(...cols.map(colX => Math.abs(c.x0 - colX)));
      if (bestDist <= 28) aligned++;
    }
  }
  if (total === 0 || aligned / total < 0.75) return null;

  const escCell = (s: string) => s.replace(/\|/g, '\\|').trim();
  const grid = rawRows.map(r => {
    const row = new Array<string>(cols.length).fill('');
    for (const c of r) {
      let best = 0, bestD = Infinity;
      cols.forEach((cx, ci) => { const d = Math.abs(c.x0 - cx); if (d < bestD) { bestD = d; best = ci; } });
      row[best] = row[best] ? row[best] + ' ' + escCell(c.text) : escCell(c.text);
    }
    return row;
  });

  const mdLines = [
    '| ' + grid[0].join(' | ') + ' |',
    '| ' + cols.map(() => '---').join(' | ') + ' |',
    ...grid.slice(1).map(r => '| ' + r.join(' | ') + ' |'),
  ];
  return { md: mdLines.join('\n'), end };
}

function joinWrappedParagraph(parts: string[], vocab: Set<string>): string {
  const edge = (w: string) => w.toLowerCase().replace(/^\p{P}+/u, '').replace(/\p{P}+$/u, '');
  let acc = '';
  for (const raw of parts) {
    const line = raw.trim();
    if (!line) continue;
    if (!acc) { acc = line; continue; }
    // Check trailing hyphen across line wrap
    const m = /(\S+)[-\u2010]$/.exec(acc);
    if (m) {
      const firstWord = line.split(/\s+/)[0] ?? '';
      if (/^\p{Ll}/u.test(firstWord)) {
        const stem = m[1], joined = stem + firstWord, hyph = stem + '-' + firstWord;
        const keepHyphen = vocab.has(edge(hyph)) && !vocab.has(edge(joined));
        acc = keepHyphen ? acc.slice(0, -1) + '-' + line : acc.slice(0, -1) + line;
        continue;
      }
    }
    acc += ' ' + line;
  }
  return acc;
}

const BULLET_RE = /^(?:[\u2022\u25E6\u25AA\u25AB\u2023\u2043\u25CF\u25CB]|[-*\u2013])\s+(.+)$/;
const ORDERED_RE = /^(\d{1,3})[.)]\s+(.+)$/;
const HR_RE = /^[-_=*~]{3,}$/;

/** Convert a structured PdfExtract into clean, layout-preserving GFM Markdown. */
export function pdfExtractToMarkdown(ex: PdfExtract): string {
  const richPages: RichLine[][] = ex.pages.map((p, pi) =>
    p.lines.map(l => enrichLine(pi, l)).filter((x): x is RichLine => x !== null),
  );

  // Document-wide weighted body font size & vocab (for smart dehyphenation)
  const sizeHist = new Map<number, number>();
  const vocab = new Set<string>();
  const edge = (w: string) => w.toLowerCase().replace(/^\p{P}+/u, '').replace(/\p{P}+$/u, '');
  for (const lines of richPages) {
    for (const l of lines) {
      for (const w of l.words) {
        const bucket = Math.round(w.h * 2) / 2;
        sizeHist.set(bucket, (sizeHist.get(bucket) ?? 0) + w.t.length);
        vocab.add(edge(w.t));
      }
    }
  }
  let bodySize = 10.5, bestWeight = -1;
  sizeHist.forEach((wt, sz) => { if (wt > bestWeight) { bestWeight = wt; bodySize = sz; } });

  const classifyHeading = (l: RichLine, prev: RichLine | undefined, next: RichLine | undefined): 0 | 1 | 2 | 3 => {
    const t = l.text.trim();
    if (!t || t.length > 130 || l.words.length > 16) return 0;
    if (/[,;]$/.test(t)) return 0;
    if (/^page\s+\d+(?:\s+of\s+\d+)?$/i.test(t)) return 0;
    const ratio = l.h / Math.max(1, bodySize);
    if (ratio >= 1.55) return 1;
    if (ratio >= 1.25) return 2;
    if (ratio >= 1.12 && (l.allBold || l.gap || !prev || (next?.gap ?? true))) return 2;
    if (l.allBold && (!prev || l.gap) && (!next || next.gap || !next.allBold) && !/[.!?]$/.test(t)) return 3;
    return 0;
  };

  const mdPages: string[] = [];
  richPages.forEach((lines, pi) => {
    if (!lines.length) { mdPages.push(''); return; }
    // Estimate left margin for this page (15th percentile of x0)
    const xs = lines.map(l => l.x0).sort((a, b) => a - b);
    const leftMargin = xs[Math.floor(xs.length * 0.15)] ?? 0;

    const blocks: string[] = [];
    let i = 0;
    while (i < lines.length) {
      const l = lines[i];

      // 1. Horizontal rule
      if (HR_RE.test(l.text.trim())) {
        blocks.push('---');
        i++;
        continue;
      }

      // 2. Table detection
      const tbl = tryBuildTable(lines, i, bodySize);
      if (tbl) {
        blocks.push(tbl.md);
        i = tbl.end;
        continue;
      }

      // 3. Heading detection
      const hLevel = classifyHeading(l, lines[i - 1], lines[i + 1]);
      if (hLevel > 0) {
        // Combine multi-line heading if next line has same heading size & no gap
        const hParts = [l.text.trim()];
        while (i + 1 < lines.length && !lines[i + 1].gap && Math.abs(lines[i + 1].h - l.h) < 0.8 && classifyHeading(lines[i + 1], lines[i], lines[i + 2]) === hLevel) {
          i++;
          hParts.push(lines[i].text.trim());
        }
        blocks.push('#'.repeat(hLevel) + ' ' + hParts.join(' '));
        i++;
        continue;
      }

      // 4. Monospace code block
      if (l.allMono) {
        const codeLines: string[] = [l.text];
        while (i + 1 < lines.length && lines[i + 1].allMono && !lines[i + 1].gap) {
          i++;
          codeLines.push(lines[i].text);
        }
        if (codeLines.length >= 2) {
          blocks.push('```\n' + codeLines.join('\n') + '\n```');
          i++;
          continue;
        }
      }

      // 5. Lists (unordered & ordered)
      const bm = BULLET_RE.exec(l.text);
      const om = !bm ? ORDERED_RE.exec(l.text) : null;
      if (bm || om) {
        const listLines: string[] = [];
        while (i < lines.length) {
          const cur = lines[i];
          const b2 = BULLET_RE.exec(cur.text);
          const o2 = !b2 ? ORDERED_RE.exec(cur.text) : null;
          if (!b2 && !o2) break;
          const indent = cur.x0 - leftMargin > bodySize * 2.2 ? '  ' : '';
          const itemParts = [b2 ? b2[1] : o2![2]];
          const prefix = b2 ? '- ' : `${o2![1]}. `;
          while (i + 1 < lines.length && !lines[i + 1].gap &&
                 !BULLET_RE.test(lines[i + 1].text) && !ORDERED_RE.test(lines[i + 1].text) &&
                 !tryBuildTable(lines, i + 1, bodySize) && classifyHeading(lines[i + 1], lines[i], lines[i + 2]) === 0) {
            i++;
            itemParts.push(formatInlineWords(lines[i].words, true));
          }
          listLines.push(indent + prefix + joinWrappedParagraph(itemParts, vocab));
          i++;
          if (i < lines.length && lines[i].gap) {
            // Keep adjacent list items in the same list if the next line is also a list item
            if (!BULLET_RE.test(lines[i].text) && !ORDERED_RE.test(lines[i].text)) break;
          }
        }
        blocks.push(listLines.join('\n'));
        continue;
      }

      // 6. Blockquote / indented callout or regular paragraph (ignore small captions/headers)
      const isQuote = l.h >= bodySize * 0.9 && l.x0 - leftMargin >= Math.max(24, bodySize * 2.0) && l.x0 < (ex.pages[pi].width * 0.45);
      const paraParts = [formatInlineWords(l.words, true)];
      while (i + 1 < lines.length && !lines[i + 1].gap) {
        const nxt = lines[i + 1];
        if (classifyHeading(nxt, lines[i], lines[i + 2]) > 0) break;
        if (BULLET_RE.test(nxt.text) || ORDERED_RE.test(nxt.text)) break;
        if (tryBuildTable(lines, i + 1, bodySize)) break;
        if (HR_RE.test(nxt.text.trim())) break;
        i++;
        paraParts.push(formatInlineWords(nxt.words, true));
      }
      const paraText = joinWrappedParagraph(paraParts, vocab);
      blocks.push(isQuote ? '> ' + paraText : paraText);
      i++;
    }

    mdPages.push(blocks.join('\n\n'));
  });

  if (mdPages.length <= 1) return mdPages[0] ?? '';
  return mdPages.map((pg, i) => (i === 0 ? pg : `<!-- page: ${i + 1} -->\n\n${pg}`)).join('\n\n');
}

// ── 2. Word (.docx) XML → Markdown ──────────────────────────────────────────

function decodeXml(s: string): string {
  const ENT: Record<string, string> = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'" };
  return s.replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, (m, e: string) => {
    if (e[0] !== '#') return ENT[e.toLowerCase()] ?? m;
    const cp = e[1] === 'x' || e[1] === 'X' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10);
    return Number.isFinite(cp) && cp > 0 && cp <= 0x10ffff ? String.fromCodePoint(cp) : '';
  });
}

/** Convert Word document.xml into GFM Markdown preserving headings, bold, italic, lists, tables & page breaks. */
export function docxXmlToMarkdown(xml: string): string {
  const rendered = xml.includes('<w:lastRenderedPageBreak');
  const out: string[] = [];
  const cells: string[][] = [], rows: string[][] = [];
  let inPara = false, inRun = false, inT = false, inPPr = false, inRPr = false, skip = 0;
  let bold = false, italic = false, isList = false, heading = 0;
  let paraChunks: string[] = [];

  const flushPara = () => {
    const raw = paraChunks.join('').replace(/[^\S\f]+/g, ' ').replace(/^ +| +$/g, '');
    paraChunks = [];
    if (!raw) return;
    let formatted = raw;
    if (heading > 0 && heading <= 6) formatted = '#'.repeat(heading) + ' ' + raw.replace(/\*\*/g, '');
    else if (isList) formatted = '- ' + raw;
    if (cells.length) cells[cells.length - 1].push(formatted);
    else out.push(formatted);
  };

  const re = /<(\/?)([\w:.-]+)([^>]*?)(\/?)>|([^<]+)/g;
  for (let m = re.exec(xml); m; m = re.exec(xml)) {
    if (m[5] !== undefined) {
      if (inT && !skip && inPara) {
        const txt = decodeXml(m[5]);
        if (txt) {
          if (bold && italic && txt.trim()) paraChunks.push('***' + txt.trim() + '***');
          else if (bold && txt.trim()) paraChunks.push('**' + txt.trim() + '**');
          else if (italic && txt.trim()) paraChunks.push('*' + txt.trim() + '*');
          else paraChunks.push(txt);
        }
      }
      continue;
    }
    const close = m[1] === '/', name = m[2], attrs = m[3], self = m[4] === '/';
    if (name === 'w:del' || name === 'w:moveFrom' || name === 'mc:Fallback') {
      if (!self) skip += close ? -1 : 1;
      continue;
    }
    if (skip) continue;
    switch (name) {
      case 'w:p':
        if (self) break;
        if (!close) { inPara = true; heading = 0; isList = false; paraChunks = []; }
        else { flushPara(); inPara = false; }
        break;
      case 'w:pPr': if (!self) inPPr = !close; break;
      case 'w:rPr': if (!self) inRPr = !close; break;
      case 'w:pStyle':
        if (inPPr) {
          const hm = /w:val="Heading(\d)"/i.exec(attrs);
          if (hm) heading = Number(hm[1]);
        }
        break;
      case 'w:numPr': if (inPPr && !close) isList = true; break;
      case 'w:r':
        if (!self) { inRun = !close; if (!close) { bold = false; italic = false; } }
        break;
      case 'w:b': if (inRPr && !close) bold = !/w:val="(?:0|false|off)"/i.test(attrs); break;
      case 'w:i': if (inRPr && !close) italic = !/w:val="(?:0|false|off)"/i.test(attrs); break;
      case 'w:t': inT = !close && !self; break;
      case 'w:tab': if (inRun && inPara) paraChunks.push(' '); break;
      case 'w:br': case 'w:cr':
        if (inRun && inPara) paraChunks.push(!rendered && /w:type="page"/.test(attrs) ? '\f' : ' ');
        break;
      case 'w:lastRenderedPageBreak': if (rendered && inPara) paraChunks.push('\f'); break;
      case 'w:pageBreakBefore': if (!rendered && inPara && !/w:val="(?:0|false|off)"/.test(attrs)) paraChunks.push('\f'); break;
      case 'w:noBreakHyphen': if (inPara) paraChunks.push('-'); break;
      case 'w:tr':
        if (close) { const r = rows.pop(); if (r && r.some(Boolean)) out.push('__ROW__' + r.map(x => x.replace(/\|/g, '\\|')).join(' | ')); }
        else if (!self) rows.push([]);
        break;
      case 'w:tc':
        if (close) { const c = cells.pop(); if (c && rows.length) rows[rows.length - 1].push(c.join(' ').trim()); }
        else if (!self) cells.push([]);
        break;
    }
  }

  // Group table rows into Markdown tables and convert \f into page comments
  const blocks: string[] = [];
  let pageNo = 1;
  for (let i = 0; i < out.length; i++) {
    const item = out[i];
    if (item.startsWith('__ROW__')) {
      const tblRows: string[] = [];
      while (i < out.length && out[i].startsWith('__ROW__')) {
        tblRows.push('| ' + out[i].slice(7) + ' |');
        i++;
      }
      i--;
      if (tblRows.length) {
        const cols = (tblRows[0].match(/\|/g)?.length ?? 2) - 1;
        blocks.push(tblRows[0] + '\n| ' + Array(Math.max(1, cols)).fill('---').join(' | ') + ' |\n' + tblRows.slice(1).join('\n'));
      }
      continue;
    }
    const parts = item.split('\f');
    parts.forEach((pt, idx) => {
      if (idx > 0) { pageNo++; blocks.push(`<!-- page: ${pageNo} -->`); }
      const s = pt.trim();
      if (s) blocks.push(s);
    });
  }
  return blocks.join('\n\n');
}

// ── 3. Markdown → Pure Semantic HTML ────────────────────────────────────────

const SAFE_TAGS = new Set([
  'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'br', 'hr', 'strong', 'b', 'em', 'i', 'u', 's',
  'code', 'pre', 'blockquote', 'ul', 'ol', 'li', 'table', 'thead', 'tbody', 'tfoot', 'tr', 'th', 'td',
  'a', 'del', 'ins', 'span', 'div',
]);

function sanitizeFallback(html: string): string {
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, '')
    .replace(/<style[\s\S]*?<\/style>/gi, '')
    .replace(/<\/?([a-z0-9-]+)([^>]*)>/gi, (m, tag: string, attrs: string) => {
      const t = tag.toLowerCase();
      if (!SAFE_TAGS.has(t)) return '';
      if (m.startsWith('</')) return `</${t}>`;
      const kept: string[] = [];
      for (const am of attrs.matchAll(/\b(class|data-page|data-ch|colspan|rowspan|href)=("([^"]*)"|'([^']*)')/gi)) {
        const k = am[1].toLowerCase(), v = am[3] ?? am[4] ?? '';
        if (k === 'href' && !/^https?:\/\//i.test(v)) continue;
        kept.push(`${k}="${v.replace(/"/g, '&quot;')}"`);
      }
      const self = m.endsWith('/>') || t === 'hr' || t === 'br' ? ' /' : '';
      return `<${t}${kept.length ? ' ' + kept.join(' ') : ''}${self}>`;
    });
}

/** Convert Markdown into clean, sanitized, pure semantic HTML. */
export function markdownToPureHtml(md: string): string {
  // Normalize page markers (<!-- page: N --> or === PAGE ===) into distinct HTML page-break <hr> elements.
  const norm = md
    .replace(/\r\n?/g, '\n')
    .replace(/<!--\s*page:\s*(\d+)\s*-->/gi, (_, p: string) => `\n\n<hr class="pdf-page-break" data-page="${p}" />\n\n`)
    .replace(/^[ \t]*(?:\f|={3,}[ \t]*page(?:[ \t]*break)?[ \t]*={3,})[ \t]*$/gim, () => `\n\n<hr class="pdf-page-break" />\n\n`);

  const raw = marked.parse(norm, { gfm: true, breaks: false, async: false }) as string;
  if (typeof window !== 'undefined' && typeof DOMPurify?.sanitize === 'function') {
    return DOMPurify.sanitize(raw, {
      ALLOWED_TAGS: Array.from(SAFE_TAGS),
      ALLOWED_ATTR: ['class', 'data-page', 'data-ch', 'colspan', 'rowspan', 'href', 'title'],
    }).trim();
  }
  return sanitizeFallback(raw).trim();
}

// ── 4. Pure HTML AST, Tokenization & Diff Stitching ─────────────────────────

interface HtmlElem { kind: 'el'; tag: string; attrs: Record<string, string>; children: HtmlNode[]; blockId: number }
interface HtmlText { kind: 'tx'; text: string; page: number; blockId: number; nodeId: number }
type HtmlNode = HtmlElem | HtmlText;

const VOID_TAGS = new Set(['br', 'hr', 'img', 'wbr']);
const BLOCK_TAGS = new Set(['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'li', 'th', 'td', 'blockquote', 'pre']);
const CONTAINER_TAGS = new Set(['ul', 'ol', 'table', 'thead', 'tbody', 'tfoot', 'tr', 'div']);

const HTML_ENT: Record<string, string> = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", '#39': "'", nbsp: ' ', ndash: '\u2013', mdash: '\u2014' };
function unescapeHtml(s: string): string {
  return s.replace(/&(#x[0-9a-f]+|#\d+|[a-z0-9]+);/gi, (m, e: string) => {
    const low = e.toLowerCase();
    if (HTML_ENT[low]) return HTML_ENT[low];
    if (e[0] === '#') {
      const cp = e[1] === 'x' || e[1] === 'X' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10);
      return Number.isFinite(cp) && cp > 0 && cp <= 0x10ffff ? String.fromCodePoint(cp) : '';
    }
    return m;
  });
}

function escapeHtml(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

interface ParsedHtml {
  roots: HtmlNode[];
  raw: RawDoc;
  spans: WordSpan[];
  blockNodes: Map<number, HtmlElem>;
}

interface WordSpan {
  blockId: number;
  lineNo: number;
  page: number;
  nodeId: number;
  start: number;
  end: number;
  text: string;
}

const EDGE = /^(\p{P}*)([\s\S]*?)(\p{P}*)$/u;

function splitSubTokens(w: string, split: boolean): { text: string; start: number; end: number }[] {
  const m = split && !/\d/.test(w) ? EDGE.exec(w) : null;
  if (!m || !m[2]) return [{ text: w, start: 0, end: w.length }];
  const out: { text: string; start: number; end: number }[] = [];
  let off = 0;
  for (const ch of m[1]) { out.push({ text: ch, start: off, end: off + ch.length }); off += ch.length; }
  out.push({ text: m[2], start: off, end: off + m[2].length }); off += m[2].length;
  for (const ch of m[3]) { out.push({ text: ch, start: off, end: off + ch.length }); off += ch.length; }
  return out;
}

function parseHtmlToTree(html: string, splitPunct: boolean): ParsedHtml {
  const roots: HtmlNode[] = [];
  const stack: HtmlElem[] = [];
  const blockNodes = new Map<number, HtmlElem>();
  let page = 0;
  let nextBlock = 0;
  let nextNode = 0;

  const pushNode = (n: HtmlNode) => {
    if (stack.length) stack[stack.length - 1].children.push(n);
    else roots.push(n);
  };
  const currentBlock = (): number => {
    for (let i = stack.length - 1; i >= 0; i--) if (stack[i].blockId >= 0) return stack[i].blockId;
    return -1;
  };

  const re = /<!--[\s\S]*?-->|<(\/?)([a-z0-9-]+)([^>]*?)(\/?)>|([^<]+)/gi;
  for (let m = re.exec(html); m; m = re.exec(html)) {
    if (m[5] !== undefined) {
      const text = unescapeHtml(m[5]);
      if (!text) continue;
      let bid = currentBlock();
      if (bid < 0 && !text.trim()) continue;
      if (bid < 0) bid = nextBlock++;
      pushNode({ kind: 'tx', text, page, blockId: bid, nodeId: nextNode++ });
      continue;
    }
    if (!m[2]) continue;
    const close = m[1] === '/', tag = m[2].toLowerCase(), attrStr = m[3], self = m[4] === '/' || VOID_TAGS.has(tag);
    if (!SAFE_TAGS.has(tag)) continue;

    if (close) {
      for (let i = stack.length - 1; i >= 0; i--) {
        if (stack[i].tag === tag) { stack.length = i; break; }
      }
      continue;
    }

    const attrs: Record<string, string> = {};
    for (const am of attrStr.matchAll(/\b(class|data-page|colspan|rowspan|href)=("([^"]*)"|'([^']*)')/gi)) {
      const k = am[1].toLowerCase(), v = am[3] ?? am[4] ?? '';
      if (k === 'href' && !/^https?:\/\//i.test(v)) continue;
      attrs[k] = v;
    }
    if (tag === 'hr' && attrs.class?.includes('pdf-page-break')) page++;

    const isBlock = BLOCK_TAGS.has(tag);
    const blockId = isBlock ? nextBlock++ : -1;
    const el: HtmlElem = { kind: 'el', tag, attrs, children: [], blockId };
    if (isBlock) blockNodes.set(blockId, el);
    pushNode(el);
    if (!self) stack.push(el);
  }

  // Extract RawLines & WordSpans per leaf block (skipping empty container blocks)
  const blockWords = new Map<number, { page: number; words: string[] }>();
  const spans: WordSpan[] = [];
  const blockLine = new Map<number, number>();
  let lineCounter = 0;

  const walk = (n: HtmlNode) => {
    if (n.kind === 'tx') {
      if (!n.text.trim()) return;
      let bw = blockWords.get(n.blockId);
      if (!bw) {
        lineCounter += 2; // blank gap between distinct HTML blocks
        blockLine.set(n.blockId, lineCounter);
        bw = { page: n.page, words: [] };
        blockWords.set(n.blockId, bw);
      }
      const lineNo = blockLine.get(n.blockId)!;
      for (const wm of n.text.matchAll(/\S+/g)) {
        const w = wm[0], base = wm.index!;
        bw.words.push(w);
        for (const sub of splitSubTokens(w, splitPunct)) {
          spans.push({
            blockId: n.blockId,
            lineNo,
            page: n.page,
            nodeId: n.nodeId,
            start: base + sub.start,
            end: base + sub.end,
            text: sub.text,
          });
        }
      }
      return;
    }
    for (const ch of n.children) walk(ch);
  };
  for (const r of roots) walk(r);

  const lines: RawLine[] = [];
  Array.from(blockWords.entries())
    .sort((a, b) => (blockLine.get(a[0]) ?? 0) - (blockLine.get(b[0]) ?? 0))
    .forEach(([bid, bw]) => {
      lines.push({ page: bw.page, line: blockLine.get(bid)!, words: bw.words, gap: true, hf: false });
    });

  return { roots, raw: { lines, pages: Math.max(1, page + 1) }, spans, blockNodes };
}

export interface HtmlDiffResult {
  res: CompareResult;
  redlineHtml: string;
  leftHtml: string;
  rightHtml: string;
}

function tokSpanClass(kind: number, move: number): string {
  if (kind === INS) return move >= 0 ? 'tk tk-mvto' : 'tk tk-ins';
  return move >= 0 ? 'tk tk-mvfrom' : 'tk tk-del';
}

function renderAttrs(attrs: Record<string, string>): string {
  return Object.entries(attrs).map(([k, v]) => ` ${k}="${escapeHtml(v)}"`).join('');
}

function mapTokensToSpans(toks: Tok[], spans: WordSpan[]): Map<number, { span: WordSpan; tok: Tok }> {
  const byTok = new Map<number, { span: WordSpan; tok: Tok }>();
  let si = 0;
  for (const tok of toks) {
    while (si < spans.length && (spans[si].lineNo < tok.line || (spans[si].lineNo === tok.line && spans[si].text !== tok.text))) {
      si++;
    }
    if (si < spans.length && spans[si].lineNo === tok.line && spans[si].text === tok.text) {
      byTok.set(tok.i, { span: spans[si], tok });
      si++;
    }
  }
  return byTok;
}

function renderSideHtml(roots: HtmlNode[], items: CompareResult['items'], side: 'left' | 'right', spans: WordSpan[]): string {
  const toks: Tok[] = [];
  const itemByTok = new Map<number, CompareResult['items'][number]>();
  for (const it of items) {
    const t = side === 'left' ? it.a : it.b;
    if (!t) continue;
    toks.push(t);
    itemByTok.set(t.i, it);
  }
  const map = mapTokensToSpans(toks, spans);
  const byNode = new Map<number, { start: number; end: number; item: CompareResult['items'][number] }[]>();
  map.forEach(({ span, tok }) => {
    const it = itemByTok.get(tok.i)!;
    if (it.kind === EQ) return;
    const arr = byNode.get(span.nodeId) ?? [];
    arr.push({ start: span.start, end: span.end, item: it });
    byNode.set(span.nodeId, arr);
  });

  const renderNode = (n: HtmlNode): string => {
    if (n.kind === 'tx') {
      const marks = byNode.get(n.nodeId);
      if (!marks || !marks.length) return escapeHtml(n.text);
      marks.sort((a, b) => a.start - b.start);
      let out = '', pos = 0;
      for (const mk of marks) {
        if (mk.start > pos) out += escapeHtml(n.text.slice(pos, mk.start));
        const tag = mk.item.kind === DEL ? 'del' : 'ins';
        const cls = tokSpanClass(mk.item.kind, mk.item.move);
        out += `<${tag} data-ch="${mk.item.change}" class="${cls}">${escapeHtml(n.text.slice(mk.start, mk.end))}</${tag}>`;
        pos = mk.end;
      }
      if (pos < n.text.length) out += escapeHtml(n.text.slice(pos));
      return out;
    }
    const inner = n.children.map(renderNode).join('');
    if (VOID_TAGS.has(n.tag)) return `<${n.tag}${renderAttrs(n.attrs)} />`;
    return `<${n.tag}${renderAttrs(n.attrs)}>${inner}</${n.tag}>`;
  };
  return roots.map(renderNode).join('\n');
}

function renderRedlineHtml(parsedA: ParsedHtml, parsedB: ParsedHtml, res: CompareResult): string {
  // Map B tokens -> spans & items
  const bToks: Tok[] = [];
  const itemByB = new Map<number, CompareResult['items'][number]>();
  const aToks: Tok[] = [];
  const itemByA = new Map<number, CompareResult['items'][number]>();

  for (const it of res.items) {
    if (it.b) { bToks.push(it.b); itemByB.set(it.b.i, it); }
    if (it.a) { aToks.push(it.a); itemByA.set(it.a.i, it); }
  }
  const bMap = mapTokensToSpans(bToks, parsedB.spans);
  const aMap = mapTokensToSpans(aToks, parsedA.spans);

  // Determine which blocks in A are completely deleted (no EQ token on that block)
  const blockHasEqA = new Set<number>();
  for (const it of res.items) {
    if (it.kind === EQ && it.a) {
      const m = aMap.get(it.a.i);
      if (m) blockHasEqA.add(m.span.blockId);
    }
  }

  // Group DEL runs and attach them either:
  //   • as a whole-block deletion before nextB's block,
  //   • inline AFTER prevB (when deleted from the end of prevB's block before a new block starts), or
  //   • inline BEFORE nextB (when deleted inside the same block).
  interface DelRun { change: number; move: number; text: string; wholeBlock: boolean; blockTag: string }
  const delsBeforeB = new Map<number, DelRun[]>(); // key = B token index, or -1 for trailing
  const delsAfterB = new Map<number, DelRun[]>();  // key = B token index
  const addDel = (map: Map<number, DelRun[]>, key: number, run: DelRun) => {
    const arr = map.get(key) ?? [];
    arr.push(run);
    map.set(key, arr);
  };

  for (let i = 0; i < res.items.length; i++) {
    const it = res.items[i];
    if (it.kind !== DEL) continue;
    const aSpan = aMap.get(it.a!.i)?.span;
    const whole = !!aSpan && !blockHasEqA.has(aSpan.blockId);
    const blockTag = aSpan ? (parsedA.blockNodes.get(aSpan.blockId)?.tag ?? 'p') : 'p';
    const toks: Tok[] = [it.a!];
    let j = i + 1;
    while (j < res.items.length && res.items[j].kind === DEL && res.items[j].change === it.change) {
      const ns = aMap.get(res.items[j].a!.i)?.span;
      const nWhole = !!ns && !blockHasEqA.has(ns.blockId);
      if (nWhole !== whole || (whole && ns?.blockId !== aSpan?.blockId)) break;
      toks.push(res.items[j].a!);
      j++;
    }
    i = j - 1;

    let prevB = -1;
    for (let k = i - toks.length; k >= 0; k--) {
      if (res.items[k].b) { prevB = res.items[k].b!.i; break; }
    }
    let nextB = -1;
    for (let k = j; k < res.items.length; k++) {
      if (res.items[k].b) { nextB = res.items[k].b!.i; break; }
    }
    const delRun: DelRun = {
      change: it.change,
      move: it.move,
      text: joinToks(toks),
      wholeBlock: whole,
      blockTag,
    };
    const prevSpan = prevB >= 0 ? bMap.get(prevB)?.span : undefined;
    const nextSpan = nextB >= 0 ? bMap.get(nextB)?.span : undefined;
    // If this inline deletion happened at the end of prevB's block right before a different block starts, place it after prevB!
    if (!whole && prevSpan && (!nextSpan || prevSpan.blockId !== nextSpan.blockId)) {
      addDel(delsAfterB, prevB, delRun);
    } else {
      addDel(delsBeforeB, nextB, delRun);
    }
  }

  // Attach token marks & inline DELs to B's text nodes; whole-block DELs attach before B's block!
  const bMarksByNode = new Map<number, { start: number; end: number; beforeHtml: string; afterHtml: string; wrapKind?: number; wrapMove?: number; change?: number }[]>();
  const blockBeforeHtml = new Map<number, string>();
  const trailingHtml: string[] = [];

  const renderDelChip = (d: DelRun) =>
    `<del data-ch="${d.change}" class="${tokSpanClass(DEL, d.move)}" title="${d.move >= 0 ? 'Moved from here' : 'Deleted'}">${escapeHtml(d.text)}</del>`;

  const renderDelBlock = (d: DelRun) => {
    const cls = d.move >= 0 ? 'html-mv-block' : 'html-del-block';
    if (d.blockTag === 'tr' || d.blockTag === 'td' || d.blockTag === 'th') {
      return `<p class="${cls}">${renderDelChip(d)}</p>`;
    }
    const tag = ['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'blockquote', 'li'].includes(d.blockTag) ? d.blockTag : 'p';
    return `<${tag} class="${cls}">${renderDelChip(d)}</${tag}>`;
  };

  for (const tok of bToks) {
    const it = itemByB.get(tok.i)!;
    const mapped = bMap.get(tok.i);
    if (!mapped) continue;
    const { span } = mapped;
    const dels = delsBeforeB.get(tok.i) ?? [];
    const afterDels = delsAfterB.get(tok.i) ?? [];
    let inlineBefore = '';
    for (const d of dels) {
      if (d.wholeBlock && span.start === 0) {
        blockBeforeHtml.set(span.blockId, (blockBeforeHtml.get(span.blockId) ?? '') + renderDelBlock(d));
      } else {
        inlineBefore += renderDelChip(d) + ' ';
      }
    }
    const inlineAfter = afterDels.map(d => ' ' + renderDelChip(d)).join('');
    if (inlineBefore || inlineAfter || it.kind !== EQ) {
      const arr = bMarksByNode.get(span.nodeId) ?? [];
      arr.push({
        start: span.start,
        end: span.end,
        beforeHtml: inlineBefore,
        afterHtml: inlineAfter,
        wrapKind: it.kind !== EQ ? it.kind : undefined,
        wrapMove: it.move,
        change: it.change,
      });
      bMarksByNode.set(span.nodeId, arr);
    }
  }
  for (const d of delsBeforeB.get(-1) ?? []) {
    trailingHtml.push(d.wholeBlock ? renderDelBlock(d) : `<p class="html-del-block">${renderDelChip(d)}</p>`);
  }

  const renderNode = (n: HtmlNode): string => {
    if (n.kind === 'tx') {
      const marks = bMarksByNode.get(n.nodeId);
      if (!marks || !marks.length) return escapeHtml(n.text);
      marks.sort((a, b) => a.start - b.start);
      let out = '', pos = 0;
      for (const mk of marks) {
        if (mk.start > pos) out += escapeHtml(n.text.slice(pos, mk.start));
        out += mk.beforeHtml;
        const slice = escapeHtml(n.text.slice(mk.start, mk.end));
        if (mk.wrapKind !== undefined) {
          out += `<ins data-ch="${mk.change}" class="${tokSpanClass(mk.wrapKind, mk.wrapMove ?? -1)}" title="${(mk.wrapMove ?? -1) >= 0 ? 'Moved here' : 'Added'}">${slice}</ins>`;
        } else {
          out += slice;
        }
        out += mk.afterHtml;
        pos = mk.end;
      }
      if (pos < n.text.length) out += escapeHtml(n.text.slice(pos));
      return out;
    }
    const prefix = n.blockId >= 0 ? (blockBeforeHtml.get(n.blockId) ?? '') : '';
    const inner = n.children.map(renderNode).join('');
    if (VOID_TAGS.has(n.tag)) return prefix + `<${n.tag}${renderAttrs(n.attrs)} />`;
    return prefix + `<${n.tag}${renderAttrs(n.attrs)}>${inner}</${n.tag}>`;
  };

  void CONTAINER_TAGS;
  return parsedB.roots.map(renderNode).join('\n') + trailingHtml.join('\n');
}

/**
 * Compare two pure HTML documents: runs DiffEngine v3 on the structured HTML blocks and returns both the standard
 * CompareResult (for Change log, Alignment map, Page map, Insights, Word redline) and stitched HTML views.
 */
export function compareHtml(htmlA: string, htmlB: string, opts: CompareOptions): HtmlDiffResult {
  const split = opts.splitPunctuation;
  const parsedA = parseHtmlToTree(htmlA, split);
  const parsedB = parseHtmlToTree(htmlB, split);
  const res = compareRaw(parsedA.raw, parsedB.raw, { ...opts, dehyphenate: false });
  const redlineHtml = renderRedlineHtml(parsedA, parsedB, res);
  const leftHtml = renderSideHtml(parsedA.roots, res.items, 'left', parsedA.spans);
  const rightHtml = renderSideHtml(parsedB.roots, res.items, 'right', parsedB.spans);
  return { res, redlineHtml, leftHtml, rightHtml };
}

/** Build a standalone, shareable pure HTML diff report file. */
export function buildStandaloneHtmlReport(titleA: string, titleB: string, redlineHtml: string, similarity: number, changesCount: number): string {
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Comparison: ${escapeHtml(titleA)} vs ${escapeHtml(titleB)}</title>
<style>
  body { font-family: Georgia, "Times New Roman", serif; max-width: 860px; margin: 40px auto; padding: 0 24px 60px; color: #1d1a15; background: #faf8f4; line-height: 1.65; }
  header { font-family: system-ui, sans-serif; border-bottom: 2px solid #e2ddd2; padding-bottom: 16px; margin-bottom: 28px; }
  header h1 { font-size: 20px; margin: 0 0 6px; }
  header p { margin: 0; font-size: 13px; color: #6b6456; }
  h1, h2, h3, h4 { color: #111; margin-top: 1.4em; margin-bottom: 0.5em; line-height: 1.3; }
  table { width: 100%; border-collapse: collapse; margin: 1.2em 0; font-family: system-ui, sans-serif; font-size: 14px; background: #fff; }
  th, td { border: 1px solid #d9d3c7; padding: 8px 12px; text-align: left; }
  th { background: #efebe2; font-weight: 600; }
  blockquote { border-left: 3px solid #c9c1b0; margin: 1em 0; padding: 0.2em 1em; color: #524c41; }
  pre { background: #f0ece3; padding: 12px; border-radius: 6px; overflow-x: auto; font-size: 13px; }
  hr.pdf-page-break { border: 0; border-top: 1px dashed #c8c0b0; margin: 2em 0; position: relative; }
  ins.tk-ins { background: #c8ebd5; color: #0b5230; text-decoration: none; border-bottom: 2px solid #2f9e63; padding: 0 2px; border-radius: 2px; }
  del.tk-del { background: #f9d3d4; color: #8f1a1d; text-decoration: line-through; padding: 0 2px; border-radius: 2px; }
  ins.tk-mvto { background: #d4e0ff; color: #1b3a9c; text-decoration: none; border-bottom: 2px solid #4c7df0; padding: 0 2px; border-radius: 2px; }
  del.tk-mvfrom { background: #e6ecff; color: #5b72b6; text-decoration: line-through; padding: 0 2px; border-radius: 2px; }
  .html-del-block { background: #fdf2f2; border-left: 3px solid #e5484d; padding: 4px 10px; border-radius: 4px; }
</style>
</head>
<body>
<header>
  <h1>Document Comparison (Markdown &rarr; Pure HTML)</h1>
  <p>${escapeHtml(titleA)} &rarr; ${escapeHtml(titleB)} &bull; ${(similarity * 100).toFixed(1)}% similar &bull; ${changesCount} change(s)</p>
</header>
<main>${redlineHtml}</main>
</body>
</html>`;
}
