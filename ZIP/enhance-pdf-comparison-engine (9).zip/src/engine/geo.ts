/*
 * Word geometry shared by the PDF reader, the comparison engine and the PDF writers.
 * Coordinates are "display space": points, origin top-left, y pointing DOWN, after page rotation and crop box.
 */

/** Axis-aligned box on page `p` (0-based). */
export interface Box { p: number; x0: number; y0: number; x1: number; y1: number }

/**
 * One physical line segment of a word. `xs` holds n + 1 character boundaries (n = UTF-16 length of the text it
 * covers), so any character range maps to an exact box — this is what lets a changed comma highlight only the comma.
 * A word re-joined across a line break has two segments.
 */
export interface GSeg { p: number; y0: number; y1: number; xs: number[] }

export const segChars = (s: GSeg): number => s.xs.length - 1;

/** Boxes (one per touched segment) covering characters [from, to) of a word. */
export function subBoxes(geo: GSeg[], from: number, to: number): Box[] {
  const out: Box[] = [];
  let off = 0;
  for (const s of geo) {
    const n = segChars(s);
    const a = Math.max(from, off), b = Math.min(to, off + n);
    if (b > a) {
      const u = s.xs[a - off], v = s.xs[b - off]; // xs decreases for upside-down text
      out.push({ p: s.p, x0: Math.min(u, v), x1: Math.max(u, v), y0: s.y0, y1: s.y1 });
    }
    off += n;
  }
  return out;
}

/** Drop the last character (a line-break hyphen) but stretch the previous character over it, so the highlight still covers the printed hyphen. */
export function dropLastChar(geo: GSeg[]): GSeg[] {
  if (!geo.length) return geo;
  const last = geo[geo.length - 1];
  if (segChars(last) < 2) return geo.slice(0, -1).concat(segChars(last) === 1 ? [] : [last]);
  const xs = last.xs.slice(0, -2).concat(last.xs[last.xs.length - 1]);
  return geo.slice(0, -1).concat({ ...last, xs });
}
