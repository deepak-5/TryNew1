/*
 * Docuzen DiffEngine v3 — TypeScript reference implementation.
 * Mirrors csharp/PdfComparer.DiffEngine.cs one-to-one so the browser lab and the C# port stay in lock-step.
 *
 * Pipeline per region:
 *   1. Trim common prefix / suffix
 *   2. Maximal unique phrase anchors  (unique k-grams, extended to maximal runs, chained by HEAVIEST
 *      non-overlapping increasing chain — weight = run length — instead of a count-based LIS)
 *   3. Unique-token patience anchors  (LIS)
 *   4. Linear-space Myers bisection   (O(N+M) memory, no trace snapshots). When the cost cap is hit the
 *      region is split at the furthest-reaching point instead of being reported as a full replacement.
 */

export const EQ = 0, DEL = 1, INS = 2;
export type Kind = 0 | 1 | 2;
export interface DiffOp { kind: Kind; a: number; b: number }
export interface DiffOptions { maxCost?: number; phraseAnchors?: boolean; tokenAnchors?: boolean; phraseLength?: number }
export interface DiffResult { ops: DiffOp[]; cappedRegions: number; phraseRuns: number; tokenAnchors: number; bisections: number }
export type Seq = ArrayLike<number>;

const REGION = 0, LEAF = 1, RUN = 2;

export function diff(a: Seq, b: Seq, opts: DiffOptions = {}): DiffResult {
  const maxCost = Math.max(2, opts.maxCost ?? 4000);
  const usePhrase = opts.phraseAnchors ?? true;
  const useToken = opts.tokenAnchors ?? true;
  const K = Math.max(2, opts.phraseLength ?? 3);
  const res: DiffResult = { ops: [], cappedRegions: 0, phraseRuns: 0, tokenAnchors: 0, bisections: 0 };
  const ops = res.ops;
  // Work stack of 5-tuples: type, alo, ahi, blo, bhi  (RUN: alo = aStart, ahi = count, blo = bStart)
  const st: number[] = [REGION, 0, a.length, 0, b.length];

  while (st.length) {
    let bhi = st.pop()!, blo = st.pop()!, ahi = st.pop()!, alo = st.pop()!;
    const type = st.pop()!;

    if (type === RUN) {
      for (let k = 0; k < ahi; k++) ops.push({ kind: EQ, a: alo + k, b: blo + k });
      continue;
    }

    while (alo < ahi && blo < bhi && a[alo] === b[blo]) { ops.push({ kind: EQ, a: alo, b: blo }); alo++; blo++; }
    let suf = 0;
    while (ahi > alo && bhi > blo && a[ahi - 1] === b[bhi - 1]) { ahi--; bhi--; suf++; }
    if (suf) st.push(RUN, ahi, suf, bhi, 0);

    if (alo === ahi) { for (let j = blo; j < bhi; j++) ops.push({ kind: INS, a: -1, b: j }); continue; }
    if (blo === bhi) { for (let i = alo; i < ahi; i++) ops.push({ kind: DEL, a: i, b: -1 }); continue; }

    if (type === REGION) {
      if (usePhrase && ahi - alo >= 12 && bhi - blo >= 12) {
        const runs = phraseAnchors(a, alo, ahi, b, blo, bhi, K);
        if (runs.length) { res.phraseRuns += runs.length / 3; pushAnchors(st, runs, alo, ahi, blo, bhi); continue; }
      }
      if (useToken) {
        const anchors = tokenAnchors(a, alo, ahi, b, blo, bhi);
        if (anchors.length) { res.tokenAnchors += anchors.length / 3; pushAnchors(st, anchors, alo, ahi, blo, bhi); continue; }
      }
    }

    res.bisections++;
    const sp = bisect(a, alo, ahi, b, blo, bhi, maxCost);
    if (sp.status >= 2) {
      // 2 = proven: nothing in common. 3 = cap hit with no usable split point.
      if (sp.status === 3) res.cappedRegions++;
      for (let i = alo; i < ahi; i++) ops.push({ kind: DEL, a: i, b: -1 });
      for (let j = blo; j < bhi; j++) ops.push({ kind: INS, a: -1, b: j });
      continue;
    }
    if (sp.status === 1) res.cappedRegions++;
    st.push(LEAF, alo + sp.x, ahi, blo + sp.y, bhi);
    st.push(LEAF, alo, alo + sp.x, blo, blo + sp.y);
  }

  normalizeBlocks(ops);
  return res;
}

function pushAnchors(st: number[], anchors: number[], alo: number, ahi: number, blo: number, bhi: number): void {
  let pa = ahi, pb = bhi;
  for (let k = anchors.length - 3; k >= 0; k -= 3) {
    const ai = anchors[k], bi = anchors[k + 1], len = anchors[k + 2];
    st.push(REGION, ai + len, pa, bi + len, pb);
    st.push(RUN, ai, len, bi, 0);
    pa = ai; pb = bi;
  }
  st.push(REGION, alo, pa, blo, pb);
}

/** Within every change block put all deletions before all insertions (stable). */
export function normalizeBlocks(ops: DiffOp[]): void {
  const n = ops.length;
  let i = 0;
  while (i < n) {
    if (ops[i].kind === EQ) { i++; continue; }
    let j = i, sawIns = false, need = false;
    while (j < n && ops[j].kind !== EQ) {
      if (ops[j].kind === INS) sawIns = true; else if (sawIns) need = true;
      j++;
    }
    if (need) {
      const d: DiffOp[] = [], s: DiffOp[] = [];
      for (let k = i; k < j; k++) (ops[k].kind === DEL ? d : s).push(ops[k]);
      let p = i;
      for (const o of d) ops[p++] = o;
      for (const o of s) ops[p++] = o;
    }
    i = j;
  }
}

/** 53-bit k-gram key (two independent 32-bit mixes). Collisions are harmless: every hit is verified. */
export function gramKey(t: Seq, i: number, k: number): number {
  let h1 = 0x811c9dc5 | 0, h2 = 7;
  for (let n = 0; n < k; n++) {
    const v = t[i + n];
    h1 = Math.imul(h1 ^ v, 0x01000193);
    h2 = (Math.imul(h2, 0x9e3779b1) + v) | 0;
  }
  return (h1 >>> 0) * 2097152 + (h2 >>> 11);
}

function lowerBound(arr: number[], v: number): number {
  let lo = 0, hi = arr.length;
  while (lo < hi) { const mid = (lo + hi) >> 1; if (arr[mid] < v) lo = mid + 1; else hi = mid; }
  return lo;
}
function upperBound(arr: number[], v: number): number {
  let lo = 0, hi = arr.length;
  while (lo < hi) { const mid = (lo + hi) >> 1; if (arr[mid] <= v) lo = mid + 1; else hi = mid; }
  return lo;
}

/**
 * Heaviest chain of non-overlapping, order-preserving runs. Run i covers A[aS, aS+len) and B[bS, bS+len)
 * with weight w. O(R log R) using a prefix-max Fenwick tree keyed by B-end rank.
 * Returns the indices of the chosen runs in ascending order.
 */
export function heaviestChain(aS: Seq, bS: Seq, len: Seq, w: Seq): number[] {
  const R = aS.length;
  if (R === 0) return [];
  if (R === 1) return [0];
  const byStart: number[] = new Array(R), byEnd: number[] = new Array(R), bEnds: number[] = new Array(R);
  for (let i = 0; i < R; i++) { byStart[i] = i; byEnd[i] = i; bEnds[i] = bS[i] + len[i]; }
  byStart.sort((p, q) => aS[p] - aS[q] || bS[p] - bS[q]);
  byEnd.sort((p, q) => aS[p] + len[p] - aS[q] - len[q]);
  bEnds.sort((x, y) => x - y);
  const fw = new Float64Array(R + 1), fi = new Int32Array(R + 1).fill(-1);
  const score = new Float64Array(R), prev = new Int32Array(R).fill(-1);
  let e = 0, best = -1, bestScore = -1;
  for (let s = 0; s < R; s++) {
    const i = byStart[s];
    while (e < R && aS[byEnd[e]] + len[byEnd[e]] <= aS[i]) {
      const j = byEnd[e++];
      for (let p = lowerBound(bEnds, bS[j] + len[j]) + 1; p <= R; p += p & -p) {
        if (score[j] > fw[p]) { fw[p] = score[j]; fi[p] = j; }
      }
    }
    let bw = 0, bj = -1;
    for (let p = upperBound(bEnds, bS[i]); p > 0; p -= p & -p) {
      if (fw[p] > bw) { bw = fw[p]; bj = fi[p]; }
    }
    score[i] = w[i] + bw; prev[i] = bj;
    if (score[i] > bestScore) { bestScore = score[i]; best = i; }
  }
  const out: number[] = [];
  for (let k = best; k >= 0; k = prev[k]) out.push(k);
  return out.reverse();
}

/** Unique k-grams (once per side) → verified → extended to maximal runs → heaviest chain. Flat triples [a, b, len]. */
function phraseAnchors(a: Seq, alo: number, ahi: number, b: Seq, blo: number, bhi: number, K: number): number[] {
  const mA = new Map<number, number>(), mB = new Map<number, number>();
  for (let i = alo; i + K <= ahi; i++) { const h = gramKey(a, i, K); mA.set(h, mA.has(h) ? -1 : i); }
  for (let j = blo; j + K <= bhi; j++) { const h = gramKey(b, j, K); mB.set(h, mB.has(h) ? -1 : j); }

  const aS: number[] = [], bS: number[] = [], len: number[] = [];
  const seen = new Set<number>();
  const span = bhi + 1;
  mA.forEach((ia, h) => {
    if (ia < 0) return;
    const ib = mB.get(h);
    if (ib === undefined || ib < 0) return;
    for (let k = 0; k < K; k++) if (a[ia + k] !== b[ib + k]) return;
    let s = 0;
    while (ia - s > alo && ib - s > blo && a[ia - s - 1] === b[ib - s - 1]) s++;
    let e = K;
    while (ia + e < ahi && ib + e < bhi && a[ia + e] === b[ib + e]) e++;
    const key = (ia - s) * span + (ib - s);
    if (seen.has(key)) return;
    seen.add(key);
    aS.push(ia - s); bS.push(ib - s); len.push(s + e);
  });
  if (!aS.length) return [];
  const out: number[] = [];
  for (const i of heaviestChain(aS, bS, len, len)) out.push(aS[i], bS[i], len[i]);
  return out;
}

/** Patience anchors: tokens occurring exactly once on each side, reduced by LIS. Flat triples [a, b, 1]. */
function tokenAnchors(a: Seq, alo: number, ahi: number, b: Seq, blo: number, bhi: number): number[] {
  const cA = new Map<number, number>(), pB = new Map<number, number>();
  for (let i = alo; i < ahi; i++) cA.set(a[i], (cA.get(a[i]) ?? 0) + 1);
  for (let j = blo; j < bhi; j++) pB.set(b[j], pB.has(b[j]) ? -1 : j);
  const pa: number[] = [], pb: number[] = [];
  for (let i = alo; i < ahi; i++) {
    if (cA.get(a[i]) !== 1) continue;
    const j = pB.get(a[i]);
    if (j !== undefined && j >= 0) { pa.push(i); pb.push(j); }
  }
  if (!pa.length) return [];
  const tails: number[] = [], prev = new Int32Array(pa.length);
  for (let i = 0; i < pa.length; i++) {
    let lo = 0, hi = tails.length;
    while (lo < hi) { const mid = (lo + hi) >> 1; if (pb[tails[mid]] < pb[i]) lo = mid + 1; else hi = mid; }
    prev[i] = lo > 0 ? tails[lo - 1] : -1;
    tails[lo] = i;
  }
  const out: number[] = [];
  for (let k = tails[tails.length - 1]; k >= 0; k = prev[k]) out.push(1, pb[k], pa[k]);
  return out.reverse();
}

interface Split { x: number; y: number; status: 0 | 1 | 2 | 3 }

/**
 * Myers bidirectional bisection (linear space). The caller guarantees that the first and last tokens
 * differ (prefix/suffix already trimmed) and both sides are non-empty.
 * status 0 = exact midpoint, 1 = cost cap hit (heuristic split), 2 = nothing in common, 3 = cap hit, no split.
 */
function bisect(a: Seq, alo: number, ahi: number, b: Seq, blo: number, bhi: number, maxCost: number): Split {
  const n = ahi - alo, m = bhi - blo;
  const full = (n + m + 1) >> 1;
  const maxD = Math.min(full, maxCost);
  const vOff = maxD, vLen = 2 * maxD + 2;
  const v1 = new Int32Array(vLen).fill(-1), v2 = new Int32Array(vLen).fill(-1);
  v1[vOff + 1] = 0; v2[vOff + 1] = 0;
  const delta = n - m;
  const front = (delta & 1) !== 0;
  let k1s = 0, k1e = 0, k2s = 0, k2e = 0;

  for (let d = 0; d < maxD; d++) {
    for (let k1 = -d + k1s; k1 <= d - k1e; k1 += 2) {
      const o = vOff + k1;
      let x1 = (k1 === -d || (k1 !== d && v1[o - 1] < v1[o + 1])) ? v1[o + 1] : v1[o - 1] + 1;
      let y1 = x1 - k1;
      while (x1 < n && y1 < m && a[alo + x1] === b[blo + y1]) { x1++; y1++; }
      v1[o] = x1;
      if (x1 > n) k1e += 2;
      else if (y1 > m) k1s += 2;
      else if (front) {
        const o2 = vOff + delta - k1;
        if (o2 >= 0 && o2 < vLen && v2[o2] !== -1 && x1 >= n - v2[o2]) return { x: x1, y: y1, status: 0 };
      }
    }
    for (let k2 = -d + k2s; k2 <= d - k2e; k2 += 2) {
      const o = vOff + k2;
      let x2 = (k2 === -d || (k2 !== d && v2[o - 1] < v2[o + 1])) ? v2[o + 1] : v2[o - 1] + 1;
      let y2 = x2 - k2;
      while (x2 < n && y2 < m && a[ahi - x2 - 1] === b[bhi - y2 - 1]) { x2++; y2++; }
      v2[o] = x2;
      if (x2 > n) k2e += 2;
      else if (y2 > m) k2s += 2;
      else if (!front) {
        const o1 = vOff + delta - k2;
        if (o1 >= 0 && o1 < vLen && v1[o1] !== -1) {
          const x1 = v1[o1], y1 = vOff + x1 - o1;
          if (x1 >= n - x2) return { x: x1, y: y1, status: 0 };
        }
      }
    }
  }
  if (maxD >= full) return { x: 0, y: 0, status: 2 };

  // Cost cap reached: split at the furthest-reaching point of either search front (still a valid diff).
  let fb = -1, fx = 0, fy = 0, bb = -1, bx = 0, by = 0;
  for (let k = -(maxD - 1); k <= maxD - 1; k++) {
    const x = v1[vOff + k];
    if (x >= 0) { const y = x - k; if (x <= n && y >= 0 && y <= m && x + y > fb) { fb = x + y; fx = x; fy = y; } }
    const r = v2[vOff + k];
    if (r >= 0) { const y = r - k; if (r <= n && y >= 0 && y <= m && r + y > bb) { bb = r + y; bx = r; by = y; } }
  }
  const total = n + m;
  if (bb > fb && bb > 0 && bb < total) return { x: n - bx, y: m - by, status: 1 };
  if (fb > 0 && fb < total) return { x: fx, y: fy, status: 1 };
  return { x: 0, y: 0, status: 3 };
}
