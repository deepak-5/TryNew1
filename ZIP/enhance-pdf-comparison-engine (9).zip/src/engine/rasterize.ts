/*
 * Browser page renderer on top of pdf.js: RGBA pixels for the image comparison, JPEG for the fallback embedding.
 * One renderer per PDF; pages are rendered on demand and the canvas is released right away.
 */
import { getPdfJs } from './files';
import type { RasterImage } from './rasterdiff';

export interface PageRenderer {
  rgba(page: number, scale: number): Promise<RasterImage>;
  jpeg(page: number, scale?: number): Promise<{ jpeg: Uint8Array }>;
  close(): void;
}

export async function openRenderer(bytes: Uint8Array): Promise<PageRenderer> {
  const lib = await getPdfJs();
  const doc = await lib.getDocument({ data: bytes.slice(), isEvalSupported: false }).promise;

  async function draw(page: number, scale: number): Promise<HTMLCanvasElement> {
    const p = await doc.getPage(page + 1);
    const vp = p.getViewport({ scale });
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.ceil(vp.width));
    canvas.height = Math.max(1, Math.ceil(vp.height));
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) throw new Error('Canvas is not available in this browser.');
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    await p.render({ canvas, canvasContext: ctx, viewport: vp }).promise;
    p.cleanup();
    return canvas;
  }
  const release = (c: HTMLCanvasElement) => { c.width = 0; c.height = 0; };

  return {
    async rgba(page, scale) {
      const c = await draw(page, scale);
      const img = c.getContext('2d')!.getImageData(0, 0, c.width, c.height);
      const out = { width: c.width, height: c.height, data: img.data };
      release(c);
      return out;
    },
    async jpeg(page, scale = 1.6) {
      const c = await draw(page, scale);
      const blob = await new Promise<Blob | null>(res => c.toBlob(res, 'image/jpeg', 0.86));
      release(c);
      if (!blob) throw new Error('Could not encode the page image.');
      return { jpeg: new Uint8Array(await blob.arrayBuffer()) };
    },
    close() { void doc.destroy(); },
  };
}
