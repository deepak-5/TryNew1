/*
 * PDF reading (library-agnostic, testable in Node).
 *  • extractPdf: pdf.js text items → words WITH geometry, in reading order. Per-character boundaries are interpolated
 *    along each text run with Helvetica-proportional weights, so even a one-character highlight lands on the right glyph.
 *    Baseline clustering with a running mean, gap-based word joining, duplicate-glyph removal (fake bold),
 *    two-column detection, paragraph gaps from line spacing. Everything is computed in display space (rotation and
 *    crop box applied), which is the space the PDF writers draw in.
 *  • pdfToText: the same extraction rendered as lab text.
 *  • textToPdf: tiny PDF writer (Helvetica, WinAnsi) used for generated test / demo files.
 */
import type { GSeg } from './geo';
import type { RawDoc, RawLine } from './compare';

export interface PdfPageInfo {
  /** Display size in points (rotation applied). */
  width: number; height: number;
  /** Visible area in PDF user space: crop box ∩ media box. */
  view: number[];
  /** pdf.js viewport transform: user space → display space (y down). */
  transform: number[];
  rotation: number;
}
export interface PdfWord {
  t: string; geo: GSeg[];
  /** Layout metadata captured from PDF font & geometry (used by Markdown / HTML extraction). */
  h?: number; bold?: boolean; italic?: boolean; mono?: boolean;
}
export interface PdfLine { words: PdfWord[]; gap: boolean }
export interface PdfPageData extends PdfPageInfo { lines: PdfLine[]; wordCount: number }
export interface PdfExtract { pages: PdfPageData[]; text: string; emptyPages: number[] }

export interface PdfLikePage {
  getTextContent(): Promise<{ items: unknown[]; styles?: Record<string, { fontFamily?: string }> }>;
  getViewport(o: { scale: number }): { width: number; height: number; transform: number[]; rotation: number };
  getOperatorList?(): Promise<unknown>;
  commonObjs?: { get(id: string): unknown };
  view: number[];
  cleanup?(): unknown;
}
export interface PdfLikeDoc { numPages: number; getPage(n: number): Promise<PdfLikePage> }

// Helvetica advance widths for ASCII 32..126 (1/1000 em) — used only as RELATIVE weights inside one text run.
const HELV = [278, 278, 355, 556, 556, 889, 667, 191, 333, 333, 389, 584, 278, 333, 278, 278, 556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 278, 278, 584, 584, 584, 556,
  1015, 667, 667, 722, 722, 667, 611, 778, 722, 278, 500, 667, 556, 833, 722, 778, 667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 278, 278, 278, 469, 556,
  333, 556, 556, 500, 556, 556, 278, 556, 556, 222, 222, 500, 222, 833, 556, 556, 556, 556, 333, 500, 278, 556, 500, 722, 500, 500, 500, 334, 260, 334, 584];
const weight = (ch: string): number => {
  const c = ch.charCodeAt(0);
  if (c >= 32 && c <= 126) return HELV[c - 32];
  if (c >= 0x2e80) return 1000;
  return 556;
};

/** xs may DEcrease for upside-down text (page rotated 180°); lo/hi are the true horizontal extent. */
interface Piece { s: string; xs: number[]; lo: number; hi: number; yb: number; h: number; atom: number; before: boolean; after: boolean; horiz: boolean; flip: boolean; bold: boolean; italic: boolean; mono: boolean }

const median = (v: number[]) => { const s = [...v].sort((a, b) => a - b); return s.length ? s[s.length >> 1] : 0; };
const ASC = 0.8, DESC = 0.2;

interface FontFlags { bold: boolean; italic: boolean; mono: boolean }

function resolveFontFlags(fontId: string | undefined, styles: Record<string, { fontFamily?: string }> | undefined, commonObjs: { get(id: string): unknown } | undefined): FontFlags {
  if (!fontId) return { bold: false, italic: false, mono: false };
  let name = '';
  let bold = false, italic = false, mono = false;
  try {
    const obj = commonObjs?.get(fontId) as { name?: string; bold?: boolean; italic?: boolean; black?: boolean; isMonospace?: boolean; fallbackName?: string } | undefined;
    if (obj) {
      name = obj.name ?? '';
      bold = !!(obj.bold || obj.black);
      italic = !!obj.italic;
      mono = !!(obj.isMonospace || obj.fallbackName === 'monospace');
    }
  } catch { /* font not resolved in commonObjs */ }
  const st = styles?.[fontId];
  if (st?.fontFamily === 'monospace') mono = true;
  if (name) {
    if (/bold|black|heavy|demi|semibold|extrabold/i.test(name)) bold = true;
    if (/italic|oblique|slant/i.test(name)) italic = true;
    if (/courier|consolas|monaco|menlo|mono|code/i.test(name)) mono = true;
  }
  return { bold, italic, mono };
}

function piecesOf(items: unknown[], tf: number[], pageIndex: number, styles?: Record<string, { fontFamily?: string }>, commonObjs?: { get(id: string): unknown }): Piece[] {
  void pageIndex;
  const ap = (x: number, y: number): [number, number] => [tf[0] * x + tf[2] * y + tf[4], tf[1] * x + tf[3] * y + tf[5]];
  const out: Piece[] = [];
  const seen = new Set<string>();
  const fontCache = new Map<string, FontFlags>();
  let atom = 0;
  for (const raw of items as { str?: unknown; transform?: number[]; width?: number; height?: number; fontName?: string }[]) {
    if (typeof raw.str !== 'string' || !raw.str.trim() || !raw.transform) continue;
    const s = raw.str, t = raw.transform;
    const fk = raw.fontName ?? '';
    let ff = fontCache.get(fk);
    if (!ff) { ff = resolveFontFlags(raw.fontName, styles, commonObjs); fontCache.set(fk, ff); }
    const len = Math.hypot(t[0], t[1]) || 1;
    const ux = t[0] / len, uy = t[1] / len;
    const fs = Math.hypot(t[2], t[3]) || Math.abs(raw.height ?? 0) || 10;
    let total = 0;
    const cum = new Float64Array(s.length + 1);
    for (let i = 0; i < s.length; i++) { total += weight(s[i]); cum[i + 1] = total; }
    const iw = (raw.width ?? 0) > 0 ? raw.width! : (fs * total) / 1000;
    const [ox, oy] = ap(t[4], t[5]);
    const [ex, ey] = ap(t[4] + ux * iw, t[5] + uy * iw);
    const dx = ex - ox, dy = ey - oy;
    const along = Math.abs(dx) >= Math.abs(dy);
    const horiz = along && dx > 0, flip = along && dx <= 0;
    const key = s + '|' + Math.round(ox * 2) + '|' + Math.round(oy * 2);
    if (seen.has(key)) continue; // same text painted twice (fake bold / shadow)
    seen.add(key);

    const xsAll = new Array<number>(s.length + 1);
    let yb: number;
    if (along) {
      for (let i = 0; i <= s.length; i++) xsAll[i] = ox + (cum[i] / total) * dx;
      yb = oy;
    } else { // rotated relative to the page: keep a coarse, but valid, box
      const lo = ox - fs * 0.5, hi = ox + fs * 0.5;
      for (let i = 0; i <= s.length; i++) xsAll[i] = lo + (i / s.length) * (hi - lo);
      yb = (oy + ey) / 2;
    }
    atom++;
    for (const m of s.matchAll(/\S+/g)) {
      const a = m.index!, n = m[0].length;
      const xs = xsAll.slice(a, a + n + 1);
      out.push({ s: m[0], xs, lo: Math.min(xs[0], xs[n]), hi: Math.max(xs[0], xs[n]), yb, h: fs, atom, before: a > 0, after: a + n < s.length, horiz, flip, bold: ff.bold, italic: ff.italic, mono: ff.mono });
    }
  }
  return out;
}

function splitColumns(ps: Piece[]): Piece[][] {
  if (ps.length < 30) return [ps];
  let minX = Infinity, maxX = -Infinity;
  for (const p of ps) { minX = Math.min(minX, p.lo); maxX = Math.max(maxX, p.hi); }
  const width = maxX - minX;
  if (width < 200) return [ps];
  const iv = ps.map(p => [p.lo, p.hi]).sort((a, b) => a[0] - b[0]);
  let end = iv[0][1], bestGap = 0, bestMid = 0;
  for (let i = 1; i < iv.length; i++) {
    if (iv[i][0] > end) {
      const gap = iv[i][0] - end, mid = (iv[i][0] + end) / 2, rel = (mid - minX) / width;
      if (rel >= 0.3 && rel <= 0.7 && gap > bestGap) { bestGap = gap; bestMid = mid; }
    }
    end = Math.max(end, iv[i][1]);
  }
  if (bestGap < Math.max(12, median(ps.map(p => p.h)) * 1.2)) return [ps];
  const mid = (p: Piece) => (p.lo + p.hi) / 2;
  const left = ps.filter(p => mid(p) < bestMid), right = ps.filter(p => mid(p) >= bestMid);
  return left.length < ps.length * 0.15 || right.length < ps.length * 0.15 ? [ps] : [left, right];
}

interface L { yb: number; h: number; ps: Piece[] }

function layoutColumn(ps: Piece[], pageIndex: number, firstGap: boolean): PdfLine[] {
  const sorted = [...ps].sort((a, b) => a.yb - b.yb || a.lo - b.lo);
  const lines: L[] = [];
  let cur: L | null = null, sum = 0;
  for (const p of sorted) {
    if (cur && Math.abs(p.yb - sum / cur.ps.length) <= Math.max(2, Math.min(p.h, cur.h) * 0.5)) {
      cur.ps.push(p); sum += p.yb; cur.h = Math.max(cur.h, p.h); cur.yb = sum / cur.ps.length;
    } else { cur = { yb: p.yb, h: p.h, ps: [p] }; sum = p.yb; lines.push(cur); }
  }
  const deltas: number[] = [];
  for (let i = 1; i < lines.length; i++) deltas.push(lines[i].yb - lines[i - 1].yb);
  const typical = deltas.length >= 3 ? median(deltas) : 0;

  return lines.map((l, i) => {
    const gap = i === 0 ? firstGap
      : (typical > 0 && lines[i].yb - lines[i - 1].yb > typical * 1.55) || lines[i].yb - lines[i - 1].yb > Math.max(l.h, lines[i - 1].h) * 2.1;
    l.ps.sort((a, b) => a.lo - b.lo);
    const words: PdfWord[] = [];
    let w: { t: string; xs: number[]; y0: number; y1: number; last: Piece; h: number; bold: boolean; italic: boolean; mono: boolean } | null = null;
    const flush = () => {
      if (w) words.push({ t: w.t, geo: [{ p: pageIndex, y0: w.y0, y1: w.y1, xs: w.xs }], h: w.h, bold: w.bold, italic: w.italic, mono: w.mono });
      w = null;
    };
    for (const p of l.ps) {
      const y0 = p.yb - (p.flip ? DESC : ASC) * p.h, y1 = p.yb + (p.flip ? ASC : DESC) * p.h;
      if (w) {
        const gapX = p.lo - w.last.hi;
        const join = !w.last.after && !p.before && w.last.atom !== p.atom && w.last.horiz && p.horiz &&
          gapX <= Math.max(1, 0.2 * Math.min(p.h, w.last.h)) && gapX >= -0.35 * p.h;
        if (join) {
          w.t += p.s; w.xs = w.xs.concat(p.xs.slice(1)); w.y0 = Math.min(w.y0, y0); w.y1 = Math.max(w.y1, y1);
          w.h = Math.max(w.h, p.h); w.bold = w.bold && p.bold; w.italic = w.italic && p.italic; w.mono = w.mono && p.mono;
          w.last = p;
          continue;
        }
        flush();
      }
      w = { t: p.s, xs: p.xs.slice(), y0, y1, last: p, h: p.h, bold: p.bold, italic: p.italic, mono: p.mono };
    }
    flush();
    return { words, gap };
  });
}

export function pageText(lines: PdfLine[]): string {
  return lines.map((l, i) => (l.gap && i > 0 ? '\n' : '') + l.words.map(w => w.t).join(' ')).join('\n');
}

export async function extractPdf(doc: PdfLikeDoc, onProgress?: (done: number, total: number) => void): Promise<PdfExtract> {
  const pages: PdfPageData[] = [], emptyPages: number[] = [];
  for (let n = 1; n <= doc.numPages; n++) {
    const page = await doc.getPage(n);
    const vp = page.getViewport({ scale: 1 });
    if (page.getOperatorList) await page.getOperatorList().catch(() => undefined);
    const tc = await page.getTextContent();
    const pieces = piecesOf(tc.items, vp.transform, n - 1, tc.styles, page.commonObjs);
    const info: PdfPageInfo = { width: vp.width, height: vp.height, view: Array.from(page.view), transform: Array.from(vp.transform), rotation: vp.rotation };
    page.cleanup?.();
    const lines: PdfLine[] = [];
    if (pieces.length) splitColumns(pieces).forEach((col, k) => lines.push(...layoutColumn(col, n - 1, k > 0)));
    else emptyPages.push(n);
    pages.push({ ...info, lines, wordCount: lines.reduce((s, l) => s + l.words.length, 0) });
    onProgress?.(n, doc.numPages);
  }
  return { pages, text: pages.map(p => pageText(p.lines)).join('\n=== PAGE ===\n'), emptyPages };
}

/** Structured document for the comparison engine (keeps every word's geometry). */
export function extractToRaw(ex: PdfExtract): RawDoc {
  const lines: RawLine[] = [];
  let line = 0;
  ex.pages.forEach((p, page) => {
    p.lines.forEach(l => {
      line += l.gap ? 2 : 1;
      lines.push({ page, line, words: l.words.map(w => w.t), geo: l.words.map(w => w.geo), gap: l.gap, hf: false });
    });
    line++;
  });
  return { lines, pages: ex.pages.length };
}

export async function pdfToText(doc: PdfLikeDoc, onProgress?: (done: number, total: number) => void): Promise<{ text: string; pages: number; emptyPages: number[] }> {
  const ex = await extractPdf(doc, onProgress);
  return { text: ex.text, pages: ex.pages.length, emptyPages: ex.emptyPages };
}

// ── Demo writer ─────────────────────────────────────────────────────────────

const PAGE_SPLIT = /\n?[ \t]*(?:\f|={3,}[ \t]*page(?:[ \t]*break)?[ \t]*={3,})[ \t]*\n?/i;
const WIN: Record<string, number> = { '€': 0x80, '‚': 0x82, '„': 0x84, '…': 0x85, '‘': 0x91, '’': 0x92, '“': 0x93, '”': 0x94, '•': 0x95, '–': 0x96, '—': 0x97, '™': 0x99 };

function pdfString(s: string): string {
  let o = '';
  for (const ch of s) {
    let c = ch.codePointAt(0)!;
    if (c > 255) c = WIN[ch] ?? 63; else if (c >= 0x80 && c < 0xa0) c = 63;
    const x = String.fromCharCode(c);
    o += x === '(' || x === ')' || x === '\\' ? '\\' + x : x;
  }
  return o;
}

/** Lab text → PDF (A4, Helvetica 10/13). "=== PAGE ===" starts a new page; long pages overflow onto extra pages. */
export function textToPdf(text: string): Uint8Array {
  const LINES = 58;
  const pages: string[][] = [];
  for (const p of text.replace(/\r\n?/g, '\n').split(PAGE_SPLIT)) {
    const ls = p.split('\n');
    for (let i = 0; i < ls.length; i += LINES) pages.push(ls.slice(i, i + LINES));
  }
  let out = '%PDF-1.4\n%\u00e2\u00e3\u00cf\u00d3\n';
  const offs: number[] = [];
  const obj = (n: number, body: string) => { offs[n] = out.length; out += `${n} 0 obj\n${body}\nendobj\n`; };
  obj(1, '<</Type/Catalog/Pages 2 0 R>>');
  obj(2, `<</Type/Pages/Count ${pages.length}/Kids[${pages.map((_, i) => `${4 + 2 * i} 0 R`).join(' ')}]>>`);
  obj(3, '<</Type/Font/Subtype/Type1/BaseFont/Helvetica/Encoding/WinAnsiEncoding>>');
  pages.forEach((ls, i) => {
    const data = 'BT /F1 10 Tf 13 TL 56 800 Td\n' + ls.map(l => (l.trim() ? `(${pdfString(l)}) Tj T*` : 'T*')).join('\n') + '\nET';
    obj(4 + 2 * i, `<</Type/Page/Parent 2 0 R/MediaBox[0 0 595 842]/Resources<</Font<</F1 3 0 R>>>>/Contents ${5 + 2 * i} 0 R>>`);
    obj(5 + 2 * i, `<</Length ${data.length}>>\nstream\n${data}\nendstream`);
  });
  const n = 4 + 2 * pages.length, xref = out.length;
  out += `xref\n0 ${n}\n0000000000 65535 f \n`;
  for (let k = 1; k < n; k++) out += `${String(offs[k]).padStart(10, '0')} 00000 n \n`;
  out += `trailer\n<</Size ${n}/Root 1 0 R>>\nstartxref\n${xref}\n%%EOF\n`;
  return Uint8Array.from(out, c => c.charCodeAt(0));
}
