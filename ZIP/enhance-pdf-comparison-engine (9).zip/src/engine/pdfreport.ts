/*
 * Executive summary + classified change log, drawn directly with pdf-lib (A4 portrait, paginated tables).
 */
import type { PDFDocument, PDFPage } from 'pdf-lib';
import { rgb } from 'pdf-lib';
import { COLOR, Fonts, fillRect, strokeRect, hLine, text } from './pdfdraw';

type Color = ReturnType<typeof rgb>;

export interface ReportSlot { sheet: number; pages: string; status: string; del: number; add: number; moved: number; visual: number; changed: boolean }
export interface ReportChange { page: string; type: string; typeColor: 'red' | 'green' | 'blue' | 'amber' | 'gray'; risk: string; del: string; ins: string; note: string }
export interface ReportData {
  titleA: string; titleB: string; layout: string; matching: string; pairing: string; fidelity: string; generated: Date;
  identical: boolean; sheets: number; changedSheets: number; deleted: number; added: number; moved: number; visual: number; similarity: number;
  slots: ReportSlot[]; changes: ReportChange[]; omittedChanges: number; warnings: string[];
}

const W = 595.28, H = 841.89, M = 40, CW = W - 2 * M;
const HEAD_BG = rgb(0.945, 0.96, 0.975), ZEBRA = rgb(0.975, 0.98, 0.99);
const tone = (t: ReportChange['typeColor']): Color => (t === 'red' ? COLOR.red : t === 'green' ? COLOR.green : t === 'blue' ? COLOR.blue : t === 'amber' ? COLOR.amber : COLOR.slate);

interface Cell { t: string; color?: Color; bold?: boolean; strike?: boolean; align?: 'right'; maxLines?: number }

/** Draws the report pages at the end of `doc`; returns how many pages it added. */
export function drawReport(doc: PDFDocument, f: Fonts, d: ReportData): number {
  const first = doc.getPageCount();
  let page: PDFPage = doc.addPage([W, H]);
  let y = H - M;
  const newPage = () => { page = doc.addPage([W, H]); y = H - M; };

  // Header
  text(page, f, 'Document Comparison Report', M, y - 20, 20, COLOR.ink, true);
  text(page, f, `Docuzen Compare Engine  \u00b7  Generated ${d.generated.toISOString().replace('T', ' ').slice(0, 16)} UTC`, M, y - 36, 9, COLOR.slate);
  const badge = d.identical ? 'EXACT MATCH' : 'DIFFERENCES DETECTED';
  const bw = f.width(badge, 8, f.bold) + 20;
  fillRect(page, { x: W - M - bw, y: y - 24, w: bw, h: 20 }, d.identical ? rgb(0.86, 0.99, 0.91) : rgb(0.99, 0.89, 0.89));
  strokeRect(page, { x: W - M - bw, y: y - 24, w: bw, h: 20 }, d.identical ? rgb(0.53, 0.94, 0.67) : rgb(0.99, 0.65, 0.65), 0.8);
  text(page, f, badge, W - M - bw + 10, y - 17.5, 8, d.identical ? rgb(0.08, 0.5, 0.24) : rgb(0.73, 0.11, 0.11), true);
  y -= 52;
  hLine(page, M, W - M, y, COLOR.line, 1.5);
  y -= 16;

  // Meta box
  const meta: [string, string][] = [
    ['Original document (before)', d.titleA], ['Modified document (after)', d.titleB], ['Output layout', d.layout],
    ['Word matching', d.matching], ['Page pairing', d.pairing], ['Rendering & fidelity', d.fidelity],
  ];
  const mh = meta.length * 15 + 14;
  fillRect(page, { x: M, y: y - mh, w: CW, h: mh }, rgb(0.972, 0.98, 0.988));
  strokeRect(page, { x: M, y: y - mh, w: CW, h: mh }, COLOR.line, 0.8);
  meta.forEach(([k, v], i) => {
    const ty = y - 17 - i * 15;
    text(page, f, k, M + 12, ty, 8.5, COLOR.slate);
    text(page, f, f.fit(v, 8.5, CW - 175, f.bold), M + 165, ty, 8.5, COLOR.ink, true);
  });
  y -= mh + 14;

  // KPI cards
  const cards: [string, string, Color][] = [
    [String(d.sheets), 'Sheets', COLOR.blue], [String(d.changedSheets), 'Changed sheets', COLOR.amber], [String(d.deleted), 'Deleted words', COLOR.red],
    [String(d.added), 'Added words', COLOR.green], [String(d.moved), 'Moved blocks', COLOR.blue], [`${(d.similarity * 100).toFixed(1)}%`, 'Similarity', COLOR.ink],
  ];
  const gap = 7, cw = (CW - gap * (cards.length - 1)) / cards.length;
  cards.forEach(([v, label, color], i) => {
    const x = M + i * (cw + gap);
    strokeRect(page, { x, y: y - 50, w: cw, h: 50 }, COLOR.line, 0.8);
    const vw = f.bold.widthOfTextAtSize(f.safe(v, f.bold), 17);
    text(page, f, v, x + (cw - vw) / 2, y - 26, 17, color, true);
    const lw = f.width(label.toUpperCase(), 6.2);
    text(page, f, label.toUpperCase(), x + (cw - lw) / 2, y - 41, 6.2, COLOR.slate);
  });
  y -= 64;

  // Legend
  let lx = M;
  for (const [label, color] of [['deleted (red line through)', COLOR.red], ['added (green line under)', COLOR.green], ['moved (blue, dashed)', COLOR.blue], ['visual / graphic change', COLOR.amber]] as [string, Color][]) {
    fillRect(page, { x: lx, y: y - 2, w: 9, h: 9 }, color, 0.8);
    text(page, f, label, lx + 14, y, 8, COLOR.slate);
    lx += 14 + f.width(label, 8) + 18;
  }
  y -= 22;

  if (d.warnings.length) {
    for (const w of d.warnings) {
      const lines = f.wrap(w, 8, CW - 24, 4);
      const h = lines.length * 10.5 + 10;
      fillRect(page, { x: M, y: y - h, w: CW, h }, rgb(1, 0.97, 0.88));
      strokeRect(page, { x: M, y: y - h, w: CW, h }, rgb(0.98, 0.85, 0.5), 0.8);
      lines.forEach((l, i) => text(page, f, l, M + 12, y - 13 - i * 10.5, 8, rgb(0.5, 0.33, 0.04)));
      y -= h + 6;
    }
    y -= 6;
  }

  const heading = (s: string) => {
    if (y - 70 < M + 18) newPage();
    text(page, f, s, M, y - 12, 12.5, COLOR.ink, true);
    y -= 24;
  };

  const table = (cols: { title: string; w: number; align?: 'right' }[], rows: Cell[][]) => {
    const widths = cols.map(c => c.w * CW);
    const header = () => {
      fillRect(page, { x: M, y: y - 16, w: CW, h: 16 }, HEAD_BG);
      let x = M;
      cols.forEach((c, i) => {
        const t = c.title.toUpperCase();
        const tx = c.align === 'right' ? x + widths[i] - 6 - f.width(t, 6.5, f.bold) : x + 6;
        text(page, f, t, tx, y - 11, 6.5, COLOR.slate, true);
        x += widths[i];
      });
      y -= 16;
    };
    header();
    rows.forEach((cells, ri) => {
      const wrapped = cells.map((c, i) => f.wrap(c.t || ' ', 8, widths[i] - 12, c.maxLines ?? 3, c.bold ? f.bold : f.reg));
      const h = Math.max(1, ...wrapped.map(w => w.length)) * 10.5 + 8;
      if (y - h < M + 18) { newPage(); header(); }
      if (ri % 2 === 1) fillRect(page, { x: M, y: y - h, w: CW, h }, ZEBRA);
      let x = M;
      cells.forEach((c, i) => {
        const font = c.bold ? f.bold : f.reg, color = c.color ?? COLOR.ink;
        wrapped[i].forEach((ln, li) => {
          const ty = y - 11 - li * 10.5, lw = font.widthOfTextAtSize(ln, 8);
          const tx = c.align === 'right' ? x + widths[i] - 6 - lw : x + 6;
          page.drawText(ln, { x: tx, y: ty, size: 8, font, color });
          if (c.strike) hLine(page, tx, tx + lw, ty + 2.7, color, 0.6);
        });
        x += widths[i];
      });
      hLine(page, M, W - M, y - h, COLOR.line, 0.5);
      y -= h;
    });
    y -= 14;
  };

  heading('Sheet-by-sheet comparison');
  table(
    [{ title: 'Sheet', w: 0.08 }, { title: 'Pages (before \u2192 after)', w: 0.22 }, { title: 'Status', w: 0.2 }, { title: 'Deleted', w: 0.12, align: 'right' }, { title: 'Added', w: 0.12, align: 'right' }, { title: 'Moved', w: 0.12, align: 'right' }, { title: 'Visual', w: 0.14, align: 'right' }],
    d.slots.map(s => [
      { t: String(s.sheet), bold: true }, { t: s.pages },
      { t: s.status, color: s.changed ? COLOR.amber : COLOR.green, bold: true },
      { t: s.del ? `-${s.del}` : '0', color: s.del ? COLOR.red : COLOR.mute, align: 'right' as const },
      { t: s.add ? `+${s.add}` : '0', color: s.add ? COLOR.green : COLOR.mute, align: 'right' as const },
      { t: s.moved ? String(s.moved) : '0', color: s.moved ? COLOR.blue : COLOR.mute, align: 'right' as const },
      { t: s.visual ? `${s.visual} region${s.visual > 1 ? 's' : ''}` : '0', color: s.visual ? COLOR.amber : COLOR.mute, align: 'right' as const },
    ]),
  );

  if (d.changes.length) {
    heading('Detailed change log');
    table(
      [{ title: '#', w: 0.06 }, { title: 'Page', w: 0.1 }, { title: 'Type', w: 0.12 }, { title: 'Priority', w: 0.1 }, { title: 'Original', w: 0.31 }, { title: 'Modified', w: 0.31 }],
      d.changes.map((c, i) => [
        { t: String(i + 1), color: COLOR.slate },
        { t: c.page },
        { t: c.type, color: tone(c.typeColor), bold: true },
        { t: c.risk, color: c.risk === 'Critical' ? COLOR.red : c.risk === 'High' ? COLOR.amber : COLOR.slate, bold: c.risk === 'Critical' || c.risk === 'High' },
        { t: c.del || '\u2014', color: c.del ? COLOR.red : COLOR.mute, strike: !!c.del && c.typeColor !== 'blue', maxLines: 4 },
        { t: (c.ins || '\u2014') + (c.note ? `  (${c.note})` : ''), color: c.ins ? COLOR.green : COLOR.mute, maxLines: 4 },
      ]),
    );
    if (d.omittedChanges > 0) text(page, f, `... and ${d.omittedChanges} more change(s) not listed.`, M, y, 8.5, COLOR.slate);
  }

  const n = doc.getPageCount() - first;
  for (let p = 0; p < n; p++) {
    const pg = doc.getPage(first + p);
    text(pg, f, `Docuzen Compare Engine  \u00b7  report page ${p + 1} of ${n}`, M, 22, 7.5, COLOR.mute);
  }
  return n;
}
