/*
 * Direct PDF → PDF comparison output.
 *   Input : a CompareResult whose tokens carry word geometry (compareRaw on PDF-derived documents) + the two source PDFs.
 *   Output: a new PDF with the ORIGINAL pages embedded as vector pages and the changes drawn on top —
 *           red = deleted (line through), green = added (line under), blue = moved, amber = graphic / image change.
 *   Layouts: 'sidebyside' (original left, modified right, same sheet) and 'overlay' (modified page 1:1, additions in
 *           place, deletions as numbered-free callouts in the right margin with a caret at the position they were removed).
 */
import { PDFDocument, rgb } from 'pdf-lib';
import type { CompareResult, Change, Tok } from './compare';
import { joinToks } from './compare';
import { DEL, EQ } from './diff';
import type { Box } from './geo';
import type { PdfPageData } from './pdf';
import type { RawDoc } from './compare';
import {
  COLOR, Fonts, Pane, PdfSource, clusterBoxes, fillRect, strokeRect, hLine, vLine, text, textCentered, pill, addOutline, collectGarbage,
  paintAdded, paintDeleted, paintGraphic, paintMoved, type JpegRenderer, type Rect,
} from './pdfdraw';
import { drawReport, type ReportChange, type ReportData, type ReportSlot } from './pdfreport';
import { diffImages, explainedByText, type RasterImage } from './rasterdiff';

export type PdfLayout = 'sidebyside' | 'overlay';

export interface DocPdf { name: string; bytes: Uint8Array; pages: PdfPageData[]; raw: RawDoc }

export interface PdfOutputOptions {
  layout: PdfLayout; includeSummary: boolean; onlyChangedPages: boolean; banners: boolean; marginBars: boolean;
  matchLabel: string; now?: Date;
}

// ── Visual (image) analysis ─────────────────────────────────────────────────

export interface SlotVisual { raster: boolean; changed: boolean; boxes: Box[]; changedPixels: number; sampled: number }
export type RenderFn = (doc: 0 | 1, page: number, scale: number) => Promise<RasterImage>;
export interface VisualOptions { enabled: boolean; dpi: number; threshold: number; antiAlias: boolean; maxShift: number }

type R4 = { x0: number; y0: number; x1: number; y1: number };

function pageRects(raw: RawDoc): Map<number, R4[]> {
  const m = new Map<number, R4[]>();
  for (const l of raw.lines) {
    for (const g of l.geo ?? []) {
      for (const s of g) {
        let lo = Infinity, hi = -Infinity;
        for (const x of s.xs) { if (x < lo) lo = x; if (x > hi) hi = x; }
        const arr = m.get(s.p) ?? [];
        arr.push({ x0: lo, y0: s.y0, x1: hi, y1: s.y1 });
        m.set(s.p, arr);
      }
    }
  }
  return m;
}

/**
 * Renders every paired page of both documents, compares the pixels and keeps the regions that text does not explain
 * (images, drawings, table rules, shifted layout). Pages where one side has no text at all (scans) are compared purely
 * as images.
 */
export async function analyzeVisuals(res: CompareResult, A: DocPdf, B: DocPdf, render: RenderFn, o: VisualOptions,
  onProgress?: (done: number, total: number) => void): Promise<(SlotVisual | null)[]> {
  const out: (SlotVisual | null)[] = new Array(res.slots.length).fill(null);
  const rectsA = pageRects(A.raw), rectsB = pageRects(B.raw);
  const scale = o.dpi / 72;
  const todo = res.slots.map((s, k) => ({ s, k })).filter(({ s }) => s.a >= 0 && s.b >= 0 &&
    (o.enabled || A.pages[s.a].wordCount === 0 || B.pages[s.b].wordCount === 0));
  let done = 0;
  for (const { s, k } of todo) {
    onProgress?.(done++, todo.length);
    const raster = A.pages[s.a].wordCount === 0 || B.pages[s.b].wordCount === 0;
    const ia = await render(0, s.a, scale), ib = await render(1, s.b, scale);
    const d = diffImages(ia, ib, { threshold: o.threshold, antiAlias: o.antiAlias, maxShift: o.maxShift });
    let boxes: Box[] = d.boxes.map(b => ({ p: s.b, x0: b.x0 / scale, y0: b.y0 / scale, x1: b.x1 / scale, y1: b.y1 / scale }));
    if (!raster) {
      if (!d.changed) boxes = [];
      else {
        const words = [...(rectsA.get(s.a) ?? []), ...(rectsB.get(s.b) ?? [])];
        boxes = boxes.filter(b => !explainedByText(b, words));
      }
    }
    out[k] = { raster, changed: raster ? d.changed : boxes.length > 0, boxes, changedPixels: d.changedPixels, sampled: d.sampled };
  }
  onProgress?.(todo.length, todo.length);
  return out;
}

// ── Per-sheet marks ─────────────────────────────────────────────────────────

interface Marks { del: Box[]; add: Box[]; mvFrom: Box[]; mvTo: Box[]; gfx: Box[]; nDel: number; nAdd: number; nMove: number }
interface SlotInfo { k: number; a: number; b: number; raster: boolean; marks: Marks; changed: boolean; status: string }

function analyseSlots(res: CompareResult, A: DocPdf, B: DocPdf, visuals: (SlotVisual | null)[]): SlotInfo[] {
  const slotOfA = new Int32Array(res.pagesA).fill(-1), slotOfB = new Int32Array(res.pagesB).fill(-1);
  res.slots.forEach((s, k) => { if (s.a >= 0) slotOfA[s.a] = k; if (s.b >= 0) slotOfB[s.b] = k; });
  const infos: SlotInfo[] = res.slots.map((s, k) => {
    const v = visuals[k];
    const raster = !!v?.raster || (s.a >= 0 && s.b >= 0 && (A.pages[s.a].wordCount === 0 || B.pages[s.b].wordCount === 0));
    return { k, a: s.a, b: s.b, raster, status: '', changed: false, marks: { del: [], add: [], mvFrom: [], mvTo: [], gfx: v?.boxes ?? [], nDel: 0, nAdd: 0, nMove: 0 } };
  });
  for (const it of res.items) {
    if (it.kind === EQ) continue;
    const t = (it.kind === DEL ? it.a : it.b)!;
    const k = (it.kind === DEL ? slotOfA : slotOfB)[t.page];
    if (k < 0 || infos[k].raster) continue;
    const m = infos[k].marks, moved = it.move >= 0;
    if (it.kind === DEL) { moved ? m.nMove++ : m.nDel++; (moved ? m.mvFrom : m.del).push(...(t.boxes ?? [])); }
    else { moved ? m.nMove++ : m.nAdd++; (moved ? m.mvTo : m.add).push(...(t.boxes ?? [])); }
  }
  for (const s of infos) {
    const v = visuals[s.k];
    const m = s.marks;
    s.changed = s.a < 0 || s.b < 0 || m.nDel > 0 || m.nAdd > 0 || m.nMove > 0 || (s.raster ? !!v?.changed : m.gfx.length > 0);
    s.status = s.a < 0 ? 'Inserted page' : s.b < 0 ? 'Deleted page' : s.raster ? (s.changed ? 'Image differences' : 'Images identical') : s.changed ? 'Changed' : 'Identical';
  }
  return infos;
}

/** Unchanged word before / after each change — anchors for margin callouts. */
function neighbours(res: CompareResult): { prev: (Tok | null)[]; next: (Tok | null)[] } {
  const n = res.changes.length;
  const prev: (Tok | null)[] = new Array(n).fill(null), next: (Tok | null)[] = new Array(n).fill(null);
  const seen = new Uint8Array(n);
  let open: number[] = [], last: Tok | null = null;
  for (const it of res.items) {
    if (it.kind === EQ) { for (const c of open) next[c] = it.b; open = []; last = it.b; continue; }
    const c = it.change;
    if (c < 0 || res.changes[c].moveId >= 0) continue;
    if (!seen[c]) { seen[c] = 1; prev[c] = last; open.push(c); }
  }
  return { prev, next };
}

// ── Sheet drawing ───────────────────────────────────────────────────────────

const M = 20, GUTTER = 20, BANNER = 44, CALLOUT_W = 160;
const MUTED_ON_NAVY = COLOR.mute;

interface Ctx {
  out: PDFDocument; f: Fonts; A: DocPdf; B: DocPdf; srcA: PdfSource; srcB: PdfSource; o: PdfOutputOptions; res: CompareResult;
  sheets: number; nb: ReturnType<typeof neighbours>; slotByB: Int32Array; slotRaster: (beforePage: number) => boolean;
}

function statusText(s: SlotInfo): string {
  const m = s.marks;
  if (!s.changed) return 'Pages identical';
  if (s.raster) return 'Visual differences detected (image comparison)';
  if (m.gfx.length && !m.nDel && !m.nAdd && !m.nMove) return `Visual / graphic differences detected (${m.gfx.length} region${m.gfx.length > 1 ? 's' : ''})`;
  return `Differences detected (${m.nDel} removed, ${m.nAdd} added${m.nMove ? `, ${m.nMove} moved` : ''}${m.gfx.length ? `, ${m.gfx.length} visual` : ''})`;
}

function banner(ctx: Ctx, pg: ReturnType<PDFDocument['addPage']>, sheetW: number, sheetH: number, title: string, s: SlotInfo, sides?: { left: string; right: string }) {
  const { f } = ctx, y = sheetH - BANNER, cx = sheetW / 2;
  fillRect(pg, { x: 0, y, w: sheetW, h: BANNER }, COLOR.navy);
  hLine(pg, 0, sheetW, y, COLOR.navyLine, 1);
  textCentered(pg, f, title, cx, y + 24, 9, COLOR.white, true);
  textCentered(pg, f, statusText(s), cx, y + 10, 8, s.changed ? rgb(0.95, 0.45, 0.45) : rgb(0.3, 0.85, 0.45));
  if (!sides) return;
  const m = s.marks;
  text(pg, f, 'ORIGINAL (BEFORE)', 24, y + 24, 9, COLOR.white, true);
  text(pg, f, f.fit(ctx.A.name + (sides.left ? '  \u00b7  ' + sides.left : ''), 8, Math.max(80, cx - 190)), 24, y + 10, 8, MUTED_ON_NAVY);
  pill(pg, f, s.raster ? 'IMAGE DIFF' : m.nDel ? `${m.nDel} DELETIONS` : 'NO DELETIONS', 24 + f.width('ORIGINAL (BEFORE)', 9, f.bold) + 10, y + 21, m.nDel && !s.raster ? COLOR.red : rgb(0.22, 0.28, 0.38));
  const rx = Math.max(cx + 190, sheetW - 280);
  text(pg, f, 'MODIFIED (AFTER)', rx, y + 24, 9, COLOR.white, true);
  text(pg, f, f.fit(ctx.B.name + (sides.right ? '  \u00b7  ' + sides.right : ''), 8, sheetW - rx - 24), rx, y + 10, 8, MUTED_ON_NAVY);
  pill(pg, f, s.raster ? 'IMAGE DIFF' : m.nAdd ? `${m.nAdd} ADDITIONS` : 'NO ADDITIONS', rx + f.width('MODIFIED (AFTER)', 9, f.bold) + 10, y + 21, m.nAdd && !s.raster ? COLOR.green : rgb(0.22, 0.28, 0.38));
}

function pageFrame(pg: ReturnType<PDFDocument['addPage']>, r: Rect) { fillRect(pg, r, COLOR.white); }
function pageBorder(pg: ReturnType<PDFDocument['addPage']>, r: Rect) { strokeRect(pg, r, rgb(0.72, 0.76, 0.82), 0.6); }

function missingPane(ctx: Ctx, pg: ReturnType<PDFDocument['addPage']>, r: Rect, label: string) {
  fillRect(pg, r, rgb(0.96, 0.97, 0.98));
  strokeRect(pg, r, rgb(0.72, 0.76, 0.82), 0.8, [4, 3]);
  textCentered(pg, ctx.f, label, r.x + r.w / 2, r.y + r.h / 2, 12, COLOR.slate);
}

function drawSideBySide(ctx: Ctx, s: SlotInfo, n: number) {
  const { out, A, B, o } = ctx;
  const aOk = s.a >= 0, bOk = s.b >= 0;
  const pa = aOk ? A.pages[s.a] : B.pages[s.b], pb = bOk ? B.pages[s.b] : A.pages[s.a];
  const bannerH = o.banners ? BANNER : 0;
  const sheetW = M + pa.width + GUTTER + pb.width + M, maxH = Math.max(pa.height, pb.height), sheetH = M + maxH + M + bannerH;
  const pg = out.addPage([sheetW, sheetH]);
  fillRect(pg, { x: 0, y: 0, w: sheetW, h: sheetH }, COLOR.desk);
  if (o.banners) banner(ctx, pg, sheetW, sheetH, `COMPARISON  \u00b7  SHEET ${n} OF ${ctx.sheets}`, s, { left: aOk ? `p.${s.a + 1} of ${A.pages.length}` : '', right: bOk ? `p.${s.b + 1} of ${B.pages.length}` : '' });

  const lx = M, ly = M + (maxH - pa.height) / 2, rx = M + pa.width + GUTTER, ry = M + (maxH - pb.height) / 2;
  const lr: Rect = { x: lx, y: ly, w: pa.width, h: pa.height }, rr: Rect = { x: rx, y: ry, w: pb.width, h: pb.height };
  const m = s.marks;

  if (aOk) {
    pageFrame(pg, lr);
    ctx.srcA.draw(pg, s.a, 'FmL', lx, ly, 1);
    pageBorder(pg, lr);
    const pane = new Pane(lx, ly, 1, pa.height), st = { margin: o.marginBars, barX: Math.max(4, lx - 8) };
    for (const b of clusterBoxes(m.del)) paintDeleted(pg, pane.map(b), st);
    for (const b of clusterBoxes(m.mvFrom)) paintMoved(pg, pane.map(b), st);
    for (const b of m.gfx) paintGraphic(pg, pane.map(b), st);
  } else missingPane(ctx, pg, lr, 'Page not present in original document');

  if (bOk) {
    pageFrame(pg, rr);
    ctx.srcB.draw(pg, s.b, 'FmR', rx, ry, 1);
    pageBorder(pg, rr);
    const pane = new Pane(rx, ry, 1, pb.height), st = { margin: o.marginBars, barX: rx + pb.width + 8 };
    for (const b of clusterBoxes(m.add)) paintAdded(pg, pane.map(b), st);
    for (const b of clusterBoxes(m.mvTo)) paintMoved(pg, pane.map(b), st);
    for (const b of m.gfx) paintGraphic(pg, pane.map(b), st);
  } else missingPane(ctx, pg, rr, 'Page deleted in modified document');

  const divX = M + pa.width + GUTTER / 2;
  vLine(pg, divX, 12, sheetH - bannerH - 8, rgb(0.8, 0.84, 0.9), 1);
}

interface Callout { lines: string[]; w: number; h: number; ax: number; ay: number; y: number }

function drawOverlay(ctx: Ctx, s: SlotInfo, n: number, calloutsFor: Map<number, Change[]>, beforeToAfter: Int32Array) {
  const { out, f, A, B, o } = ctx;
  const useB = s.b >= 0;
  const info = useB ? B.pages[s.b] : A.pages[s.a];
  const bannerH = o.banners ? BANNER : 0;
  const sheetW = M + info.width + CALLOUT_W + M, sheetH = M + info.height + M + bannerH;
  const pg = out.addPage([sheetW, sheetH]);
  fillRect(pg, { x: 0, y: 0, w: sheetW, h: sheetH }, COLOR.desk);
  if (o.banners) banner(ctx, pg, sheetW, sheetH, `COMPARISON  \u00b7  SHEET ${n} OF ${ctx.sheets}`, s);

  const px = M, py = M, r: Rect = { x: px, y: py, w: info.width, h: info.height };
  pageFrame(pg, r);
  (useB ? ctx.srcB : ctx.srcA).draw(pg, useB ? s.b : s.a, 'FmBase', px, py, 1);
  pageBorder(pg, r);
  const pane = new Pane(px, py, 1, info.height), m = s.marks;
  const leftBar = { margin: o.marginBars, barX: Math.max(4, px - 8) }, rightBar = { margin: o.marginBars, barX: px + info.width + 6 };

  if (!useB) { // page exists only in the original: mark its content in place
    for (const b of clusterBoxes(m.del)) paintDeleted(pg, pane.map(b), leftBar);
    for (const b of clusterBoxes(m.mvFrom)) paintMoved(pg, pane.map(b), leftBar);
    return;
  }
  for (const b of clusterBoxes(m.add)) paintAdded(pg, pane.map(b), rightBar);
  for (const b of clusterBoxes(m.mvTo)) paintMoved(pg, pane.map(b), rightBar);
  for (const b of m.gfx) paintGraphic(pg, pane.map(b), rightBar);

  // Deletion callouts in the right margin
  const calloutX = px + info.width + 10, maxW = CALLOUT_W - 16, FS = 6.5, LH = 8.5, GAP = 3;
  const items: Callout[] = [];
  for (const ch of calloutsFor.get(s.b) ?? []) {
    const del = ch.del.filter(t => beforeToAfter[t.page] >= 0 && !ctx.slotRaster(t.page));
    if (!del.length) continue;
    const onPage = (tk: Tok | null | undefined) => tk && tk.boxes?.find(b => b.p === s.b);
    let ax: number, ay: number;
    const insHere = ch.ins.find(t => t.page === s.b && t.boxes?.length);
    const prev = ctx.nb.prev[ch.id], next = ctx.nb.next[ch.id];
    if (insHere) { const b = insHere.boxes!.find(x => x.p === s.b)!, q = pane.map(b); ax = q.x; ay = q.y + q.h / 2; }
    else if (onPage(prev)) { const q = pane.map(onPage(prev)!); ax = q.x + q.w; ay = q.y + q.h / 2; }
    else if (onPage(next)) { const q = pane.map(onPage(next)!); ax = q.x; ay = q.y + q.h / 2; }
    else {
      const first = del[0], ba = first.boxes?.[0];
      const bi = A.pages[first.page];
      ax = px + info.width; ay = py + Math.min(1, Math.max(0, 1 - (ba ? ba.y0 : 0) / Math.max(1, bi.height))) * info.height;
    }
    const lines = f.wrap(joinToks(del), FS, maxW - 12, 3);
    if (!lines.length) continue;
    const lw = Math.max(...lines.map(l => f.width(l, FS)));
    items.push({ lines, w: Math.min(maxW, Math.max(32, lw + 12)), h: Math.max(14, 5 + lines.length * LH), ax, ay, y: 0 });
  }
  items.sort((p, q) => q.ay - p.ay);
  let last = Infinity;
  for (const it of items) { let y = it.ay - it.h / 2; if (y + it.h > last - GAP) y = last - GAP - it.h; it.y = y; last = y; }
  for (let k = items.length - 1; k >= 0; k--) {
    const lower = k === items.length - 1 ? py : items[k + 1].y + items[k + 1].h + GAP;
    if (items[k].y < lower) items[k].y = lower;
  }
  for (const it of items) {
    vLine(pg, it.ax, it.ay - 3.5, it.ay + 3.5, COLOR.red, 1.5);                                  // caret where text was removed
    if (it.ax < calloutX - 4) pg.drawLine({ start: { x: it.ax + 1, y: it.ay }, end: { x: calloutX, y: it.y + it.h / 2 }, color: rgb(0.85, 0.35, 0.35), thickness: 0.6, dashArray: [2, 2] });
    pg.drawRectangle({ x: calloutX, y: it.y, width: it.w, height: it.h, color: COLOR.redSoft, borderColor: COLOR.red, borderWidth: 0.6 });
    it.lines.forEach((ln, i) => {
      const ty = it.y + it.h - 2 - (i + 1) * LH, tx = calloutX + 5;
      pg.drawText(ln, { x: tx, y: ty, size: FS, font: f.reg, color: rgb(0.8, 0.15, 0.15) });
      hLine(pg, tx, tx + f.reg.widthOfTextAtSize(ln, FS), ty + FS * 0.35, COLOR.red, 0.5);
    });
    if (o.marginBars) vLine(pg, leftBar.barX, it.ay - 5, it.ay + 5, COLOR.red, 2.5);
  }
}

// ── Orchestration ───────────────────────────────────────────────────────────

export interface PdfOutput {
  bytes: Uint8Array; pages: number; sheets: number; warnings: string[];
  stats: { sheets: number; changedSheets: number; deleted: number; added: number; moved: number; visual: number };
  modeA: 'vector' | 'raster'; modeB: 'vector' | 'raster'; removedObjects: number;
}

const RISK = { critical: 'Critical', high: 'High', medium: 'Medium', low: 'Low', info: 'Info' } as const;
const TYPE: Record<string, [string, ReportChange['typeColor']]> = {
  insert: ['Added', 'green'], delete: ['Deleted', 'red'], replace: ['Replaced', 'amber'], move: ['Moved', 'blue'], number: ['Number', 'amber'],
  spelling: ['Spelling', 'amber'], case: ['Case', 'gray'], punctuation: ['Punctuation', 'gray'], spacing: ['Spacing', 'gray'],
};

export interface BuildInputs { jpegA?: JpegRenderer; jpegB?: JpegRenderer }

export async function buildComparisonPdf(res: CompareResult, A: DocPdf, B: DocPdf, visuals: (SlotVisual | null)[], o: PdfOutputOptions,
  inputs: BuildInputs = {}, onProgress?: (msg: string, frac: number) => void): Promise<PdfOutput> {
  const warnings: string[] = [];
  const infos = analyseSlots(res, A, B, visuals);
  const rendered = infos.filter(s => !o.onlyChangedPages || s.changed);
  const progress = (msg: string, frac: number) => onProgress?.(msg, Math.min(1, Math.max(0, frac)));

  const out = await PDFDocument.create();
  out.setProducer('Docuzen Compare Engine');
  out.setCreator('Docuzen Compare Engine');
  out.setTitle(`Comparison: ${A.name} \u2192 ${B.name}`);
  out.setSubject(o.layout === 'sidebyside' ? 'Side-by-side comparison' : 'Overlay comparison');
  const now = o.now ?? new Date();
  out.setCreationDate(now); out.setModificationDate(now);
  const f = await Fonts.load(out);

  const srcA = new PdfSource(out, A.name, A.bytes, A.pages, inputs.jpegA), srcB = new PdfSource(out, B.name, B.bytes, B.pages, inputs.jpegB);
  const needA: number[] = [], needB: number[] = [];
  for (const s of rendered) {
    if (o.layout === 'sidebyside') { if (s.a >= 0) needA.push(s.a); if (s.b >= 0) needB.push(s.b); }
    else if (s.b >= 0) needB.push(s.b); else needA.push(s.a);
  }
  progress(`Embedding pages of ${A.name}`, 0.05);
  await srcA.prepare(needA);
  progress(`Embedding pages of ${B.name}`, 0.25);
  await srcB.prepare(needB);
  for (const src of [srcA, srcB]) if (src.note) warnings.push(src.note);
  if (res.stats.cappedRegions > 0) warnings.push(`${res.stats.cappedRegions} region(s) hit the diff cost cap and were split heuristically; the marks there are valid but may not be minimal.`);

  const stats = {
    sheets: infos.length, changedSheets: infos.filter(s => s.changed).length,
    deleted: infos.reduce((n, s) => n + s.marks.nDel, 0), added: infos.reduce((n, s) => n + s.marks.nAdd, 0),
    moved: res.moves.length, visual: infos.reduce((n, s) => n + s.marks.gfx.length, 0),
  };
  const bookmarks: { title: string; page: number }[] = [];

  // Summary pages
  if (o.includeSummary) {
    progress('Writing summary', 0.4);
    const maxRows = 400;
    const label = (s: SlotInfo) => (s.a >= 0 && s.b >= 0 ? (s.a === s.b ? `p.${s.a + 1}` : `p.${s.a + 1} \u2192 p.${s.b + 1}`) : s.b >= 0 ? `new p.${s.b + 1}` : `removed p.${s.a + 1}`);
    const clip = (t: string) => (t.length > 300 ? t.slice(0, 297) + '...' : t);
    const data: ReportData = {
      titleA: A.name, titleB: B.name, layout: o.layout === 'sidebyside' ? 'Side-by-side (original left, modified right)' : 'Overlay (modified page with deletion callouts)',
      matching: o.matchLabel, pairing: res.slots.some(s => s.a !== s.b) ? 'Pages paired by content (inserted / deleted pages detected)' : 'Pages paired by position',
      fidelity: [srcA, srcB].every(x => x.mode === 'vector') ? 'Original pages embedded as vector pages; text stays selectable' : 'Vector pages where possible; image rendering used for some input',
      generated: now, identical: stats.changedSheets === 0, ...stats, similarity: res.stats.similarity,
      slots: infos.map((s): ReportSlot => ({ sheet: s.k + 1, pages: label(s), status: s.status, del: s.marks.nDel, add: s.marks.nAdd, moved: s.marks.nMove, visual: s.marks.gfx.length, changed: s.changed })),
      changes: res.changes.slice(0, maxRows).map((c): ReportChange => {
        const [tl, tc] = TYPE[c.type] ?? ['Changed', 'gray'];
        return {
          page: c.type === 'move' ? `${c.pageA + 1} \u2192 ${c.pageB + 1}` : String((c.ins.length ? c.pageB : c.pageA) + 1), type: tl, typeColor: tc, risk: RISK[c.risk],
          del: clip(c.delText), ins: c.type === 'move' ? 'moved, text unchanged' : clip(c.insText), note: c.note,
        };
      }),
      omittedChanges: Math.max(0, res.changes.length - maxRows), warnings,
    };
    const n = drawReport(out, f, data);
    bookmarks.push({ title: 'Executive summary', page: 0 });
    void n;
  }

  // Sheets
  const slotByB = new Int32Array(res.pagesB).fill(-1);
  const beforeToAfter = new Int32Array(res.pagesA).fill(-1);
  const rasterPageA = new Uint8Array(res.pagesA);
  infos.forEach(s => { if (s.b >= 0) slotByB[s.b] = s.k; if (s.a >= 0 && s.b >= 0) beforeToAfter[s.a] = s.b; if (s.a >= 0 && s.raster) rasterPageA[s.a] = 1; });
  const nb = neighbours(res);
  const calloutsFor = new Map<number, Change[]>();
  if (o.layout === 'overlay') {
    for (const ch of res.changes) {
      if (ch.moveId >= 0 || !ch.del.length) continue;
      let home: number;
      if (ch.ins.length) home = ch.ins[0].page;
      else {
        const mapped = beforeToAfter[ch.del[0].page], pv = nb.prev[ch.id]?.page ?? -1, nx = nb.next[ch.id]?.page ?? -1;
        home = mapped >= 0 && (mapped === pv || mapped === nx) ? mapped : pv >= 0 ? pv : nx >= 0 ? nx : mapped;
      }
      if (home < 0) continue;
      const list = calloutsFor.get(home) ?? [];
      list.push(ch);
      calloutsFor.set(home, list);
    }
  }
  const ctx: Ctx = { out, f, A, B, srcA, srcB, o, res, sheets: infos.length, nb, slotByB, slotRaster: p => rasterPageA[p] === 1 };

  rendered.forEach((s, i) => {
    progress(`Drawing sheet ${i + 1} of ${rendered.length}`, 0.45 + 0.45 * (i / Math.max(1, rendered.length)));
    const pageIndex = out.getPageCount();
    if (o.layout === 'sidebyside') drawSideBySide(ctx, s, s.k + 1); else drawOverlay(ctx, s, s.k + 1, calloutsFor, beforeToAfter);
    const m = s.marks;
    const where = s.a >= 0 && s.b >= 0 ? (s.a === s.b ? `Page ${s.a + 1}` : `Page ${s.a + 1} \u2192 ${s.b + 1}`) : s.b >= 0 ? `Page ${s.b + 1} (inserted)` : `Page ${s.a + 1} (deleted)`;
    const what = !s.changed ? 'Identical' : s.raster ? 'Differences (image comparison)'
      : `Differences (${m.nDel} del, ${m.nAdd} add${m.nMove ? `, ${m.nMove} moved` : ''}${m.gfx.length ? `, ${m.gfx.length} visual` : ''})`;
    bookmarks.push({ title: `${where}: ${what}`, page: pageIndex });
  });

  if (!rendered.length) {
    const pg = out.addPage([595.28, 841.89]);
    pg.drawCircle({ x: 297.64, y: 500, size: 40, color: COLOR.green });
    pg.drawLine({ start: { x: 278, y: 500 }, end: { x: 292, y: 486 }, thickness: 5, color: COLOR.white });
    pg.drawLine({ start: { x: 292, y: 486 }, end: { x: 318, y: 516 }, thickness: 5, color: COLOR.white });
    textCentered(pg, f, 'DOCUMENTS ARE IDENTICAL', 297.64, 420, 16, COLOR.ink, true);
    textCentered(pg, f, `All ${infos.length} sheet(s) match: no text or visual differences were found.`, 297.64, 395, 11, COLOR.slate);
    bookmarks.push({ title: 'No differences', page: out.getPageCount() - 1 });
  }

  progress('Finishing PDF', 0.93);
  addOutline(out, bookmarks);
  await out.flush();
  const { removed } = collectGarbage(out);
  const bytes = await out.save({ useObjectStreams: true });
  progress('Done', 1);
  return { bytes, pages: out.getPageCount(), sheets: rendered.length, warnings, stats, modeA: srcA.mode, modeB: srcB.mode, removedObjects: removed };
}

