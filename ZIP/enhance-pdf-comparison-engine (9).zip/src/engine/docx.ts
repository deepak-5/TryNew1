/*
 * Word (.docx) support without a DOM: a streaming tag scanner over word/document.xml (works in browsers and Node),
 * a plain-text → .docx writer (demo files) and a redline writer that emits REAL Word tracked changes (w:ins / w:del),
 * so the comparison can be reviewed with Accept / Reject in Word.
 */
import { unzipSync, zipSync, strFromU8, strToU8 } from 'fflate';
import { EQ, INS } from './diff';
import type { Item } from './compare';

const PAGE_SPLIT = /\n?[ \t]*(?:\f|={3,}[ \t]*page(?:[ \t]*break)?[ \t]*={3,})[ \t]*\n?/i;
const ENT: Record<string, string> = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'" };

function decode(s: string): string {
  return s.replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, (m, e: string) => {
    if (e[0] !== '#') return ENT[e.toLowerCase()] ?? m;
    const cp = e[1] === 'x' || e[1] === 'X' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10);
    return Number.isFinite(cp) && cp > 0 && cp <= 0x10ffff ? String.fromCodePoint(cp) : '';
  });
}

export interface DocxText { text: string; pages: number; paragraphs: number; tables: number; trackedChanges: number; renderedBreaks: boolean }

/**
 * document.xml → text in the lab format: one line per paragraph, blank line between paragraphs, table rows as
 * "cell | cell", page breaks as "=== PAGE ===". Tracked changes are read in their ACCEPTED state (w:del / w:moveFrom
 * skipped). If Word stored rendered page breaks (w:lastRenderedPageBreak) those are used, so page numbers match Word's
 * own layout; otherwise explicit page breaks and pageBreakBefore are used.
 */
export function docxXmlToText(xml: string): DocxText {
  const rendered = xml.includes('<w:lastRenderedPageBreak');
  const out: string[] = [];
  const cells: string[][] = [], rows: string[][] = [], paraStack: string[][] = [];
  let para: string[] | null = null;
  let inT = false, run = 0, skip = 0, paragraphs = 0, tables = 0, tracked = 0;
  const emit = (p: string) => { if (cells.length) cells[cells.length - 1].push(p); else out.push(p); };

  const re = /<(\/?)([\w:.-]+)([^>]*?)(\/?)>|([^<]+)/g;
  for (let m = re.exec(xml); m; m = re.exec(xml)) {
    if (m[5] !== undefined) { if (inT && !skip && para) para.push(decode(m[5])); continue; }
    const close = m[1] === '/', name = m[2], attrs = m[3], self = m[4] === '/';
    if (name === 'w:del' || name === 'w:moveFrom' || name === 'mc:Fallback') {
      if (!self) { skip += close ? -1 : 1; if (!close && name !== 'mc:Fallback') tracked++; }
      continue;
    }
    if (name === 'w:ins' && !close && !self) tracked++;
    if (skip) continue;
    switch (name) {
      case 'w:p':
        if (self) { emit(''); break; }
        if (!close) { if (para) paraStack.push(para); para = []; paragraphs++; }
        else if (para) { emit(para.join('')); para = paraStack.pop() ?? null; }
        break;
      case 'w:r': if (!self) run += close ? -1 : 1; break;
      case 'w:t': inT = !close && !self; break;
      case 'w:tab': if (run > 0 && para) para.push(' '); break;
      case 'w:br': case 'w:cr':
        if (run > 0 && para) para.push(!rendered && /w:type="page"/.test(attrs) ? '\f' : ' ');
        break;
      case 'w:lastRenderedPageBreak': if (rendered && para) para.push('\f'); break;
      case 'w:pageBreakBefore': if (!rendered && para && !/w:val="(?:0|false|off)"/.test(attrs)) para.push('\f'); break;
      case 'w:noBreakHyphen': if (para) para.push('-'); break;
      case 'w:tbl': if (!close && !self) tables++; break;
      case 'w:tr':
        if (close) { const r = rows.pop(); if (r && r.some(Boolean)) emit(r.join(' | ')); }
        else if (!self) rows.push([]);
        break;
      case 'w:tc':
        if (close) { const c = cells.pop(); if (c && rows.length) rows[rows.length - 1].push(c.filter(s => s.trim()).join(' ')); }
        else if (!self) cells.push([]);
        break;
    }
  }

  // Collapse whitespace but keep the \f page-break markers (String.trim would eat them).
  const paras = out.map(p => p.replace(/[^\S\f]+/g, ' ').replace(/^ +| +$/g, '')).filter(p => p.length > 0);
  const text = paras.join('\n\n').replace(/\s*\f\s*/g, '\n=== PAGE ===\n');
  return { text, pages: text.split(PAGE_SPLIT).length, paragraphs, tables, trackedChanges: tracked, renderedBreaks: rendered };
}

export function extractDocxXml(data: Uint8Array): string {
  let files: Record<string, Uint8Array>;
  try { files = unzipSync(data, { filter: f => f.name === 'word/document.xml' }); }
  catch { throw new Error('This file is not a valid .docx package (zip could not be read).'); }
  const xml = files['word/document.xml'];
  if (!xml) throw new Error('No word/document.xml inside — this zip is not a Word document.');
  return strFromU8(xml);
}

export function docxToText(data: Uint8Array): DocxText {
  return docxXmlToText(extractDocxXml(data));
}

// ── Writers ─────────────────────────────────────────────────────────────────

const esc = (s: string) => s
  .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\uFFFE\uFFFF]/g, '')
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

const W_NS = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main';
const CONTENT_TYPES = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>';
const RELS = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>';
const SECT = '<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134" w:header="567" w:footer="567" w:gutter="0"/></w:sectPr>';

export const DOCX_MIME = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';

function pack(body: string): Uint8Array {
  const doc = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="${W_NS}"><w:body>${body}${SECT}</w:body></w:document>`;
  return zipSync({ '[Content_Types].xml': strToU8(CONTENT_TYPES), '_rels/.rels': strToU8(RELS), 'word/document.xml': strToU8(doc) }, { level: 6 });
}

const run = (t: string, rpr = '') => `<w:r>${rpr}<w:t xml:space="preserve">${esc(t)}</w:t></w:r>`;
const PAGE_BREAK = '<w:r><w:br w:type="page"/></w:r>';

/** Lab text → .docx. Blank-line separated blocks become paragraphs (wrapped lines are re-joined so Word re-flows them). */
export function textToDocx(text: string): Uint8Array {
  let body = '';
  text.replace(/\r\n?/g, '\n').split(PAGE_SPLIT).forEach((page, i) => {
    if (i > 0) body += `<w:p>${PAGE_BREAK}</w:p>`;
    for (const block of page.split(/\n[ \t]*\n/)) {
      // Re-join wrapped lines like a word processor: "conse-⏎quential" → "consequential", "state-of-the-⏎art" keeps its hyphen.
      const p = block.split('\n').map(l => l.trim()).filter(Boolean).reduce((acc, l) => {
        const m = /(\S+)-$/.exec(acc);
        if (m && /^\p{Ll}/u.test(l)) return m[1].includes('-') ? acc + l : acc.slice(0, -1) + l;
        return acc ? acc + ' ' + l : l;
      }, '');
      if (p) body += `<w:p>${run(p)}</w:p>`;
    }
  });
  return pack(body);
}

/**
 * Comparison → .docx with native tracked changes. Accept All in Word gives the modified text, Reject All the original.
 * Moved text is tracked as delete + insert by the author "Docuzen Compare (moved)" so it can be filtered in the review pane.
 */
export function redlineDocx(items: Item[], title: string, now = new Date()): Uint8Array {
  const date = now.toISOString().replace(/\.\d+Z$/, 'Z');
  let id = 1;
  let body = `<w:p><w:pPr><w:spacing w:after="80"/></w:pPr>${run(title, '<w:rPr><w:b/><w:sz w:val="32"/></w:rPr>')}</w:p>` +
    `<w:p><w:pPr><w:spacing w:after="240"/></w:pPr>${run('Generated by Docuzen Compare. Review → Accept / Reject works on every change. Moved text is tracked by the author "Docuzen Compare (moved)".', '<w:rPr><w:i/><w:color w:val="666666"/><w:sz w:val="18"/></w:rPr>')}</w:p>`;
  let para = '', first = true, lastPage = -1;
  let cur: { kind: number; moved: boolean; text: string } | null = null;

  const flushRun = () => {
    if (!cur) return;
    const author = cur.moved ? 'Docuzen Compare (moved)' : 'Docuzen Compare';
    if (cur.kind === EQ) para += run(cur.text);
    else if (cur.kind === INS) para += `<w:ins w:id="${id++}" w:author="${author}" w:date="${date}">${run(cur.text)}</w:ins>`;
    else para += `<w:del w:id="${id++}" w:author="${author}" w:date="${date}"><w:r><w:delText xml:space="preserve">${esc(cur.text)}</w:delText></w:r></w:del>`;
    cur = null;
  };
  const flushPara = () => { flushRun(); if (para) body += `<w:p>${para}</w:p>`; para = ''; first = true; };

  for (const it of items) {
    const tok = (it.b ?? it.a)!;
    const newPage = !!it.b && lastPage >= 0 && it.b.page !== lastPage;
    if (!first && (tok.gap || newPage)) { flushPara(); if (newPage) para = PAGE_BREAK; }
    const moved = it.move >= 0;
    const piece = (first || tok.glue ? '' : ' ') + tok.text;
    if (cur && cur.kind === it.kind && cur.moved === moved) cur.text += piece;
    else { flushRun(); cur = { kind: it.kind, moved, text: piece }; }
    first = false;
    if (it.b) lastPage = it.b.page;
  }
  flushPara();
  return pack(body);
}
