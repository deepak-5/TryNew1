/*
 * Generates two real, typeset PDFs from the contract sample so the PDF → PDF comparison can be tried without any files:
 *   v1  wide column, navy logo, 6-bar uptime chart
 *   v2  NARROWER column (the text re-flows onto different lines), clause 5 moved to page 3, teal logo, one bar changed
 * Text edits are the ones from the "Service agreement" sample; the logo and the bar are changes only the image
 * comparison can see. The fee table is identical in both and must NOT be reported.
 */
import { PDFDocument, StandardFonts, rgb, type PDFFont, type PDFPage } from 'pdf-lib';
import { contractBlocks } from '../samples';

const PAGE_W = 595.28, PAGE_H = 841.89, LEFT = 64;

interface Look { measure: number; accent: [number, number, number]; bars: number[] }

function wrapText(text: string, font: PDFFont, size: number, maxW: number): string[] {
  const lines: string[] = [];
  let cur = '';
  for (const w of text.split(/\s+/).filter(Boolean)) {
    const cand = cur ? cur + ' ' + w : w;
    if (font.widthOfTextAtSize(cand, size) <= maxW) cur = cand;
    else { if (cur) lines.push(cur); cur = w; }
  }
  if (cur) lines.push(cur);
  return lines;
}

async function typeset(head: string, pages: string[][], look: Look, title: string): Promise<Uint8Array> {
  const doc = await PDFDocument.create();
  doc.setTitle(title);
  doc.setProducer('Docuzen demo');
  const body = await doc.embedFont(StandardFonts.TimesRoman), sans = await doc.embedFont(StandardFonts.Helvetica), bold = await doc.embedFont(StandardFonts.HelveticaBold);
  const gray = rgb(0.4, 0.42, 0.46), ink = rgb(0.1, 0.1, 0.12), accent = rgb(...look.accent);

  pages.forEach((blocks, pi) => {
    const pg: PDFPage = doc.addPage([PAGE_W, PAGE_H]);
    // running header: logo mark + title + rule
    // letterhead logo on page 1 only (its colour changes in v2); later pages carry the same neutral mark in both versions
    pg.drawRectangle({ x: LEFT, y: 796, width: 20, height: 20, color: pi === 0 ? accent : rgb(0.1, 0.2, 0.45) });
    pg.drawRectangle({ x: LEFT + 6, y: 802, width: 8, height: 8, color: rgb(1, 1, 1) });
    pg.drawText(head, { x: LEFT + 30, y: 803, size: 8.5, font: sans, color: gray });
    pg.drawLine({ start: { x: LEFT, y: 788 }, end: { x: PAGE_W - 64, y: 788 }, thickness: 0.6, color: rgb(0.8, 0.82, 0.86) });
    // footer
    pg.drawLine({ start: { x: LEFT, y: 62 }, end: { x: PAGE_W - 64, y: 62 }, thickness: 0.6, color: rgb(0.8, 0.82, 0.86) });
    const foot = `Page ${pi + 1} of ${pages.length}`;
    pg.drawText(foot, { x: PAGE_W / 2 - sans.widthOfTextAtSize(foot, 8.5) / 2, y: 44, size: 8.5, font: sans, color: gray });

    let y = 758;
    for (const b of blocks) {
      if (/^\d+\.\s/.test(b)) {
        y -= 8;
        pg.drawText(b, { x: LEFT, y, size: 12.5, font: bold, color: ink });
        y -= 20;
      } else {
        for (const line of wrapText(b, body, 10.5, look.measure)) { pg.drawText(line, { x: LEFT, y, size: 10.5, font: body, color: ink }); y -= 14.5; }
        y -= 6;
      }
    }

    if (pi === 0) { // Figure 1: uptime bars — the third bar differs in v2
      const base = 150, x0 = LEFT + 10;
      pg.drawText('Figure 1  \u2014  Monthly uptime, production environment', { x: LEFT, y: 276, size: 9, font: bold, color: ink });
      pg.drawLine({ start: { x: x0 - 6, y: base }, end: { x: x0 + 6 * 46 + 4, y: base }, thickness: 0.8, color: gray });
      look.bars.forEach((h, i) => {
        pg.drawRectangle({ x: x0 + i * 46, y: base, width: 30, height: h, color: rgb(0.1, 0.2, 0.45) });
        const m = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'][i];
        pg.drawText(m, { x: x0 + i * 46 + 15 - sans.widthOfTextAtSize(m, 8) / 2, y: base - 12, size: 8, font: sans, color: gray });
      });
    }
    if (pi === 1) { // identical service-credit table in both versions (must not be flagged)
      const ty = 230, cols = [LEFT, LEFT + 190, LEFT + 330], rows = [['Downtime in month', 'Service credit', 'Notes'], ['1 hour or less', '5%', 'automatic'], ['More than 1 hour', '10%', 'on request'], ['More than 4 hours', '25%', 'on request']];
      rows.forEach((r, ri) => {
        const ry = ty - ri * 20;
        if (ri === 0) pg.drawRectangle({ x: LEFT, y: ry - 5, width: PAGE_W - 128, height: 19, color: rgb(0.93, 0.94, 0.96) });
        pg.drawLine({ start: { x: LEFT, y: ry - 5 }, end: { x: PAGE_W - 64, y: ry - 5 }, thickness: 0.5, color: rgb(0.75, 0.78, 0.83) });
        r.forEach((c, ci) => pg.drawText(c, { x: cols[ci] + 6, y: ry, size: 9, font: ri === 0 ? bold : sans, color: ink }));
      });
    }
  });
  return doc.save();
}

export async function makeDemoPdfs(): Promise<{ v1: Uint8Array; v2: Uint8Array }> {
  const { head, before, after } = contractBlocks();
  const v1 = await typeset(head, before, { measure: 467, accent: [0.1, 0.2, 0.45], bars: [70, 74, 62, 72, 75, 66] }, 'Service agreement v1');
  const v2 = await typeset(head, after, { measure: 392, accent: [0.04, 0.5, 0.55], bars: [70, 74, 38, 72, 75, 66] }, 'Service agreement v2');
  return { v1, v2 };
}
