/*
 * Word-equality rules (match modes). Mirrors csharp/PdfComparer.Normalization.cs.
 */

export type MatchMode = 'strict' | 'ignoreCase' | 'ignoreCasePunct' | 'typographic' | 'numeric' | 'loose' | 'ocr';

export interface MatchFlags {
  ignoreCase: boolean;      // "Shall" == "shall"
  typography: boolean;      // curly quotes == straight quotes, en/em dash == hyphen
  edgePunct: boolean;       // "agreement," == "agreement"   (never around digits)
  diacritics: boolean;      // "résumé" == "resume"
  numbers: boolean;         // "1,000" == "1000", "$1,000.50" == "$1000.5"
  ocr: boolean;             // O/0, l/I/1, rn/m, vv/w confusions
}

export const MATCH_MODES: { id: MatchMode; label: string; hint: string }[] = [
  { id: 'strict', label: 'Strict', hint: 'Exact after NFKC. "Shall" ≠ "shall", “x” ≠ "x".' },
  { id: 'ignoreCase', label: 'Ignore case', hint: 'Strict, but case-insensitive.' },
  { id: 'ignoreCasePunct', label: 'Ignore case + edge punctuation', hint: 'Also ignores leading/trailing punctuation (never around digits).' },
  { id: 'typographic', label: 'Typographic', hint: 'Folds curly/straight quotes and dash variants. Kills Word-vs-LaTeX export noise.' },
  { id: 'numeric', label: 'Numeric-aware', hint: 'Typographic + thousands separators: 1,000 = 1000. Currency/percent trailing zeros folded.' },
  { id: 'loose', label: 'Loose', hint: 'Case, typography, edge punctuation, diacritics and number formatting all folded.' },
  { id: 'ocr', label: 'OCR-tolerant', hint: 'Loose + common OCR confusions (O/0, l/I/1, rn/m). Lossy by design.' },
];

export function flagsFor(mode: MatchMode): MatchFlags {
  const f: MatchFlags = { ignoreCase: false, typography: false, edgePunct: false, diacritics: false, numbers: false, ocr: false };
  switch (mode) {
    case 'strict': break;
    case 'ignoreCase': f.ignoreCase = true; break;
    case 'ignoreCasePunct': f.ignoreCase = true; f.edgePunct = true; break;
    case 'typographic': f.typography = true; break;
    case 'numeric': f.typography = true; f.numbers = true; break;
    case 'loose': f.ignoreCase = f.typography = f.edgePunct = f.diacritics = f.numbers = true; break;
    case 'ocr': f.ignoreCase = f.typography = f.edgePunct = f.diacritics = f.numbers = f.ocr = true; break;
  }
  return f;
}

export function foldTypography(s: string): string {
  return s
    .replace(/[\u2018\u2019\u201A\u201B\u2032\u00B4`]/g, "'")
    .replace(/[\u201C\u201D\u201E\u201F\u2033\u00AB\u00BB]/g, '"')
    .replace(/[\u2010\u2011\u2012\u2013\u2014\u2015\u2212]/g, '-')
    .replace(/\u2026/g, '...');
}

const NUM_RE = /^([^\d]*)(\d{1,3}(?:,\d{3})+|\d+)(?:\.(\d+))?([^\d]*)$/;
const CURRENCY_RE = /\p{Sc}/u;

/**
 * Canonical form of a single-number token. Thousands separators are always removed. Trailing decimal
 * zeros are only folded next to a currency symbol or percent sign — "3.10" vs "3.1" may be section
 * numbers, and those must stay different.
 */
export function normalizeNumber(s: string): string {
  const m = NUM_RE.exec(s);
  if (!m) return s;
  const int = m[2].replace(/,/g, '');
  let frac = m[3] ?? '';
  if (frac && (CURRENCY_RE.test(m[1]) || CURRENCY_RE.test(m[4]) || m[4].includes('%'))) frac = frac.replace(/0+$/, '');
  return m[1] + int + (frac ? '.' + frac : '') + m[4];
}

export function matchKey(text: string, f: MatchFlags): string {
  let s = text.normalize('NFKC').replace(/\u00AD/g, '');
  if (f.typography) s = foldTypography(s);
  if (f.ignoreCase) s = s.toLowerCase();
  if (f.diacritics) s = s.normalize('NFD').replace(/\p{Mn}/gu, '').normalize('NFC');
  const hasDigit = /\d/.test(s);
  if (hasDigit) {
    if (f.numbers) s = normalizeNumber(s);
  } else if (f.edgePunct) {
    const t = s.replace(/^\p{P}+/u, '').replace(/\p{P}+$/u, '');
    if (t.length) s = t;
  }
  if (f.ocr) s = s.replace(/rn/g, 'm').replace(/vv/g, 'w').replace(/[il|!1]/g, '1').replace(/[o0]/g, '0');
  return s;
}
