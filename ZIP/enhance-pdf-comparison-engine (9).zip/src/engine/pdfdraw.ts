/*
 * PDF writing primitives on top of pdf-lib: safe text (standard fonts are WinAnsi-only), word wrapping,
 * highlight painters, source-page embedding (vector Form XObjects, with a raster fallback), outline, garbage collection.
 */
import {
  PDFDocument, PDFPage, PDFFont, PDFRef, PDFName, PDFDict, PDFArray, PDFStream, PDFHexString, PDFImage, PDFEmbeddedPage,
  StandardFonts, rgb, BlendMode, pushGraphicsState, popGraphicsState, concatTransformationMatrix, drawObject, type PDFObject,
} from 'pdf-lib';
import type { Box } from './geo';
import type { PdfPageInfo } from './pdf';

export const COLOR = {
  red: rgb(0.85, 0.15, 0.15), redFill: rgb(0.96, 0.3, 0.3), redSoft: rgb(1, 0.91, 0.91),
  green: rgb(0.18, 0.65, 0.25), greenFill: rgb(0.2, 0.78, 0.35),
  blue: rgb(0.15, 0.38, 0.85), blueFill: rgb(0.3, 0.52, 0.98),
  amber: rgb(0.88, 0.55, 0.1), amberFill: rgb(0.98, 0.74, 0.2),
  ink: rgb(0.06, 0.09, 0.16), slate: rgb(0.39, 0.45, 0.55), mute: rgb(0.58, 0.64, 0.72), line: rgb(0.89, 0.91, 0.94),
  navy: rgb(0.08, 0.11, 0.18), navyLine: rgb(0.18, 0.22, 0.32), white: rgb(1, 1, 1), desk: rgb(0.93, 0.94, 0.96),
};

// ── Fonts & text ────────────────────────────────────────────────────────────

// Symbols the built-in PDF fonts cannot encode, mapped to readable ASCII instead of "?".
const FOLD: Record<string, string> = {
  '\u2010': '-', '\u2011': '-', '\u2212': '-', '\u00a0': ' ', '\u2009': ' ', '\u202f': ' ',
  '\u2192': '->', '\u2190': '<-', '\u2194': '<->', '\u21d2': '=>', '\u2260': '!=', '\u2265': '>=', '\u2264': '<=', '\u2248': '~', '\u2713': 'ok', '\u2717': 'x',
};

export class Fonts {
  private sets = new Map<PDFFont, Set<number>>();
  private cache = new Map<string, string>();
  constructor(readonly reg: PDFFont, readonly bold: PDFFont) {}
  static async load(doc: PDFDocument): Promise<Fonts> {
    return new Fonts(await doc.embedFont(StandardFonts.Helvetica), await doc.embedFont(StandardFonts.HelveticaBold));
  }
  /** Text that the font can encode; anything else becomes "?" (the pages themselves are never affected). */
  safe(text: string, f: PDFFont = this.reg): string {
    const key = (f === this.bold ? 'b' : 'r') + text;
    const hit = this.cache.get(key);
    if (hit !== undefined) return hit;
    let set = this.sets.get(f);
    if (!set) this.sets.set(f, (set = new Set(f.getCharacterSet())));
    let out = '';
    for (const ch of text.normalize('NFKC')) {
      const cp = ch.codePointAt(0)!;
      if (cp < 32 || (cp >= 0x7f && cp < 0xa0)) out += ' ';
      else if (set.has(cp)) out += ch;
      else out += FOLD[ch] ?? '?';
    }
    if (this.cache.size > 20000) this.cache.clear();
    this.cache.set(key, out);
    return out;
  }
  width(text: string, size: number, f: PDFFont = this.reg): number { return f.widthOfTextAtSize(this.safe(text, f), size); }
  fit(text: string, size: number, maxW: number, f: PDFFont = this.reg): string {
    const t = this.safe(text, f);
    if (f.widthOfTextAtSize(t, size) <= maxW) return t;
    let n = t.length;
    while (n > 1 && f.widthOfTextAtSize(t.slice(0, n) + '...', size) > maxW) n--;
    return t.slice(0, n) + '...';
  }
  wrap(text: string, size: number, maxW: number, maxLines: number, f: PDFFont = this.reg): string[] {
    const words = this.safe(text, f).split(/\s+/).filter(Boolean);
    const lines: string[] = [];
    let cur = '';
    for (let i = 0; i < words.length; i++) {
      const cand = cur ? cur + ' ' + words[i] : words[i];
      if (f.widthOfTextAtSize(cand, size) <= maxW) { cur = cand; continue; }
      if (lines.length === maxLines - 1) { lines.push(this.fit([cand, ...words.slice(i + 1)].join(' '), size, maxW, f)); return lines; }
      if (cur) { lines.push(cur); cur = this.fit(words[i], size, maxW, f); } else lines.push(this.fit(words[i], size, maxW, f));
    }
    if (cur && lines.length < maxLines) lines.push(cur);
    return lines;
  }
}

export interface Rect { x: number; y: number; w: number; h: number }

/** Maps display-space boxes (y down) of one page into a placed pane of the output sheet (y up). */
export class Pane {
  constructor(readonly ox: number, readonly oy: number, readonly s: number, readonly H: number) {}
  map(b: { x0: number; y0: number; x1: number; y1: number }): Rect {
    return { x: this.ox + this.s * b.x0, y: this.oy + this.s * (this.H - b.y1), w: this.s * (b.x1 - b.x0), h: this.s * (b.y1 - b.y0) };
  }
}

/** Merge word boxes of one page into line-level highlight boxes (same line, small horizontal gaps). */
export function clusterBoxes(boxes: Box[]): Box[] {
  if (!boxes.length) return [];
  const items = boxes.map(b => ({ b, cy: (b.y0 + b.y1) / 2, h: b.y1 - b.y0 })).sort((p, q) => p.cy - q.cy);
  const bands: { cy: number; its: typeof items }[] = [];
  for (const it of items) {
    const band = bands[bands.length - 1];
    if (band && Math.abs(it.cy - band.cy) <= Math.max(2.5, it.h * 0.5)) band.its.push(it);
    else bands.push({ cy: it.cy, its: [it] });
  }
  const out: Box[] = [];
  for (const band of bands) {
    band.its.sort((p, q) => p.b.x0 - q.b.x0);
    let cur: Box | null = null;
    for (const { b, h } of band.its) {
      if (cur && b.x0 - cur.x1 <= Math.max(12, h * 1.5) && b.x0 - cur.x1 >= -1) {
        cur = { p: cur.p, x0: Math.min(cur.x0, b.x0), y0: Math.min(cur.y0, b.y0), x1: Math.max(cur.x1, b.x1), y1: Math.max(cur.y1, b.y1) };
      } else { if (cur) out.push(cur); cur = { ...b }; }
    }
    if (cur) out.push(cur);
  }
  return out;
}

// ── Painters ────────────────────────────────────────────────────────────────

export const fillRect = (pg: PDFPage, r: Rect, color: ReturnType<typeof rgb>, opacity = 1, multiply = false) =>
  pg.drawRectangle({ x: r.x, y: r.y, width: r.w, height: r.h, color, opacity, ...(multiply ? { blendMode: BlendMode.Multiply } : {}) });

export const strokeRect = (pg: PDFPage, r: Rect, color: ReturnType<typeof rgb>, width: number, dash?: number[]) =>
  pg.drawRectangle({ x: r.x, y: r.y, width: r.w, height: r.h, borderColor: color, borderWidth: width, ...(dash ? { borderDashArray: dash } : {}) });

export const hLine = (pg: PDFPage, x1: number, x2: number, y: number, color: ReturnType<typeof rgb>, thickness: number, dash?: number[]) =>
  pg.drawLine({ start: { x: x1, y }, end: { x: x2, y }, color, thickness, ...(dash ? { dashArray: dash } : {}) });

export const vLine = (pg: PDFPage, x: number, y1: number, y2: number, color: ReturnType<typeof rgb>, thickness: number, dash?: number[]) =>
  pg.drawLine({ start: { x, y: y1 }, end: { x, y: y2 }, color, thickness, ...(dash ? { dashArray: dash } : {}) });

export interface MarkStyle { margin: boolean; barX: number }

/** Deleted: red tint + red line THROUGH the text. */
export function paintDeleted(pg: PDFPage, r: Rect, st: MarkStyle): void {
  const x = r.x - 1.5, y = r.y - 1, w = r.w + 3, h = r.h + 2;
  fillRect(pg, { x, y, w, h }, COLOR.redFill, 0.3, true);
  hLine(pg, x, x + w, y + h * 0.45, COLOR.red, 1.15);
  if (st.margin) vLine(pg, st.barX, y, y + h, COLOR.red, 2.5);
}
/** Added: green tint + green line UNDER the text. */
export function paintAdded(pg: PDFPage, r: Rect, st: MarkStyle): void {
  const x = r.x - 1.5, y = r.y - 1, w = r.w + 3, h = r.h + 2;
  fillRect(pg, { x, y, w, h }, COLOR.greenFill, 0.28, true);
  hLine(pg, x, x + w, y + 0.6, COLOR.green, 1.4);
  if (st.margin) vLine(pg, st.barX, y, y + h, COLOR.green, 2.5);
}
/** Moved: blue tint + dashed blue underline. */
export function paintMoved(pg: PDFPage, r: Rect, st: MarkStyle): void {
  const x = r.x - 1.5, y = r.y - 1, w = r.w + 3, h = r.h + 2;
  fillRect(pg, { x, y, w, h }, COLOR.blueFill, 0.26, true);
  hLine(pg, x, x + w, y + 0.6, COLOR.blue, 1.2, [2.5, 1.8]);
  if (st.margin) vLine(pg, st.barX, y, y + h, COLOR.blue, 2.5);
}
/** Graphic / image / layout difference: amber tint + dashed frame. */
export function paintGraphic(pg: PDFPage, r: Rect, st: MarkStyle): void {
  const x = r.x - 2, y = r.y - 2, w = r.w + 4, h = r.h + 4;
  fillRect(pg, { x, y, w, h }, COLOR.amberFill, 0.2, true);
  strokeRect(pg, { x, y, w, h }, COLOR.amber, 1.2, [3, 2]);
  if (st.margin) vLine(pg, st.barX, y, y + h, COLOR.amber, 2.5);
}

export function text(pg: PDFPage, f: Fonts, s: string, x: number, y: number, size: number, color: ReturnType<typeof rgb>, bold = false): void {
  const font = bold ? f.bold : f.reg;
  pg.drawText(f.safe(s, font), { x, y, size, font, color });
}
export function textCentered(pg: PDFPage, f: Fonts, s: string, cx: number, y: number, size: number, color: ReturnType<typeof rgb>, bold = false): void {
  const font = bold ? f.bold : f.reg;
  const t = f.safe(s, font);
  pg.drawText(t, { x: cx - font.widthOfTextAtSize(t, size) / 2, y, size, font, color });
}
export function pill(pg: PDFPage, f: Fonts, s: string, x: number, y: number, bg: ReturnType<typeof rgb>): number {
  const w = f.width(s, 7, f.bold) + 12;
  fillRect(pg, { x, y, w, h: 14 }, bg);
  text(pg, f, s, x + 6, y + 3.8, 7, COLOR.white, true);
  return w;
}

// ── Source pages ────────────────────────────────────────────────────────────

export interface JpegPage { jpeg: Uint8Array }
export type JpegRenderer = (pageIndex: number) => Promise<JpegPage>;

/** Entries that would drag unrelated objects (annotation trees, structure, thumbnails) into the output when a page is copied. */
const STRIP = ['Annots', 'Thumb', 'B', 'StructParents', 'Metadata', 'PieceInfo', 'AA', 'LastModified', 'Tabs', 'PresSteps', 'VP', 'ID', 'PZ'];

/**
 * One input PDF as a source of drawable pages. Vector mode embeds each page as a Form XObject (text stays text, fonts
 * and images are shared across pages). If pdf-lib cannot read the file (encryption, damage) the pages are rendered to
 * JPEG instead — the marks still line up because both modes use the same display-space geometry.
 */
export class PdfSource {
  mode: 'vector' | 'raster' = 'vector';
  note = '';
  private emb = new Map<number, PDFEmbeddedPage>();
  private img = new Map<number, PDFImage>();
  constructor(private out: PDFDocument, readonly name: string, private bytes: Uint8Array, readonly pages: PdfPageInfo[], private jpeg?: JpegRenderer) {}

  async prepare(indices: number[], progress?: () => void): Promise<void> {
    const need = [...new Set(indices)].sort((a, b) => a - b);
    if (!need.length) return;
    try {
      const src = await PDFDocument.load(this.bytes, { updateMetadata: false, throwOnInvalidObject: false });
      if (src.getPageCount() !== this.pages.length) throw new Error('page count differs between readers');
      const pages = need.map(i => src.getPage(i));
      for (const p of pages) for (const k of STRIP) p.node.delete(PDFName.of(k));
      const boxes = need.map(i => { const [l, b, r, t] = this.pages[i].view; return { left: l, bottom: b, right: r, top: t }; });
      const embedded = await this.out.embedPages(pages, boxes, need.map(() => [1, 0, 0, 1, 0, 0]));
      await this.out.flush(); // surfaces undecodable content streams here, where we can still fall back
      need.forEach((i, k) => { this.emb.set(i, embedded[k]); progress?.(); });
    } catch (e) {
      (this.out as unknown as { embeddedPages: unknown[] }).embeddedPages.length = 0; // drop half-built embeds so save() cannot re-throw
      this.emb.clear();
      if (!this.jpeg) throw new Error(`${this.name}: cannot be embedded as vector pages (${e instanceof Error ? e.message : e}) and no page renderer is available.`);
      this.mode = 'raster';
      this.note = `${this.name} could not be embedded as vector pages (${e instanceof Error ? e.message : String(e)}); its pages were rendered as images instead, so text is not selectable on that side.`;
      for (const i of need) { this.img.set(i, await this.out.embedJpg((await this.jpeg(i)).jpeg)); progress?.(); }
    }
  }

  /** Draw page `index` at (ox, oy) scaled by s; (ox, oy) is the bottom-left corner of the displayed page. */
  draw(pg: PDFPage, index: number, key: string, ox: number, oy: number, s: number): void {
    const info = this.pages[index];
    const e = this.emb.get(index);
    if (e) {
      const [a, b, c, d, tx, ty] = info.transform;
      pg.node.setXObject(PDFName.of(key), e.ref);
      pg.pushOperators(pushGraphicsState(), concatTransformationMatrix(s * a, -s * b, s * c, -s * d, ox + s * tx, oy + s * info.height - s * ty), drawObject(key), popGraphicsState());
      return;
    }
    const img = this.img.get(index);
    if (img) pg.drawImage(img, { x: ox, y: oy, width: s * info.width, height: s * info.height });
  }
}

// ── Document-level helpers ──────────────────────────────────────────────────

/** Drop every indirect object that is no longer reachable from the catalog / info (page copies leave their original content streams behind). */
export function collectGarbage(doc: PDFDocument): { removed: number } {
  const ctx = doc.context;
  const live = new Set<string>();
  const stack: PDFObject[] = [];
  const tr = ctx.trailerInfo;
  for (const r of [tr.Root, tr.Info, tr.Encrypt, tr.ID]) if (r) stack.push(r);
  while (stack.length) {
    const o = stack.pop()!;
    if (o instanceof PDFRef) {
      const k = o.toString();
      if (live.has(k)) continue;
      live.add(k);
      const t = ctx.lookup(o);
      if (t) stack.push(t);
    } else if (o instanceof PDFDict) {
      for (const [, v] of o.entries()) stack.push(v);
    } else if (o instanceof PDFArray) {
      for (const v of o.asArray()) stack.push(v);
    } else if (o instanceof PDFStream) {
      stack.push(o.dict);
    }
  }
  let removed = 0;
  for (const [ref] of ctx.enumerateIndirectObjects()) {
    if (!live.has(ref.toString())) { ctx.delete(ref); removed++; }
  }
  return { removed };
}

export function addOutline(doc: PDFDocument, entries: { title: string; page: number }[]): void {
  if (!entries.length) return;
  const ctx = doc.context, pages = doc.getPages();
  const root = ctx.nextRef();
  const refs = entries.map(() => ctx.nextRef());
  entries.forEach((e, i) => {
    const d: Record<string, unknown> = {
      Title: PDFHexString.fromText(e.title),
      Parent: root,
      Dest: [pages[Math.min(e.page, pages.length - 1)].ref, 'Fit'],
    };
    if (i > 0) d.Prev = refs[i - 1];
    if (i < entries.length - 1) d.Next = refs[i + 1];
    ctx.assign(refs[i], ctx.obj(d as never));
  });
  ctx.assign(root, ctx.obj({ Type: 'Outlines', First: refs[0], Last: refs[refs.length - 1], Count: entries.length } as never));
  doc.catalog.set(PDFName.of('Outlines'), root);
  doc.catalog.set(PDFName.of('PageMode'), PDFName.of('UseOutlines'));
}
