/*
 * Randomised self-test of the diff engine. Runs in the browser ("Verify" section) and in Node.
 * Checks:  (1) every edit script is a valid transformation A → B,
 *          (2) with anchors off and no cap hit, the script is MINIMAL (compared against an O(NM) LCS table),
 *          (3) boundary shifting / semantic cleanup keep the script valid,
 *          (4) every detected move is a verbatim, non-overlapping deleted→inserted block,
 *          (5) the Fenwick heaviest-chain equals brute force on small inputs.
 */
import { diff, DiffOp, EQ, DEL, INS, heaviestChain } from './diff';
import { shiftBoundaries, semanticCleanup, detectMoves } from './refine';

export interface SelfTestReport {
  cases: number; failures: string[]; optimalChecked: number; cappedCases: number; chainChecked: number;
  movesFound: number; shifts: number; ms: number;
}

function rng(seed: number): () => number {
  return () => {
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function validate(ops: DiffOp[], a: ArrayLike<number>, b: ArrayLike<number>): string | null {
  let i = 0, j = 0;
  for (const o of ops) {
    if (o.kind === EQ) { if (o.a !== i || o.b !== j) return 'EQ out of order'; if (a[i] !== b[j]) return 'EQ pairs different tokens'; i++; j++; }
    else if (o.kind === DEL) { if (o.a !== i || o.b !== -1) return 'DEL out of order'; i++; }
    else if (o.kind === INS) { if (o.b !== j || o.a !== -1) return 'INS out of order'; j++; }
    else return 'bad kind';
  }
  return i === a.length && j === b.length ? null : 'script does not cover both inputs';
}

function lcs(a: number[], b: number[]): number {
  let prev = new Int32Array(b.length + 1), cur = new Int32Array(b.length + 1);
  for (let i = 1; i <= a.length; i++) {
    for (let j = 1; j <= b.length; j++) cur[j] = a[i - 1] === b[j - 1] ? prev[j - 1] + 1 : Math.max(prev[j], cur[j - 1]);
    const t = prev; prev = cur; cur = t;
  }
  return prev[b.length];
}

function bruteChain(aS: number[], bS: number[], len: number[], w: number[]): number {
  const R = aS.length, order = aS.map((_, i) => i).sort((p, q) => aS[p] - aS[q] || bS[p] - bS[q]);
  let best = 0;
  for (let mask = 1; mask < 1 << R; mask++) {
    let ok = true, last = -1, sum = 0;
    for (const i of order) {
      if (!(mask & (1 << i))) continue;
      if (last >= 0 && (aS[last] + len[last] > aS[i] || bS[last] + len[last] > bS[i])) { ok = false; break; }
      sum += w[i]; last = i;
    }
    if (ok && sum > best) best = sum;
  }
  return best;
}

export function runSelfTest(cases: number, seed = 12345): SelfTestReport {
  const r = rng(seed), int = (n: number) => Math.floor(r() * n);
  const rep: SelfTestReport = { cases, failures: [], optimalChecked: 0, cappedCases: 0, chainChecked: 0, movesFound: 0, shifts: 0, ms: 0 };
  const fail = (c: number, msg: string) => { if (rep.failures.length < 20) rep.failures.push(`case ${c}: ${msg}`); };
  const t0 = performance.now();

  for (let c = 0; c < cases; c++) {
    const big = c % 97 === 96;
    const alpha = 2 + int(big ? 60 : 24), n = big ? 600 + int(900) : int(70);
    const a: number[] = Array.from({ length: n }, () => int(alpha));
    let b: number[];
    if (r() < 0.65) {
      b = [];
      for (const t of a) {
        const p = r();
        if (p < 0.1) continue;
        if (p < 0.2) b.push(int(alpha));
        b.push(p > 0.92 ? int(alpha) : t);
      }
      if (r() < 0.4 && b.length > 8) { const s = int(b.length - 6), l = 3 + int(Math.min(12, b.length - s - 3)); const blk = b.splice(s, l); b.splice(int(b.length + 1), 0, ...blk); }
    } else b = Array.from({ length: big ? 600 + int(900) : int(70) }, () => int(alpha));

    const anchors = r() < 0.5, tiny = r() < 0.3;
    const res = diff(a, b, { phraseAnchors: anchors, tokenAnchors: anchors, maxCost: tiny ? 2 + int(8) : 4000 });
    const v = validate(res.ops, a, b);
    if (v) { fail(c, `diff invalid (${v})`); continue; }
    if (res.cappedRegions) rep.cappedCases++;
    if (!anchors && !res.cappedRegions && !big) {
      rep.optimalChecked++;
      const d = res.ops.reduce((s, o) => s + (o.kind === EQ ? 0 : 1), 0);
      if (d !== a.length + b.length - 2 * lcs(a, b)) fail(c, `not minimal: D=${d}`);
    }

    const ops = res.ops.map(o => ({ ...o }));
    const brkA = Uint8Array.from({ length: a.length + 1 }, () => int(4)), brkB = Uint8Array.from({ length: b.length + 1 }, () => int(4));
    const before = ops.filter(o => o.kind !== EQ).length;
    rep.shifts += shiftBoundaries(ops, a, b, brkA, brkB);
    const v2 = validate(ops, a, b);
    if (v2) { fail(c, `shiftBoundaries invalid (${v2})`); continue; }
    if (ops.filter(o => o.kind !== EQ).length !== before) fail(c, 'shiftBoundaries changed edit count');

    const cl = semanticCleanup(ops, 1 + int(2));
    const v3 = validate(cl.ops, a, b);
    if (v3) { fail(c, `semanticCleanup invalid (${v3})`); continue; }

    const mv = detectMoves(cl.ops, a, b, 2 + int(4));
    const isDel = new Uint8Array(a.length), isIns = new Uint8Array(b.length), usedA = new Uint8Array(a.length), usedB = new Uint8Array(b.length);
    for (const o of cl.ops) { if (o.kind === DEL) isDel[o.a] = 1; else if (o.kind === INS) isIns[o.b] = 1; }
    for (const m of mv.moves) {
      rep.movesFound++;
      for (let k = 0; k < m.len; k++) {
        const x = m.aStart + k, y = m.bStart + k;
        if (a[x] !== b[y] || !isDel[x] || !isIns[y] || usedA[x] || usedB[y] || mv.moveOfA[x] !== m.id || mv.moveOfB[y] !== m.id) { fail(c, 'invalid move block'); break; }
        usedA[x] = 1; usedB[y] = 1;
      }
    }

    if (c % 3 === 0) {
      const R = 1 + int(9);
      const aS: number[] = [], bS: number[] = [], len: number[] = [], w: number[] = [];
      for (let k = 0; k < R; k++) { aS.push(int(20)); bS.push(int(20)); len.push(1 + int(4)); w.push(1 + int(6)); }
      const chain = heaviestChain(aS, bS, len, w);
      let sum = 0, ok = true;
      chain.forEach((i, k) => { sum += w[i]; if (k > 0) { const p = chain[k - 1]; if (aS[p] + len[p] > aS[i] || bS[p] + len[p] > bS[i]) ok = false; } });
      rep.chainChecked++;
      if (!ok) fail(c, 'chain overlaps'); else if (sum !== bruteChain(aS, bS, len, w)) fail(c, `chain not heaviest (${sum})`);
    }
  }
  rep.ms = performance.now() - t0;
  return rep;
}
