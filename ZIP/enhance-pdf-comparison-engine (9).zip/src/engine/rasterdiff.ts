/*
 * Raster comparison core (TypeScript port of csharp/PdfComparer.RasterDiff.cs):
 *   • perceptual YIQ colour distance (pixelmatch metric) instead of per-channel differences
 *   • global registration: a uniform shift of up to `maxShift` pixels (scanner / renderer offset) is estimated and removed
 *   • anti-aliasing tolerance: a differing pixel is ignored when its colour exists in the 3×3 neighbourhood of the other
 *     image AND vice versa — kills edge shimmer yet still catches a new hairline
 *   • every pixel examined, dirty 16-px cells clustered (8-connected) and nearby boxes merged
 */

export interface RasterImage { width: number; height: number; data: Uint8ClampedArray | Uint8Array } // RGBA, top-down

export interface ImageDiffOptions { threshold: number; antiAlias: boolean; maxShift: number }
export interface ImageDiff {
  changed: boolean; changedPixels: number; deletedPixels: number; addedPixels: number; sampled: number;
  shiftX: number; shiftY: number; sizeDiffers: boolean;
  /** Changed regions in pixels, y down, right/bottom exclusive. */
  boxes: { x0: number; y0: number; x1: number; y1: number }[];
}

const G = 16;

const lum = (p: ArrayLike<number>, i: number) => (p[i] * 299 + p[i + 1] * 587 + p[i + 2] * 114) / 1000;

function delta(p: ArrayLike<number>, i: number, q: ArrayLike<number>, j: number): number {
  const dr = p[i] - q[j], dg = p[i + 1] - q[j + 1], db = p[i + 2] - q[j + 2];
  const y = dr * 0.29889531 + dg * 0.58662247 + db * 0.11448223;
  const ii = dr * 0.59597799 - dg * 0.2741761 - db * 0.32180189;
  const qq = dr * 0.21147017 - dg * 0.52261711 + db * 0.31114694;
  return 0.5053 * y * y + 0.299 * ii * ii + 0.1957 * qq * qq;
}

function foundNearby(src: ArrayLike<number>, si: number, dst: ArrayLike<number>, dstW: number, w: number, h: number, cx: number, cy: number, maxDelta: number): boolean {
  for (let ny = cy - 1; ny <= cy + 1; ny++) {
    if (ny < 0 || ny >= h) continue;
    for (let nx = cx - 1; nx <= cx + 1; nx++) {
      if (nx < 0 || nx >= w) continue;
      if (delta(src, si, dst, (ny * dstW + nx) * 4) <= maxDelta) return true;
    }
  }
  return false;
}

/** Exhaustive SAD search on a sparse luminance grid; a shift is accepted only when it removes ≥ 40 % of the difference. */
function estimateShift(A: RasterImage, B: RasterImage, w: number, h: number, max: number): [number, number] {
  if (w < 64 || h < 64) return [0, 0];
  let best = Infinity, zero = 0, bx = 0, by = 0;
  for (let dy = -max; dy <= max; dy++) {
    for (let dx = -max; dx <= max; dx++) {
      let sad = 0;
      for (let y = max; y < h - max; y += 3) {
        for (let x = max; x < w - max; x += 3) sad += Math.abs(lum(A.data, (y * A.width + x) * 4) - lum(B.data, ((y + dy) * B.width + x + dx) * 4));
      }
      if (dx === 0 && dy === 0) zero = sad;
      if (sad < best || (sad === best && Math.abs(dx) + Math.abs(dy) < Math.abs(bx) + Math.abs(by))) { best = sad; bx = dx; by = dy; }
    }
  }
  return zero > 0 && best < zero * 0.6 ? [bx, by] : [0, 0];
}

export function diffImages(A: RasterImage, B: RasterImage, o: ImageDiffOptions): ImageDiff {
  const res: ImageDiff = { changed: false, changedPixels: 0, deletedPixels: 0, addedPixels: 0, sampled: 1, shiftX: 0, shiftY: 0, sizeDiffers: A.width !== B.width || A.height !== B.height, boxes: [] };
  const w = Math.min(A.width, B.width), h = Math.min(A.height, B.height);
  if (w <= 0 || h <= 0) { res.changed = res.sizeDiffers; return res; }
  const [dx, dy] = o.maxShift > 0 ? estimateShift(A, B, w, h, Math.min(o.maxShift, 8)) : [0, 0];
  res.shiftX = dx; res.shiftY = dy;

  const t = Math.min(255, Math.max(1, o.threshold)) / 255, maxDelta = 35215 * t * t;
  const cols = Math.ceil(w / G), rows = Math.ceil(h / G);
  const dirty = new Int32Array(cols * rows);
  let changed = 0, deleted = 0, added = 0, sampled = 0;
  const a = A.data, b = B.data;

  for (let y = 0; y < h; y++) {
    const ya = y + dy;
    if (ya < 0 || ya >= h) continue;
    const row = Math.floor(y / G) * cols;
    for (let x = 0; x < w; x++) {
      const xa = x + dx;
      if (xa < 0 || xa >= w) continue;
      sampled++;
      const ib = (y * A.width + x) * 4, ia = (ya * B.width + xa) * 4;
      if (a[ib] === b[ia] && a[ib + 1] === b[ia + 1] && a[ib + 2] === b[ia + 2]) continue;
      if (delta(a, ib, b, ia) <= maxDelta) continue;
      if (o.antiAlias && foundNearby(a, ib, b, B.width, w, h, xa, ya, maxDelta) && foundNearby(b, ia, a, A.width, w, h, x, y, maxDelta)) continue;
      changed++;
      if (lum(a, ib) < lum(b, ia)) deleted++; else added++;
      dirty[row + Math.floor(x / G)]++;
    }
  }
  res.changed = changed > 40 || res.sizeDiffers;
  res.changedPixels = changed; res.deletedPixels = deleted; res.addedPixels = added; res.sampled = Math.max(1, sampled);

  const visited = new Uint8Array(cols * rows);
  let boxes: { x0: number; y0: number; x1: number; y1: number }[] = [];
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const idx = r * cols + c;
      if (visited[idx] || dirty[idx] < 6) continue;
      let minC = c, maxC = c, minR = r, maxR = r, total = 0;
      visited[idx] = 1;
      const queue = [idx];
      for (let qi = 0; qi < queue.length; qi++) {
        const cur = queue[qi], cr = Math.floor(cur / cols), cc = cur % cols;
        total += dirty[cur];
        if (cc < minC) minC = cc; if (cc > maxC) maxC = cc; if (cr < minR) minR = cr; if (cr > maxR) maxR = cr;
        for (let ddy = -1; ddy <= 1; ddy++) for (let ddx = -1; ddx <= 1; ddx++) {
          if (!ddx && !ddy) continue;
          const nc = cc + ddx, nr = cr + ddy;
          if (nc < 0 || nc >= cols || nr < 0 || nr >= rows) continue;
          const ni = nr * cols + nc;
          if (visited[ni] || dirty[ni] < 3) continue;
          visited[ni] = 1; queue.push(ni);
        }
      }
      if (total >= 20) boxes.push({ x0: minC * G, y0: minR * G, x1: Math.min(w, (maxC + 1) * G), y1: Math.min(h, (maxR + 1) * G) });
    }
  }
  // Merge boxes that touch or sit within one cell of each other.
  for (let again = true; again;) {
    again = false;
    for (let i = 0; i < boxes.length; i++) {
      for (let j = i + 1; j < boxes.length; j++) {
        const p = boxes[i], q = boxes[j];
        if (p.x0 > q.x1 + G || q.x0 > p.x1 + G || p.y0 > q.y1 + G || q.y0 > p.y1 + G) continue;
        boxes[i] = { x0: Math.min(p.x0, q.x0), y0: Math.min(p.y0, q.y0), x1: Math.max(p.x1, q.x1), y1: Math.max(p.y1, q.y1) };
        boxes.splice(j, 1); j--; again = true;
      }
    }
  }
  res.boxes = boxes;
  boxes = [];
  return res;
}

/** True when words cover at least 30 % of the box — i.e. this is text that changed or re-flowed, not a graphic. */
export function explainedByText(box: { x0: number; y0: number; x1: number; y1: number }, words: { x0: number; y0: number; x1: number; y1: number }[]): boolean {
  const area = Math.max(1e-6, (box.x1 - box.x0) * (box.y1 - box.y0));
  let covered = 0;
  for (const w of words) {
    const ix = Math.min(box.x1, w.x1 + 2) - Math.max(box.x0, w.x0 - 2);
    if (ix <= 0) continue;
    const iy = Math.min(box.y1, w.y1 + 2) - Math.max(box.y0, w.y0 - 2);
    if (iy <= 0) continue;
    covered += ix * iy;
    if (covered >= 0.3 * area) return true;
  }
  return false;
}
