import type { CompareOptions } from './engine/compare';

export interface Sample {
  id: string;
  label: string;
  blurb: string;
  make: () => [string, string];
  options?: Partial<CompareOptions>;
}

const PAGE = '\n=== PAGE ===\n';

function wrap(text: string, width: number): string {
  return text
    .split('\n')
    .map(line => {
      if (line.length <= width) return line;
      const out: string[] = [];
      let cur = '';
      for (const w of line.split(' ')) {
        if (cur && cur.length + 1 + w.length > width) { out.push(cur); cur = w; } else cur = cur ? cur + ' ' + w : w;
      }
      if (cur) out.push(cur);
      return out.join('\n');
    })
    .join('\n');
}

const edit = (s: string, pairs: [string, string][]) => pairs.reduce((t, [x, y]) => t.split(x).join(y), s);

// ── 1. Contract: every kind of change in one document ───────────────────────

/** The contract sample as pages of blocks (headings are the blocks that start with "N. "). Shared by the text sample and the generated demo PDFs. */
export function contractBlocks(): { head: string; before: string[][]; after: string[][] } {
  const head = 'ACME Services Agreement — Confidential';
  const scope = 'The Supplier shall provide the hosting, monitoring and support services described in Schedule A (the "Services") to the Customer for the duration of the Term. The Supplier shall perform the Services with reasonable skill and care, and in accordance with good industry practice.';
  const fees = 'The Customer shall pay the annual fee of $25,000 within 30 days of the date of each invoice. Late payments accrue interest at 1.5% per month. All fees are exclusive of applicable taxes, which the Customer shall pay in addition.';
  const levels = 'The Supplier guarantees a monthly uptime of 99.9% for the production environment. If uptime falls below this level, the Customer will recieve a service credit equal to 5% of the monthly fee for each full hour of downtime.';
  const conf = "Each party shall keep the other party's Confidential Information secret and shall not disclose it to any third party without prior written consent. This obligation survives termination of this Agreement for a period of three years.";
  const data = 'The Supplier shall process personal data only on documented instructions from the Customer and shall implement state-of-the-art security measures to protect that data against unauthorised access.';
  const liab = "Neither party shall be liable for indirect or consequential losses. The Supplier's total liability under this Agreement shall not exceed the fees paid by the Customer in the twelve months preceding the claim.";
  const term = 'Either party may terminate this Agreement by giving 90 days written notice. The Customer may terminate immediately if the Supplier commits a material breach and fails to remedy it within 14 days.';
  const law = 'This Agreement is governed by the laws of England and Wales. The parties submit to the exclusive jurisdiction of the English courts.';
  return {
    head,
    before: [
      ['1. Scope of Services', scope, '2. Fees and Payment', fees],
      ['3. Service Levels', levels, '4. Confidentiality', conf, '5. Data Protection', data],
      ['6. Limitation of Liability', liab, '7. Termination', term, '8. Governing Law', law],
    ],
    after: [
      ['1. Scope of Services', edit(scope, [['shall perform', 'may perform'], ['"Services"', '“Services”']]),
        '2. Fees and Payment', edit(fees, [['$25,000', '$52,000'], ['30 days', '45 days'], [' All fees are exclusive of applicable taxes, which the Customer shall pay in addition.', '']])],
      ['3. Service Levels', edit(levels, [['recieve', 'receive']]) + " Service credits are the Customer's sole remedy for downtime.",
        '4. Confidentiality', edit(conf, [['Confidential Information', 'confidential information'], ['three years', 'five years']])],
      ['6. Limitation of Liability', liab, '7. Termination', edit(term, [['notice. The', 'notice; the']]),
        '5. Data Protection', data, '8. Governing Law', law],
    ],
  };
}

function contract(): [string, string] {
  const { head, before: pb, after: pa } = contractBlocks();
  const page = (n: number, blocks: string[], width: number) =>
    [head, ...blocks, `Page ${n} of 3`].map(b => wrap(b, width)).join('\n\n');
  const before = pb.map((blocks, i) => page(i + 1, blocks, 86)).join(PAGE);
  // The modified version is re-wrapped to a narrower measure (pure reflow must not show up as a change).
  const after = pa.map((blocks, i) => {
    const t = page(i + 1, blocks, 64);
    // Simulate hyphenated line breaks: an ordinary one and one inside a real hyphenated compound.
    return i === 2 ? t.replace('consequential', 'conse-\nquential').replace('state-of-the-art', 'state-of-the-\nart') : t;
  }).join(PAGE);
  return [before, after];
}

// ── 2. Typography & number formatting: step through the match modes ─────────

function typography(): [string, string] {
  const before = [
    'The "Effective Date" is 1 January 2024 - see clause 3.1.',
    'Total consideration: 1,000,000 shares at $1,250.50 each (12.50% of equity).',
    "The CEO's résumé is attached; the modern office has 1000 desks.",
    'THE BUYER shall pay promptly, without set-off.',
  ].join('\n');
  const after = [
    'The “Effective Date” is 1 January 2024 – see clause 3.10.',
    'Total consideration: 1000000 shares at $1250.5 each (12.5% of equity).',
    'The CEO’s resume is attached; the modem office has 1,000 desks.',
    'The Buyer shall pay promptly without set-off.',
  ].join('\n');
  return [before, after];
}

// ── Seeded prose generator for the page / stress samples ────────────────────

const VOCAB = ('revenue margin forecast quarter growth customer segment pipeline retention churn contract renewal ' +
  'platform release migration latency capacity incident backlog roadmap milestone budget variance headcount ' +
  'supplier inventory logistics freight warehouse tariff region market share pricing discount channel partner ' +
  'audit control policy risk exposure hedge liquidity covenant facility interest principal maturity dividend ' +
  'engineering design review prototype tooling yield defect warranty recall compliance licence regulator filing ' +
  'improved declined remained exceeded reached delivered deferred approved rejected expanded reduced offset ' +
  'strong weak stable modest material temporary seasonal structural planned expected reported adjusted').split(' ');
const GLUE = ['the', 'of', 'and', 'in', 'to', 'for', 'with', 'by', 'on', 'a', 'our', 'this', 'which', 'while', 'after'];

function rng(seed: number): () => number {
  return () => {
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function sentences(seed: number, words: number): string[] {
  const r = rng(seed), pick = (a: string[]) => a[Math.floor(r() * a.length)];
  const out: string[] = [];
  let n = 0;
  while (n < words) {
    const len = 8 + Math.floor(r() * 10);
    const ws: string[] = [];
    for (let i = 0; i < len; i++) ws.push(i % 3 === 1 ? pick(GLUE) : r() < 0.06 ? String(10 + Math.floor(r() * 890)) : pick(VOCAB));
    ws[0] = ws[0][0].toUpperCase() + ws[0].slice(1);
    out.push(ws.join(' ') + '.');
    n += len;
  }
  return out;
}

const para = (seed: number, words: number, width: number) => wrap(sentences(seed, words).join(' '), width);

// ── 3. Inserted page: content-based page pairing ────────────────────────────

function insertedPage(): [string, string] {
  const head = 'Quarterly Operations Report · FY24';
  const mk = (n: number, body: string) => `${head}\n\n${body}\n\n- ${n} -`;
  const bodies = [11, 22, 33, 44].map(s => `${para(s, 70, 88)}\n\n${para(s + 5, 60, 88)}`);
  const before = bodies.map((b, i) => mk(i + 1, b)).join(PAGE);
  const fresh = `${para(777, 65, 88)}\n\n${para(778, 55, 88)}`;
  let nth = 0;
  const tweaked = bodies[1].replace(/\b[a-z]{6,}\b/g, m => (++nth === 7 ? 'deteriorated' : nth === 31 ? 'renegotiated' : m));
  const after = [bodies[0], fresh, tweaked, bodies[2], bodies[3]].map((b, i) => mk(i + 1, b)).join(PAGE);
  return [before, after];
}

// ── 4. Stress test ──────────────────────────────────────────────────────────

function stress(): [string, string] {
  const all = sentences(2024, 12000);
  const r = rng(99);
  const mod: string[] = [];
  all.forEach((s, i) => {
    const p = r();
    if (p < 0.012) return;                                                   // sentence deleted
    if (p < 0.024) mod.push(sentences(5000 + i, 12)[0]);                      // sentence inserted
    if (p > 0.955) { const w = s.split(' '); w[Math.floor(r() * w.length)] = VOCAB[Math.floor(r() * VOCAB.length)]; mod.push(w.join(' ')); }
    else mod.push(s);
  });
  mod.splice(700, 0, ...mod.splice(200, 12));                                // a block of 12 sentences moves
  const pages = (ss: string[], width: number) => {
    const out: string[] = [];
    for (let i = 0; i < ss.length; i += 45) out.push(wrap(ss.slice(i, i + 45).join(' '), width));
    return out.join(PAGE);
  };
  return [pages(all, 96), pages(mod, 96)];
}

export const SAMPLES: Sample[] = [
  {
    id: 'contract', label: 'Service agreement',
    blurb: '3 pages with running headers. Changed amount and deadline, shall → may, a typo fix, a deleted sentence, an inserted sentence, a clause moved to another page, curly quotes, re-wrapped lines and two hyphenated line breaks.',
    make: contract,
  },
  {
    id: 'typography', label: 'Quotes, dashes & numbers',
    blurb: 'Same content, different typesetting. Step through the match modes and watch the noise disappear — while 3.1 → 3.10 stays flagged in every mode.',
    make: typography,
  },
  {
    id: 'page', label: 'Inserted page',
    blurb: 'A new page 2 pushes everything back. Open the Page map: pages are paired by content. Then switch off “Align across pages” to see what index pairing does.',
    make: insertedPage,
  },
  {
    id: 'stress', label: 'Stress · 12,000 words',
    blurb: 'Generated prose, 22 pages, with about 70 scattered edits and a moved block of 12 sentences. Check the timings under Insights.',
    make: stress,
  },
];
