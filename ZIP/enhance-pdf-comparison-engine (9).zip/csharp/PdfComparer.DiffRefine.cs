namespace Docuzen.Pdf.Core;

// NEW FILE. Post-processing passes that turn a minimal edit script into a human-grade one:
// boundary shifting, semantic cleanup, block-move detection, word pairing and character-level diff.

public static partial class PdfComparer
{
    internal readonly record struct MoveBlock(int Id, int AStart, int BStart, int Length);

    internal sealed class MoveResult
    {
        public List<MoveBlock> Moves { get; } = new();
        /// <summary>Move id per A token (-1 = not moved).</summary>
        public required int[] MoveOfA { get; init; }
        /// <summary>Move id per B token (-1 = not moved).</summary>
        public required int[] MoveOfB { get; init; }
    }

    internal static class DiffRefine
    {
        /// <summary>
        /// Slides pure-insert / pure-delete blocks to the most natural boundary ("diff slider" problem).
        /// brk[i] scores the boundary BEFORE token i (length = tokens + 1): sentence start, paragraph start, ...
        /// The edit count never changes. Returns the number of blocks that moved.
        /// </summary>
        public static int ShiftBoundaries(List<DiffOp> ops, int[] a, int[] b, byte[] brkA, byte[] brkB)
        {
            int n = ops.Count, shifted = 0, i = 0;
            while (i < n)
            {
                if (ops[i].Kind == DiffKind.Equal) { i++; continue; }
                var kind = ops[i].Kind;
                int j = i;
                bool pure = true;
                while (j < n && ops[j].Kind != DiffKind.Equal) { if (ops[j].Kind != kind) pure = false; j++; }
                if (!pure) { i = j; continue; }

                bool isIns = kind == DiffKind.Insert;
                var t = isIns ? b : a;
                var brk = isIns ? brkB : brkA;
                int len = j - i;
                int q0 = isIns ? ops[i].BIndex : ops[i].AIndex, q1 = q0 + len;

                int left = 0, right = 0;
                while (i - 1 - left >= 0 && ops[i - 1 - left].Kind == DiffKind.Equal && t[q0 - 1 - left] == t[q1 - 1 - left]) left++;
                while (j + right < n && ops[j + right].Kind == DiffKind.Equal && t[q0 + right] == t[q1 + right]) right++;
                if (left == 0 && right == 0) { i = j; continue; }

                int bestP = 0, bestS = brk[q0] + brk[q1];
                for (int p = -left; p <= right; p++)
                {
                    int s = brk[q0 + p] + brk[q1 + p];
                    if (s > bestS || (s == bestS && p > bestP)) { bestS = s; bestP = p; }
                }
                if (bestP == 0) { i = j; continue; }
                shifted++;

                if (bestP < 0)
                {
                    int s = -bestP;
                    var moved = ops.GetRange(i - s, s);
                    for (int x = 0; x < len; x++) ops[i - s + x] = Edit(isIns, q0 - s + x);
                    for (int x = 0; x < s; x++)
                    {
                        var m = moved[x];
                        ops[j - s + x] = isIns
                            ? new DiffOp(DiffKind.Equal, m.AIndex, m.BIndex + len)
                            : new DiffOp(DiffKind.Equal, m.AIndex + len, m.BIndex);
                    }
                    i = j;
                }
                else
                {
                    int p = bestP;
                    var moved = ops.GetRange(j, p);
                    for (int x = 0; x < p; x++)
                    {
                        var m = moved[x];
                        ops[i + x] = isIns
                            ? new DiffOp(DiffKind.Equal, m.AIndex, m.BIndex - len)
                            : new DiffOp(DiffKind.Equal, m.AIndex - len, m.BIndex);
                    }
                    for (int x = 0; x < len; x++) ops[i + p + x] = Edit(isIns, q0 + p + x);
                    i = j + p;
                }
            }
            if (shifted > 0) DiffEngine.NormalizeBlocks(ops);
            return shifted;

            static DiffOp Edit(bool insert, int q) => insert ? new DiffOp(DiffKind.Insert, -1, q) : new DiffOp(DiffKind.Delete, q, -1);
        }

        /// <summary>
        /// Removes coincidental equalities ("the", "of", ",") stranded between two larger edits, so a rewritten
        /// phrase reads as ONE replacement instead of confetti.
        /// level 1 (conservative): island of at most 2 low-information tokens, both neighbours at least 2x the island.
        /// level 2 (aggressive):   island of at most 4 tokens, both neighbours at least as large as the island.
        /// </summary>
        public static List<DiffOp> SemanticCleanup(List<DiffOp> ops, int level, Func<int, bool>? lowInfoA, out int merged)
        {
            merged = 0;
            if (level <= 0) return ops;

            for (int pass = 0; pass < 4; pass++)
            {
                var segs = new List<(bool Eq, int S, int E, int Size)>();
                for (int i = 0; i < ops.Count;)
                {
                    bool eq = ops[i].Kind == DiffKind.Equal;
                    int j = i, d = 0, ins = 0;
                    while (j < ops.Count && (ops[j].Kind == DiffKind.Equal) == eq)
                    {
                        if (ops[j].Kind == DiffKind.Delete) d++; else if (ops[j].Kind == DiffKind.Insert) ins++;
                        j++;
                    }
                    segs.Add((eq, i, j, Math.Max(d, ins)));
                    i = j;
                }

                var kill = new bool[segs.Count];
                bool any = false;
                for (int k = 1; k + 1 < segs.Count; k++)
                {
                    var g = segs[k];
                    if (!g.Eq) continue;
                    int len = g.E - g.S, ls = segs[k - 1].Size, rs = segs[k + 1].Size;
                    bool ok;
                    if (level == 1)
                    {
                        ok = len <= 2 && ls >= 2 * len && rs >= 2 * len;
                        if (ok && lowInfoA is not null)
                            for (int q = g.S; q < g.E; q++)
                                if (!lowInfoA(ops[q].AIndex)) { ok = false; break; }
                    }
                    else ok = len <= 4 && len <= ls && len <= rs;
                    if (ok) { kill[k] = true; any = true; merged++; }
                }
                if (!any) break;

                var next = new List<DiffOp>(ops.Count + 16);
                for (int k = 0; k < segs.Count; k++)
                {
                    var g = segs[k];
                    if (!kill[k]) { for (int q = g.S; q < g.E; q++) next.Add(ops[q]); continue; }
                    for (int q = g.S; q < g.E; q++) next.Add(new DiffOp(DiffKind.Delete, ops[q].AIndex, -1));
                    for (int q = g.S; q < g.E; q++) next.Add(new DiffOp(DiffKind.Insert, -1, ops[q].BIndex));
                }
                DiffEngine.NormalizeBlocks(next);
                ops = next;
            }
            return ops;
        }

        /// <summary>
        /// Block-move detection: deleted runs that reappear verbatim among the inserted tokens.
        /// Seeds on k-grams (k = minLen) lying entirely inside deleted / inserted runs, extends greedily,
        /// takes the longest candidate and never claims a token twice.
        /// </summary>
        public static MoveResult DetectMoves(List<DiffOp> ops, int[] a, int[] b, int minLen)
        {
            var moveOfA = new int[a.Length];
            var moveOfB = new int[b.Length];
            Array.Fill(moveOfA, -1);
            Array.Fill(moveOfB, -1);
            var result = new MoveResult { MoveOfA = moveOfA, MoveOfB = moveOfB };
            int k = Math.Max(2, minLen);

            var isDel = new bool[a.Length];
            var isIns = new bool[b.Length];
            foreach (var op in ops)
            {
                if (op.Kind == DiffKind.Delete) isDel[op.AIndex] = true;
                else if (op.Kind == DiffKind.Insert) isIns[op.BIndex] = true;
            }
            var delRun = new int[a.Length + 1];
            var insRun = new int[b.Length + 1];
            for (int i = a.Length - 1; i >= 0; i--) delRun[i] = isDel[i] ? delRun[i + 1] + 1 : 0;
            for (int j = b.Length - 1; j >= 0; j--) insRun[j] = isIns[j] ? insRun[j + 1] + 1 : 0;

            var index = new Dictionary<ulong, List<int>>();
            for (int j = 0; j + k <= b.Length; j++)
            {
                if (insRun[j] < k) continue;
                ulong h = DiffEngine.GramHash(b, j, k);
                if (!index.TryGetValue(h, out var list)) index[h] = list = new List<int>(2);
                if (list.Count < 16) list.Add(j);
            }
            if (index.Count == 0) return result;

            for (int i = 0; i + k <= a.Length;)
            {
                if (delRun[i] < k) { i++; continue; }
                int bestLen = 0, bestJ = -1;
                if (index.TryGetValue(DiffEngine.GramHash(a, i, k), out var cands))
                {
                    foreach (int j in cands)
                    {
                        int len = 0;
                        while (i + len < a.Length && j + len < b.Length && isDel[i + len] && isIns[j + len] &&
                               moveOfB[j + len] < 0 && a[i + len] == b[j + len]) len++;
                        if (len > bestLen) { bestLen = len; bestJ = j; }
                    }
                }
                if (bestLen >= k)
                {
                    int id = result.Moves.Count;
                    result.Moves.Add(new MoveBlock(id, i, bestJ, bestLen));
                    for (int x = 0; x < bestLen; x++) { moveOfA[i + x] = id; moveOfB[bestJ + x] = id; }
                    i += bestLen;
                }
                else i++;
            }
            return result;
        }

        public static int Levenshtein(string s, string t)
        {
            if (string.Equals(s, t, StringComparison.Ordinal)) return 0;
            if (s.Length == 0) return t.Length;
            if (t.Length == 0) return s.Length;
            var prev = new int[t.Length + 1];
            var cur = new int[t.Length + 1];
            for (int j = 0; j <= t.Length; j++) prev[j] = j;
            for (int i = 1; i <= s.Length; i++)
            {
                cur[0] = i;
                char c = s[i - 1];
                for (int j = 1; j <= t.Length; j++)
                {
                    int sub = prev[j - 1] + (c == t[j - 1] ? 0 : 1);
                    cur[j] = Math.Min(sub, Math.Min(prev[j] + 1, cur[j - 1] + 1));
                }
                (prev, cur) = (cur, prev);
            }
            return prev[t.Length];
        }

        public static double Similarity(string s, string t)
        {
            int m = Math.Max(s.Length, t.Length);
            return m == 0 ? 1.0 : 1.0 - Levenshtein(s, t) / (double)m;
        }

        /// <summary>Character-level diff of two words (to show only the characters that changed).</summary>
        public static List<(DiffKind Kind, string Text)> CharDiff(string s, string t)
        {
            var a = new int[s.Length];
            var b = new int[t.Length];
            for (int i = 0; i < s.Length; i++) a[i] = s[i];
            for (int i = 0; i < t.Length; i++) b[i] = t[i];
            var res = DiffEngine.Diff(a, b, new DiffEngineOptions { MaxCost = 512, UsePhraseAnchors = false, UseTokenAnchors = false });

            var result = new List<(DiffKind Kind, string Text)>();
            var sb = new System.Text.StringBuilder();
            DiffKind? current = null;
            foreach (var op in res.Ops)
            {
                if (current != op.Kind)
                {
                    if (current is not null) result.Add((current.Value, sb.ToString()));
                    sb.Clear();
                    current = op.Kind;
                }
                sb.Append(op.Kind == DiffKind.Insert ? t[op.BIndex] : s[op.AIndex]);
            }
            if (current is not null) result.Add((current.Value, sb.ToString()));
            return result;
        }

        /// <summary>
        /// Order-preserving pairing of deleted words with inserted words inside one replacement block
        /// (similarity-weighted alignment). Returns (deletedIndex, insertedIndex, similarity).
        /// </summary>
        public static List<(int Del, int Ins, double Sim)> PairWords(IReadOnlyList<string> dels, IReadOnlyList<string> ins, double minSim = 0.5)
        {
            var result = new List<(int Del, int Ins, double Sim)>();
            int n = dels.Count, m = ins.Count;
            if (n == 0 || m == 0 || (long)n * m > 4096) return result;

            var sim = new double[n, m];
            for (int i = 0; i < n; i++)
                for (int j = 0; j < m; j++)
                    sim[i, j] = Similarity(dels[i].ToLowerInvariant(), ins[j].ToLowerInvariant());

            var score = new double[n + 1, m + 1];
            for (int i = 1; i <= n; i++)
            {
                for (int j = 1; j <= m; j++)
                {
                    double v = Math.Max(score[i - 1, j], score[i, j - 1]);
                    double s = sim[i - 1, j - 1];
                    if (s >= minSim) v = Math.Max(v, score[i - 1, j - 1] + s);
                    score[i, j] = v;
                }
            }

            int x = n, y = m;
            while (x > 0 && y > 0)
            {
                double v = score[x, y], s = sim[x - 1, y - 1];
                if (s >= minSim && Math.Abs(v - (score[x - 1, y - 1] + s)) < 1e-12) { result.Add((x - 1, y - 1, s)); x--; y--; }
                else if (v == score[x - 1, y]) x--;
                else y--;
            }
            result.Reverse();
            return result;
        }
    }
}
