using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;

namespace Docuzen.Pdf.Core;

// NEW FILE. Word-equality rules: seven match-mode presets built from composable PdfMatchFlags.

public static partial class PdfComparer
{
    private static readonly Regex NumberToken = new(
        @"^([^0-9]*)([0-9]{1,3}(?:,[0-9]{3})+|[0-9]+)(?:\.([0-9]+))?([^0-9]*)$",
        RegexOptions.Compiled | RegexOptions.CultureInvariant);

    internal static PdfMatchFlags FlagsFor(PdfWordMatchMode mode) => mode switch
    {
        PdfWordMatchMode.Strict => PdfMatchFlags.None,
        PdfWordMatchMode.IgnoreCase => PdfMatchFlags.IgnoreCase,
        PdfWordMatchMode.IgnoreCaseAndPunctuation => PdfMatchFlags.IgnoreCase | PdfMatchFlags.IgnoreEdgePunctuation,
        PdfWordMatchMode.Typographic => PdfMatchFlags.FoldTypography,
        PdfWordMatchMode.NumericAware => PdfMatchFlags.FoldTypography | PdfMatchFlags.NormalizeNumbers,
        PdfWordMatchMode.Loose => PdfMatchFlags.IgnoreCase | PdfMatchFlags.FoldTypography | PdfMatchFlags.IgnoreEdgePunctuation |
                                  PdfMatchFlags.IgnoreDiacritics | PdfMatchFlags.NormalizeNumbers,
        PdfWordMatchMode.OcrTolerant => PdfMatchFlags.IgnoreCase | PdfMatchFlags.FoldTypography | PdfMatchFlags.IgnoreEdgePunctuation |
                                        PdfMatchFlags.IgnoreDiacritics | PdfMatchFlags.NormalizeNumbers | PdfMatchFlags.OcrConfusables,
        _ => PdfMatchFlags.None
    };

    internal static PdfMatchFlags EffectiveMatchFlags(PdfComparisonOptions o) => o.CustomMatchFlags ?? FlagsFor(o.MatchMode);

    /// <summary>Back-compat overload with the v2 signature.</summary>
    private static string MatchKey(string text, PdfWordMatchMode mode) => MatchKey(text, FlagsFor(mode));

    /// <summary>
    /// Canonical comparison key of a word. Two words are equal for the diff iff their keys are equal.
    /// Text is expected to be NFKC-normalised already (CreateWord does that).
    /// </summary>
    internal static string MatchKey(string text, PdfMatchFlags f)
    {
        if (f == PdfMatchFlags.None) return text;
        var s = text;
        if ((f & PdfMatchFlags.FoldTypography) != 0) s = FoldTypography(s);
        if ((f & PdfMatchFlags.IgnoreCase) != 0) s = s.ToLowerInvariant();
        if ((f & PdfMatchFlags.IgnoreDiacritics) != 0) s = StripDiacritics(s);

        bool hasDigit = false;
        foreach (var c in s)
            if (char.IsDigit(c)) { hasDigit = true; break; }

        if (hasDigit)
        {
            // Punctuation around digits is never ignored: "(500)" != "500", "-500" != "500".
            if ((f & PdfMatchFlags.NormalizeNumbers) != 0) s = NormalizeNumber(s);
        }
        else if ((f & PdfMatchFlags.IgnoreEdgePunctuation) != 0)
        {
            int st = 0, en = s.Length - 1;
            while (st <= en && char.IsPunctuation(s[st])) st++;
            while (en >= st && char.IsPunctuation(s[en])) en--;
            if (st <= en) s = s[st..(en + 1)];
        }

        if ((f & PdfMatchFlags.OcrConfusables) != 0) s = FoldOcrConfusables(s);
        return s;
    }

    /// <summary>Curly quotes → straight quotes, dash variants → hyphen-minus, ellipsis → three dots.</summary>
    internal static string FoldTypography(string s)
    {
        StringBuilder? sb = null;
        for (int i = 0; i < s.Length; i++)
        {
            char c = s[i];
            string? rep = c switch
            {
                '\u2018' or '\u2019' or '\u201A' or '\u201B' or '\u2032' or '\u00B4' or '`' => "'",
                '\u201C' or '\u201D' or '\u201E' or '\u201F' or '\u2033' or '\u00AB' or '\u00BB' => "\"",
                '\u2010' or '\u2011' or '\u2012' or '\u2013' or '\u2014' or '\u2015' or '\u2212' => "-",
                '\u2026' => "...",
                _ => null
            };
            if (rep is null) { sb?.Append(c); continue; }
            sb ??= new StringBuilder(s.Length + 2).Append(s, 0, i);
            sb.Append(rep);
        }
        return sb?.ToString() ?? s;
    }

    internal static string StripDiacritics(string s)
    {
        bool ascii = true;
        foreach (var c in s)
            if (c > 127) { ascii = false; break; }
        if (ascii) return s;

        var d = s.Normalize(NormalizationForm.FormD);
        var sb = new StringBuilder(d.Length);
        foreach (var c in d)
            if (CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark) sb.Append(c);
        return sb.ToString().Normalize(NormalizationForm.FormC);
    }

    /// <summary>
    /// Canonical form of a single-number token. Thousands separators are always removed ("1,000" == "1000").
    /// Trailing decimal zeros are folded ONLY next to a currency symbol or percent sign ("$1.50" == "$1.5"):
    /// "3.10" vs "3.1" may be section numbers and must stay different.
    /// </summary>
    internal static string NormalizeNumber(string s)
    {
        var m = NumberToken.Match(s);
        if (!m.Success) return s;
        string prefix = m.Groups[1].Value, suffix = m.Groups[4].Value;
        string whole = m.Groups[2].Value.Replace(",", "");
        string frac = m.Groups[3].Success ? m.Groups[3].Value : "";
        if (frac.Length > 0 && (HasCurrency(prefix) || HasCurrency(suffix) || suffix.Contains('%')))
            frac = frac.TrimEnd('0');
        return prefix + whole + (frac.Length > 0 ? "." + frac : "") + suffix;

        static bool HasCurrency(string t)
        {
            foreach (var c in t)
                if (CharUnicodeInfo.GetUnicodeCategory(c) == UnicodeCategory.CurrencySymbol) return true;
            return false;
        }
    }

    /// <summary>Folds the classic OCR confusions: rn/m, vv/w, O/o/0, I/l/i/|/!/1. Lossy by design.</summary>
    internal static string FoldOcrConfusables(string s)
    {
        s = s.Replace("rn", "m", StringComparison.Ordinal).Replace("vv", "w", StringComparison.Ordinal);
        var sb = new StringBuilder(s.Length);
        foreach (var c in s)
        {
            sb.Append(c switch
            {
                'i' or 'I' or 'l' or '|' or '!' or '1' => '1',
                'o' or 'O' or '0' => '0',
                _ => c
            });
        }
        return sb.ToString();
    }
}
