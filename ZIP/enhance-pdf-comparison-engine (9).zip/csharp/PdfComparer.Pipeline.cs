using System.Globalization;
using System.Text;
using Docuzen.Pdf.Html;
using Docuzen.Pdf.Raster;

namespace Docuzen.Pdf.Core;

// REPLACEMENT for the original entry-point / CompareVisual file.
// Public surface is unchanged. Inside: content-based page pairing, seven output modes, move / formatting marks,
// v3 raster analysis, classified change records, and a fix for bookmarks when the summary spans several pages.

public static partial class PdfComparer
{
    private const double BannerHeightPt = 44.0;
    private const double PageMarginPt = 20.0;
    private const double GutterPt = 20.0;
    private const double OverlayCalloutGutterPt = 160.0;
    private const int MaxChangeLogRows = 400;

    // ── Public entry points ──────────────────────────────────────────────────

    /// <summary>
    /// Generates a comparison PDF in the mode selected by <see cref="PdfComparisonOptions.Mode"/>.
    /// Red = deleted, green = added, blue = moved, violet = formatting, amber = graphical change.
    /// </summary>
    public static byte[] CompareToPdf(PdfDocument before, PdfDocument after, PdfComparisonOptions? options = null)
        => CompareVisual(before, after, options).PdfBytes;

    public static byte[] CompareFilesToPdf(string beforePath, string afterPath,
        PdfComparisonOptions? options = null, PdfOpenOptions? openOptions = null)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(beforePath);
        ArgumentException.ThrowIfNullOrWhiteSpace(afterPath);
        using var before = PdfDocument.Open(beforePath, openOptions);
        using var after = PdfDocument.Open(afterPath, openOptions);
        return CompareToPdf(before, after, options);
    }

    public static void CompareToFile(PdfDocument before, PdfDocument after, string outputPath,
        PdfComparisonOptions? options = null)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(outputPath);
        File.WriteAllBytes(outputPath, CompareToPdf(before, after, options));
    }

    public static void CompareFilesToFile(string beforePath, string afterPath, string outputPath,
        PdfComparisonOptions? options = null, PdfOpenOptions? openOptions = null)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(outputPath);
        File.WriteAllBytes(outputPath, CompareFilesToPdf(beforePath, afterPath, options, openOptions));
    }

    /// <summary>Writes the comparison PDF to a stream.</summary>
    public static void CompareToStream(PdfDocument before, PdfDocument after, Stream output,
        PdfComparisonOptions? options = null)
    {
        ArgumentNullException.ThrowIfNull(output);
        CompareVisual(before, after, options).WriteTo(output);
    }

    // ── Core pipeline ────────────────────────────────────────────────────────

    public static PdfVisualComparisonResult CompareVisual(PdfDocument before, PdfDocument after, PdfComparisonOptions? options = null)
    {
        ArgumentNullException.ThrowIfNull(before);
        ArgumentNullException.ThrowIfNull(after);
        options ??= new PdfComparisonOptions();
        ValidateComparisonOptions(options);

        var ct = options.CancellationToken;
        var clock = options.UtcNow ?? (() => DateTime.UtcNow);
        var warnings = new List<string>();
        var mode = options.Mode;

        int nBefore = before.Pages.Count, nAfter = after.Pages.Count;
        if (Math.Max(nBefore, nAfter) > options.MaxPages)
            throw new PdfOperationException($"PDF visual comparison is limited to {options.MaxPages} pages per document");

        // Line-level baseline report.
        var textReport = Compare(before, after, new PdfCompareOptions
        {
            MaxPages = options.MaxPages,
            CompareVisual = false
        });

        // 1. Extract words (line clustering, punctuation-aware tokens, header/footer stripping), then settle
        //    line-break hyphenation against the shared vocabulary of both documents.
        var beforeDoc = ExtractDocument(before, options, ct);
        var afterDoc = ExtractDocument(after, options, ct);
        ResolveHyphenation(beforeDoc, afterDoc);

        // 2. Align words (v3 engine + boundary shifting + semantic cleanup + move detection).
        var items = AlignWords(beforeDoc, afterDoc, options, warnings, ct);

        // 3. Pair pages by content. Every equal word votes for (beforePage, afterPage).
        var slots = PageAligner.Align(nBefore, nAfter,
            items.Where(it => it.Kind == DiffKind.Equal).Select(it => (it.BeforeWord!.PageIndex, it.AfterWord!.PageIndex)),
            beforeDoc.Pages.Select(p => p.Count).ToArray(),
            afterDoc.Pages.Select(p => p.Count).ToArray(),
            options.AlignPages && options.AlignAcrossPages);

        var beforeToAfter = new int[nBefore];
        Array.Fill(beforeToAfter, -1);

        // 4. Raster path: a paired slot where at least one side has no text (scan, drawing, scan-vs-digital).
        //    The words of the text side cannot be matched against pixels, so they leave the word comparison.
        var rasterSlot = new bool[slots.Count];
        var rasterBeforePage = new bool[nBefore];
        var rasterAfterPage = new bool[nAfter];
        bool anyRaster = false;
        for (int s = 0; s < slots.Count; s++)
        {
            var (bi, ai) = slots[s];
            if (bi < 0 || ai < 0) continue;
            beforeToAfter[bi] = ai;
            if (beforeDoc.RawCounts[bi] == 0 || afterDoc.RawCounts[ai] == 0)
            {
                rasterSlot[s] = true;
                rasterBeforePage[bi] = true;
                rasterAfterPage[ai] = true;
                anyRaster = true;
            }
        }
        if (anyRaster)
        {
            items = items.Where(it => it.Kind == DiffKind.Equal ||
                !((it.BeforeWord is { } bw && rasterBeforePage[bw.PageIndex]) ||
                  (it.AfterWord is { } aw && rasterAfterPage[aw.PageIndex]))).ToList();
        }

        // 5. Changes (classified) and per-page mark buckets.
        var changes = BuildSemanticChanges(items, options.ClassifyChanges);
        if (options.DetectFormattingChanges)
            changes.AddRange(DetectFormattingChanges(items, options.FormattingTolerance));

        static List<ComparisonWord>[] Buckets(int n)
        {
            var arr = new List<ComparisonWord>[n];
            for (int i = 0; i < n; i++) arr[i] = new List<ComparisonWord>();
            return arr;
        }

        var delByPage = Buckets(nBefore);
        var movedFromByPage = Buckets(nBefore);
        var formatBeforeByPage = Buckets(nBefore);
        var addByPage = Buckets(nAfter);
        var movedToByPage = Buckets(nAfter);
        var formatAfterByPage = Buckets(nAfter);

        int equalWords = 0, editWords = 0;
        foreach (var item in items)
        {
            if (item.Kind == DiffKind.Equal) { equalWords++; continue; }
            editWords++;
            if (item.Kind == DiffKind.Delete && item.BeforeWord is { } bw)
                (item.MoveId >= 0 ? movedFromByPage : delByPage)[bw.PageIndex].Add(bw);
            else if (item.Kind == DiffKind.Insert && item.AfterWord is { } aw)
                (item.MoveId >= 0 ? movedToByPage : addByPage)[aw.PageIndex].Add(aw);
        }
        foreach (var ch in changes)
        {
            if (ch.Type != PdfChangeType.Formatting) continue;
            foreach (var w in ch.DeletedWords) formatBeforeByPage[w.PageIndex].Add(w);
            foreach (var w in ch.AddedWords) formatAfterByPage[w.PageIndex].Add(w);
        }
        double similarity = equalWords * 2 + editWords == 0 ? 1.0 : equalWords * 2.0 / (equalWords * 2 + editWords);

        // 6. Build output pages.
        bool rendersPages = mode is not (PdfComparisonMode.RedlineText or PdfComparisonMode.ChangeReport);
        var output = new PdfOutputDocument();
        var pagesRoot = output.Reserve();
        var shared = CreateSharedResources(output);
        var pageReferences = new List<CosReference>(slots.Count);
        var bookmarkLabels = new List<string>(slots.Count);
        var pageVisualDiffs = new List<PdfPageVisualDiff>(slots.Count);
        var mapEntries = new List<ChangeMapEntry>();
        var empty = new List<ComparisonWord>();

        int changedPagesCount = 0, totalDeletions = 0, totalAdditions = 0, totalGraphicalChanges = 0;

        for (int s = 0; s < slots.Count; s++)
        {
            ct.ThrowIfCancellationRequested();

            var (bi, ai) = slots[s];
            bool beforeExists = bi >= 0, afterExists = ai >= 0;
            bool raster = rasterSlot[s];
            var marks = new SlotMarks
            {
                Deleted = beforeExists ? delByPage[bi] : empty,
                MovedFrom = beforeExists ? movedFromByPage[bi] : empty,
                FormatBefore = beforeExists ? formatBeforeByPage[bi] : empty,
                Added = afterExists ? addByPage[ai] : empty,
                MovedTo = afterExists ? movedToByPage[ai] : empty,
                FormatAfter = afterExists ? formatAfterByPage[ai] : empty
            };

            RasterDiffAnalysis? rda = null;
            if (beforeExists && afterExists && (raster || options.HighlightChangedRegions))
            {
                var scale = options.Dpi / 72.0;
                var rwarn = new List<string>();
                var geomB = PdfImposition.GetPageGeometry(before, before.Pages.Pages[bi]);
                var geomA = PdfImposition.GetPageGeometry(after, after.Pages.Pages[ai]);
                double dispW = Math.Max(geomB.DisplayWidth, geomA.DisplayWidth);
                double dispH = Math.Max(geomB.DisplayHeight, geomA.DisplayHeight);

                RasterCanvas? cBefore = PdfRasterizer.RenderCanvas(before, bi, scale, rwarn);
                RasterCanvas? cAfter = PdfRasterizer.RenderCanvas(after, ai, scale, rwarn);
                rda = AnalyzeRasterDifferencesV3(cBefore, cAfter, scale, options, dispW, dispH, geomA.Box[0], geomA.Box[1]);
                if (rwarn.Count > 0) warnings.Add($"Slot {s + 1}: raster warnings: {string.Join("; ", rwarn)}");

                if (raster)
                {
                    marks.RasterBoxes.AddRange(rda.DifferenceBoxes);
                }
                else if (rda.Changed)
                {
                    // Graphical difference = a raster difference that text (of either version) does not explain.
                    var pageWords = beforeDoc.Pages[bi].Concat(afterDoc.Pages[ai]).ToList();
                    foreach (var box in rda.DifferenceBoxes)
                    {
                        if (!ExplainedByText(box, pageWords))
                            marks.GraphicalBoxes.Add(box);
                    }
                }
            }

            int movedCount = marks.MovedFrom.Count + marks.MovedTo.Count;
            bool pageChanged = !beforeExists || !afterExists ||
                               marks.Deleted.Count > 0 || marks.Added.Count > 0 || movedCount > 0 ||
                               marks.FormatAfter.Count > 0 ||
                               (raster && (rda?.Changed ?? false)) ||
                               marks.GraphicalBoxes.Count > 0;

            if (pageChanged)
            {
                changedPagesCount++;
                totalDeletions += marks.Deleted.Count;
                totalAdditions += marks.Added.Count;
                totalGraphicalChanges += marks.GraphicalBoxes.Count;
            }

            int delCount = raster ? (rda?.DeletedPixels ?? 0) : marks.Deleted.Count;
            int addCount = raster ? (rda?.AddedPixels ?? 0) : marks.Added.Count;
            int wordTotal = (beforeExists ? beforeDoc.Pages[bi].Count : 0) + (afterExists ? afterDoc.Pages[ai].Count : 0);
            double pct = !pageChanged ? 0.0
                : raster ? Math.Round((rda?.ChangedPixels ?? 0) / (double)Math.Max(1, rda?.SampledPixels ?? 1) * 100.0, 2)
                : Math.Round(Math.Min(1.0, (marks.Deleted.Count + marks.Added.Count + movedCount) / (double)Math.Max(1, wordTotal)) * 100.0, 2);

            // The line-level report pairs pages by index, so it only applies when this slot does too.
            var textDiff = bi == ai && bi < textReport.Pages.Count ? textReport.Pages[bi] : null;

            pageVisualDiffs.Add(new PdfPageVisualDiff(
                PageNumber: s + 1,
                BeforeExists: beforeExists,
                AfterExists: afterExists,
                Changed: pageChanged,
                ChangedPixelCount: delCount + addCount + marks.GraphicalBoxes.Count,
                DeletedPixelCount: delCount,
                AddedPixelCount: addCount,
                ModifiedPixelCount: Math.Min(delCount, addCount),
                ChangePercentage: pct,
                AddedLinesCount: textDiff?.AddedLines.Count ?? marks.Added.Count,
                RemovedLinesCount: textDiff?.RemovedLines.Count ?? marks.Deleted.Count)
            {
                UsedRasterFallback = raster,
                BeforePageNumber = bi + 1,
                AfterPageNumber = ai + 1,
                MovedWordCount = movedCount,
                FormattingChangeCount = marks.FormatAfter.Count
            });

            if (!rendersPages) continue;
            if (options.OnlyChangedPages && !pageChanged) continue;

            if (mode == PdfComparisonMode.ChangeMap)
            {
                mapEntries.Add(new ChangeMapEntry(bi, ai, marks, pageChanged, raster));
                continue;
            }

            var pageRef = mode switch
            {
                PdfComparisonMode.SideBySide => RenderSideBySideSlot(output, pagesRoot, shared, before, after, bi, ai, marks,
                    options, s + 1, slots.Count, pageChanged, raster),
                PdfComparisonMode.Annotated => RenderAnnotatedSlot(output, pagesRoot, shared, before, after, bi, ai, marks,
                    changes, beforeToAfter, options),
                PdfComparisonMode.OnionSkin => RenderOnionSkinSlot(output, pagesRoot, shared, before, after, bi, ai,
                    options, s + 1, slots.Count, pageChanged),
                _ => RenderOverlaySlot(output, pagesRoot, shared, before, after, bi, ai, marks,
                    changes, beforeToAfter, options, s + 1, slots.Count, pageChanged, raster)
            };
            pageReferences.Add(pageRef);

            string where = beforeExists && afterExists
                ? (bi == ai ? $"Page {ai + 1}" : $"Page {bi + 1} -> {ai + 1}")
                : afterExists ? $"Page {ai + 1} (inserted)" : $"Page {bi + 1} (deleted)";
            string what = !pageChanged ? "Identical"
                : raster ? "Differences (image comparison)"
                : marks.GraphicalBoxes.Count > 0 && marks.Deleted.Count == 0 && marks.Added.Count == 0 && movedCount == 0
                    ? $"Graphical Differences ({marks.GraphicalBoxes.Count} visual regions)"
                    : $"Differences ({marks.Deleted.Count} del, {marks.Added.Count} add" +
                      (movedCount > 0 ? $", {movedCount} moved" : "") +
                      (marks.GraphicalBoxes.Count > 0 ? $", {marks.GraphicalBoxes.Count} visual" : "") + ")";
            bookmarkLabels.Add($"{where}: {what}");
        }

        byte[]? diffPdfBytes = null;
        if (rendersPages)
        {
            if (mode == PdfComparisonMode.ChangeMap && mapEntries.Count > 0)
                RenderChangeMapSheets(output, pagesRoot, shared, before, after, mapEntries, options, pageReferences, bookmarkLabels);

            if (pageReferences.Count == 0)
            {
                AddIdenticalNoticePage(output, pagesRoot, shared, pageReferences, nBefore);
                bookmarkLabels.Add("No differences");
            }

            output.Set(pagesRoot.Id, new CosDictionary()
                .Set("Type", new CosName("Pages"))
                .Set("Kids", new CosArray(pageReferences))
                .Set("Count", new CosInteger(pageReferences.Count)));

            var catalog = output.Add(new CosDictionary()
                .Set("Type", new CosName("Catalog"))
                .Set("Pages", pagesRoot));

            var info = output.Add(new CosDictionary()
                .Set("Producer", CosString.FromText("Docuzen PDF Comparison Engine"))
                .Set("Title", CosString.FromText("Document Comparison Report"))
                .Set("CreationDate", CosString.FromText("D:" + clock().ToString("yyyyMMddHHmmss", CultureInfo.InvariantCulture) + "Z")));

            diffPdfBytes = WritePdf(output, new CosDictionary().Set("Root", catalog).Set("Info", info));
        }
        else if (mode == PdfComparisonMode.RedlineText)
        {
            var beforeTitle = options.BeforeTitle ?? (string.IsNullOrWhiteSpace(before.Name) ? "Original" : before.Name);
            var afterTitle = options.AfterTitle ?? (string.IsNullOrWhiteSpace(after.Name) ? "Modified" : after.Name);
            diffPdfBytes = HtmlToPdf.Convert(BuildRedlineHtml(items, beforeTitle, afterTitle), new HtmlPdfOptions
            {
                Title = "Document Comparison Redline",
                Producer = "Docuzen PDF Comparison Engine"
            });
            bookmarkLabels.Add("Redline text");
        }

        // 7. Executive summary + classified change log. Mandatory for ChangeReport (it IS the output there).
        bool summaryAdded = false;
        int summaryPages = 0;
        if (options.IncludeSummaryPage || mode == PdfComparisonMode.ChangeReport)
        {
            try
            {
                bool fullLog = mode == PdfComparisonMode.ChangeReport;
                var summaryHtml = BuildSummaryHtml(before, after, pageVisualDiffs, options, clock(),
                    changedPagesCount, totalDeletions, totalAdditions, totalGraphicalChanges,
                    new List<ChangeRow>(), 0, anyRaster);
                summaryHtml = InjectSummaryBlocks(summaryHtml,
                    BuildInsightsHtml(changes, slots, similarity),
                    options.IncludeDeletedTextInSummary || fullLog
                        ? BuildChangeLogHtml(changes, fullLog ? int.MaxValue : MaxChangeLogRows)
                        : string.Empty);

                var summaryPdfBytes = HtmlToPdf.Convert(summaryHtml, new HtmlPdfOptions
                {
                    Title = "Document Comparison Summary",
                    Producer = "Docuzen PDF Comparison Engine"
                });

                using var summaryDoc = PdfDocument.FromBytes(summaryPdfBytes);
                int pagesInSummary = summaryDoc.Pages.Count;
                if (diffPdfBytes is null)
                {
                    diffPdfBytes = summaryPdfBytes;
                }
                else
                {
                    using var diffDoc = PdfDocument.FromBytes(diffPdfBytes);
                    var merged = PdfOperations.Merge([summaryDoc, diffDoc], new AssemblyOptions
                    {
                        Version = "1.7",
                        WriteObjectStreams = true
                    });
                    diffPdfBytes = WritePdf(merged.Output, merged.Trailer);
                }
                summaryPages = pagesInSummary;
                summaryAdded = true;
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception ex) when (diffPdfBytes is not null)
            {
                warnings.Add($"Summary page skipped: {ex.GetType().Name}: {ex.Message}");
            }
        }
        if (diffPdfBytes is null)
            throw new PdfOperationException("comparison produced no output");

        // 8. Outline bookmarks. v2 assumed a one-page summary; a long change log pushed every bookmark off target.
        try
        {
            using var finalDoc = PdfDocument.FromBytes(diffPdfBytes);
            var bookmarks = new List<PdfBookmark>();
            int pageIndex = 1;
            if (summaryAdded)
            {
                bookmarks.Add(new PdfBookmark("Executive Summary", 1));
                pageIndex += summaryPages;
            }
            foreach (var label in bookmarkLabels)
                bookmarks.Add(new PdfBookmark(label, pageIndex++));

            var bookmarked = PdfBookmarks.Apply(finalDoc, bookmarks, new AssemblyOptions
            {
                Version = "1.7",
                WriteObjectStreams = true
            });
            diffPdfBytes = WritePdf(bookmarked.Output, bookmarked.Trailer);
        }
        catch (OperationCanceledException) { throw; }
        catch (Exception ex)
        {
            warnings.Add($"Bookmarks skipped: {ex.GetType().Name}: {ex.Message}");
        }

        return new PdfVisualComparisonResult(
            PdfBytes: diffPdfBytes,
            Report: textReport,
            PageDiffs: pageVisualDiffs,
            ChangedPagesCount: changedPagesCount,
            TotalDeletions: totalDeletions,
            TotalAdditions: totalAdditions,
            IsIdentical: changedPagesCount == 0)
        {
            Warnings = warnings,
            Changes = BuildChangeRecords(changes),
            PageMap = slots.Select(p => new PdfPageSlot(p.Before + 1, p.After + 1)).ToList(),
            TotalMoves = changes.Count(c => c.Type == PdfChangeType.Moved),
            Similarity = similarity
        };
    }

    // ── Raster glue ──────────────────────────────────────────────────────────

    /// <summary>
    /// Runs the v3 raster core and converts its pixel boxes to page user space. Unlike v2 the page-box origin is
    /// added, so pages whose MediaBox/CropBox does not start at (0,0) get correctly placed marks (unrotated pages).
    /// </summary>
    private static RasterDiffAnalysis AnalyzeRasterDifferencesV3(RasterCanvas? before, RasterCanvas? after, double scale,
        PdfComparisonOptions o, double displayW, double displayH, double originX, double originY)
    {
        var result = new RasterDiffAnalysis();
        if (before is null && after is null) return result;
        if (before is null || after is null)
        {
            var only = (before ?? after)!;
            int n = only.Width * only.Height;
            result.Changed = true;
            result.ChangedPixels = n;
            result.SampledPixels = Math.Max(1, n);
            if (before is null) result.AddedPixels = n; else result.DeletedPixels = n;
            result.DifferenceBoxes.Add(new PdfRect(originX, originY, originX + displayW, originY + displayH));
            return result;
        }

        var core = RasterDiffCore.Analyze(before.Pixels, before.Width, before.Height, after.Pixels, after.Width, after.Height,
            o.DifferenceThreshold, o.TolerateAntiAliasing, o.MaxRasterShiftPixels);
        result.Changed = core.Changed;
        result.ChangedPixels = core.ChangedPixels;
        result.DeletedPixels = core.DeletedPixels;
        result.AddedPixels = core.AddedPixels;
        result.SampledPixels = core.SampledPixels;
        foreach (var (x0, y0, x1, y1) in core.Boxes)
        {
            result.DifferenceBoxes.Add(new PdfRect(
                originX + x0 / scale,
                originY + Math.Max(0.0, displayH - y1 / scale),
                originX + x1 / scale,
                originY + Math.Min(displayH, displayH - y0 / scale)));
        }
        return result;
    }

    /// <summary>
    /// v2 dropped a raster box as soon as it touched ANY word, which hid changed images sitting next to a caption.
    /// v3 asks how much of the box the words actually cover: at least 30 % means "this is just text that changed or reflowed".
    /// </summary>
    private static bool ExplainedByText(PdfRect box, List<ComparisonWord> words)
    {
        double area = Math.Max(1e-6, (box.X1 - box.X0) * (box.Y1 - box.Y0));
        double covered = 0;
        foreach (var w in words)
        {
            double ix = Math.Min(box.X1, w.Box.X1 + 2.0) - Math.Max(box.X0, w.Box.X0 - 2.0);
            if (ix <= 0) continue;
            double iy = Math.Min(box.Y1, w.Box.Y1 + 2.0) - Math.Max(box.Y0, w.Box.Y0 - 2.0);
            if (iy <= 0) continue;
            covered += ix * iy;
            if (covered >= 0.3 * area) return true;
        }
        return false;
    }

    private static byte[] WritePdf(PdfOutputDocument output, CosDictionary trailer)
        => PdfFileWriter.WriteToBytes(output, trailer, new PdfWriteOptions
        {
            Producer = "Docuzen PDF Comparison Engine",
            Version = "1.7",
            Deterministic = true,
            WriteObjectStreams = true
        });

    private static void ValidateComparisonOptions(PdfComparisonOptions o)
    {
        if (o.MaxPages is < 1 or > 5_000)
            throw new PdfOperationException("comparison max pages must be between 1 and 5,000");
        if (!double.IsFinite(o.Dpi) || o.Dpi is < 36.0 or > 600.0)
            throw new PdfOperationException("comparison DPI must be between 36 and 600");
        if (o.DifferenceThreshold is < 1 or > 255)
            throw new PdfOperationException("comparison difference threshold must be between 1 and 255");
        if (o.MaxDiffCost is < 1 or > 10_000)
            throw new PdfOperationException("comparison max diff cost must be between 1 and 10,000");
        if (!double.IsFinite(o.HeaderFooterBandFraction) || o.HeaderFooterBandFraction is < 0.0 or > 0.25)
            throw new PdfOperationException("header/footer band fraction must be between 0 and 0.25");
        if (!double.IsFinite(o.HeaderFooterMinPageFraction) || o.HeaderFooterMinPageFraction is < 0.0 or > 1.0)
            throw new PdfOperationException("header/footer min page fraction must be between 0 and 1");
        if (o.MaxDegreeOfParallelism is < 1 or > 64)
            throw new PdfOperationException("max degree of parallelism must be between 1 and 64");
        if (!Enum.IsDefined(o.Mode))
            throw new PdfOperationException("unknown comparison mode");
        if (!Enum.IsDefined(o.MatchMode))
            throw new PdfOperationException("unknown word match mode");
        if (o.MinMoveWords is < 2 or > 1_000)
            throw new PdfOperationException("minimum move length must be between 2 and 1,000 words");
        if (!double.IsFinite(o.FormattingTolerance) || o.FormattingTolerance is < 0.01 or > 1.0)
            throw new PdfOperationException("formatting tolerance must be between 0.01 and 1");
        if (o.MaxRasterShiftPixels is < 0 or > 8)
            throw new PdfOperationException("max raster shift must be between 0 and 8 pixels");
        if (o.ChangeMapColumns is < 2 or > 10)
            throw new PdfOperationException("change map columns must be between 2 and 10");
    }
}
