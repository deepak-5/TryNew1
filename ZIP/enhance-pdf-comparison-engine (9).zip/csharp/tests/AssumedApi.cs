// ─────────────────────────────────────────────────────────────────────────────
// DO NOT ADD THIS FILE TO YOUR PROJECT.
//
// These are empty stand-ins for the parts of Docuzen.Pdf that the comparison code calls, plus the members of
// PdfComparer that live in your UNCHANGED files (overlay header drawing, PaintMark, summary HTML, ...).
// Every signature here was inferred from the source you shared. They exist only so the v3 files can be
// type-checked and the engine tests can run outside your repository.
//
// If your real API differs from a signature below, that is exactly where a compile error will show up
// when you drop the v3 files in - use this file as the checklist.
// ─────────────────────────────────────────────────────────────────────────────
using System.Globalization;
using System.Text;

namespace Docuzen.Pdf.Core
{
    public readonly record struct PdfRect(double X0, double Y0, double X1, double Y1);

    public class PdfOperationException : Exception
    {
        public PdfOperationException(string message) : base(message) { }
    }

    public sealed class PdfOpenOptions { }

    public sealed class PdfCompareOptions
    {
        public int MaxPages { get; init; }
        public bool CompareVisual { get; init; }
    }

    public sealed class PdfPageTextDiff
    {
        public List<string> AddedLines { get; } = new();
        public List<string> RemovedLines { get; } = new();
    }

    public sealed class PdfDiffReport
    {
        public List<PdfPageTextDiff> Pages { get; } = new();
    }

    public sealed class PdfPage { }

    public sealed class PdfPageTree
    {
        public List<PdfPage> Pages { get; } = new();
        public int Count => Pages.Count;
    }

    public sealed partial class PdfDocument : IDisposable
    {
        public PdfPageTree Pages { get; } = new();
        public string Name { get; set; } = string.Empty;
        public static PdfDocument Open(string path, PdfOpenOptions? options = null) => new();
        public static PdfDocument FromBytes(byte[] bytes) => new();
        public void Dispose() { }
    }

    public abstract class CosObject { }
    public sealed class CosReference : CosObject { public int Id { get; init; } }
    public sealed class CosName : CosObject { public CosName(string name) { } }
    public sealed class CosInteger : CosObject { public CosInteger(long value) { } }
    public sealed class CosReal : CosObject { public CosReal(double value) { } }
    public sealed class CosString : CosObject { public static CosString FromText(string text) => new(); }
    public sealed class CosArray : CosObject { public CosArray(IEnumerable<CosObject> items) { } }
    public sealed class CosDictionary : CosObject { public CosDictionary Set(string key, CosObject value) => this; }
    public sealed class CosStream : CosObject { public CosStream(CosDictionary dictionary, byte[] data) { } }

    public sealed class PdfOutputDocument
    {
        public CosReference Reserve() => new();
        public CosReference Add(CosObject value) => new();
        public void Set(int id, CosObject value) { }
    }

    public sealed class PdfWriteOptions
    {
        public string Producer { get; init; } = string.Empty;
        public string Version { get; init; } = string.Empty;
        public bool Deterministic { get; init; }
        public bool WriteObjectStreams { get; init; }
    }

    public static class PdfFileWriter
    {
        public static byte[] WriteToBytes(PdfOutputDocument output, CosDictionary trailer, PdfWriteOptions options) => Array.Empty<byte>();
    }

    public sealed class AssemblyOptions
    {
        public string Version { get; init; } = string.Empty;
        public bool WriteObjectStreams { get; init; }
    }

    public sealed record AssemblyResult(PdfOutputDocument Output, CosDictionary Trailer);

    public static class PdfOperations
    {
        public static AssemblyResult Merge(IReadOnlyList<PdfDocument> documents, AssemblyOptions options) => new(new PdfOutputDocument(), new CosDictionary());
    }

    public sealed record PdfBookmark(string Title, int PageNumber);

    public static class PdfBookmarks
    {
        public static AssemblyResult Apply(PdfDocument document, List<PdfBookmark> bookmarks, AssemblyOptions options) => new(new PdfOutputDocument(), new CosDictionary());
    }

    public static class PdfFormat
    {
        public static string Real(double value) => value.ToString("0.###", CultureInfo.InvariantCulture);
    }

    public sealed record PdfImpositionCell(int Index, int Row, int Column, double X, double Y, double Width, double Height);

    public static class PdfImposition
    {
        public sealed record SourcePageGeometry(double[] Box, double Scale, int Rotation, double DisplayWidth, double DisplayHeight);
        public readonly record struct Placement(double A, double B, double C, double D, double E, double F);

        public static SourcePageGeometry GetPageGeometry(PdfDocument document, PdfPage page) => new(new[] { 0.0, 0.0, 595.28, 841.89 }, 1.0, 0, 595.28, 841.89);
        public static CosReference AddPageForm(PdfOutputDocument output, PdfDocument document, PdfPage page, SourcePageGeometry geometry) => new();
        public static Placement FitPageToCell(SourcePageGeometry geometry, PdfImpositionCell cell) => new(1, 0, 0, 1, cell.X, cell.Y);
        public static CosArray NumberArray(double[] values) => new(Array.Empty<CosObject>());
    }

    // Members of PdfComparer that stay in YOUR unchanged files (signatures only).
    public static partial class PdfComparer
    {
        public static PdfDiffReport Compare(PdfDocument before, PdfDocument after, PdfCompareOptions options) => new();

        private readonly record struct Mat(double A, double B, double C, double D, double E, double F)
        {
            public (double X, double Y) Apply(double x, double y) => (A * x + C * y + E, B * x + D * y + F);
        }

        private static (double X, double Y, double W, double H) MapRect(Mat m, PdfRect box, double[] geomBox)
        {
            var p1 = m.Apply(box.X0 - geomBox[0], box.Y0 - geomBox[1]);
            var p2 = m.Apply(box.X1 - geomBox[0], box.Y1 - geomBox[1]);
            return (Math.Min(p1.X, p2.X), Math.Min(p1.Y, p2.Y), Math.Abs(p2.X - p1.X), Math.Abs(p2.Y - p1.Y));
        }

        private static void PaintMark(StringBuilder c, (double X, double Y, double W, double H) r, bool deletion, PdfComparisonOptions o, double barX) { }
        private static void PaintGraphicalMark(StringBuilder c, (double X, double Y, double W, double H) r, PdfComparisonOptions o, double barX) { }
        private static string N(double v) => PdfFormat.Real(v);
        private static void AppendPlacement(StringBuilder c, Mat m, string name) { }

        private sealed class SharedResources
        {
            public required CosReference Bold { get; init; }
            public required CosReference Regular { get; init; }
            public required CosReference Highlight { get; init; }
        }

        private static SharedResources CreateSharedResources(PdfOutputDocument output) => new() { Bold = new(), Regular = new(), Highlight = new() };
        private static CosDictionary BuildResources(SharedResources s, CosDictionary xObjects) => new();
        private static CosReference AddPage(PdfOutputDocument output, CosReference pagesRoot, SharedResources shared, CosDictionary xObjects, StringBuilder content, double sheetW, double sheetH) => new();
        private static PdfImposition.SourcePageGeometry DefaultGeometry() => new(new[] { 0.0, 0.0, 595.28, 841.89 }, 1.0, 0, 595.28, 841.89);
        private static void DrawMissingPane(StringBuilder c, double x, double y, double w, double h, string label) { }

        private sealed record CalloutBadge(List<string> Lines, double PillW, double PillH, double AnchorX, double AnchorY);

        private static double TextWidth(string text, double fontSize, bool bold) => text.Length * fontSize * 0.5;
        private static List<string> WrapText(string text, double fontSize, double maxWidth, int maxLines) => new() { text };
        private static string EscapePdfString(string text) => text;
        private static void DrawCenteredText(StringBuilder content, string text, double cx, double cy, double fontSize, string color, bool bold = false) { }
        private static void DrawLeftText(StringBuilder c, string text, double x, double y, double size, string color, bool bold) { }
        private static string Truncate(string text, int max) => string.IsNullOrEmpty(text) ? string.Empty : text.Length <= max ? text : text[..(max - 3)] + "...";
        private static void DrawBannerBase(StringBuilder content, double sheetW, double yBanner, double bannerH) { }

        private static void DrawSideBySideHeader(StringBuilder content, double sheetW, double sheetH, double bannerH,
            string beforeTitle, string afterTitle, int pageNumber, int totalPages, int deletions, int additions,
            int graphical, bool pageChanged, bool raster) { }

        private static void DrawOverlayHeader(StringBuilder content, double sheetW, double sheetH, double bannerH,
            int pageNumber, int totalPages, int deletions, int additions, int graphical, bool pageChanged, bool raster) { }

        private sealed class RasterDiffAnalysis
        {
            public bool Changed { get; set; }
            public int ChangedPixels { get; set; }
            public int DeletedPixels { get; set; }
            public int AddedPixels { get; set; }
            public int SampledPixels { get; set; }
            public List<PdfRect> DifferenceBoxes { get; } = new();
        }

        private static void AddIdenticalNoticePage(PdfOutputDocument output, CosReference pagesRoot, SharedResources shared,
            List<CosReference> pageReferences, int pageCount) => pageReferences.Add(new CosReference());

        private sealed record ChangeRow(int Page, string Type, string Deleted, string Added);

        private static string BuildSummaryHtml(
            PdfDocument before, PdfDocument after, IReadOnlyList<PdfPageVisualDiff> pageDiffs,
            PdfComparisonOptions options, DateTime nowUtc, int changedPagesCount, int totalDeletions, int totalAdditions,
            int totalGraphicalChanges, List<ChangeRow> changeRows, int omittedRows, bool anyRaster)
            => "<html><body><h3>Page-by-Page</h3><div class=\"footer\"></div></body></html>";
    }
}

namespace Docuzen.Pdf.Export
{
    using Docuzen.Pdf.Core;

    public sealed class PdfToDocxChar
    {
        public string Text { get; init; } = string.Empty;
        public PdfRect Box { get; init; }
        public (double X, double Y) Origin { get; init; }
        public double FontSize { get; init; }
    }

    public static class PdfToDocxCharExtractor
    {
        public static List<PdfToDocxChar> ExtractPage(PdfDocument document, int pageIndex) => new();
    }
}

namespace Docuzen.Pdf.Html
{
    public sealed class HtmlPdfOptions
    {
        public string Title { get; init; } = string.Empty;
        public string Producer { get; init; } = string.Empty;
    }

    public static class HtmlToPdf
    {
        public static byte[] Convert(string html, HtmlPdfOptions options) => Array.Empty<byte>();
    }
}

namespace Docuzen.Pdf.Raster
{
    using Docuzen.Pdf.Core;

    public sealed class RasterCanvas
    {
        public int Width { get; init; }
        public int Height { get; init; }
        public byte[] Pixels { get; init; } = Array.Empty<byte>();
    }

    public static class PdfRasterizer
    {
        public static RasterCanvas? RenderCanvas(PdfDocument document, int pageIndex, double scale, List<string> warnings) => null;
    }
}
