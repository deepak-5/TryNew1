// Standalone console harness for the pure-algorithm layer (no PDF library needed beyond the stand-ins in AssumedApi.cs).
//   dotnet run -c Release            → 24,000 randomised cases + targeted tests, exit code 0 on success
//
// What it proves:
//   1. every edit script is a valid transformation A → B (also when the cost cap is hit)
//   2. with anchors off and no cap, the script is MINIMAL (checked against an O(NM) LCS table)
//   3. ShiftBoundaries / SemanticCleanup keep the script valid; shifting never changes the edit count
//   4. every detected move is a verbatim, non-overlapping deleted → inserted block
//   5. the Fenwick heaviest-chain equals brute force
//   6. match-mode normalisation, page alignment and the raster core behave as specified
using System.Diagnostics;

namespace Docuzen.Pdf.Core;

public static partial class PdfComparer
{
    internal static class EngineFuzz
    {
        private static int failures;

        private static void Fail(string message)
        {
            failures++;
            if (failures <= 20) Console.WriteLine("  FAIL: " + message);
        }

        private static void Check(bool condition, string message)
        {
            if (!condition) Fail(message);
        }

        private static string? Validate(List<DiffOp> ops, int[] a, int[] b)
        {
            int i = 0, j = 0;
            foreach (var o in ops)
            {
                switch (o.Kind)
                {
                    case DiffKind.Equal:
                        if (o.AIndex != i || o.BIndex != j) return "EQ out of order";
                        if (a[i] != b[j]) return "EQ pairs different tokens";
                        i++; j++;
                        break;
                    case DiffKind.Delete:
                        if (o.AIndex != i || o.BIndex != -1) return "DEL out of order";
                        i++;
                        break;
                    default:
                        if (o.BIndex != j || o.AIndex != -1) return "INS out of order";
                        j++;
                        break;
                }
            }
            return i == a.Length && j == b.Length ? null : "script does not cover both inputs";
        }

        private static int Lcs(int[] a, int[] b)
        {
            var prev = new int[b.Length + 1];
            var cur = new int[b.Length + 1];
            for (int i = 1; i <= a.Length; i++)
            {
                for (int j = 1; j <= b.Length; j++)
                    cur[j] = a[i - 1] == b[j - 1] ? prev[j - 1] + 1 : Math.Max(prev[j], cur[j - 1]);
                (prev, cur) = (cur, prev);
            }
            return prev[b.Length];
        }

        private static double BruteChain(int[] aS, int[] bS, int[] len, double[] w)
        {
            int r = aS.Length;
            var order = Enumerable.Range(0, r).OrderBy(i => aS[i]).ThenBy(i => bS[i]).ToArray();
            double best = 0;
            for (int mask = 1; mask < 1 << r; mask++)
            {
                bool ok = true;
                int last = -1;
                double sum = 0;
                foreach (int i in order)
                {
                    if ((mask & (1 << i)) == 0) continue;
                    if (last >= 0 && (aS[last] + len[last] > aS[i] || bS[last] + len[last] > bS[i])) { ok = false; break; }
                    sum += w[i];
                    last = i;
                }
                if (ok && sum > best) best = sum;
            }
            return best;
        }

        private static void Fuzz(int cases, int seed, ref int optimal, ref int capped, ref int moves, ref int shifts)
        {
            var rnd = new Random(seed);
            for (int c = 0; c < cases; c++)
            {
                bool big = c % 97 == 96;
                int alpha = 2 + rnd.Next(big ? 60 : 24);
                int n = big ? 600 + rnd.Next(900) : rnd.Next(70);
                var a = new int[n];
                for (int i = 0; i < n; i++) a[i] = rnd.Next(alpha);

                List<int> bl;
                if (rnd.NextDouble() < 0.65)
                {
                    bl = new List<int>();
                    foreach (int t in a)
                    {
                        double p = rnd.NextDouble();
                        if (p < 0.1) continue;
                        if (p < 0.2) bl.Add(rnd.Next(alpha));
                        bl.Add(p > 0.92 ? rnd.Next(alpha) : t);
                    }
                    if (rnd.NextDouble() < 0.4 && bl.Count > 8)
                    {
                        int s = rnd.Next(bl.Count - 6), l = 3 + rnd.Next(Math.Min(12, bl.Count - s - 3));
                        var blk = bl.GetRange(s, l);
                        bl.RemoveRange(s, l);
                        bl.InsertRange(rnd.Next(bl.Count + 1), blk);
                    }
                }
                else
                {
                    int m = big ? 600 + rnd.Next(900) : rnd.Next(70);
                    bl = new List<int>(m);
                    for (int i = 0; i < m; i++) bl.Add(rnd.Next(alpha));
                }
                var b = bl.ToArray();

                bool anchors = rnd.NextDouble() < 0.5, tiny = rnd.NextDouble() < 0.3;
                var res = DiffEngine.Diff(a, b, new DiffEngineOptions
                {
                    UsePhraseAnchors = anchors,
                    UseTokenAnchors = anchors,
                    MaxCost = tiny ? 2 + rnd.Next(8) : 4000
                });
                var v = Validate(res.Ops, a, b);
                if (v is not null) { Fail($"seed {seed} case {c}: diff invalid ({v})"); continue; }
                if (res.CappedRegions > 0) capped++;
                if (!anchors && res.CappedRegions == 0 && !big)
                {
                    optimal++;
                    int d = res.Ops.Count(o => o.Kind != DiffKind.Equal);
                    if (d != a.Length + b.Length - 2 * Lcs(a, b)) Fail($"seed {seed} case {c}: not minimal (D={d})");
                }

                var ops = new List<DiffOp>(res.Ops);
                var brkA = new byte[a.Length + 1];
                var brkB = new byte[b.Length + 1];
                for (int i = 0; i < brkA.Length; i++) brkA[i] = (byte)rnd.Next(4);
                for (int i = 0; i < brkB.Length; i++) brkB[i] = (byte)rnd.Next(4);
                int editsBefore = ops.Count(o => o.Kind != DiffKind.Equal);
                shifts += DiffRefine.ShiftBoundaries(ops, a, b, brkA, brkB);
                v = Validate(ops, a, b);
                if (v is not null) { Fail($"seed {seed} case {c}: ShiftBoundaries invalid ({v})"); continue; }
                Check(ops.Count(o => o.Kind != DiffKind.Equal) == editsBefore, $"seed {seed} case {c}: ShiftBoundaries changed the edit count");

                ops = DiffRefine.SemanticCleanup(ops, 1 + rnd.Next(2), null, out _);
                v = Validate(ops, a, b);
                if (v is not null) { Fail($"seed {seed} case {c}: SemanticCleanup invalid ({v})"); continue; }

                var mv = DiffRefine.DetectMoves(ops, a, b, 2 + rnd.Next(4));
                var isDel = new bool[a.Length];
                var isIns = new bool[b.Length];
                var usedA = new bool[a.Length];
                var usedB = new bool[b.Length];
                foreach (var o in ops)
                {
                    if (o.Kind == DiffKind.Delete) isDel[o.AIndex] = true;
                    else if (o.Kind == DiffKind.Insert) isIns[o.BIndex] = true;
                }
                foreach (var m in mv.Moves)
                {
                    moves++;
                    for (int k = 0; k < m.Length; k++)
                    {
                        int x = m.AStart + k, y = m.BStart + k;
                        if (a[x] != b[y] || !isDel[x] || !isIns[y] || usedA[x] || usedB[y] || mv.MoveOfA[x] != m.Id || mv.MoveOfB[y] != m.Id)
                        {
                            Fail($"seed {seed} case {c}: invalid move block");
                            break;
                        }
                        usedA[x] = true; usedB[y] = true;
                    }
                }

                if (c % 3 == 0)
                {
                    int r = 1 + rnd.Next(9);
                    var aS = new int[r]; var bS = new int[r]; var len = new int[r]; var w = new double[r];
                    for (int k = 0; k < r; k++) { aS[k] = rnd.Next(20); bS[k] = rnd.Next(20); len[k] = 1 + rnd.Next(4); w[k] = 1 + rnd.Next(6); }
                    var chain = DiffEngine.HeaviestChain(aS, bS, len, w);
                    double sum = 0;
                    bool ok = true;
                    for (int k = 0; k < chain.Count; k++)
                    {
                        sum += w[chain[k]];
                        if (k > 0)
                        {
                            int p = chain[k - 1], q = chain[k];
                            if (aS[p] + len[p] > aS[q] || bS[p] + len[p] > bS[q]) ok = false;
                        }
                    }
                    Check(ok, $"seed {seed} case {c}: chain overlaps");
                    Check(Math.Abs(sum - BruteChain(aS, bS, len, w)) < 1e-9, $"seed {seed} case {c}: chain not heaviest");
                }
            }
        }

        private static void NormalizationTests()
        {
            static bool Same(string x, string y, PdfWordMatchMode mode) => MatchKey(x, FlagsFor(mode)) == MatchKey(y, FlagsFor(mode));

            Check(!Same("Shall", "shall", PdfWordMatchMode.Strict), "strict must be case-sensitive");
            Check(Same("Shall", "shall", PdfWordMatchMode.IgnoreCase), "ignore-case");
            Check(Same("agreement,", "Agreement", PdfWordMatchMode.IgnoreCaseAndPunctuation), "edge punctuation");
            Check(!Same("(500)", "500", PdfWordMatchMode.IgnoreCaseAndPunctuation), "punctuation around digits must stay significant");
            Check(!Same("-500", "500", PdfWordMatchMode.Loose), "sign must stay significant");
            Check(Same("\u201CTerm\u201D", "\"Term\"", PdfWordMatchMode.Typographic), "curly vs straight quotes");
            Check(Same("2020\u20132024", "2020-2024", PdfWordMatchMode.Typographic), "en dash vs hyphen");
            Check(!Same("\u201CTerm\u201D", "\"Term\"", PdfWordMatchMode.Strict), "strict keeps typography");
            Check(Same("1,000,000", "1000000", PdfWordMatchMode.NumericAware), "thousands separators");
            Check(Same("$1,250.50", "$1250.5", PdfWordMatchMode.NumericAware), "currency trailing zero");
            Check(Same("12.50%", "12.5%", PdfWordMatchMode.NumericAware), "percent trailing zero");
            Check(!Same("3.10", "3.1", PdfWordMatchMode.NumericAware), "section numbers 3.10 vs 3.1 must stay different");
            Check(!Same("1,000", "1,001", PdfWordMatchMode.NumericAware), "different numbers");
            Check(!Same("1,00", "100", PdfWordMatchMode.Strict), "strict numbers");
            Check(Same("modern", "modem", PdfWordMatchMode.OcrTolerant), "OCR rn/m");
            Check(Same("l0ad", "load", PdfWordMatchMode.OcrTolerant), "OCR 0/o");
            Check(!Same("modern", "modem", PdfWordMatchMode.Loose), "loose is not OCR-tolerant");
            Check(MatchKey("x", PdfMatchFlags.None) == "x", "no flags = identity");
            Check(NormalizeNumber("abc") == "abc", "non-number untouched");
            Check(DiffRefine.Levenshtein("kitten", "sitting") == 3, "levenshtein");
            var cd = DiffRefine.CharDiff("recieve", "receive");
            Check(string.Concat(cd.Where(s => s.Kind != DiffKind.Insert).Select(s => s.Text)) == "recieve" &&
                  string.Concat(cd.Where(s => s.Kind != DiffKind.Delete).Select(s => s.Text)) == "receive", "char diff round-trip");
            var pairs = DiffRefine.PairWords(new[] { "colour", "quick", "fox" }, new[] { "color", "slow", "foxes" });
            Check(pairs.Count == 2 && pairs[0].Del == 0 && pairs[0].Ins == 0 && pairs[1].Del == 2 && pairs[1].Ins == 2, "pair words");
        }

        private static void PageAlignmentTests()
        {
            // Before: pages 0..3. After: a new page inserted at index 1, so before i ↔ after i+1 for i >= 1.
            var votes = new List<(int, int)>();
            for (int k = 0; k < 100; k++) { votes.Add((0, 0)); votes.Add((1, 2)); votes.Add((2, 3)); votes.Add((3, 4)); }
            for (int k = 0; k < 5; k++) votes.Add((1, 1)); // a few stray matches must not derail the chain
            var slots = PageAligner.Align(4, 5, votes, new[] { 100, 105, 100, 100 }, new[] { 100, 120, 100, 100, 100 }, align: true);
            var expected = new[] { (0, 0), (-1, 1), (1, 2), (2, 3), (3, 4) };
            Check(slots.SequenceEqual(expected), "inserted page must become its own slot: " + string.Join(" ", slots));

            var byIndex = PageAligner.Align(4, 5, votes, new[] { 100, 105, 100, 100 }, new[] { 100, 120, 100, 100, 100 }, align: false);
            Check(byIndex.SequenceEqual(new[] { (0, 0), (1, 1), (2, 2), (3, 3), (-1, 4) }), "index pairing (v2 behaviour)");

            // A rewritten page with no matching words sits in a 1:1 gap and is paired in order.
            var v2 = new List<(int, int)>();
            for (int k = 0; k < 50; k++) { v2.Add((0, 0)); v2.Add((2, 2)); }
            var gap = PageAligner.Align(3, 3, v2, new[] { 50, 50, 50 }, new[] { 50, 50, 50 }, align: true);
            Check(gap.SequenceEqual(new[] { (0, 0), (1, 1), (2, 2) }), "equal-sized gap is paired in order");

            var none = PageAligner.Align(1, 1, new List<(int, int)>(), new[] { 0 }, new[] { 0 }, align: true);
            Check(none.SequenceEqual(new[] { (0, 0) }), "text-less single pages pair up");
        }

        private static byte[] Canvas(int w, int h, Action<byte[], int, int> draw)
        {
            var px = new byte[w * h * 3];
            Array.Fill(px, (byte)255);
            draw(px, w, h);
            return px;
        }

        private static void Rect(byte[] px, int w, int x0, int y0, int x1, int y1, byte v)
        {
            for (int y = y0; y < y1; y++)
                for (int x = x0; x < x1; x++)
                {
                    int i = (y * w + x) * 3;
                    px[i] = v; px[i + 1] = v; px[i + 2] = v;
                }
        }

        private static void RasterTests()
        {
            const int w = 320, h = 240;
            void Scene(byte[] px, int dx, int dy)
            {
                for (int k = 0; k < 8; k++) Rect(px, w, 30 + dx, 30 + k * 20 + dy, 250 + dx - k * 9, 36 + k * 20 + dy, 20);
                Rect(px, w, 260 + dx, 60 + dy, 300 + dx, 150 + dy, 90);
            }

            var basePx = Canvas(w, h, (px, _, _) => Scene(px, 0, 0));
            var same = RasterDiffCore.Analyze(basePx, w, h, (byte[])basePx.Clone(), w, h, 16);
            Check(!same.Changed && same.Boxes.Count == 0, "identical images must not differ");

            var shifted = Canvas(w, h, (px, _, _) => Scene(px, 2, 1));
            var reg = RasterDiffCore.Analyze(basePx, w, h, shifted, w, h, 16, tolerateAntiAliasing: true, maxShift: 2);
            Check(reg.ShiftX == 2 && reg.ShiftY == 1, $"registration should find (2,1), got ({reg.ShiftX},{reg.ShiftY})");
            Check(!reg.Changed, "a uniform 2px shift is registration noise, not a change");
            var noReg = RasterDiffCore.Analyze(basePx, w, h, shifted, w, h, 16, tolerateAntiAliasing: true, maxShift: 0);
            Check(noReg.Changed, "with registration disabled the shift must be reported");

            var added = Canvas(w, h, (px, _, _) => { Scene(px, 0, 0); Rect(px, w, 100, 200, 180, 220, 0); });
            var diff = RasterDiffCore.Analyze(basePx, w, h, added, w, h, 16);
            Check(diff.Changed && diff.Boxes.Count == 1, $"added block: expected 1 box, got {diff.Boxes.Count}");
            if (diff.Boxes.Count == 1)
            {
                var bx = diff.Boxes[0];
                Check(bx.X0 <= 100 && bx.X1 >= 180 && bx.Y0 <= 200 && bx.Y1 >= 220, "box must cover the added block");
                Check(bx.X1 - bx.X0 <= 80 + 32 && bx.Y1 - bx.Y0 <= 20 + 32, "box must stay tight");
            }
            Check(diff.AddedPixels > diff.DeletedPixels, "darker content counts as added");

            var thin = Canvas(w, h, (px, _, _) => { Scene(px, 0, 0); Rect(px, w, 40, 210, 280, 211, 0); });
            var thinDiff = RasterDiffCore.Analyze(basePx, w, h, thin, w, h, 16);
            Check(thinDiff.Changed, "a new 1px hairline must survive anti-aliasing tolerance");

            var soft = (byte[])basePx.Clone();
            for (int i = 0; i < soft.Length; i++) if (soft[i] > 8) soft[i] = (byte)(soft[i] - 6);
            Check(!RasterDiffCore.Analyze(basePx, w, h, soft, w, h, 16).Changed, "sub-threshold tone drift is ignored");
        }

        private static int Main()
        {
            var sw = Stopwatch.StartNew();
            int total = 0, optimal = 0, capped = 0, moves = 0, shifts = 0;
            foreach (int seed in new[] { 1, 2, 3, 4, 5, 6, 7, 8 })
            {
                Fuzz(3000, seed * 7919, ref optimal, ref capped, ref moves, ref shifts);
                total += 3000;
            }
            Console.WriteLine($"fuzz: cases={total} minimality-checked={optimal} cap-hit={capped} moves={moves} shifts={shifts} ({sw.ElapsedMilliseconds} ms)");

            NormalizationTests();
            PageAlignmentTests();
            RasterTests();
            Console.WriteLine("targeted: normalisation, page alignment, raster core");

            // Scale check: 200k-token documents with scattered edits and one moved block.
            var rnd = new Random(42);
            var a = new int[200_000];
            for (int i = 0; i < a.Length; i++) a[i] = rnd.Next(6000);
            var bl = new List<int>(a);
            for (int k = 0; k < 2500; k++) bl[rnd.Next(bl.Count)] = 6000 + k;
            var block = bl.GetRange(50_000, 400);
            bl.RemoveRange(50_000, 400);
            bl.InsertRange(150_000, block);
            var b = bl.ToArray();
            sw.Restart();
            var bigRes = DiffEngine.Diff(a, b, 4000);
            long diffMs = sw.ElapsedMilliseconds;
            Check(Validate(bigRes.Ops, a, b) is null, "large diff invalid");
            var bigMoves = DiffRefine.DetectMoves(bigRes.Ops, a, b, 5);
            // The moved block also received a few of the random substitutions, so it is recovered as several
            // verbatim fragments (a moved-and-edited block is not merged into one move - see INTEGRATION.md).
            Check(bigMoves.Moves.Sum(m => m.Length) >= 350, "the 400-token moved block should be recovered as move fragments");
            Console.WriteLine($"scale: 200k x 200k tokens → {bigRes.Ops.Count(o => o.Kind != DiffKind.Equal)} edits in {diffMs} ms, " +
                              $"{bigRes.PhraseAnchorRuns} phrase runs, {bigRes.Bisections} bisections, capped={bigRes.CappedRegions}, moves={bigMoves.Moves.Count}");

            Console.WriteLine(failures == 0 ? "ALL PASSED" : $"{failures} FAILURE(S)");
            return failures == 0 ? 0 : 1;
        }
    }
}
