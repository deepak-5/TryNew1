using System.Text;

namespace Docuzen.Pdf.Core;

// NEW FILE. Page-pair-aware versions of the two v2 renderers (the originals paired pages by index).
// They are named *Slot so the original RenderSideBySidePage / RenderOverlayPage can stay in place as dead code
// (or be deleted). They reuse the unchanged v2 helpers: Mat, MapRect, PaintMark, PaintGraphicalMark,
// AppendPlacement, AddPage, DrawSideBySideHeader, DrawOverlayHeader, DrawMissingPane, WrapText, TextWidth, ...

public static partial class PdfComparer
{
    /// <summary>Everything that gets marked on one comparison slot (a before page, an after page, or a pair).</summary>
    private sealed class SlotMarks
    {
        public List<ComparisonWord> Deleted { get; init; } = new();
        public List<ComparisonWord> Added { get; init; } = new();
        public List<ComparisonWord> MovedFrom { get; init; } = new();
        public List<ComparisonWord> MovedTo { get; init; } = new();
        public List<ComparisonWord> FormatBefore { get; init; } = new();
        public List<ComparisonWord> FormatAfter { get; init; } = new();
        public List<PdfRect> GraphicalBoxes { get; } = new();
        public List<PdfRect> RasterBoxes { get; } = new();
    }

    private const string MoveFill = "0.800 0.870 1.000";
    private const string MoveStroke = "0.150 0.380 0.850";
    private const string FormatFill = "0.900 0.840 1.000";
    private const string FormatStroke = "0.480 0.250 0.800";

    /// <summary>Tinted highlight with a dashed underline: blue = moved text, violet = formatting change.</summary>
    private static void PaintTintMark(StringBuilder c, (double X, double Y, double W, double H) r, string fill, string stroke,
        PdfComparisonOptions o, double barX)
    {
        double bx = r.X - 1.5, by = r.Y - 1.0, bw = r.W + 3.0, bh = r.H + 2.0;

        if (o.HighlightChangedRegions)
        {
            c.Append("q\n/GSHighlight gs\n").Append(fill).Append(" rg\n")
             .Append(N(bx)).Append(' ').Append(N(by)).Append(' ').Append(N(bw)).Append(' ').Append(N(bh)).Append(" re f\nQ\n");
        }

        c.Append("q\n").Append(stroke).Append(" RG 1.1 w [2 1.5] 0 d\n")
         .Append(N(bx)).Append(' ').Append(N(by + 0.5)).Append(" m ")
         .Append(N(bx + bw)).Append(' ').Append(N(by + 0.5)).Append(" l S\nQ\n");

        if (o.DrawMarginChangeBars)
        {
            c.Append("q\n").Append(stroke).Append(" RG 2.5 w\n")
             .Append(N(barX)).Append(' ').Append(N(by)).Append(" m ")
             .Append(N(barX)).Append(' ').Append(N(by + bh)).Append(" l S\nQ\n");
        }
    }

    /// <summary>
    /// The after-page on which a change is shown. Insertions/replacements live where their first added word is.
    /// A pure deletion is shown on the after-page its before-page is paired with when a neighbouring unchanged word
    /// confirms it, otherwise next to the preceding (then following) unchanged word.
    /// </summary>
    private static int HomeAfterPage(SemanticDiffChange ch, int[] beforeToAfter)
    {
        if (ch.AddedWords.Count > 0) return ch.AddedWords[0].PageIndex;
        int mapped = ch.DeletedWords.Count > 0 ? beforeToAfter[ch.DeletedWords[0].PageIndex] : -1;
        int prec = ch.PrecedingEqualAfter?.PageIndex ?? -1;
        int next = ch.SubsequentEqualAfter?.PageIndex ?? -1;
        if (mapped >= 0 && (mapped == prec || mapped == next)) return mapped;
        return prec >= 0 ? prec : next >= 0 ? next : mapped;
    }

    // ── Side-by-side ─────────────────────────────────────────────────────────

    private static CosReference RenderSideBySideSlot(
        PdfOutputDocument output, CosReference pagesRoot, SharedResources shared,
        PdfDocument before, PdfDocument after, int beforeIndex, int afterIndex, SlotMarks marks,
        PdfComparisonOptions options, int slotNumber, int totalSlots, bool pageChanged, bool raster)
    {
        bool beforeExists = beforeIndex >= 0, afterExists = afterIndex >= 0;

        var geomBefore = beforeExists ? PdfImposition.GetPageGeometry(before, before.Pages.Pages[beforeIndex]) : DefaultGeometry();
        var geomAfter = afterExists ? PdfImposition.GetPageGeometry(after, after.Pages.Pages[afterIndex]) : DefaultGeometry();

        double wBefore = geomBefore.DisplayWidth, hBefore = geomBefore.DisplayHeight;
        double wAfter = geomAfter.DisplayWidth, hAfter = geomAfter.DisplayHeight;

        double bannerH = options.IncludePageBanners ? BannerHeightPt : 0.0;
        double sheetW = PageMarginPt + wBefore + GutterPt + wAfter + PageMarginPt;
        double maxH = Math.Max(hBefore, hAfter);
        double sheetH = PageMarginPt + maxH + PageMarginPt + bannerH;

        double leftX = PageMarginPt, leftY = PageMarginPt + (maxH - hBefore) / 2.0;
        double rightX = PageMarginPt + wBefore + GutterPt, rightY = PageMarginPt + (maxH - hAfter) / 2.0;

        var xObjects = new CosDictionary();
        if (beforeExists) xObjects.Set("FmBefore", PdfImposition.AddPageForm(output, before, before.Pages.Pages[beforeIndex], geomBefore));
        if (afterExists) xObjects.Set("FmAfter", PdfImposition.AddPageForm(output, after, after.Pages.Pages[afterIndex], geomAfter));

        var c = new StringBuilder();
        c.Append("1 1 1 rg 0 0 ").Append(N(sheetW)).Append(' ').Append(N(sheetH)).Append(" re f\n");

        if (options.IncludePageBanners)
        {
            DrawSideBySideHeader(c, sheetW, sheetH, bannerH,
                options.BeforeTitle ?? (string.IsNullOrWhiteSpace(before.Name) ? "Original" : before.Name),
                options.AfterTitle ?? (string.IsNullOrWhiteSpace(after.Name) ? "Modified" : after.Name),
                slotNumber, totalSlots, marks.Deleted.Count, marks.Added.Count, marks.GraphicalBoxes.Count, pageChanged, raster);
        }

        double divX = PageMarginPt + wBefore + GutterPt / 2.0;
        double divTop = sheetH - bannerH - 8.0;
        c.Append("0.85 0.88 0.92 RG 1.5 w\n").Append(N(divX)).Append(" 15 m ").Append(N(divX)).Append(' ').Append(N(divTop)).Append(" l S\n");

        if (beforeExists)
        {
            var placement = PdfImposition.FitPageToCell(geomBefore, new PdfImpositionCell(0, 0, 0, leftX, leftY, wBefore, hBefore));
            var m = new Mat(placement.A, placement.B, placement.C, placement.D, placement.E, placement.F);
            AppendPlacement(c, m, "FmBefore");
            double barX = Math.Max(4.0, leftX - 8.0);

            if (raster)
            {
                foreach (var box in marks.RasterBoxes)
                    PaintMark(c, MapRect(m, box, geomBefore.Box), deletion: true, options, barX);
            }
            else
            {
                foreach (var box in ClusterWordsIntoBoxes(marks.Deleted))
                    PaintMark(c, MapRect(m, box, geomBefore.Box), deletion: true, options, barX);
                foreach (var box in ClusterWordsIntoBoxes(marks.MovedFrom))
                    PaintTintMark(c, MapRect(m, box, geomBefore.Box), MoveFill, MoveStroke, options, barX);
                foreach (var box in ClusterWordsIntoBoxes(marks.FormatBefore))
                    PaintTintMark(c, MapRect(m, box, geomBefore.Box), FormatFill, FormatStroke, options, barX);
                foreach (var box in marks.GraphicalBoxes)
                    PaintGraphicalMark(c, MapRect(m, box, geomBefore.Box), options, barX);
            }
        }
        else
        {
            DrawMissingPane(c, leftX, leftY, wBefore, hBefore, "Page Not Present in Original Document");
        }

        if (afterExists)
        {
            var placement = PdfImposition.FitPageToCell(geomAfter, new PdfImpositionCell(1, 0, 1, rightX, rightY, wAfter, hAfter));
            var m = new Mat(placement.A, placement.B, placement.C, placement.D, placement.E, placement.F);
            AppendPlacement(c, m, "FmAfter");
            double barX = rightX + wAfter + 8.0;

            if (raster)
            {
                foreach (var box in marks.RasterBoxes)
                    PaintMark(c, MapRect(m, box, geomAfter.Box), deletion: false, options, barX);
            }
            else
            {
                foreach (var box in ClusterWordsIntoBoxes(marks.Added))
                    PaintMark(c, MapRect(m, box, geomAfter.Box), deletion: false, options, barX);
                foreach (var box in ClusterWordsIntoBoxes(marks.MovedTo))
                    PaintTintMark(c, MapRect(m, box, geomAfter.Box), MoveFill, MoveStroke, options, barX);
                foreach (var box in ClusterWordsIntoBoxes(marks.FormatAfter))
                    PaintTintMark(c, MapRect(m, box, geomAfter.Box), FormatFill, FormatStroke, options, barX);
                foreach (var box in marks.GraphicalBoxes)
                    PaintGraphicalMark(c, MapRect(m, box, geomAfter.Box), options, barX);
            }
        }
        else
        {
            DrawMissingPane(c, rightX, rightY, wAfter, hAfter, "Page Deleted in Modified Document");
        }

        return AddPage(output, pagesRoot, shared, xObjects, c, sheetW, sheetH);
    }

    // ── Overlay ──────────────────────────────────────────────────────────────

    private static CosReference RenderOverlaySlot(
        PdfOutputDocument output, CosReference pagesRoot, SharedResources shared,
        PdfDocument before, PdfDocument after, int beforeIndex, int afterIndex, SlotMarks marks,
        List<SemanticDiffChange> changes, int[] beforeToAfter, PdfComparisonOptions options,
        int slotNumber, int totalSlots, bool pageChanged, bool raster)
    {
        bool afterExists = afterIndex >= 0;
        var baseDoc = afterExists ? after : before;
        int baseIndex = afterExists ? afterIndex : beforeIndex;
        var baseGeom = PdfImposition.GetPageGeometry(baseDoc, baseDoc.Pages.Pages[baseIndex]);
        double baseW = baseGeom.DisplayWidth, baseH = baseGeom.DisplayHeight;

        double bannerH = options.IncludePageBanners ? BannerHeightPt : 0.0;
        double sheetW = PageMarginPt + baseW + OverlayCalloutGutterPt + PageMarginPt;
        double sheetH = PageMarginPt + baseH + PageMarginPt + bannerH;
        double paneX = PageMarginPt, paneY = PageMarginPt;

        var xObjects = new CosDictionary();
        xObjects.Set("FmBase", PdfImposition.AddPageForm(output, baseDoc, baseDoc.Pages.Pages[baseIndex], baseGeom));

        var c = new StringBuilder();
        c.Append("1 1 1 rg 0 0 ").Append(N(sheetW)).Append(' ').Append(N(sheetH)).Append(" re f\n");

        if (options.IncludePageBanners)
            DrawOverlayHeader(c, sheetW, sheetH, bannerH, slotNumber, totalSlots, marks.Deleted.Count, marks.Added.Count,
                marks.GraphicalBoxes.Count, pageChanged, raster);

        var placement = PdfImposition.FitPageToCell(baseGeom, new PdfImpositionCell(0, 0, 0, paneX, paneY, baseW, baseH));
        var m = new Mat(placement.A, placement.B, placement.C, placement.D, placement.E, placement.F);
        AppendPlacement(c, m, "FmBase");

        double leftBarX = Math.Max(4.0, paneX - 8.0);

        // Page exists only in the original: mark its content in place.
        if (!afterExists)
        {
            foreach (var box in ClusterWordsIntoBoxes(marks.Deleted))
                PaintMark(c, MapRect(m, box, baseGeom.Box), deletion: true, options, leftBarX);
            foreach (var box in ClusterWordsIntoBoxes(marks.MovedFrom))
                PaintTintMark(c, MapRect(m, box, baseGeom.Box), MoveFill, MoveStroke, options, leftBarX);
            return AddPage(output, pagesRoot, shared, xObjects, c, sheetW, sheetH);
        }

        double addBarX = paneX + baseW + 6.0;

        if (raster)
        {
            foreach (var box in marks.RasterBoxes)
                PaintMark(c, MapRect(m, box, baseGeom.Box), deletion: false, options, addBarX);
        }
        else
        {
            foreach (var box in ClusterWordsIntoBoxes(marks.Added))
                PaintMark(c, MapRect(m, box, baseGeom.Box), deletion: false, options, addBarX);
            foreach (var box in ClusterWordsIntoBoxes(marks.MovedTo))
                PaintTintMark(c, MapRect(m, box, baseGeom.Box), MoveFill, MoveStroke, options, addBarX);
            foreach (var box in ClusterWordsIntoBoxes(marks.FormatAfter))
                PaintTintMark(c, MapRect(m, box, baseGeom.Box), FormatFill, FormatStroke, options, addBarX);
            foreach (var box in marks.GraphicalBoxes)
                PaintGraphicalMark(c, MapRect(m, box, baseGeom.Box), options, addBarX);
        }

        // Deletion callouts in the right gutter with word wrapping, caret anchor and leader lines.
        double calloutX = paneX + baseW + 10.0;
        double maxCalloutW = OverlayCalloutGutterPt - 16.0;
        const double fontSize = 6.5;
        const double lineH = 8.5;
        const double minGap = 3.0;

        var items = new List<CalloutBadge>();
        foreach (var change in changes)
        {
            // Moved text still exists in the document and formatting changes delete nothing: no deletion callout.
            if (change.Type is PdfChangeType.Moved or PdfChangeType.Formatting) continue;
            if (HomeAfterPage(change, beforeToAfter) != afterIndex) continue;

            // Words on unpaired (deleted) pages are shown in place on their own slot.
            var deleted = change.DeletedWords.Where(w => beforeToAfter[w.PageIndex] >= 0).ToList();
            if (deleted.Count == 0) continue;

            ComparisonWord? anchor =
                change.AddedWords.FirstOrDefault(w => w.PageIndex == afterIndex)
                ?? (change.PrecedingEqualAfter is { } p && p.PageIndex == afterIndex ? p : null)
                ?? (change.SubsequentEqualAfter is { } s && s.PageIndex == afterIndex ? s : null);

            double anchorX, anchorY;
            if (anchor is not null)
            {
                var mapped = MapRect(m, anchor.Box, baseGeom.Box);
                anchorX = ReferenceEquals(change.PrecedingEqualAfter, anchor) ? mapped.X + mapped.W : mapped.X;
                anchorY = mapped.Y + mapped.H * 0.5;
            }
            else
            {
                var first = deleted[0];
                var g = PdfImposition.GetPageGeometry(before, before.Pages.Pages[first.PageIndex]);
                double rel = (first.Box.Y0 - g.Box[1]) / Math.Max(1.0, g.DisplayHeight);
                anchorX = paneX + baseW;
                anchorY = paneY + Math.Clamp(rel, 0.0, 1.0) * baseH;
            }

            var wrappedLines = WrapText(JoinWords(deleted), fontSize, maxCalloutW - 12.0, maxLines: 3);
            if (wrappedLines.Count == 0) continue;

            double maxLineW = wrappedLines.Max(l => TextWidth(l, fontSize, false));
            double pillW = Math.Min(maxCalloutW, Math.Max(32.0, maxLineW + 12.0));
            double pillH = Math.Max(14.0, 5.0 + wrappedLines.Count * lineH);

            items.Add(new CalloutBadge(wrappedLines, pillW, pillH, anchorX, anchorY));
        }

        items = items.OrderByDescending(t => t.AnchorY).ToList();
        var ys = new double[items.Count];
        double last = double.MaxValue;
        for (int k = 0; k < items.Count; k++)
        {
            double y = items[k].AnchorY - items[k].PillH / 2.0;
            if (y + items[k].PillH > last - minGap)
                y = last - minGap - items[k].PillH;
            ys[k] = y;
            last = y;
        }
        for (int k = items.Count - 1; k >= 0; k--)
        {
            double lower = k == items.Count - 1 ? paneY : ys[k + 1] + items[k + 1].PillH + minGap;
            if (ys[k] < lower) ys[k] = lower;
        }

        for (int k = 0; k < items.Count; k++)
        {
            var item = items[k];
            double y = ys[k];
            double pillW = item.PillW;
            double pillH = item.PillH;

            // Caret marker on the document at the deletion position
            c.Append("q\n0.850 0.180 0.180 RG 1.5 w\n")
             .Append(N(item.AnchorX)).Append(' ').Append(N(item.AnchorY - 3.5)).Append(" m ")
             .Append(N(item.AnchorX)).Append(' ').Append(N(item.AnchorY + 3.5)).Append(" l S\nQ\n");

            // Dotted leader line from caret to callout pill
            if (item.AnchorX < calloutX - 4.0)
            {
                c.Append("q\n[2 2] 0 d\n0.850 0.350 0.350 RG 0.6 w\n")
                 .Append(N(item.AnchorX + 1.0)).Append(' ').Append(N(item.AnchorY)).Append(" m ")
                 .Append(N(calloutX)).Append(' ').Append(N(y + pillH / 2.0)).Append(" l S\nQ\n");
            }

            // Deletion badge
            c.Append("q\n1.000 0.910 0.910 rg 0.850 0.220 0.220 RG 0.6 w\n")
             .Append(N(calloutX)).Append(' ').Append(N(y)).Append(' ').Append(N(pillW)).Append(' ').Append(N(pillH)).Append(" re B\n");

            for (int lineIdx = 0; lineIdx < item.Lines.Count; lineIdx++)
            {
                string lineText = item.Lines[lineIdx];
                double textY = y + pillH - 4.0 - (lineIdx + 1) * lineH + 2.0;
                double textX = calloutX + 5.0;

                c.Append("BT\n/F_Regular ").Append(N(fontSize)).Append(" Tf\n0.800 0.150 0.150 rg\n")
                 .Append(N(textX)).Append(' ').Append(N(textY)).Append(" Td\n")
                 .Append('(').Append(EscapePdfString(lineText)).Append(") Tj\nET\n");

                double strikeY = textY + fontSize * 0.35;
                double strikeW = TextWidth(lineText, fontSize, false);
                c.Append("q\n0.850 0.220 0.220 RG 0.5 w\n")
                 .Append(N(textX)).Append(' ').Append(N(strikeY)).Append(" m ")
                 .Append(N(textX + strikeW)).Append(' ').Append(N(strikeY)).Append(" l S\nQ\n");
            }
            c.Append("Q\n");

            if (options.DrawMarginChangeBars)
            {
                c.Append("q\n0.850 0.150 0.150 RG 2.5 w\n")
                 .Append(N(leftBarX)).Append(' ').Append(N(y)).Append(" m ")
                 .Append(N(leftBarX)).Append(' ').Append(N(y + pillH)).Append(" l S\nQ\n");
            }
        }

        return AddPage(output, pagesRoot, shared, xObjects, c, sheetW, sheetH);
    }
}
