namespace Docuzen.Pdf.Core;

// DROP-IN REPLACEMENT for the original DiffEngine file. DiffKind / DiffOp / DiffResult / DiffEngine.Diff(a, b, maxCost, ct)
// keep their names and shapes, so existing callers compile unchanged.

public static partial class PdfComparer
{
    internal enum DiffKind : byte { Equal = 0, Delete = 1, Insert = 2 }

    /// <summary>One edit operation. For Equal both indices are set; Delete has BIndex = -1; Insert has AIndex = -1.</summary>
    internal readonly record struct DiffOp(DiffKind Kind, int AIndex, int BIndex);

    internal sealed class DiffEngineOptions
    {
        /// <summary>Upper bound on the Myers edit distance explored per bisection before the heuristic split kicks in.</summary>
        public int MaxCost { get; init; } = 4000;
        public bool UsePhraseAnchors { get; init; } = true;
        public bool UseTokenAnchors { get; init; } = true;
        /// <summary>k-gram length used to seed phrase anchors (seeds are extended to maximal runs).</summary>
        public int PhraseLength { get; init; } = 3;
    }

    internal sealed class DiffResult
    {
        public List<DiffOp> Ops { get; } = new();
        /// <summary>
        /// Regions where the cost cap was hit. v2 reported these as full replacements; v3 splits at the
        /// furthest-reaching point and keeps diffing, so the result is still a fine-grained (if not minimal) script.
        /// </summary>
        public int CappedRegions { get; set; }
        public int PhraseAnchorRuns { get; set; }
        public int TokenAnchors { get; set; }
        public int Bisections { get; set; }
    }

    /// <summary>
    /// Token-id diff engine v3 (tokens are pre-interned ints, so comparison is O(1)).
    /// Pipeline per region:
    ///   1. Trim common prefix and suffix
    ///   2. Maximal unique phrase anchors: k-grams unique on both sides, verified, extended to maximal runs,
    ///      then reduced by the HEAVIEST non-overlapping increasing chain (weight = run length, O(R log R))
    ///   3. Unique-token patience anchors (LIS)
    ///   4. Linear-space Myers bisection: O(N+M) memory, no trace snapshots. On hitting the cost cap the region
    ///      is split at the furthest-reaching point of either search front instead of being given up.
    /// Finally every change block is normalised to "all deletions, then all insertions".
    /// </summary>
    internal static class DiffEngine
    {
        private readonly record struct Work(byte Type, int ALo, int AHi, int BLo, int BHi);
        private const byte WRegion = 0;   // full pipeline
        private const byte WLeaf = 1;     // produced by a bisection: Myers only (keeps the leaf minimal)
        private const byte WEqualRun = 2; // ALo = aStart, BLo = bStart, AHi = count

        public static DiffResult Diff(int[] a, int[] b, int maxCost, CancellationToken ct = default)
            => Diff(a, b, new DiffEngineOptions { MaxCost = maxCost }, ct);

        public static DiffResult Diff(int[] a, int[] b, DiffEngineOptions o, CancellationToken ct = default)
        {
            ArgumentNullException.ThrowIfNull(a);
            ArgumentNullException.ThrowIfNull(b);
            ArgumentNullException.ThrowIfNull(o);

            int maxCost = Math.Max(2, o.MaxCost);
            int phraseLen = Math.Max(2, o.PhraseLength);
            var res = new DiffResult();
            var ops = res.Ops;
            var stack = new Stack<Work>();
            var scratch = new BisectScratch();
            stack.Push(new Work(WRegion, 0, a.Length, 0, b.Length));

            while (stack.Count > 0)
            {
                ct.ThrowIfCancellationRequested();
                var w = stack.Pop();

                if (w.Type == WEqualRun)
                {
                    for (int i = 0; i < w.AHi; i++)
                        ops.Add(new DiffOp(DiffKind.Equal, w.ALo + i, w.BLo + i));
                    continue;
                }

                int alo = w.ALo, ahi = w.AHi, blo = w.BLo, bhi = w.BHi;

                // 1. Trim common prefix / suffix
                while (alo < ahi && blo < bhi && a[alo] == b[blo])
                {
                    ops.Add(new DiffOp(DiffKind.Equal, alo, blo));
                    alo++; blo++;
                }
                int suffix = 0;
                while (ahi > alo && bhi > blo && a[ahi - 1] == b[bhi - 1]) { ahi--; bhi--; suffix++; }
                if (suffix > 0) stack.Push(new Work(WEqualRun, ahi, suffix, bhi, 0));

                if (alo == ahi)
                {
                    for (int j = blo; j < bhi; j++) ops.Add(new DiffOp(DiffKind.Insert, -1, j));
                    continue;
                }
                if (blo == bhi)
                {
                    for (int i = alo; i < ahi; i++) ops.Add(new DiffOp(DiffKind.Delete, i, -1));
                    continue;
                }

                if (w.Type == WRegion)
                {
                    // 2. Maximal unique phrase anchors
                    if (o.UsePhraseAnchors && ahi - alo >= 12 && bhi - blo >= 12)
                    {
                        var runs = FindPhraseAnchors(a, alo, ahi, b, blo, bhi, phraseLen);
                        if (runs.Count > 0)
                        {
                            res.PhraseAnchorRuns += runs.Count;
                            PushAnchors(stack, runs, alo, ahi, blo, bhi);
                            continue;
                        }
                    }

                    // 3. Unique-token patience anchors
                    if (o.UseTokenAnchors)
                    {
                        var anchors = FindTokenAnchors(a, alo, ahi, b, blo, bhi);
                        if (anchors.Count > 0)
                        {
                            res.TokenAnchors += anchors.Count;
                            PushAnchors(stack, anchors, alo, ahi, blo, bhi);
                            continue;
                        }
                    }
                }

                // 4. Linear-space Myers bisection
                res.Bisections++;
                var sp = Bisect(a, alo, ahi, b, blo, bhi, maxCost, scratch, ct);
                if (sp.Status >= 2)
                {
                    // 2 = proven: the two sides share nothing. 3 = cap hit and no usable split point.
                    if (sp.Status == 3) res.CappedRegions++;
                    for (int i = alo; i < ahi; i++) ops.Add(new DiffOp(DiffKind.Delete, i, -1));
                    for (int j = blo; j < bhi; j++) ops.Add(new DiffOp(DiffKind.Insert, -1, j));
                    continue;
                }
                if (sp.Status == 1) res.CappedRegions++;
                stack.Push(new Work(WLeaf, alo + sp.X, ahi, blo + sp.Y, bhi));
                stack.Push(new Work(WLeaf, alo, alo + sp.X, blo, blo + sp.Y));
            }

            NormalizeBlocks(ops);
            return res;
        }

        private static void PushAnchors(Stack<Work> stack, List<(int A, int B, int Length)> anchors, int alo, int ahi, int blo, int bhi)
        {
            int pa = ahi, pb = bhi;
            for (int k = anchors.Count - 1; k >= 0; k--)
            {
                var (ai, bi, len) = anchors[k];
                stack.Push(new Work(WRegion, ai + len, pa, bi + len, pb));
                stack.Push(new Work(WEqualRun, ai, len, bi, 0));
                pa = ai; pb = bi;
            }
            stack.Push(new Work(WRegion, alo, pa, blo, pb));
        }

        /// <summary>Within every change block put all deletions before all insertions (stable).</summary>
        internal static void NormalizeBlocks(List<DiffOp> ops)
        {
            int n = ops.Count, i = 0;
            List<DiffOp>? dels = null, ins = null;
            while (i < n)
            {
                if (ops[i].Kind == DiffKind.Equal) { i++; continue; }
                int j = i;
                bool sawInsert = false, need = false;
                while (j < n && ops[j].Kind != DiffKind.Equal)
                {
                    if (ops[j].Kind == DiffKind.Insert) sawInsert = true; else if (sawInsert) need = true;
                    j++;
                }
                if (need)
                {
                    (dels ??= new List<DiffOp>()).Clear();
                    (ins ??= new List<DiffOp>()).Clear();
                    for (int k = i; k < j; k++) (ops[k].Kind == DiffKind.Delete ? dels : ins).Add(ops[k]);
                    int p = i;
                    foreach (var op in dels) ops[p++] = op;
                    foreach (var op in ins) ops[p++] = op;
                }
                i = j;
            }
        }

        /// <summary>64-bit FNV-1a over k token ids. Collisions are harmless: every hit is verified token by token.</summary>
        internal static ulong GramHash(int[] t, int i, int k)
        {
            const ulong prime = 1099511628211UL;
            ulong h = 1469598103934665603UL;
            for (int n = 0; n < k; n++) h = (h ^ (uint)t[i + n]) * prime;
            return h;
        }

        private static int LowerBound(int[] arr, int v)
        {
            int lo = 0, hi = arr.Length;
            while (lo < hi) { int mid = (lo + hi) >> 1; if (arr[mid] < v) lo = mid + 1; else hi = mid; }
            return lo;
        }

        private static int UpperBound(int[] arr, int v)
        {
            int lo = 0, hi = arr.Length;
            while (lo < hi) { int mid = (lo + hi) >> 1; if (arr[mid] <= v) lo = mid + 1; else hi = mid; }
            return lo;
        }

        /// <summary>
        /// Heaviest chain of non-overlapping, order-preserving runs. Run i covers A[aS, aS+len) and B[bS, bS+len)
        /// with weight w. O(R log R) via a prefix-max Fenwick tree keyed by B-end rank.
        /// Returns the indices of the chosen runs in ascending order. Also used for page alignment.
        /// </summary>
        internal static List<int> HeaviestChain(IReadOnlyList<int> aS, IReadOnlyList<int> bS, IReadOnlyList<int> len, IReadOnlyList<double> w)
        {
            int r = aS.Count;
            var result = new List<int>();
            if (r == 0) return result;
            if (r == 1) { result.Add(0); return result; }

            var byStart = new int[r];
            var byEnd = new int[r];
            var bEnds = new int[r];
            for (int i = 0; i < r; i++) { byStart[i] = i; byEnd[i] = i; bEnds[i] = bS[i] + len[i]; }
            Array.Sort(byStart, (p, q) => { int c = aS[p].CompareTo(aS[q]); return c != 0 ? c : bS[p].CompareTo(bS[q]); });
            Array.Sort(byEnd, (p, q) => (aS[p] + len[p]).CompareTo(aS[q] + len[q]));
            Array.Sort(bEnds);

            var fenW = new double[r + 1];
            var fenI = new int[r + 1];
            Array.Fill(fenI, -1);
            var score = new double[r];
            var prev = new int[r];
            Array.Fill(prev, -1);

            int e = 0, best = -1;
            double bestScore = -1;
            for (int s = 0; s < r; s++)
            {
                int i = byStart[s];
                while (e < r && aS[byEnd[e]] + len[byEnd[e]] <= aS[i])
                {
                    int j = byEnd[e++];
                    for (int p = LowerBound(bEnds, bS[j] + len[j]) + 1; p <= r; p += p & -p)
                        if (score[j] > fenW[p]) { fenW[p] = score[j]; fenI[p] = j; }
                }
                double bw = 0;
                int bj = -1;
                for (int p = UpperBound(bEnds, bS[i]); p > 0; p -= p & -p)
                    if (fenW[p] > bw) { bw = fenW[p]; bj = fenI[p]; }
                score[i] = w[i] + bw;
                prev[i] = bj;
                if (score[i] > bestScore) { bestScore = score[i]; best = i; }
            }

            for (int x = best; x >= 0; x = prev[x]) result.Add(x);
            result.Reverse();
            return result;
        }

        /// <summary>
        /// k-grams occurring exactly once in each region are verified, extended in both directions to maximal
        /// matching runs, de-duplicated, and reduced to the heaviest non-overlapping increasing chain.
        /// </summary>
        private static List<(int A, int B, int Length)> FindPhraseAnchors(int[] a, int alo, int ahi, int[] b, int blo, int bhi, int k)
        {
            var result = new List<(int A, int B, int Length)>();

            var mapA = new Dictionary<ulong, int>(Math.Max(0, ahi - alo));
            for (int i = alo; i + k <= ahi; i++)
            {
                ulong h = GramHash(a, i, k);
                mapA[h] = mapA.ContainsKey(h) ? -1 : i;
            }
            var mapB = new Dictionary<ulong, int>(Math.Max(0, bhi - blo));
            for (int j = blo; j + k <= bhi; j++)
            {
                ulong h = GramHash(b, j, k);
                mapB[h] = mapB.ContainsKey(h) ? -1 : j;
            }

            var aS = new List<int>();
            var bS = new List<int>();
            var len = new List<int>();
            var weight = new List<double>();
            var seen = new HashSet<long>();
            long span = (long)bhi + 1;

            foreach (var kv in mapA)
            {
                int ia = kv.Value;
                if (ia < 0 || !mapB.TryGetValue(kv.Key, out int ib) || ib < 0) continue;

                bool same = true;
                for (int n = 0; n < k; n++)
                    if (a[ia + n] != b[ib + n]) { same = false; break; }
                if (!same) continue;

                int s = 0;
                while (ia - s > alo && ib - s > blo && a[ia - s - 1] == b[ib - s - 1]) s++;
                int e = k;
                while (ia + e < ahi && ib + e < bhi && a[ia + e] == b[ib + e]) e++;

                if (!seen.Add((ia - s) * span + (ib - s))) continue;
                aS.Add(ia - s); bS.Add(ib - s); len.Add(s + e); weight.Add(s + e);
            }

            if (aS.Count == 0) return result;
            foreach (int i in HeaviestChain(aS, bS, len, weight)) result.Add((aS[i], bS[i], len[i]));
            return result;
        }

        /// <summary>Patience anchors: tokens occurring exactly once on each side, reduced to the longest increasing subsequence.</summary>
        private static List<(int A, int B, int Length)> FindTokenAnchors(int[] a, int alo, int ahi, int[] b, int blo, int bhi)
        {
            var result = new List<(int A, int B, int Length)>();
            var countA = new Dictionary<int, int>();
            var posB = new Dictionary<int, int>();
            for (int i = alo; i < ahi; i++)
                countA[a[i]] = countA.TryGetValue(a[i], out var ca) ? ca + 1 : 1;
            for (int j = blo; j < bhi; j++)
                posB[b[j]] = posB.ContainsKey(b[j]) ? -1 : j;

            var pairs = new List<(int A, int B)>();
            for (int i = alo; i < ahi; i++)
            {
                if (countA[a[i]] == 1 && posB.TryGetValue(a[i], out int j) && j >= 0)
                    pairs.Add((i, j));
            }
            if (pairs.Count == 0) return result;

            // LIS on B positions (pairs already ascending in A).
            var tails = new List<int>(pairs.Count);
            var prev = new int[pairs.Count];
            for (int i = 0; i < pairs.Count; i++)
            {
                int lo = 0, hi = tails.Count, bi = pairs[i].B;
                while (lo < hi)
                {
                    int mid = (lo + hi) >> 1;
                    if (pairs[tails[mid]].B < bi) lo = mid + 1; else hi = mid;
                }
                prev[i] = lo > 0 ? tails[lo - 1] : -1;
                if (lo == tails.Count) tails.Add(i); else tails[lo] = i;
            }

            for (int k = tails[^1]; k >= 0; k = prev[k]) result.Add((pairs[k].A, pairs[k].B, 1));
            result.Reverse();
            return result;
        }

        private sealed class BisectScratch
        {
            public int[] V1 = Array.Empty<int>();
            public int[] V2 = Array.Empty<int>();

            public void Ensure(int length)
            {
                if (V1.Length < length)
                {
                    int cap = Math.Max(length, V1.Length * 2);
                    V1 = new int[cap];
                    V2 = new int[cap];
                }
                Array.Fill(V1, -1, 0, length);
                Array.Fill(V2, -1, 0, length);
            }
        }

        /// <summary>Status: 0 = exact midpoint, 1 = cost cap hit (heuristic split), 2 = nothing in common, 3 = cap hit, no usable split.</summary>
        private readonly record struct Split(int X, int Y, byte Status);

        /// <summary>
        /// Myers bidirectional bisection in linear space. The caller guarantees the first and last tokens differ
        /// (prefix/suffix trimmed) and both sides are non-empty, which guarantees a proper split point.
        /// </summary>
        private static Split Bisect(int[] a, int alo, int ahi, int[] b, int blo, int bhi, int maxCost,
            BisectScratch scratch, CancellationToken ct)
        {
            int n = ahi - alo, m = bhi - blo;
            int full = (int)(((long)n + m + 1) >> 1);
            int maxD = Math.Min(full, maxCost);
            int vOff = maxD, vLen = 2 * maxD + 2;
            scratch.Ensure(vLen);
            int[] v1 = scratch.V1, v2 = scratch.V2;
            v1[vOff + 1] = 0;
            v2[vOff + 1] = 0;
            int delta = n - m;
            // Odd delta: the forward front can only meet the reverse front on a forward step.
            bool front = (delta & 1) != 0;
            // Offsets that skip diagonals which have run off the grid.
            int k1s = 0, k1e = 0, k2s = 0, k2e = 0;

            for (int d = 0; d < maxD; d++)
            {
                if ((d & 63) == 0) ct.ThrowIfCancellationRequested();

                // Forward front, one step.
                for (int k1 = -d + k1s; k1 <= d - k1e; k1 += 2)
                {
                    int o = vOff + k1;
                    int x1 = (k1 == -d || (k1 != d && v1[o - 1] < v1[o + 1])) ? v1[o + 1] : v1[o - 1] + 1;
                    int y1 = x1 - k1;
                    while (x1 < n && y1 < m && a[alo + x1] == b[blo + y1]) { x1++; y1++; }
                    v1[o] = x1;
                    if (x1 > n) k1e += 2;
                    else if (y1 > m) k1s += 2;
                    else if (front)
                    {
                        int o2 = vOff + delta - k1;
                        if (o2 >= 0 && o2 < vLen && v2[o2] != -1 && x1 >= n - v2[o2])
                            return new Split(x1, y1, 0);
                    }
                }

                // Reverse front, one step (coordinates mirrored: x2/y2 count from the end).
                for (int k2 = -d + k2s; k2 <= d - k2e; k2 += 2)
                {
                    int o = vOff + k2;
                    int x2 = (k2 == -d || (k2 != d && v2[o - 1] < v2[o + 1])) ? v2[o + 1] : v2[o - 1] + 1;
                    int y2 = x2 - k2;
                    while (x2 < n && y2 < m && a[ahi - x2 - 1] == b[bhi - y2 - 1]) { x2++; y2++; }
                    v2[o] = x2;
                    if (x2 > n) k2e += 2;
                    else if (y2 > m) k2s += 2;
                    else if (!front)
                    {
                        int o1 = vOff + delta - k2;
                        if (o1 >= 0 && o1 < vLen && v1[o1] != -1)
                        {
                            int x1 = v1[o1];
                            int y1 = vOff + x1 - o1;
                            if (x1 >= n - x2) return new Split(x1, y1, 0);
                        }
                    }
                }
            }

            if (maxD >= full) return new Split(0, 0, 2);

            // Cost cap reached: split at the furthest-reaching point of either front. Any split yields a valid
            // edit script; this one keeps everything the search has already matched.
            int fb = -1, fx = 0, fy = 0, bb = -1, bx = 0, by = 0;
            for (int k = -(maxD - 1); k <= maxD - 1; k++)
            {
                int x = v1[vOff + k];
                if (x >= 0)
                {
                    int y = x - k;
                    if (x <= n && y >= 0 && y <= m && x + y > fb) { fb = x + y; fx = x; fy = y; }
                }
                int r = v2[vOff + k];
                if (r >= 0)
                {
                    int y = r - k;
                    if (r <= n && y >= 0 && y <= m && r + y > bb) { bb = r + y; bx = r; by = y; }
                }
            }
            long total = (long)n + m;
            if (bb > fb && bb > 0 && bb < total) return new Split(n - bx, m - by, 1);
            if (fb > 0 && fb < total) return new Split(fx, fy, 1);
            return new Split(0, 0, 3);
        }
    }
}
