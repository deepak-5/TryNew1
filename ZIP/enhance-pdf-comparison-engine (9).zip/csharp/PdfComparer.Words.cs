using System.Globalization;
using System.Text;
using Docuzen.Pdf.Export;

namespace Docuzen.Pdf.Core;

// REPLACEMENT for the original word-model / extraction / alignment file.
// Unchanged from v2: ExtractDocument flow, StripHeadersAndFooters, MaskDigits, SplitColumns, line clustering,
// ClusterWordsIntoBoxes. Changed: punctuation-aware tokenisation, vocabulary-aware dehyphenation, AlignWords
// (v3 engine + refinement + moves), BuildSemanticChanges (classification, move changes), formatting detection.

public static partial class PdfComparer
{
    // ── Word model ───────────────────────────────────────────────────────────

    internal sealed class ComparisonWord
    {
        public required string Text { get; set; }
        public required PdfRect Box { get; init; }
        public required (double X, double Y) Origin { get; init; }
        public required double FontSize { get; init; }
        public required int PageIndex { get; init; }
        public int LineIndex { get; set; }
        /// <summary>Additional bounding boxes when a hyphenated word across lines is dehyphenated.</summary>
        public List<PdfRect>? AdditionalBoxes { get; init; }
        /// <summary>True when this token attaches to the previous one without a space (split-off punctuation).</summary>
        public bool GlueLeft { get; init; }
        /// <summary>For a word re-joined across a line break: the variant that keeps the hyphen ("well-known").</summary>
        public string? HyphenatedAlt { get; init; }
        public bool IsPunctuation => Text.Length > 0 && Text.All(char.IsPunctuation);
    }

    internal sealed record WordDiffItem(DiffKind Kind, ComparisonWord? BeforeWord, ComparisonWord? AfterWord)
    {
        /// <summary>Id of the move this deleted/inserted word belongs to, or -1.</summary>
        public int MoveId { get; init; } = -1;
    }

    internal sealed class SemanticDiffChange
    {
        public List<ComparisonWord> DeletedWords { get; } = new();
        public List<ComparisonWord> AddedWords { get; } = new();
        public ComparisonWord? PrecedingEqualAfter { get; set; }
        public ComparisonWord? SubsequentEqualAfter { get; set; }
        public PdfChangeType Type { get; set; } = PdfChangeType.Replaced;
        public PdfChangeRisk Risk { get; set; } = PdfChangeRisk.Medium;
        /// <summary>For Type == Moved: DeletedWords is the source block, AddedWords the destination block.</summary>
        public int MoveId { get; set; } = -1;
        public string Note { get; set; } = string.Empty;
    }

    // ── Extraction ───────────────────────────────────────────────────────────

    private sealed class DocExtraction
    {
        public required List<ComparisonWord>[] Pages { get; init; }
        /// <summary>Word counts before header/footer stripping (used to detect text-less pages).</summary>
        public required int[] RawCounts { get; init; }
    }

    private static DocExtraction ExtractDocument(PdfDocument doc, PdfComparisonOptions o, CancellationToken ct)
    {
        int n = doc.Pages.Count;
        var pages = new List<ComparisonWord>[n];
        // Splitting punctuation is pointless (and noisy) when the match rule ignores edge punctuation anyway.
        bool split = o.SplitPunctuation && (EffectiveMatchFlags(o) & PdfMatchFlags.IgnoreEdgePunctuation) == 0;

        void Work(int i)
        {
            ct.ThrowIfCancellationRequested();
            pages[i] = ExtractWordsFromPage(doc, i, split);
        }

        if (o.MaxDegreeOfParallelism > 1 && n > 1)
            Parallel.For(0, n, new ParallelOptions { MaxDegreeOfParallelism = o.MaxDegreeOfParallelism, CancellationToken = ct }, Work);
        else
            for (int i = 0; i < n; i++) Work(i);

        var raw = pages.Select(p => p.Count).ToArray();
        if (o.IgnoreHeadersAndFooters)
            StripHeadersAndFooters(doc, pages, o);

        return new DocExtraction { Pages = pages, RawCounts = raw };
    }

    private static void StripHeadersAndFooters(PdfDocument doc, List<ComparisonWord>[] pages, PdfComparisonOptions o)
    {
        int n = pages.Length;
        double band = Math.Clamp(o.HeaderFooterBandFraction, 0.0, 0.25);
        if (n < 3 || band <= 0) return;

        int minPages = Math.Max(3, (int)Math.Ceiling(n * o.HeaderFooterMinPageFraction));
        var pageLineKeys = new Dictionary<(int LineIndex, bool Top), string>[n];
        var keyPages = new Dictionary<string, HashSet<int>>(StringComparer.Ordinal);

        for (int i = 0; i < n; i++)
        {
            var g = PdfImposition.GetPageGeometry(doc, doc.Pages.Pages[i]);
            double y0 = g.Box[1], h = g.Box[3] - g.Box[1];
            var map = new Dictionary<(int, bool), string>();
            pageLineKeys[i] = map;
            if (h <= 0) continue;

            var lines = new Dictionary<(int, bool), List<ComparisonWord>>();
            foreach (var w in pages[i])
            {
                double rel = (w.Box.Y0 - y0) / h;
                bool top = rel >= 1.0 - band;
                bool bottom = rel <= band;
                if (!top && !bottom) continue;
                var key = (w.LineIndex, top);
                if (!lines.TryGetValue(key, out var list)) lines[key] = list = new List<ComparisonWord>();
                list.Add(w);
            }

            foreach (var (lk, words) in lines)
            {
                var text = (lk.Item2 ? "T|" : "B|") + MaskDigits(string.Join(' ', words.OrderBy(w => w.Box.X0).Select(w => w.Text.ToLowerInvariant())));
                map[lk] = text;
                if (!keyPages.TryGetValue(text, out var set)) keyPages[text] = set = new HashSet<int>();
                set.Add(i);
            }
        }

        var strip = new HashSet<string>(keyPages.Where(kv => kv.Value.Count >= minPages).Select(kv => kv.Key), StringComparer.Ordinal);
        if (strip.Count == 0) return;

        for (int i = 0; i < n; i++)
        {
            var map = pageLineKeys[i];
            pages[i] = pages[i].Where(w =>
            {
                if (map.TryGetValue((w.LineIndex, true), out var kt) && strip.Contains(kt)) return false;
                if (map.TryGetValue((w.LineIndex, false), out var kb) && strip.Contains(kb)) return false;
                return true;
            }).ToList();
        }
    }

    private static string MaskDigits(string s)
    {
        var sb = new StringBuilder(s.Length);
        bool inDigits = false;
        foreach (var c in s)
        {
            if (char.IsDigit(c)) { if (!inDigits) sb.Append('#'); inDigits = true; }
            else { sb.Append(c); inDigits = false; }
        }
        return sb.ToString();
    }

    private static List<ComparisonWord> ExtractWordsFromPage(PdfDocument doc, int pageIndex, bool splitPunctuation)
    {
        if (pageIndex < 0 || pageIndex >= doc.Pages.Count)
            return new List<ComparisonWord>();

        var chars = PdfToDocxCharExtractor.ExtractPage(doc, pageIndex);
        if (chars.Count == 0) return new List<ComparisonWord>();

        var seen = new HashSet<(string, long, long)>();
        var valid = new List<PdfToDocxChar>(chars.Count);
        foreach (var c in chars)
        {
            if (string.IsNullOrEmpty(c.Text) || char.IsControl(c.Text[0])) continue;
            if (!seen.Add((c.Text, (long)Math.Round(c.Box.X0 * 2.0), (long)Math.Round(c.Origin.Y * 2.0)))) continue;
            valid.Add(c);
        }
        if (valid.Count == 0) return new List<ComparisonWord>();

        var words = new List<ComparisonWord>();
        int lineIdx = 0;
        foreach (var column in SplitColumns(valid))
            lineIdx = AppendWords(column, pageIndex, lineIdx, words, splitPunctuation);
        return words;
    }

    private static List<List<PdfToDocxChar>> SplitColumns(List<PdfToDocxChar> chars)
    {
        var single = new List<List<PdfToDocxChar>> { chars };
        if (chars.Count < 80) return single;

        double minX = chars.Min(c => c.Box.X0);
        double maxX = chars.Max(c => c.Box.X1);
        double width = maxX - minX;
        if (width < 200) return single;

        double medFont = chars.Select(c => c.FontSize).OrderBy(f => f).ElementAt(chars.Count / 2);
        var iv = chars.Select(c => (S: c.Box.X0, E: c.Box.X1)).OrderBy(t => t.S).ToList();

        double curEnd = iv[0].E, bestGap = 0, bestMid = 0;
        for (int i = 1; i < iv.Count; i++)
        {
            if (iv[i].S > curEnd)
            {
                double gap = iv[i].S - curEnd;
                double mid = (iv[i].S + curEnd) / 2.0;
                double rel = (mid - minX) / width;
                if (rel >= 0.3 && rel <= 0.7 && gap > bestGap) { bestGap = gap; bestMid = mid; }
            }
            curEnd = Math.Max(curEnd, iv[i].E);
        }
        if (bestGap < Math.Max(12.0, medFont * 1.2)) return single;

        var left = chars.Where(c => (c.Box.X0 + c.Box.X1) / 2.0 < bestMid).ToList();
        var right = chars.Where(c => (c.Box.X0 + c.Box.X1) / 2.0 >= bestMid).ToList();
        if (left.Count < chars.Count * 0.15 || right.Count < chars.Count * 0.15) return single;
        return new List<List<PdfToDocxChar>> { left, right };
    }

    private static int AppendWords(List<PdfToDocxChar> region, int pageIndex, int lineIdx, List<ComparisonWord> words, bool splitPunctuation)
    {
        var sorted = region.OrderByDescending(c => c.Origin.Y).ThenBy(c => c.Box.X0).ToList();

        var lines = new List<List<PdfToDocxChar>>();
        var currentLine = new List<PdfToDocxChar>();
        double currentSumY = 0;

        // Baseline grouping using a true arithmetic running mean to prevent vertical drift
        foreach (var ch in sorted)
        {
            var y = ch.Origin.Y;
            double baseline = currentLine.Count == 0 ? y : (currentSumY / currentLine.Count);
            if (currentLine.Count == 0 || Math.Abs(y - baseline) <= Math.Max(2.5, ch.FontSize * 0.35))
            {
                currentLine.Add(ch);
                currentSumY += y;
            }
            else
            {
                lines.Add(currentLine);
                currentLine = new List<PdfToDocxChar> { ch };
                currentSumY = y;
            }
        }
        if (currentLine.Count > 0) lines.Add(currentLine);

        lines = lines.OrderByDescending(l => l.Average(c => c.Origin.Y)).ToList();

        var columnWords = new List<ComparisonWord>();
        foreach (var line in lines)
        {
            var ordered = line.OrderBy(c => c.Box.X0).ToList();
            var buf = new List<PdfToDocxChar>();

            foreach (var ch in ordered)
            {
                if (string.IsNullOrWhiteSpace(ch.Text))
                {
                    CreateWords(buf, pageIndex, lineIdx, splitPunctuation, columnWords);
                    buf.Clear();
                    continue;
                }

                if (buf.Count > 0)
                {
                    var prev = buf[^1];
                    double gap = ch.Box.X0 - prev.Box.X1;
                    if (gap > Math.Max(2.0, ch.FontSize * 0.28))
                    {
                        CreateWords(buf, pageIndex, lineIdx, splitPunctuation, columnWords);
                        buf.Clear();
                    }
                }
                buf.Add(ch);
            }
            CreateWords(buf, pageIndex, lineIdx, splitPunctuation, columnWords);
            lineIdx++;
        }

        // Dehyphenate across lines while preserving each physical bounding box
        DehyphenateWords(columnWords);
        words.AddRange(columnWords);

        return lineIdx;
    }

    private static bool IsPunctuationGlyph(PdfToDocxChar c) => c.Text.Length > 0 && c.Text.All(char.IsPunctuation);

    private static bool IsHyphenGlyph(PdfToDocxChar c) => c.Text is "-" or "\u2010" or "\u00AD";

    /// <summary>
    /// Turns one whitespace-delimited glyph run into tokens. With <paramref name="split"/>, leading and trailing
    /// punctuation glyphs become their own tokens (each with its own box) so a changed comma highlights only the
    /// comma. Runs containing a digit are never split ("(500)", "-3.5%", "1,000."), and a trailing hyphen stays
    /// attached so dehyphenation can still see it.
    /// </summary>
    private static void CreateWords(List<PdfToDocxChar> chars, int pageIndex, int lineIndex, bool split, List<ComparisonWord> into)
    {
        if (chars.Count == 0) return;
        int lead = 0, trail = chars.Count;
        if (split && !chars.Any(c => c.Text.Any(char.IsDigit)))
        {
            while (lead < chars.Count && IsPunctuationGlyph(chars[lead])) lead++;
            if (lead == chars.Count) lead = 0; // pure punctuation ("—", "..."): keep as one token
            else while (trail > lead + 1 && IsPunctuationGlyph(chars[trail - 1]) && !IsHyphenGlyph(chars[trail - 1])) trail--;
        }

        bool glue = false;
        for (int i = 0; i < lead; i++) Add(i, i + 1);
        Add(lead, trail);
        for (int i = trail; i < chars.Count; i++) Add(i, i + 1);

        void Add(int from, int to)
        {
            var w = CreateWord(chars.GetRange(from, to - from), pageIndex, lineIndex, glue);
            if (w is null) return;
            into.Add(w);
            glue = true;
        }
    }

    private static ComparisonWord? CreateWord(List<PdfToDocxChar> chars, int pageIndex, int lineIndex, bool glueLeft = false)
    {
        var text = string.Concat(chars.Select(c => c.Text)).Normalize(NormalizationForm.FormKC).Replace("\u00AD", "");
        if (text.Length == 0) return null;

        return new ComparisonWord
        {
            Text = text,
            Box = new PdfRect(chars.Min(c => c.Box.X0), chars.Min(c => c.Box.Y0),
                              chars.Max(c => c.Box.X1), chars.Max(c => c.Box.Y1)),
            Origin = chars[0].Origin,
            FontSize = chars.Average(c => c.FontSize),
            PageIndex = pageIndex,
            LineIndex = lineIndex,
            GlueLeft = glueLeft
        };
    }

    /// <summary>
    /// Combines hyphenated words across consecutive lines into one semantic token while preserving all original
    /// physical bounding boxes. The hyphen-keeping variant is remembered in HyphenatedAlt; ResolveHyphenation
    /// later decides which spelling is the real one.
    /// </summary>
    private static void DehyphenateWords(List<ComparisonWord> words)
    {
        if (words.Count < 2) return;
        for (int i = 0; i < words.Count - 1; i++)
        {
            var w1 = words[i];
            var w2 = words[i + 1];

            if (w1.LineIndex == w2.LineIndex) continue;
            if (w1.Text.Length < 3 || !(w1.Text.EndsWith('-') || w1.Text.EndsWith('\u2010'))) continue;
            if (w2.Text.Length == 0 || !char.IsLower(w2.Text[0])) continue;

            double lineGap = Math.Abs(w1.Origin.Y - w2.Origin.Y);
            if (lineGap > Math.Max(24.0, w1.FontSize * 3.0)) continue;

            var extraBoxes = new List<PdfRect>();
            if (w1.AdditionalBoxes is not null) extraBoxes.AddRange(w1.AdditionalBoxes);
            extraBoxes.Add(w2.Box);
            if (w2.AdditionalBoxes is not null) extraBoxes.AddRange(w2.AdditionalBoxes);

            words[i] = new ComparisonWord
            {
                Text = w1.Text[..^1] + w2.Text,
                HyphenatedAlt = (w1.HyphenatedAlt ?? w1.Text)[..^1] + "-" + w2.Text,
                Box = w1.Box,
                AdditionalBoxes = extraBoxes,
                Origin = w1.Origin,
                FontSize = (w1.FontSize + w2.FontSize) / 2.0,
                PageIndex = w1.PageIndex,
                LineIndex = w1.LineIndex,
                GlueLeft = w1.GlueLeft
            };
            words.RemoveAt(i + 1);
            i--;
        }
    }

    /// <summary>
    /// v2 always fused "well-⏎known" into "wellknown", which then mismatched "well-known" set on one line in the
    /// other document. Here the shared vocabulary of BOTH documents decides: if the hyphenated compound exists
    /// as a normal word somewhere and the fused form does not, the hyphen is kept.
    /// </summary>
    private static void ResolveHyphenation(DocExtraction before, DocExtraction after)
    {
        var vocab = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        bool any = false;
        foreach (var doc in new[] { before, after })
            foreach (var page in doc.Pages)
                foreach (var w in page)
                {
                    if (w.HyphenatedAlt is null) vocab.Add(w.Text); else any = true;
                }
        if (!any) return;

        foreach (var doc in new[] { before, after })
            foreach (var page in doc.Pages)
                foreach (var w in page)
                {
                    if (w.HyphenatedAlt is { } alt && vocab.Contains(alt) && !vocab.Contains(w.Text))
                        w.Text = alt;
                }
    }

    private static string JoinWords(IEnumerable<ComparisonWord> words)
    {
        var sb = new StringBuilder();
        foreach (var w in words)
        {
            if (sb.Length > 0 && !w.GlueLeft) sb.Append(' ');
            sb.Append(w.Text);
        }
        return sb.ToString();
    }

    // ── Natural boundaries ───────────────────────────────────────────────────

    private static bool IsCloserChar(char c) => c is '"' or '\'' or ')' or ']' or '\u201D' or '\u2019';

    private static bool EndsSentence(List<ComparisonWord> words, int i)
    {
        while (i > 0 && words[i].GlueLeft && words[i].Text.All(IsCloserChar)) i--;
        var s = words[i].Text;
        int e = s.Length - 1;
        while (e >= 0 && IsCloserChar(s[e])) e--;
        return e >= 0 && (s[e] == '.' || s[e] == '!' || s[e] == '?');
    }

    /// <summary>brk[i] = how natural a change boundary is BEFORE word i (page start > paragraph > sentence > clause > line).</summary>
    private static byte[] BreakScores(List<ComparisonWord> words)
    {
        int n = words.Count;
        var brk = new byte[n + 1];
        brk[0] = 6;
        brk[n] = 6;
        for (int i = 1; i < n; i++)
        {
            var p = words[i - 1];
            var t = words[i];
            int s = 0;
            if (t.GlueLeft) s = 0;
            else if (t.PageIndex != p.PageIndex) s = 6;
            else if (t.LineIndex != p.LineIndex && p.Origin.Y - t.Origin.Y > 1.7 * Math.Max(p.FontSize, t.FontSize)) s = 5;
            else
            {
                if (EndsSentence(words, i - 1)) s = 3;
                else if (p.Text.Length > 0 && p.Text[^1] is ',' or ';' or ':') s = 1;
                if (t.LineIndex != p.LineIndex) s += 1;
            }
            brk[i] = (byte)s;
        }
        return brk;
    }

    private static readonly HashSet<string> LowInfoWords = new(StringComparer.OrdinalIgnoreCase)
    {
        "that", "this", "with", "from", "which", "have", "been", "were", "their", "such", "into", "than"
    };

    private static bool IsLowInformation(ComparisonWord w) => w.IsPunctuation || w.Text.Length <= 3 || LowInfoWords.Contains(w.Text);

    // ── Alignment ────────────────────────────────────────────────────────────

    private static List<WordDiffItem> AlignWords(DocExtraction before, DocExtraction after,
        PdfComparisonOptions o, List<string> warnings, CancellationToken ct)
    {
        var flags = EffectiveMatchFlags(o);
        var intern = new Dictionary<string, int>(StringComparer.Ordinal);
        int Id(ComparisonWord w)
        {
            var key = MatchKey(w.Text, flags);
            if (!intern.TryGetValue(key, out var id)) intern[key] = id = intern.Count;
            return id;
        }

        var groupIntern = new Dictionary<string, int>(StringComparer.Ordinal);
        var engineOptions = new DiffEngineOptions
        {
            MaxCost = o.MaxDiffCost,
            UsePhraseAnchors = o.UsePhraseAnchors,
            UseTokenAnchors = o.UseTokenAnchors
        };
        var items = new List<WordDiffItem>();
        int capped = 0, moveBase = 0;

        void Run(List<ComparisonWord> a, List<ComparisonWord> b)
        {
            var ia = a.Select(Id).ToArray();
            var ib = b.Select(Id).ToArray();
            List<DiffOp> ops;

            if (o.Granularity == PdfDiffGranularity.Sentence)
            {
                var (sentenceOps, sentenceCapped) = SentenceDiff(a, ia, b, ib, groupIntern, engineOptions, ct);
                ops = sentenceOps;
                capped += sentenceCapped;
            }
            else
            {
                var res = DiffEngine.Diff(ia, ib, engineOptions, ct);
                capped += res.CappedRegions;
                ops = res.Ops;
                if (o.ShiftChangeBoundaries)
                    DiffRefine.ShiftBoundaries(ops, ia, ib, BreakScores(a), BreakScores(b));
                if (o.SemanticCleanup != PdfSemanticCleanup.Off)
                    ops = DiffRefine.SemanticCleanup(ops, (int)o.SemanticCleanup, i => IsLowInformation(a[i]), out _);
            }

            MoveResult? mv = o.DetectMoves ? DiffRefine.DetectMoves(ops, ia, ib, o.MinMoveWords) : null;
            foreach (var op in ops)
            {
                switch (op.Kind)
                {
                    case DiffKind.Equal:
                        items.Add(new WordDiffItem(DiffKind.Equal, a[op.AIndex], b[op.BIndex]));
                        break;
                    case DiffKind.Delete:
                    {
                        int id = mv?.MoveOfA[op.AIndex] ?? -1;
                        items.Add(new WordDiffItem(DiffKind.Delete, a[op.AIndex], null) { MoveId = id < 0 ? -1 : moveBase + id });
                        break;
                    }
                    default:
                    {
                        int id = mv?.MoveOfB[op.BIndex] ?? -1;
                        items.Add(new WordDiffItem(DiffKind.Insert, null, b[op.BIndex]) { MoveId = id < 0 ? -1 : moveBase + id });
                        break;
                    }
                }
            }
            if (mv is not null) moveBase += mv.Moves.Count;
        }

        if (o.AlignAcrossPages)
        {
            var a = new List<ComparisonWord>();
            var b = new List<ComparisonWord>();
            foreach (var page in before.Pages) a.AddRange(page);
            foreach (var page in after.Pages) b.AddRange(page);
            Run(a, b);
        }
        else
        {
            int pages = Math.Max(before.Pages.Length, after.Pages.Length);
            for (int i = 0; i < pages; i++)
            {
                Run(i < before.Pages.Length ? before.Pages[i] : new List<ComparisonWord>(),
                    i < after.Pages.Length ? after.Pages[i] : new List<ComparisonWord>());
            }
        }

        if (capped > 0)
            warnings.Add($"{capped} region(s) exceeded MaxDiffCost={o.MaxDiffCost}; they were split heuristically, so the diff there is valid but may not be minimal. Raise MaxDiffCost for an exact result.");
        return items;
    }

    private static List<int> SentenceStarts(List<ComparisonWord> words)
    {
        var starts = new List<int>();
        for (int i = 0; i < words.Count; i++)
        {
            if (i == 0 || words[i].PageIndex != words[i - 1].PageIndex || (!words[i].GlueLeft && EndsSentence(words, i - 1)))
                starts.Add(i);
        }
        return starts;
    }

    /// <summary>Sentence granularity: diff sentence ids, then expand back to per-word operations.</summary>
    private static (List<DiffOp> Ops, int Capped) SentenceDiff(List<ComparisonWord> a, int[] ia, List<ComparisonWord> b, int[] ib,
        Dictionary<string, int> groupIntern, DiffEngineOptions engineOptions, CancellationToken ct)
    {
        var ga = SentenceStarts(a);
        var gb = SentenceStarts(b);

        int[] Composite(int[] ids, List<int> starts)
        {
            var comp = new int[starts.Count];
            for (int k = 0; k < starts.Count; k++)
            {
                int s = starts[k], e = k + 1 < starts.Count ? starts[k + 1] : ids.Length;
                var key = string.Join(',', new ArraySegment<int>(ids, s, e - s));
                if (!groupIntern.TryGetValue(key, out var id)) groupIntern[key] = id = groupIntern.Count;
                comp[k] = id;
            }
            return comp;
        }

        var res = DiffEngine.Diff(Composite(ia, ga), Composite(ib, gb), engineOptions, ct);
        var ops = new List<DiffOp>(a.Count + b.Count);
        int EndA(int k) => k + 1 < ga.Count ? ga[k + 1] : a.Count;
        int EndB(int k) => k + 1 < gb.Count ? gb[k + 1] : b.Count;

        foreach (var op in res.Ops)
        {
            if (op.Kind == DiffKind.Equal)
            {
                int n = EndA(op.AIndex) - ga[op.AIndex];
                for (int k = 0; k < n; k++) ops.Add(new DiffOp(DiffKind.Equal, ga[op.AIndex] + k, gb[op.BIndex] + k));
            }
            else if (op.Kind == DiffKind.Delete)
            {
                for (int q = ga[op.AIndex]; q < EndA(op.AIndex); q++) ops.Add(new DiffOp(DiffKind.Delete, q, -1));
            }
            else
            {
                for (int q = gb[op.BIndex]; q < EndB(op.BIndex); q++) ops.Add(new DiffOp(DiffKind.Insert, -1, q));
            }
        }
        return (ops, res.CappedRegions);
    }

    // ── Changes: grouping + classification ───────────────────────────────────

    /// <summary>
    /// Groups the item stream into changes: one per contiguous block of non-moved edits, plus one per move
    /// (source words in DeletedWords, destination words in AddedWords). Changes are returned in document order.
    /// </summary>
    private static List<SemanticDiffChange> BuildSemanticChanges(List<WordDiffItem> diffItems, bool classify = true)
    {
        var changes = new List<SemanticDiffChange>();
        var moveChanges = new Dictionary<int, SemanticDiffChange>();
        var openMoves = new List<SemanticDiffChange>();
        SemanticDiffChange? current = null;
        ComparisonWord? lastAfter = null;

        foreach (var item in diffItems)
        {
            if (item.Kind == DiffKind.Equal)
            {
                if (current is not null)
                {
                    current.SubsequentEqualAfter = item.AfterWord;
                    current = null;
                }
                foreach (var mc in openMoves) mc.SubsequentEqualAfter ??= item.AfterWord;
                openMoves.Clear();
                lastAfter = item.AfterWord;
                continue;
            }

            SemanticDiffChange target;
            if (item.MoveId >= 0)
            {
                if (!moveChanges.TryGetValue(item.MoveId, out var mc))
                {
                    mc = new SemanticDiffChange { Type = PdfChangeType.Moved, Risk = PdfChangeRisk.Info, MoveId = item.MoveId };
                    moveChanges[item.MoveId] = mc;
                    changes.Add(mc);
                }
                if (item.Kind == DiffKind.Insert && mc.AddedWords.Count == 0)
                {
                    mc.PrecedingEqualAfter = lastAfter;
                    openMoves.Add(mc);
                }
                target = mc;
            }
            else
            {
                if (current is null)
                {
                    current = new SemanticDiffChange { PrecedingEqualAfter = lastAfter };
                    changes.Add(current);
                }
                target = current;
            }

            if (item.Kind == DiffKind.Delete && item.BeforeWord is not null) target.DeletedWords.Add(item.BeforeWord);
            else if (item.Kind == DiffKind.Insert && item.AfterWord is not null) target.AddedWords.Add(item.AfterWord);
        }

        foreach (var ch in changes)
        {
            if (ch.MoveId >= 0) continue;
            if (classify) ClassifyChange(ch);
            else ch.Type = ch.DeletedWords.Count == 0 ? PdfChangeType.Inserted : ch.AddedWords.Count == 0 ? PdfChangeType.Deleted : PdfChangeType.Replaced;
        }
        return changes;
    }

    /// <summary>English negation / obligation words whose appearance in a change raises its review priority.</summary>
    private static readonly HashSet<string> RiskWords = new(StringComparer.OrdinalIgnoreCase)
    {
        "not", "no", "never", "neither", "nor", "none", "without", "except", "unless", "only",
        "shall", "must", "may", "might", "will", "would", "should", "can", "cannot", "could"
    };

    private static bool HasDigit(string s) => s.Any(char.IsDigit);

    private static string BareKey(string s)
    {
        var folded = FoldTypography(s).ToLowerInvariant();
        var sb = new StringBuilder(folded.Length);
        foreach (var c in folded)
            if (!char.IsPunctuation(c) && !char.IsWhiteSpace(c)) sb.Append(c);
        return sb.ToString();
    }

    private static string RemoveWhitespace(string s)
    {
        var sb = new StringBuilder(s.Length);
        foreach (var c in s)
            if (!char.IsWhiteSpace(c)) sb.Append(c);
        return sb.ToString();
    }

    private static bool TryParseNumber(string s, out double value)
    {
        var sb = new StringBuilder();
        bool started = false, dot = false;
        for (int i = 0; i < s.Length; i++)
        {
            char c = s[i];
            if (c >= '0' && c <= '9') { sb.Append(c); started = true; }
            else if (started && c == ',') continue;
            else if (started && c == '.' && !dot && i + 1 < s.Length && s[i + 1] >= '0' && s[i + 1] <= '9') { sb.Append('.'); dot = true; }
            else if (started) break;
        }
        return double.TryParse(sb.ToString(), NumberStyles.Float, CultureInfo.InvariantCulture, out value);
    }

    private static bool SameNumbersDifferentFormat(List<ComparisonWord> deleted, List<ComparisonWord> added)
    {
        for (int i = 0; i < deleted.Count; i++)
        {
            if (!HasDigit(deleted[i].Text)) return false;
            if (NormalizeNumber(FoldTypography(deleted[i].Text)) != NormalizeNumber(FoldTypography(added[i].Text))) return false;
        }
        return true;
    }

    private static void ClassifyChange(SemanticDiffChange ch)
    {
        var del = ch.DeletedWords;
        var add = ch.AddedWords;
        bool minorEdit = false;

        if (del.Count == 0) ch.Type = PdfChangeType.Inserted;
        else if (add.Count == 0) ch.Type = PdfChangeType.Deleted;
        else
        {
            string dT = JoinWords(del), aT = JoinWords(add);
            var dW = del.Where(w => !w.IsPunctuation).ToList();
            var aW = add.Where(w => !w.IsPunctuation).ToList();

            if (string.Equals(dT, aT, StringComparison.OrdinalIgnoreCase)) ch.Type = PdfChangeType.CaseOnly;
            else if (RemoveWhitespace(dT) == RemoveWhitespace(aT)) ch.Type = PdfChangeType.SpacingOnly;
            else if (BareKey(dT) == BareKey(aT)) ch.Type = PdfChangeType.PunctuationOnly;
            else if (dW.Count > 0 && dW.Count == aW.Count && SameNumbersDifferentFormat(dW, aW))
            {
                // "$1,250.50" -> "$1250.5": same value, only the formatting moved. ("3.1" -> "3.10" does NOT land here.)
                ch.Type = PdfChangeType.PunctuationOnly;
                ch.Note = "same value, different formatting";
            }
            else if (dW.Count > 0 && dW.Count == aW.Count && dW.All(w => HasDigit(w.Text)) && aW.All(w => HasDigit(w.Text)))
            {
                ch.Type = PdfChangeType.Number;
                if (dW.Count == 1 && TryParseNumber(dW[0].Text, out double x) && TryParseNumber(aW[0].Text, out double y) && x != 0 && x != y)
                {
                    double d = y - x;
                    string sign = d > 0 ? "+" : "-";
                    ch.Note = FormattableString.Invariant($"{sign}{Math.Abs(d):0.##} ({sign}{Math.Abs(d / x) * 100.0:0.#}%)");
                }
            }
            else if (dW.Count == 1 && aW.Count == 1)
            {
                int lev = DiffRefine.Levenshtein(dW[0].Text, aW[0].Text);
                if (lev <= 2 && DiffRefine.Similarity(dW[0].Text, aW[0].Text) >= 0.6)
                {
                    ch.Type = PdfChangeType.Spelling;
                    minorEdit = lev <= 1;
                }
                else ch.Type = PdfChangeType.Replaced;
            }
            else ch.Type = PdfChangeType.Replaced;
        }

        var all = del.Concat(add).ToList();
        if (ch.Type is PdfChangeType.CaseOnly or PdfChangeType.PunctuationOnly or PdfChangeType.SpacingOnly) ch.Risk = PdfChangeRisk.Low;
        else if (all.Any(w => HasDigit(w.Text))) ch.Risk = PdfChangeRisk.Critical;
        else if (all.Any(w => RiskWords.Contains(w.Text))) ch.Risk = PdfChangeRisk.High;
        else if (minorEdit || all.All(w => w.IsPunctuation)) ch.Risk = PdfChangeRisk.Low;
        else ch.Risk = PdfChangeRisk.Medium;
    }

    /// <summary>
    /// Formatting changes among UNCHANGED words: the after/before font-size ratio is compared with the document-wide
    /// median ratio, so a uniformly rescaled document reports nothing while a single enlarged heading is flagged.
    /// Consecutive flagged words on a page are grouped into one change (DeletedWords = before, AddedWords = after).
    /// </summary>
    private static List<SemanticDiffChange> DetectFormattingChanges(List<WordDiffItem> items, double tolerance)
    {
        var result = new List<SemanticDiffChange>();
        var ratios = new List<double>();
        foreach (var it in items)
        {
            if (it.Kind == DiffKind.Equal && it.BeforeWord is { FontSize: > 0 } b && it.AfterWord is { FontSize: > 0 } a)
                ratios.Add(a.FontSize / b.FontSize);
        }
        if (ratios.Count < 8) return result;
        ratios.Sort();
        double median = ratios[ratios.Count / 2];

        SemanticDiffChange? current = null;
        ComparisonWord? lastAfter = null;
        foreach (var it in items)
        {
            if (it.Kind != DiffKind.Equal) continue;
            bool flagged = false;
            if (it.BeforeWord is { FontSize: > 0 } b && it.AfterWord is { FontSize: > 0 } a)
            {
                flagged = Math.Abs(a.FontSize / b.FontSize / median - 1.0) > tolerance;
                if (flagged)
                {
                    if (current is null || current.AddedWords[^1].PageIndex != a.PageIndex)
                    {
                        current = new SemanticDiffChange
                        {
                            Type = PdfChangeType.Formatting,
                            Risk = PdfChangeRisk.Low,
                            PrecedingEqualAfter = lastAfter,
                            Note = FormattableString.Invariant($"font size {b.FontSize:0.#} -> {a.FontSize:0.#} pt")
                        };
                        result.Add(current);
                    }
                    current.DeletedWords.Add(b);
                    current.AddedWords.Add(a);
                }
            }
            if (!flagged) current = null;
            lastAfter = it.AfterWord;
        }
        return result;
    }

    // ── Highlight clustering & geometry ──────────────────────────────────────

    private static List<PdfRect> ClusterWordsIntoBoxes(IEnumerable<ComparisonWord> words)
    {
        var allBoxes = new List<(PdfRect Box, double Y, double FontSize)>();
        foreach (var w in words)
        {
            allBoxes.Add((w.Box, w.Origin.Y, w.FontSize));
            if (w.AdditionalBoxes is not null)
            {
                foreach (var b in w.AdditionalBoxes)
                    allBoxes.Add((b, (b.Y0 + b.Y1) / 2.0, w.FontSize));
            }
        }
        var list = allBoxes.OrderByDescending(w => w.Y).ThenBy(w => w.Box.X0).ToList();
        var result = new List<PdfRect>();
        if (list.Count == 0) return result;

        PdfRect box = list[0].Box;
        var prev = list[0];

        for (int i = 1; i < list.Count; i++)
        {
            var item = list[i];
            bool sameLine = Math.Abs(item.Y - prev.Y) <= Math.Max(2.5, item.FontSize * 0.35);
            double gap = item.Box.X0 - box.X1;

            if (sameLine && gap >= -1.0 && gap <= Math.Max(12.0, item.FontSize * 1.5))
            {
                box = new PdfRect(Math.Min(box.X0, item.Box.X0), Math.Min(box.Y0, item.Box.Y0),
                                  Math.Max(box.X1, item.Box.X1), Math.Max(box.Y1, item.Box.Y1));
            }
            else
            {
                result.Add(box);
                box = item.Box;
            }
            prev = item;
        }
        result.Add(box);
        return result;
    }
}
