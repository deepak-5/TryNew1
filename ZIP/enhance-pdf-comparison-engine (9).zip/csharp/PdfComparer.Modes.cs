using System.Globalization;
using System.Net;
using System.Text;

namespace Docuzen.Pdf.Core;

// NEW FILE. The five new output modes (Annotated, OnionSkin, ChangeMap, RedlineText, ChangeReport) plus the
// HTML blocks that surface v3 information (similarity, moves, review priority, classified change log).

public static partial class PdfComparer
{
    // ── Shared text helpers ──────────────────────────────────────────────────

    private static string ChangeTypeLabel(PdfChangeType t) => t switch
    {
        PdfChangeType.Inserted => "Added",
        PdfChangeType.Deleted => "Deleted",
        PdfChangeType.Replaced => "Replaced",
        PdfChangeType.Moved => "Moved",
        PdfChangeType.Number => "Number",
        PdfChangeType.Spelling => "Spelling",
        PdfChangeType.CaseOnly => "Case",
        PdfChangeType.PunctuationOnly => "Punctuation",
        PdfChangeType.SpacingOnly => "Spacing",
        PdfChangeType.Formatting => "Formatting",
        _ => "Changed"
    };

    internal static string DescribeMode(PdfComparisonMode mode) => mode switch
    {
        PdfComparisonMode.SideBySide => "Dual Pane (Side-by-Side)",
        PdfComparisonMode.Annotated => "Annotated (native PDF comments)",
        PdfComparisonMode.OnionSkin => "Onion Skin (red/cyan vector blend)",
        PdfComparisonMode.ChangeMap => "Change Map (contact sheet)",
        PdfComparisonMode.RedlineText => "Redline Text (track changes)",
        PdfComparisonMode.ChangeReport => "Change Report",
        _ => "Vector Overlay (Redline)"
    };

    internal static string DescribeMatch(PdfComparisonOptions o)
    {
        if (o.CustomMatchFlags is { } f) return "Custom (" + f + ")";
        return o.MatchMode switch
        {
            PdfWordMatchMode.Strict => "Strict (case and punctuation significant)",
            PdfWordMatchMode.IgnoreCase => "Ignore case",
            PdfWordMatchMode.IgnoreCaseAndPunctuation => "Ignore case and surrounding punctuation",
            PdfWordMatchMode.Typographic => "Typographic (quotes and dashes folded)",
            PdfWordMatchMode.NumericAware => "Numeric-aware (number formatting folded)",
            PdfWordMatchMode.Loose => "Loose (case, typography, punctuation, diacritics, number formatting)",
            _ => "OCR-tolerant"
        };
    }

    /// <summary>Plain-text description of a change (annotation contents, API records).</summary>
    private static string DescribeChange(SemanticDiffChange ch, int maxLength = 900)
    {
        var sb = new StringBuilder();
        sb.Append(ChangeTypeLabel(ch.Type));
        if (ch.Risk >= PdfChangeRisk.High) sb.Append(" [").Append(ch.Risk == PdfChangeRisk.Critical ? "CRITICAL" : "HIGH").Append(']');
        if (ch.Note.Length > 0) sb.Append(" (").Append(ch.Note).Append(')');

        string del = JoinWords(ch.DeletedWords), add = JoinWords(ch.AddedWords);
        if (ch.Type == PdfChangeType.Moved)
        {
            sb.Append(": from page ").Append(ch.DeletedWords.Count > 0 ? ch.DeletedWords[0].PageIndex + 1 : 0)
              .Append(" to page ").Append(ch.AddedWords.Count > 0 ? ch.AddedWords[0].PageIndex + 1 : 0)
              .Append("\n").Append(add.Length > 0 ? add : del);
        }
        else if (ch.Type == PdfChangeType.Formatting) sb.Append('\n').Append(add);
        else
        {
            if (del.Length > 0) sb.Append("\nDeleted: ").Append(del);
            if (add.Length > 0) sb.Append("\nAdded: ").Append(add);
        }
        return sb.Length <= maxLength ? sb.ToString() : sb.ToString(0, maxLength - 3) + "...";
    }

    private static List<PdfChangeRecord> BuildChangeRecords(List<SemanticDiffChange> changes)
    {
        var records = new List<PdfChangeRecord>(changes.Count);
        for (int i = 0; i < changes.Count; i++)
        {
            var ch = changes[i];
            int bp = ch.DeletedWords.Count > 0 ? ch.DeletedWords[0].PageIndex : -1;
            int ap = ch.AddedWords.Count > 0 ? ch.AddedWords[0].PageIndex : (ch.PrecedingEqualAfter ?? ch.SubsequentEqualAfter)?.PageIndex ?? -1;
            records.Add(new PdfChangeRecord(i + 1, ch.Type, ch.Risk, bp + 1, ap + 1, JoinWords(ch.DeletedWords), JoinWords(ch.AddedWords), ch.Note)
            {
                BeforeBoxes = ClusterWordsIntoBoxes(ch.DeletedWords.Where(w => w.PageIndex == bp)),
                AfterBoxes = ch.AddedWords.Count > 0 ? ClusterWordsIntoBoxes(ch.AddedWords.Where(w => w.PageIndex == ap)) : new List<PdfRect>()
            });
        }
        return records;
    }

    private static CosDictionary BuildModeResources(SharedResources s, CosDictionary xObjects, CosDictionary extGStates)
        => new CosDictionary()
            .Set("XObject", xObjects)
            .Set("ExtGState", extGStates.Set("GSHighlight", s.Highlight))
            .Set("Font", new CosDictionary().Set("F_Bold", s.Bold).Set("F_Regular", s.Regular));

    // ── Annotated mode ───────────────────────────────────────────────────────

    /// <summary>
    /// The modified page at 1:1 with native annotations: one multi-quad Highlight per change that has words on
    /// this page (green = added, amber = replaced, blue = moved, violet = formatting) and a Text note where
    /// something was deleted. Contents carry the classified description, so the reader's comment list IS the change list.
    /// A page that exists only in the original is shown with StrikeOut annotations.
    /// </summary>
    private static CosReference RenderAnnotatedSlot(
        PdfOutputDocument output, CosReference pagesRoot, SharedResources shared,
        PdfDocument before, PdfDocument after, int beforeIndex, int afterIndex, SlotMarks marks,
        List<SemanticDiffChange> changes, int[] beforeToAfter, PdfComparisonOptions options)
    {
        bool afterExists = afterIndex >= 0;
        var doc = afterExists ? after : before;
        int index = afterExists ? afterIndex : beforeIndex;
        var geom = PdfImposition.GetPageGeometry(doc, doc.Pages.Pages[index]);
        double w = geom.DisplayWidth, h = geom.DisplayHeight;

        var xObjects = new CosDictionary();
        xObjects.Set("FmBase", PdfImposition.AddPageForm(output, doc, doc.Pages.Pages[index], geom));

        var c = new StringBuilder();
        c.Append("1 1 1 rg 0 0 ").Append(N(w)).Append(' ').Append(N(h)).Append(" re f\n");
        var placement = PdfImposition.FitPageToCell(geom, new PdfImpositionCell(0, 0, 0, 0.0, 0.0, w, h));
        var m = new Mat(placement.A, placement.B, placement.C, placement.D, placement.E, placement.F);
        AppendPlacement(c, m, "FmBase");

        var annots = new List<CosReference>();

        void Markup(string subtype, List<PdfRect> boxes, double[] rgb, string contents)
        {
            if (boxes.Count == 0) return;
            var quads = new double[boxes.Count * 8];
            double x0 = double.MaxValue, y0 = double.MaxValue, x1 = double.MinValue, y1 = double.MinValue;
            for (int i = 0; i < boxes.Count; i++)
            {
                var r = MapRect(m, boxes[i], geom.Box);
                double l = r.X, b = r.Y, rt = r.X + r.W, t = r.Y + r.H;
                // Quad order used by all major viewers: top-left, top-right, bottom-left, bottom-right.
                quads[i * 8] = l; quads[i * 8 + 1] = t; quads[i * 8 + 2] = rt; quads[i * 8 + 3] = t;
                quads[i * 8 + 4] = l; quads[i * 8 + 5] = b; quads[i * 8 + 6] = rt; quads[i * 8 + 7] = b;
                x0 = Math.Min(x0, l); y0 = Math.Min(y0, b); x1 = Math.Max(x1, rt); y1 = Math.Max(y1, t);
            }
            annots.Add(output.Add(new CosDictionary()
                .Set("Type", new CosName("Annot"))
                .Set("Subtype", new CosName(subtype))
                .Set("Rect", PdfImposition.NumberArray(new[] { x0, y0, x1, y1 }))
                .Set("QuadPoints", PdfImposition.NumberArray(quads))
                .Set("C", PdfImposition.NumberArray(rgb))
                .Set("CA", new CosReal(0.45))
                .Set("F", new CosInteger(4))
                .Set("T", CosString.FromText(options.AnnotationAuthor))
                .Set("Contents", CosString.FromText(contents))));
        }

        void Note(double x, double y, string contents)
        {
            double nx = Math.Clamp(x, 0.0, Math.Max(0.0, w - 18.0)), ny = Math.Clamp(y, 0.0, Math.Max(0.0, h - 18.0));
            annots.Add(output.Add(new CosDictionary()
                .Set("Type", new CosName("Annot"))
                .Set("Subtype", new CosName("Text"))
                .Set("Name", new CosName("Comment"))
                .Set("Rect", PdfImposition.NumberArray(new[] { nx, ny, nx + 18.0, ny + 18.0 }))
                .Set("C", PdfImposition.NumberArray(new[] { 0.90, 0.20, 0.20 }))
                .Set("F", new CosInteger(4))
                .Set("T", CosString.FromText(options.AnnotationAuthor))
                .Set("Contents", CosString.FromText(contents))));
        }

        if (!afterExists)
        {
            Markup("StrikeOut", ClusterWordsIntoBoxes(marks.Deleted.Concat(marks.MovedFrom)), new[] { 0.90, 0.20, 0.20 },
                "Page removed in the modified document");
        }
        else
        {
            foreach (var ch in changes)
            {
                var here = ch.AddedWords.Where(x => x.PageIndex == afterIndex).ToList();
                if (here.Count > 0)
                {
                    double[] rgb = ch.Type switch
                    {
                        PdfChangeType.Moved => new[] { 0.35, 0.55, 1.00 },
                        PdfChangeType.Formatting => new[] { 0.70, 0.50, 1.00 },
                        PdfChangeType.Inserted => new[] { 0.30, 0.85, 0.45 },
                        _ => new[] { 1.00, 0.75, 0.20 }
                    };
                    Markup("Highlight", ClusterWordsIntoBoxes(here), rgb, DescribeChange(ch));
                    continue;
                }

                if (ch.Type is PdfChangeType.Moved or PdfChangeType.Formatting) continue;
                if (ch.DeletedWords.Count == 0 || HomeAfterPage(ch, beforeToAfter) != afterIndex) continue;
                if (ch.DeletedWords.All(x => beforeToAfter[x.PageIndex] < 0)) continue; // shown on the deleted page's own slot

                ComparisonWord? anchor =
                    (ch.PrecedingEqualAfter is { } p && p.PageIndex == afterIndex ? p : null)
                    ?? (ch.SubsequentEqualAfter is { } s && s.PageIndex == afterIndex ? s : null);
                if (anchor is not null)
                {
                    var r = MapRect(m, anchor.Box, geom.Box);
                    Note(ReferenceEquals(ch.PrecedingEqualAfter, anchor) ? r.X + r.W : r.X - 9.0, r.Y + r.H, DescribeChange(ch));
                }
                else Note(w - 20.0, h - 20.0, DescribeChange(ch));
            }

            for (int i = 0; i < marks.GraphicalBoxes.Count; i++)
                Markup("Highlight", new List<PdfRect> { marks.GraphicalBoxes[i] }, new[] { 1.00, 0.65, 0.10 }, "Visual / graphical difference");
            for (int i = 0; i < marks.RasterBoxes.Count; i++)
                Markup("Highlight", new List<PdfRect> { marks.RasterBoxes[i] }, new[] { 1.00, 0.65, 0.10 }, "Image difference (page has no extractable text)");
        }

        var contentRef = output.Add(new CosStream(new CosDictionary(), Encoding.Latin1.GetBytes(c.ToString())));
        var box = PdfImposition.NumberArray(new[] { 0.0, 0.0, w, h });
        var page = new CosDictionary()
            .Set("Type", new CosName("Page"))
            .Set("Parent", pagesRoot)
            .Set("MediaBox", box)
            .Set("CropBox", box)
            .Set("Resources", BuildResources(shared, xObjects))
            .Set("Contents", contentRef);
        if (annots.Count > 0) page.Set("Annots", new CosArray(annots));
        return output.Add(page);
    }

    // ── Onion-skin mode ──────────────────────────────────────────────────────

    /// <summary>
    /// Pure-vector visual difference. Each page is wrapped in a transparency group on a white ground and tinted
    /// with a Screen blend (original → red, modified → cyan); the two groups are then combined with Multiply.
    /// Result: content present in both prints black, original-only content red, modified-only content cyan.
    /// No rasterisation, no thresholds - it shows every moved line, swapped image and shifted table border.
    /// </summary>
    private static CosReference RenderOnionSkinSlot(
        PdfOutputDocument output, CosReference pagesRoot, SharedResources shared,
        PdfDocument before, PdfDocument after, int beforeIndex, int afterIndex,
        PdfComparisonOptions options, int slotNumber, int totalSlots, bool pageChanged)
    {
        bool beforeExists = beforeIndex >= 0, afterExists = afterIndex >= 0;
        var geomBefore = beforeExists ? PdfImposition.GetPageGeometry(before, before.Pages.Pages[beforeIndex]) : null;
        var geomAfter = afterExists ? PdfImposition.GetPageGeometry(after, after.Pages.Pages[afterIndex]) : null;
        double w = Math.Max(geomBefore?.DisplayWidth ?? 0.0, geomAfter?.DisplayWidth ?? 0.0);
        double h = Math.Max(geomBefore?.DisplayHeight ?? 0.0, geomAfter?.DisplayHeight ?? 0.0);

        double bannerH = options.IncludePageBanners ? BannerHeightPt : 0.0;
        double sheetW = PageMarginPt + w + PageMarginPt;
        double sheetH = PageMarginPt + h + PageMarginPt + bannerH;

        CosReference BlendState(string mode) => output.Add(new CosDictionary()
            .Set("Type", new CosName("ExtGState"))
            .Set("BM", new CosName(mode)));
        var screen = BlendState("Screen");
        var multiply = BlendState("Multiply");

        // One tinted layer = Form XObject with a transparency group: white ground, the page, a Screen-blended tint.
        CosReference Layer(PdfDocument doc, int index, PdfImposition.SourcePageGeometry geom, string tint)
        {
            var form = PdfImposition.AddPageForm(output, doc, doc.Pages.Pages[index], geom);
            // Natural size, top-left aligned inside the common w x h box (no scaling).
            var placement = PdfImposition.FitPageToCell(geom,
                new PdfImpositionCell(0, 0, 0, 0.0, h - geom.DisplayHeight, geom.DisplayWidth, geom.DisplayHeight));
            var lm = new Mat(placement.A, placement.B, placement.C, placement.D, placement.E, placement.F);

            var lc = new StringBuilder();
            lc.Append("1 1 1 rg 0 0 ").Append(N(w)).Append(' ').Append(N(h)).Append(" re f\n");
            AppendPlacement(lc, lm, "Fm");
            lc.Append("/GSScreen gs\n").Append(tint).Append(" rg 0 0 ").Append(N(w)).Append(' ').Append(N(h)).Append(" re f\n");

            var dict = new CosDictionary()
                .Set("Type", new CosName("XObject"))
                .Set("Subtype", new CosName("Form"))
                .Set("BBox", PdfImposition.NumberArray(new[] { 0.0, 0.0, w, h }))
                .Set("Group", new CosDictionary().Set("S", new CosName("Transparency")).Set("CS", new CosName("DeviceRGB")))
                .Set("Resources", new CosDictionary()
                    .Set("XObject", new CosDictionary().Set("Fm", form))
                    .Set("ExtGState", new CosDictionary().Set("GSScreen", screen)));
            return output.Add(new CosStream(dict, Encoding.Latin1.GetBytes(lc.ToString())));
        }

        var xObjects = new CosDictionary();
        var c = new StringBuilder();
        c.Append("1 1 1 rg 0 0 ").Append(N(sheetW)).Append(' ').Append(N(sheetH)).Append(" re f\n");

        if (options.IncludePageBanners)
        {
            double yBanner = sheetH - bannerH;
            DrawBannerBase(c, sheetW, yBanner, bannerH);
            DrawCenteredText(c, $"DOCUZEN ONION SKIN | SLOT {slotNumber} OF {totalSlots}", sheetW / 2.0, yBanner + 24.0, 9.0, "1 1 1", bold: true);
            DrawCenteredText(c, pageChanged ? "Red = only in original | Cyan = only in modified | Black = unchanged" : "Pages Identical (text)",
                sheetW / 2.0, yBanner + 10.0, 8.0, pageChanged ? "0.95 0.45 0.45" : "0.30 0.85 0.45");
        }

        string at = "1 0 0 1 " + N(PageMarginPt) + " " + N(PageMarginPt) + " cm\n";
        if (afterExists)
        {
            xObjects.Set("LyAfter", Layer(after, afterIndex, geomAfter!, "0 1 1"));
            c.Append("q\n").Append(at).Append("/LyAfter Do\nQ\n");
        }
        if (beforeExists)
        {
            xObjects.Set("LyBefore", Layer(before, beforeIndex, geomBefore!, "1 0 0"));
            c.Append("q\n").Append(afterExists ? "/GSMultiply gs\n" : string.Empty).Append(at).Append("/LyBefore Do\nQ\n");
        }

        var contentRef = output.Add(new CosStream(new CosDictionary(), Encoding.Latin1.GetBytes(c.ToString())));
        var box = PdfImposition.NumberArray(new[] { 0.0, 0.0, sheetW, sheetH });
        return output.Add(new CosDictionary()
            .Set("Type", new CosName("Page"))
            .Set("Parent", pagesRoot)
            .Set("MediaBox", box)
            .Set("CropBox", box)
            .Set("Resources", BuildModeResources(shared, xObjects, new CosDictionary().Set("GSMultiply", multiply)))
            .Set("Contents", contentRef));
    }

    // ── Change-map mode ──────────────────────────────────────────────────────

    private sealed record ChangeMapEntry(int BeforeIndex, int AfterIndex, SlotMarks Marks, bool Changed, bool Raster);

    /// <summary>
    /// Contact sheets (A4 landscape): every slot as a live vector thumbnail with saturated change marks, a status
    /// border and a counter line. Deletions cannot be drawn on the modified page, so they appear as red ticks in
    /// the thumbnail's left margin at the height where the text used to be.
    /// </summary>
    private static void RenderChangeMapSheets(
        PdfOutputDocument output, CosReference pagesRoot, SharedResources shared,
        PdfDocument before, PdfDocument after, List<ChangeMapEntry> entries, PdfComparisonOptions options,
        List<CosReference> pageReferences, List<string> bookmarkLabels)
    {
        const double sheetW = 841.89, sheetH = 595.28, gap = 14.0, labelH = 13.0;
        double bannerH = options.IncludePageBanners ? BannerHeightPt : 0.0;
        int cols = Math.Clamp(options.ChangeMapColumns, 2, 10);
        double cellW = (sheetW - 2 * PageMarginPt - (cols - 1) * gap) / cols;
        double thumbH = cellW * 1.4142;
        int rows = Math.Max(1, (int)((sheetH - bannerH - 2 * PageMarginPt + gap) / (thumbH + labelH + gap)));
        int perSheet = cols * rows;

        for (int start = 0; start < entries.Count; start += perSheet)
        {
            int end = Math.Min(entries.Count, start + perSheet);
            var xObjects = new CosDictionary();
            var c = new StringBuilder();
            c.Append("1 1 1 rg 0 0 ").Append(N(sheetW)).Append(' ').Append(N(sheetH)).Append(" re f\n");

            if (options.IncludePageBanners)
            {
                double yBanner = sheetH - bannerH;
                DrawBannerBase(c, sheetW, yBanner, bannerH);
                DrawCenteredText(c, $"DOCUZEN CHANGE MAP | {start + 1}-{end} OF {entries.Count}", sheetW / 2.0, yBanner + 24.0, 9.0, "1 1 1", bold: true);
                DrawCenteredText(c, "Green = added | Red ticks = deleted | Blue = moved | Violet = formatting | Amber = visual",
                    sheetW / 2.0, yBanner + 10.0, 8.0, "0.65 0.72 0.82");
            }

            for (int k = start; k < end; k++)
            {
                var e = entries[k];
                int col = (k - start) % cols, row = (k - start) / cols;
                double x = PageMarginPt + col * (cellW + gap);
                double y = sheetH - bannerH - PageMarginPt - row * (thumbH + labelH + gap) - thumbH;

                bool afterExists = e.AfterIndex >= 0, beforeExists = e.BeforeIndex >= 0;
                var doc = afterExists ? after : before;
                int index = afterExists ? e.AfterIndex : e.BeforeIndex;
                var geom = PdfImposition.GetPageGeometry(doc, doc.Pages.Pages[index]);
                string name = "Fm" + k.ToString(CultureInfo.InvariantCulture);
                xObjects.Set(name, PdfImposition.AddPageForm(output, doc, doc.Pages.Pages[index], geom));
                var placement = PdfImposition.FitPageToCell(geom, new PdfImpositionCell(k - start, row, col, x, y, cellW, thumbH));
                var m = new Mat(placement.A, placement.B, placement.C, placement.D, placement.E, placement.F);
                AppendPlacement(c, m, name);

                void FillRect((double X, double Y, double W, double H) r, string rgb)
                    => c.Append("q\n/GSHighlight gs\n").Append(rgb).Append(" rg\n")
                        .Append(N(r.X - 0.5)).Append(' ').Append(N(r.Y - 0.5)).Append(' ')
                        .Append(N(Math.Max(2.0, r.W + 1.0))).Append(' ').Append(N(Math.Max(2.0, r.H + 1.0))).Append(" re f\nQ\n");

                void Fill(IEnumerable<ComparisonWord> words, string rgb)
                {
                    foreach (var b in ClusterWordsIntoBoxes(words)) FillRect(MapRect(m, b, geom.Box), rgb);
                }

                if (afterExists)
                {
                    Fill(e.Marks.Added, "0.150 0.750 0.300");
                    Fill(e.Marks.MovedTo, "0.200 0.450 0.950");
                    Fill(e.Marks.FormatAfter, "0.600 0.300 0.900");
                    foreach (var b in e.Marks.GraphicalBoxes) FillRect(MapRect(m, b, geom.Box), "0.950 0.600 0.100");
                    foreach (var b in e.Marks.RasterBoxes) FillRect(MapRect(m, b, geom.Box), "0.950 0.600 0.100");

                    if (beforeExists && e.Marks.Deleted.Count > 0)
                    {
                        var gb = PdfImposition.GetPageGeometry(before, before.Pages.Pages[e.BeforeIndex]);
                        var seen = new HashSet<int>();
                        foreach (var word in e.Marks.Deleted)
                        {
                            double rel = Math.Clamp((word.Box.Y0 - gb.Box[1]) / Math.Max(1.0, gb.DisplayHeight), 0.0, 1.0);
                            if (!seen.Add((int)(rel * 150.0))) continue;
                            c.Append("0.900 0.150 0.150 rg ").Append(N(x - 5.0)).Append(' ').Append(N(y + rel * thumbH)).Append(" 3.5 1.6 re f\n");
                        }
                    }
                }
                else
                {
                    Fill(e.Marks.Deleted, "0.900 0.200 0.200");
                    Fill(e.Marks.MovedFrom, "0.200 0.450 0.950");
                }

                string status = !afterExists ? "0.850 0.200 0.200" : !beforeExists ? "0.150 0.650 0.250" : e.Changed ? "0.880 0.550 0.100" : "0.780 0.810 0.850";
                c.Append("q\n").Append(status).Append(" RG ").Append(e.Changed ? "1.4" : "0.6").Append(" w\n")
                 .Append(N(x)).Append(' ').Append(N(y)).Append(' ').Append(N(cellW)).Append(' ').Append(N(thumbH)).Append(" re S\nQ\n");

                var label = new StringBuilder();
                label.Append(!afterExists ? $"p.{e.BeforeIndex + 1} deleted" : !beforeExists ? $"p.{e.AfterIndex + 1} inserted" : $"p.{e.AfterIndex + 1}");
                if (e.Raster) label.Append(e.Changed ? "  image diff" : "  image");
                else if (afterExists && beforeExists)
                {
                    if (e.Marks.Added.Count > 0) label.Append("  +").Append(e.Marks.Added.Count);
                    if (e.Marks.Deleted.Count > 0) label.Append("  -").Append(e.Marks.Deleted.Count);
                    int moved = e.Marks.MovedFrom.Count + e.Marks.MovedTo.Count;
                    if (moved > 0) label.Append("  mv ").Append(moved);
                    if (e.Marks.GraphicalBoxes.Count > 0) label.Append("  vis ").Append(e.Marks.GraphicalBoxes.Count);
                }
                DrawLeftText(c, label.ToString(), x, y - 10.0, 7.0, e.Changed ? "0.15 0.15 0.20" : "0.55 0.58 0.62", e.Changed);
            }

            pageReferences.Add(AddPage(output, pagesRoot, shared, xObjects, c, sheetW, sheetH));
            bookmarkLabels.Add($"Change map {start / perSheet + 1} (slots {start + 1}-{end})");
        }
    }

    // ── Redline text mode ────────────────────────────────────────────────────

    /// <summary>
    /// Track-changes rendering of the whole text, independent of page geometry: insertions underlined green,
    /// deletions struck red, move sources struck blue, move destinations double-underlined blue. Paragraphs are
    /// re-created from vertical gaps between lines of the modified document.
    /// </summary>
    private static string BuildRedlineHtml(List<WordDiffItem> items, string beforeTitle, string afterTitle)
    {
        var sb = new StringBuilder();
        sb.Append("<!DOCTYPE html>\n<html>\n<head>\n<meta charset=\"utf-8\" />\n<style>\n")
          .Append("@page { size: A4; margin: 36pt; }\n")
          .Append("body { font-family: Georgia, \"Times New Roman\", serif; font-size: 10.5pt; line-height: 1.55; color: #1e293b; }\n")
          .Append("h1 { font-family: Helvetica, Arial, sans-serif; font-size: 16pt; margin: 0 0 4px 0; color: #0f172a; }\n")
          .Append("h4 { font-family: Helvetica, Arial, sans-serif; font-size: 8pt; letter-spacing: 1px; text-transform: uppercase; color: #94a3b8; border-top: 1px solid #e2e8f0; padding-top: 6px; margin: 18px 0 6px 0; }\n")
          .Append(".legend { font-family: Helvetica, Arial, sans-serif; font-size: 8.5pt; color: #64748b; margin: 0 0 10px 0; }\n")
          .Append("p { margin: 0 0 8px 0; }\n")
          .Append("ins { color: #15803d; background-color: #dcfce7; text-decoration: underline; }\n")
          .Append("del { color: #b91c1c; background-color: #fee2e2; text-decoration: line-through; }\n")
          .Append(".mvto { color: #1d4ed8; background-color: #dbeafe; border-bottom: 2px solid #1d4ed8; }\n")
          .Append(".mvfrom { color: #1d4ed8; text-decoration: line-through; }\n")
          .Append("</style>\n</head>\n<body>\n")
          .Append("<h1>Redline</h1>\n<p class=\"legend\">")
          .Append(WebUtility.HtmlEncode(beforeTitle)).Append(" &rarr; ").Append(WebUtility.HtmlEncode(afterTitle))
          .Append(" &nbsp;|&nbsp; <ins>added</ins> &nbsp; <del>deleted</del> &nbsp; <span class=\"mvto\">moved here</span> &nbsp; <span class=\"mvfrom\">moved from here</span></p>\n");

        // 0 = unchanged, 1 = inserted, 2 = deleted, 3 = moved-to, 4 = moved-from
        int style = 0, page = -1;
        bool paragraphOpen = false;
        ComparisonWord? prevAfter = null;

        void Close()
        {
            sb.Append(style switch { 1 => "</ins>", 2 => "</del>", 3 or 4 => "</span>", _ => string.Empty });
            style = 0;
        }

        void Emit(int wanted, bool space, string text)
        {
            if (wanted != style)
            {
                Close();
                if (space) sb.Append(' ');
                sb.Append(wanted switch { 1 => "<ins>", 2 => "<del>", 3 => "<span class=\"mvto\">", 4 => "<span class=\"mvfrom\">", _ => string.Empty });
                style = wanted;
            }
            else if (space) sb.Append(' ');
            sb.Append(WebUtility.HtmlEncode(text));
        }

        foreach (var it in items)
        {
            var word = (it.AfterWord ?? it.BeforeWord)!;
            int wanted = it.Kind == DiffKind.Equal ? 0
                : it.Kind == DiffKind.Insert ? (it.MoveId >= 0 ? 3 : 1)
                : (it.MoveId >= 0 ? 4 : 2);

            bool fresh = false;
            if (it.AfterWord is { } aw)
            {
                if (aw.PageIndex != page)
                {
                    Close();
                    if (paragraphOpen) sb.Append("</p>\n");
                    sb.Append("<h4>Page ").Append(aw.PageIndex + 1).Append("</h4>\n<p>");
                    paragraphOpen = true;
                    page = aw.PageIndex;
                    fresh = true;
                }
                else if (prevAfter is { } pa && pa.LineIndex != aw.LineIndex &&
                         pa.Origin.Y - aw.Origin.Y > 1.7 * Math.Max(pa.FontSize, aw.FontSize))
                {
                    Close();
                    sb.Append("</p>\n<p>");
                    fresh = true;
                }
                prevAfter = aw;
            }
            else if (!paragraphOpen)
            {
                sb.Append("<p>");
                paragraphOpen = true;
                fresh = true;
            }

            Emit(wanted, !fresh && !word.GlueLeft, word.Text);
        }

        Close();
        if (paragraphOpen) sb.Append("</p>\n");
        sb.Append("</body>\n</html>");
        return sb.ToString();
    }

    // ── Summary add-ons ──────────────────────────────────────────────────────

    /// <summary>KPI strip with the v3 metrics; uses the CSS classes of the v2 summary template (kpi-grid, kpi-card, ...).</summary>
    private static string BuildInsightsHtml(List<SemanticDiffChange> changes, IReadOnlyList<(int Before, int After)> slots, double similarity)
    {
        int moves = changes.Count(c => c.Type == PdfChangeType.Moved);
        int critical = changes.Count(c => c.Risk == PdfChangeRisk.Critical);
        int high = changes.Count(c => c.Risk == PdfChangeRisk.High);
        int formatting = changes.Count(c => c.Type == PdfChangeType.Formatting);
        var inserted = slots.Where(s => s.Before < 0).Select(s => (s.After + 1).ToString(CultureInfo.InvariantCulture)).ToList();
        var deleted = slots.Where(s => s.After < 0).Select(s => (s.Before + 1).ToString(CultureInfo.InvariantCulture)).ToList();

        var sb = new StringBuilder();
        void Card(string value, string label, string cssClass) =>
            sb.Append("    <div class=\"kpi-card\"><div class=\"kpi-value ").Append(cssClass).Append("\">").Append(value)
              .Append("</div><div class=\"kpi-label\">").Append(label).Append("</div></div>\n");

        sb.Append("  <div class=\"kpi-grid\">\n");
        Card((similarity * 100.0).ToString("0.#", CultureInfo.InvariantCulture) + "%", "Similarity", "kpi-blue");
        Card(critical.ToString(CultureInfo.InvariantCulture), "Critical (numbers)", "kpi-red");
        Card(high.ToString(CultureInfo.InvariantCulture), "High (wording)", "kpi-amber");
        Card(moves.ToString(CultureInfo.InvariantCulture), "Moved Blocks", "kpi-blue");
        if (formatting > 0) Card(formatting.ToString(CultureInfo.InvariantCulture), "Formatting", "kpi-amber");
        sb.Append("  </div>\n");

        if (inserted.Count > 0 || deleted.Count > 0)
        {
            sb.Append("  <p class=\"subtitle\" style=\"margin: -12px 0 18px 0;\">Page map: ");
            if (inserted.Count > 0) sb.Append("inserted page(s) ").Append(string.Join(", ", inserted)).Append(" (modified numbering)");
            if (inserted.Count > 0 && deleted.Count > 0) sb.Append("; ");
            if (deleted.Count > 0) sb.Append("deleted page(s) ").Append(string.Join(", ", deleted)).Append(" (original numbering)");
            sb.Append(". All other pages were paired by content.</p>\n");
        }
        return sb.ToString();
    }

    /// <summary>Classified change log with review priority and character-level highlighting for single-word edits.</summary>
    private static string BuildChangeLogHtml(List<SemanticDiffChange> changes, int maxRows)
    {
        if (changes.Count == 0) return string.Empty;
        var sb = new StringBuilder();
        sb.Append("<h3 style=\"font-size: 13pt; margin: 22px 0 8px 0; color: #0f172a;\">Detailed Change Log</h3>\n<table>\n<thead><tr>")
          .Append("<th style=\"width:7%;\">Page</th><th style=\"width:13%;\">Type</th><th style=\"width:10%;\">Priority</th>")
          .Append("<th style=\"width:35%;\">Original</th><th style=\"width:35%;\">Modified</th></tr></thead>\n<tbody>\n");

        const string DelStyle = "color:#b91c1c; text-decoration: line-through;";
        const string AddStyle = "color:#15803d; font-weight: 500;";
        const string Dash = "<span style=\"color:#94a3b8;\">&mdash;</span>";
        int shown = 0;

        foreach (var ch in changes)
        {
            if (shown >= maxRows) break;
            shown++;
            int page = (ch.DeletedWords.Count > 0 ? ch.DeletedWords[0].PageIndex : ch.AddedWords[0].PageIndex) + 1;
            string tag = ch.Type switch
            {
                PdfChangeType.Deleted => "tag-diff",
                PdfChangeType.Inserted => "tag-match",
                _ => "tag-replaced"
            };
            string priority = ch.Risk switch
            {
                PdfChangeRisk.Critical => "<span class=\"tag tag-diff\">Critical</span>",
                PdfChangeRisk.High => "<span class=\"tag tag-replaced\">High</span>",
                PdfChangeRisk.Medium => "Medium",
                PdfChangeRisk.Low => "<span style=\"color:#94a3b8;\">Low</span>",
                _ => "<span style=\"color:#94a3b8;\">Info</span>"
            };

            string del = Truncate(JoinWords(ch.DeletedWords), 300), add = Truncate(JoinWords(ch.AddedWords), 300);
            string delHtml, addHtml;
            if (ch.Type == PdfChangeType.Moved)
            {
                int to = ch.AddedWords.Count > 0 ? ch.AddedWords[0].PageIndex + 1 : 0;
                delHtml = "<span style=\"color:#1d4ed8;\">" + WebUtility.HtmlEncode(del) + "</span>";
                addHtml = "<span style=\"color:#1d4ed8;\">moved to page " + to.ToString(CultureInfo.InvariantCulture) + "</span>";
            }
            else if (ch.Type == PdfChangeType.Formatting)
            {
                delHtml = WebUtility.HtmlEncode(del);
                addHtml = "<span style=\"color:#6d28d9;\">" + WebUtility.HtmlEncode(ch.Note) + "</span>";
            }
            else if (ch.DeletedWords.Count == 1 && ch.AddedWords.Count == 1 && del.Length <= 80 && add.Length <= 80)
            {
                // Single-word edit: show exactly which characters changed.
                var d = new StringBuilder();
                var a = new StringBuilder();
                foreach (var (kind, text) in DiffRefine.CharDiff(del, add))
                {
                    string enc = WebUtility.HtmlEncode(text);
                    if (kind == DiffKind.Equal) { d.Append(enc); a.Append(enc); }
                    else if (kind == DiffKind.Delete) d.Append("<span style=\"").Append(DelStyle).Append(" background-color:#fee2e2;\">").Append(enc).Append("</span>");
                    else a.Append("<span style=\"").Append(AddStyle).Append(" background-color:#dcfce7;\">").Append(enc).Append("</span>");
                }
                delHtml = d.ToString();
                addHtml = a.ToString();
            }
            else
            {
                delHtml = del.Length > 0 ? "<span style=\"" + DelStyle + "\">" + WebUtility.HtmlEncode(del) + "</span>" : Dash;
                addHtml = add.Length > 0 ? "<span style=\"" + AddStyle + "\">" + WebUtility.HtmlEncode(add) + "</span>" : Dash;
            }
            if (ch.Note.Length > 0 && ch.Type != PdfChangeType.Formatting)
                addHtml += " <span style=\"color:#64748b;\">(" + WebUtility.HtmlEncode(ch.Note) + ")</span>";

            sb.Append("<tr><td>").Append(page).Append("</td><td><span class=\"tag ").Append(tag).Append("\">")
              .Append(ChangeTypeLabel(ch.Type)).Append("</span></td><td>").Append(priority).Append("</td><td>")
              .Append(delHtml).Append("</td><td>").Append(addHtml).Append("</td></tr>\n");
        }

        sb.Append("</tbody>\n</table>\n");
        if (changes.Count > shown)
            sb.Append("<p class=\"subtitle\" style=\"margin-top: 8px;\">&hellip; and ").Append(changes.Count - shown).Append(" more change(s) not listed.</p>\n");
        return sb.ToString();
    }

    /// <summary>
    /// Inserts the v3 blocks into the HTML produced by the unchanged v2 BuildSummaryHtml: the KPI strip before the
    /// first section heading and the change log before the footer. If a marker is missing the block is appended
    /// before &lt;/body&gt;, so nothing is ever lost.
    /// </summary>
    private static string InjectSummaryBlocks(string html, string insightsHtml, string changeLogHtml)
    {
        static string InsertBefore(string source, string marker, bool lastOccurrence, string block)
        {
            if (block.Length == 0) return source;
            int at = lastOccurrence ? source.LastIndexOf(marker, StringComparison.Ordinal) : source.IndexOf(marker, StringComparison.Ordinal);
            if (at < 0) at = source.LastIndexOf("</body>", StringComparison.OrdinalIgnoreCase);
            return at < 0 ? source + block : source.Insert(at, block);
        }

        html = InsertBefore(html, "<div class=\"footer\">", lastOccurrence: true, changeLogHtml);
        return InsertBefore(html, "<h3", lastOccurrence: false, insightsHtml);
    }
}
