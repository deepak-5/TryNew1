namespace Docuzen.Pdf.Core;

// NEW FILE. Page pairing derived from the word alignment (so an inserted page no longer misaligns every
// following page in side-by-side / raster comparison).

public static partial class PdfComparer
{
    internal static class PageAligner
    {
        /// <summary>
        /// Every equal word pair votes for (beforePage, afterPage). Candidate pairs need at least 15 % of the
        /// smaller page's words; the heaviest monotone chain of pairs wins. Gaps between chained pairs that
        /// hold the same number of pages on both sides are paired in order (rewritten or image-only pages);
        /// anything else becomes a deleted (Before, -1) or inserted (-1, After) page.
        /// With align = false, pages are paired by index exactly like v2.
        /// </summary>
        public static List<(int Before, int After)> Align(int pagesA, int pagesB,
            IEnumerable<(int A, int B)> equalWordPages, int[] wordsA, int[] wordsB, bool align)
        {
            var chain = new List<(int A, int B)>();
            if (!align)
            {
                for (int p = 0; p < Math.Min(pagesA, pagesB); p++) chain.Add((p, p));
            }
            else
            {
                var votes = new Dictionary<long, int>();
                foreach (var (pa, pb) in equalWordPages)
                {
                    long key = (long)pa * pagesB + pb;
                    votes[key] = votes.TryGetValue(key, out var v) ? v + 1 : 1;
                }

                var aS = new List<int>();
                var bS = new List<int>();
                var one = new List<int>();
                var weight = new List<double>();
                foreach (var kv in votes)
                {
                    int i = (int)(kv.Key / pagesB), j = (int)(kv.Key % pagesB);
                    if (kv.Value >= Math.Max(1.0, 0.15 * Math.Min(wordsA[i], wordsB[j])))
                    {
                        aS.Add(i); bS.Add(j); one.Add(1); weight.Add(kv.Value);
                    }
                }
                foreach (int i in DiffEngine.HeaviestChain(aS, bS, one, weight)) chain.Add((aS[i], bS[i]));
            }

            var slots = new List<(int Before, int After)>(Math.Max(pagesA, pagesB));
            int pi = 0, pj = 0;

            void Gap(int i1, int j1)
            {
                int ca = i1 - pi, cb = j1 - pj;
                if (ca == cb)
                {
                    for (int k = 0; k < ca; k++) slots.Add((pi + k, pj + k));
                }
                else
                {
                    for (int k = pi; k < i1; k++) slots.Add((k, -1));
                    for (int k = pj; k < j1; k++) slots.Add((-1, k));
                }
            }

            foreach (var (i, j) in chain)
            {
                Gap(i, j);
                slots.Add((i, j));
                pi = i + 1; pj = j + 1;
            }
            Gap(pagesA, pagesB);
            return slots;
        }
    }
}
