namespace Docuzen.Pdf.Core;

// REPLACEMENT for the original options file. Everything that existed in v2 keeps its name, type and default;
// all additions are new enum members (appended) or init-only properties, so existing callers compile unchanged.

/// <summary>Presentation mode for PDF visual comparison.</summary>
public enum PdfComparisonMode
{
    /// <summary>Single-pane redline: additions highlighted in place, deletions as margin callouts.</summary>
    VisualOverlay,

    /// <summary>Dual-pane: original on the left (deletions in red), modified on the right (additions in green).</summary>
    SideBySide,

    /// <summary>The modified document at 1:1 with native PDF annotations (highlights + notes), so every change shows up in the reader's comments pane.</summary>
    Annotated,

    /// <summary>Both pages blended as vector layers: red = only in original, cyan = only in modified, black = unchanged. Catches graphics, images and layout drift.</summary>
    OnionSkin,

    /// <summary>Bird's-eye contact sheet: thumbnails of every page with change marks, to see where a long document changed at a glance.</summary>
    ChangeMap,

    /// <summary>Re-flowed track-changes text (insertions underlined, deletions struck through, moves marked), independent of page layout.</summary>
    RedlineText,

    /// <summary>Report only: executive summary plus the classified change log, no page renderings.</summary>
    ChangeReport
}

/// <summary>How strictly two words are considered equal.</summary>
public enum PdfWordMatchMode
{
    /// <summary>Exact match after Unicode NFKC normalization and soft-hyphen removal. "-500" != "500", "Shall" != "shall".</summary>
    Strict,

    /// <summary>Like Strict but case-insensitive.</summary>
    IgnoreCase,

    /// <summary>Case-insensitive and ignores leading/trailing punctuation. Never ignores punctuation around digits.</summary>
    IgnoreCaseAndPunctuation,

    /// <summary>Strict, but curly/straight quotes and dash variants are folded (removes Word-vs-LaTeX export noise).</summary>
    Typographic,

    /// <summary>Typographic plus number formatting: "1,000" == "1000"; "$1.50" == "$1.5". Section-style numbers ("3.10" vs "3.1") stay different.</summary>
    NumericAware,

    /// <summary>Case, typography, edge punctuation, diacritics and number formatting are all folded.</summary>
    Loose,

    /// <summary>Loose plus common OCR confusions (O/0, l/I/1, rn/m). Lossy by design; for scanned-and-OCRed input.</summary>
    OcrTolerant
}

/// <summary>Composable equality rules. Set <see cref="PdfComparisonOptions.CustomMatchFlags"/> to override the preset.</summary>
[Flags]
public enum PdfMatchFlags
{
    None = 0,
    IgnoreCase = 1,
    FoldTypography = 2,
    IgnoreEdgePunctuation = 4,
    IgnoreDiacritics = 8,
    NormalizeNumbers = 16,
    OcrConfusables = 32
}

/// <summary>Unit of comparison.</summary>
public enum PdfDiffGranularity
{
    /// <summary>Word tokens (default). Finest result.</summary>
    Word,

    /// <summary>Whole sentences: any change marks the complete sentence.</summary>
    Sentence
}

/// <summary>How aggressively coincidental matches between two edits are absorbed into one replacement.</summary>
public enum PdfSemanticCleanup
{
    Off = 0,
    Conservative = 1,
    Aggressive = 2
}

public enum PdfChangeType
{
    Inserted,
    Deleted,
    Replaced,
    Moved,
    Number,
    Spelling,
    CaseOnly,
    PunctuationOnly,
    SpacingOnly,
    Formatting
}

/// <summary>Heuristic review priority. Critical = numeric content changed; High = negation / obligation wording changed (English word list).</summary>
public enum PdfChangeRisk
{
    Info,
    Low,
    Medium,
    High,
    Critical
}

/// <summary>One classified change, for programmatic consumers. Page numbers are 1-based; 0 means "no page on that side".</summary>
public sealed record PdfChangeRecord(
    int Id,
    PdfChangeType Type,
    PdfChangeRisk Risk,
    int BeforePage,
    int AfterPage,
    string DeletedText,
    string AddedText,
    string Note)
{
    /// <summary>Highlight boxes on <see cref="BeforePage"/> in page user space.</summary>
    public IReadOnlyList<PdfRect> BeforeBoxes { get; init; } = Array.Empty<PdfRect>();

    /// <summary>Highlight boxes on <see cref="AfterPage"/> in page user space.</summary>
    public IReadOnlyList<PdfRect> AfterBoxes { get; init; } = Array.Empty<PdfRect>();
}

/// <summary>One row of the page map. Page numbers are 1-based; 0 = page absent on that side (inserted / deleted page).</summary>
public sealed record PdfPageSlot(int BeforePage, int AfterPage);

/// <summary>Options controlling visual PDF comparison and output generation.</summary>
public sealed record PdfComparisonOptions
{
    public PdfComparisonMode Mode { get; init; } = PdfComparisonMode.VisualOverlay;

    /// <summary>Resolution in DPI for the raster fallback (scanned pages / pure drawings). Default 150.</summary>
    public double Dpi { get; init; } = 150.0;

    public bool IncludeSummaryPage { get; init; } = true;
    public bool OnlyChangedPages { get; init; } = false;
    public bool HighlightChangedRegions { get; init; } = true;

    /// <summary>Raster colour-difference threshold (1-255). Default 16.</summary>
    public int DifferenceThreshold { get; init; } = 16;

    public string? BeforeTitle { get; init; }
    public string? AfterTitle { get; init; }
    public int MaxPages { get; init; } = 500;
    public bool DrawMarginChangeBars { get; init; } = true;
    public bool IncludePageBanners { get; init; } = true;

    /// <summary>Not implemented in any version; retained so existing callers still compile.</summary>
    [Obsolete("DimUnchangedContent has no effect and will be removed.")]
    public bool DimUnchangedContent { get; init; } = true;

    // ── v2 ──────────────────────────────────────────────────────────────────

    /// <summary>Word equality preset. Default <see cref="PdfWordMatchMode.Strict"/>.</summary>
    public PdfWordMatchMode MatchMode { get; init; } = PdfWordMatchMode.Strict;

    /// <summary>Diff the whole document as one word stream so reflow does not mark every following page as changed. Default true.</summary>
    public bool AlignAcrossPages { get; init; } = true;

    /// <summary>Drop repeating headers/footers/page numbers from the comparison. Default true.</summary>
    public bool IgnoreHeadersAndFooters { get; init; } = true;

    /// <summary>Fraction of page height (0-0.25) at the top and bottom treated as header/footer candidates. Default 0.08.</summary>
    public double HeaderFooterBandFraction { get; init; } = 0.08;

    /// <summary>Minimum fraction of pages (0-1) a header/footer pattern must appear on. Default 0.5 (and at least 3 pages).</summary>
    public double HeaderFooterMinPageFraction { get; init; } = 0.5;

    /// <summary>
    /// Upper bound on the Myers edit distance explored per bisection. v3 no longer gives up beyond it: the region
    /// is split heuristically and diffing continues (reported as a warning). Default 4000.
    /// </summary>
    public int MaxDiffCost { get; init; } = 4000;

    /// <summary>Append the full text of every change to the summary. Default true.</summary>
    public bool IncludeDeletedTextInSummary { get; init; } = true;

    /// <summary>Max parallel page extractions. Default 1 because the extractor's thread-safety is not guaranteed.</summary>
    public int MaxDegreeOfParallelism { get; init; } = 1;

    /// <summary>Clock used for timestamps. Inject a fixed clock for byte-for-byte deterministic output.</summary>
    public Func<DateTime>? UtcNow { get; init; }

    /// <summary>Cancellation support for long comparisons.</summary>
    public CancellationToken CancellationToken { get; init; } = default;

    // ── v3 ──────────────────────────────────────────────────────────────────

    /// <summary>Overrides <see cref="MatchMode"/> with an explicit flag combination.</summary>
    public PdfMatchFlags? CustomMatchFlags { get; init; }

    /// <summary>Unit of comparison. Default Word.</summary>
    public PdfDiffGranularity Granularity { get; init; } = PdfDiffGranularity.Word;

    /// <summary>
    /// Split leading/trailing punctuation into its own token, so "agreement," → "agreement." flags only the comma.
    /// Tokens containing digits are never split. Ignored when the match rule ignores edge punctuation. Default true.
    /// </summary>
    public bool SplitPunctuation { get; init; } = true;

    /// <summary>Absorb coincidental matches stranded between two edits. Default Conservative.</summary>
    public PdfSemanticCleanup SemanticCleanup { get; init; } = PdfSemanticCleanup.Conservative;

    /// <summary>Slide ambiguous insertions/deletions to sentence and paragraph boundaries. Default true.</summary>
    public bool ShiftChangeBoundaries { get; init; } = true;

    /// <summary>Report text that was deleted in one place and inserted verbatim elsewhere as a move. Default true.</summary>
    public bool DetectMoves { get; init; } = true;

    /// <summary>Minimum block length (tokens) to qualify as a move. Default 5.</summary>
    public int MinMoveWords { get; init; } = 5;

    /// <summary>
    /// Pair pages by content instead of by index, so inserted/deleted pages do not misalign later pages in the
    /// rendered output and in raster comparison. Requires <see cref="AlignAcrossPages"/>. Default true.
    /// </summary>
    public bool AlignPages { get; init; } = true;

    /// <summary>Classify each change (number, spelling, case-only, ...) and assign a review priority. Default true.</summary>
    public bool ClassifyChanges { get; init; } = true;

    /// <summary>Flag unchanged words whose font size changed relative to the document-wide scale. Default false.</summary>
    public bool DetectFormattingChanges { get; init; } = false;

    /// <summary>Relative font-size deviation that counts as a formatting change. Default 0.08 (8 %).</summary>
    public double FormattingTolerance { get; init; } = 0.08;

    /// <summary>Ignore one-pixel edge shimmer in raster comparison. Default true.</summary>
    public bool TolerateAntiAliasing { get; init; } = true;

    /// <summary>Largest uniform page shift (raster pixels) removed before raster comparison; 0 disables registration. Default 2.</summary>
    public int MaxRasterShiftPixels { get; init; } = 2;

    /// <summary>Thumbnails per row in <see cref="PdfComparisonMode.ChangeMap"/>. Default 5.</summary>
    public int ChangeMapColumns { get; init; } = 5;

    /// <summary>Author shown on annotations in <see cref="PdfComparisonMode.Annotated"/>.</summary>
    public string AnnotationAuthor { get; init; } = "Docuzen Compare";

    /// <summary>Engine tuning: maximal unique phrase anchors. Default true.</summary>
    public bool UsePhraseAnchors { get; init; } = true;

    /// <summary>Engine tuning: unique-token patience anchors. Default true.</summary>
    public bool UseTokenAnchors { get; init; } = true;
}

/// <summary>Change metrics for a single comparison slot. Counts are in WORDS (or changed raster pixels on the raster path).</summary>
public sealed record PdfPageVisualDiff(
    int PageNumber,
    bool BeforeExists,
    bool AfterExists,
    bool Changed,
    int ChangedPixelCount,
    int DeletedPixelCount,
    int AddedPixelCount,
    int ModifiedPixelCount,
    double ChangePercentage,
    int AddedLinesCount,
    int RemovedLinesCount)
{
    /// <summary>True when this slot was compared via the raster path (no extractable text on at least one side).</summary>
    public bool UsedRasterFallback { get; init; }

    /// <summary>1-based page in the original document, 0 if this slot is an inserted page.</summary>
    public int BeforePageNumber { get; init; }

    /// <summary>1-based page in the modified document, 0 if this slot is a deleted page.</summary>
    public int AfterPageNumber { get; init; }

    /// <summary>Words on this slot that were moved (from or to).</summary>
    public int MovedWordCount { get; init; }

    /// <summary>Unchanged words whose formatting changed (only with DetectFormattingChanges).</summary>
    public int FormattingChangeCount { get; init; }
}

/// <summary>Complete visual comparison result.</summary>
public sealed record PdfVisualComparisonResult(
    byte[] PdfBytes,
    PdfDiffReport Report,
    IReadOnlyList<PdfPageVisualDiff> PageDiffs,
    int ChangedPagesCount,
    int TotalDeletions,
    int TotalAdditions,
    bool IsIdentical)
{
    /// <summary>Non-fatal problems (summary page failed, bookmarks failed, approximated diff regions...).</summary>
    public IReadOnlyList<string> Warnings { get; init; } = Array.Empty<string>();

    /// <summary>Every change, classified, in document order.</summary>
    public IReadOnlyList<PdfChangeRecord> Changes { get; init; } = Array.Empty<PdfChangeRecord>();

    /// <summary>How pages were paired.</summary>
    public IReadOnlyList<PdfPageSlot> PageMap { get; init; } = Array.Empty<PdfPageSlot>();

    /// <summary>Number of moved blocks.</summary>
    public int TotalMoves { get; init; }

    /// <summary>In-place similarity of the two word streams, 0..1 (2 x equal words / total words).</summary>
    public double Similarity { get; init; } = 1.0;

    public void Save(string path)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(path);
        File.WriteAllBytes(path, PdfBytes);
    }

    public void WriteTo(Stream stream)
    {
        ArgumentNullException.ThrowIfNull(stream);
        stream.Write(PdfBytes, 0, PdfBytes.Length);
    }
}
