# Docuzen Compare Engine v3 - integration guide

## 1. What to do with each file

| File | Action | Notes |
|---|---|---|
| `PdfComparer.DiffEngine.cs` | **Replace** your DiffEngine file | Same type names; `DiffEngine.Diff(a, b, maxCost, ct)` still exists. |
| `PdfComparisonOptions.cs` | **Replace** your options file | Every v2 member keeps name, type and default. New enum members are appended. |
| `PdfComparer.Words.cs` | **Replace** your word-model / extraction / alignment file | Contains `ComparisonWord`, `WordDiffItem`, `SemanticDiffChange`, `ExtractDocument`, `AlignWords`, `BuildSemanticChanges`, `ClusterWordsIntoBoxes`. |
| `PdfComparer.Pipeline.cs` | **Replace** your entry-point / `CompareVisual` file | Also holds the constants, `WritePdf`, `ValidateComparisonOptions`. |
| `PdfComparer.DiffRefine.cs` | **Add** | Boundary shifting, semantic cleanup, move detection, char diff. |
| `PdfComparer.Normalization.cs` | **Add** | Match modes / `MatchKey`. |
| `PdfComparer.PageAlignment.cs` | **Add** | Content-based page pairing. |
| `PdfComparer.RasterDiff.cs` | **Add** | Raster core on plain byte arrays. |
| `PdfComparer.Renderers.cs` | **Add** | `RenderSideBySideSlot`, `RenderOverlaySlot` (page-pair aware). |
| `PdfComparer.Modes.cs` | **Add** | Annotated, OnionSkin, ChangeMap, RedlineText, ChangeReport + summary blocks. |
| `tests/*` | **Do not add to your project** | Standalone harness. `AssumedApi.cs` contains stand-ins for your library. |

Keep these files of yours **unchanged**: the overlay / text-metrics file, the raster + summary file, the
geometry / side-by-side file, and the `PdfDocument` partial.

After the swap these v2 members are no longer called (delete them or leave them, both compile):
`RenderOverlayPage`, `RenderSideBySidePage`, `AnalyzeRasterDifferences`, `OverlapsAnyWord`, `BuildChangeRows`.

## 2. Two optional one-line edits in your summary file

`BuildSummaryHtml` hard-codes two descriptions that do not know the new enum values. Replace them with:

```csharp
var modeDesc  = DescribeMode(options.Mode);
var matchDesc = DescribeMatch(options);
```

Nothing else in that file needs to change. The v3 KPI strip and the classified change log are inserted into the
HTML it returns by `InjectSummaryBlocks` (before the first `<h3` and before `<div class="footer">`; if a marker is
missing the block is appended before `</body>`).

## 3. Using the new features

```csharp
var result = PdfComparer.CompareVisual(before, after, new PdfComparisonOptions
{
    Mode = PdfComparisonMode.Annotated,          // VisualOverlay | SideBySide | Annotated | OnionSkin | ChangeMap | RedlineText | ChangeReport
    MatchMode = PdfWordMatchMode.Typographic,    // Strict | IgnoreCase | IgnoreCaseAndPunctuation | Typographic | NumericAware | Loose | OcrTolerant
    DetectMoves = true,
    DetectFormattingChanges = true,
});

foreach (var c in result.Changes.Where(c => c.Risk >= PdfChangeRisk.High))
    Console.WriteLine($"p.{c.AfterPage} {c.Type} [{c.Risk}] {c.DeletedText} -> {c.AddedText} {c.Note}");

Console.WriteLine($"similarity {result.Similarity:P1}, {result.TotalMoves} moved blocks");
```

To get exactly the v2 behaviour back (for A/B testing):

```csharp
new PdfComparisonOptions
{
    SplitPunctuation = false, SemanticCleanup = PdfSemanticCleanup.Off, ShiftChangeBoundaries = false,
    DetectMoves = false, AlignPages = false, ClassifyChanges = false,
    TolerateAntiAliasing = false, MaxRasterShiftPixels = 0,
}
```

(The diff core itself is always v3; with these switches it produces a plain minimal-ish script like v2 did,
minus the "give up at MaxDiffCost" behaviour.)

## 4. What has been verified - and what has not

Verified on .NET SDK 8.0.427 (`cd tests && dotnet run -c Release`):

* All ten v3 files compile together with **0 errors, 0 warnings** against the stand-ins in `tests/AssumedApi.cs`.
* `EngineFuzz`: 24,000 randomised cases. Every edit script is a valid A -> B transformation (including the cases
  that hit the cost cap); with anchors off and no cap the script is minimal (checked against an LCS table);
  boundary shifting and semantic cleanup keep scripts valid; every detected move is a verbatim, non-overlapping
  block; the heaviest-chain equals brute force.
* Targeted tests for the match modes, page alignment and the raster core (synthetic images).
* 200,000 x 200,000 tokens diff in well under a second on a small build machine.

**Not verified:** anything that touches the real Docuzen.Pdf library. I never had it, so no PDF was produced by
this code. `AssumedApi.cs` lists every signature I inferred from your source - if one differs, that is where the
compiler will complain. In particular, please test these with real documents before shipping:

* `Annotated`: annotations are created without appearance streams (viewers synthesise them for Highlight / Text /
  StrikeOut). Check that `PdfOperations.Merge` and `PdfBookmarks.Apply` preserve `/Annots`.
* `OnionSkin`: relies on transparency-group Form XObjects and the Screen / Multiply blend modes, written as raw
  `CosStream`s. Check the writer emits them as-is.
* `ChangeMap`: assumes `PdfImposition.FitPageToCell` scales a page to fit the cell and preserves aspect ratio.
* `RedlineText` / summary blocks: assume `HtmlToPdf` supports `<ins>`, `<del>`, `border-bottom` and the classes
  already used by your summary template.

## 5. Known limitations (by design, not bugs)

* **Review priority is a heuristic.** Critical = a changed token contains a digit; High = an English negation /
  obligation word (`not`, `shall`, `may`, `must`, `unless`, ...) is involved. Edit the `RiskWords` set for other
  languages or domains.
* **Moved-and-edited blocks** are reported as several verbatim move fragments with ordinary edits between them,
  not as one "moved with changes" block.
* **NumericAware** understands `1,000.50`-style numbers. `1.000,50` (comma decimal) is left untouched. Trailing
  decimal zeros are folded only next to a currency symbol or `%`, so `3.10` and `3.1` (section numbers) differ.
* **Formatting detection** only sees font size (that is all `ComparisonWord` carries). Font family, weight and
  colour need those attributes from the character extractor first.
* **Page pairing** needs `AlignAcrossPages = true`. Pages with no matching words are paired in order only when
  the gap has the same number of pages on both sides; otherwise they are reported as deleted + inserted.
* **Raster box origin** is corrected for unrotated pages only.
* **Sentence granularity** uses a punctuation heuristic for sentence ends (abbreviations like "e.g." split early).
* `MaxDiffCost` no longer truncates results, but a region that hits it is diffed approximately (a warning is added).
