namespace Docuzen.Pdf.Core;

// NEW FILE. Raster comparison core working on plain RGB byte arrays (3 bytes per pixel, row-major, top-down),
// so it has no dependency on the rasteriser and can be unit-tested with synthetic images.

public static partial class PdfComparer
{
    internal sealed class RasterDiffCoreResult
    {
        public bool Changed { get; set; }
        public int ChangedPixels { get; set; }
        public int DeletedPixels { get; set; }
        public int AddedPixels { get; set; }
        public int SampledPixels { get; set; }
        /// <summary>Global registration offset applied to the AFTER image before comparing (pixels).</summary>
        public int ShiftX { get; set; }
        public int ShiftY { get; set; }
        /// <summary>Changed regions in raster pixels, y pointing down, exclusive right/bottom.</summary>
        public List<(int X0, int Y0, int X1, int Y1)> Boxes { get; } = new();
    }

    /// <summary>
    /// v3 raster comparison:
    ///   • perceptual YIQ colour distance instead of per-channel absolute difference
    ///   • global registration: a uniform shift of up to maxShift pixels (scanner / renderer offset) is estimated and removed
    ///   • anti-aliasing tolerance: a differing pixel is ignored when its colour exists in the 3x3 neighbourhood
    ///     of the other image AND vice versa (kills 1-pixel edge shimmer, still catches thin added/removed lines)
    ///   • every pixel is examined (v2 sampled one in four), then dirty 16-px cells are clustered and nearby boxes merged
    /// </summary>
    internal static class RasterDiffCore
    {
        private const int G = 16;

        public static RasterDiffCoreResult Analyze(byte[] before, int bw, int bh, byte[] after, int aw, int ah,
            int threshold, bool tolerateAntiAliasing = true, int maxShift = 2)
        {
            var res = new RasterDiffCoreResult { SampledPixels = 1 };
            int w = Math.Min(bw, aw), h = Math.Min(bh, ah);
            bool sizeDiffers = bw != aw || bh != ah;
            if (w <= 0 || h <= 0 || before.Length < (long)bw * bh * 3 || after.Length < (long)aw * ah * 3)
            {
                res.Changed = sizeDiffers;
                return res;
            }

            var (dx, dy) = maxShift > 0 ? EstimateShift(before, bw, after, aw, w, h, Math.Min(maxShift, 8)) : (0, 0);
            res.ShiftX = dx;
            res.ShiftY = dy;

            double t = Math.Clamp(threshold, 1, 255) / 255.0;
            double maxDelta = 35215.0 * t * t;
            int cols = (w + G - 1) / G, rows = (h + G - 1) / G;
            var dirty = new int[cols * rows];
            int changed = 0, deleted = 0, added = 0, sampled = 0;

            for (int y = 0; y < h; y++)
            {
                int ya = y + dy;
                if (ya < 0 || ya >= h) continue;
                for (int x = 0; x < w; x++)
                {
                    int xa = x + dx;
                    if (xa < 0 || xa >= w) continue;
                    sampled++;
                    int ib = (y * bw + x) * 3, ia = (ya * aw + xa) * 3;
                    if (before[ib] == after[ia] && before[ib + 1] == after[ia + 1] && before[ib + 2] == after[ia + 2]) continue;
                    if (Delta(before, ib, after, ia) <= maxDelta) continue;
                    if (tolerateAntiAliasing &&
                        FoundNearby(before, ib, after, aw, w, h, xa, ya, maxDelta) &&
                        FoundNearby(after, ia, before, bw, w, h, x, y, maxDelta)) continue;

                    changed++;
                    if (Lum(before, ib) < Lum(after, ia)) deleted++; else added++;
                    dirty[(y / G) * cols + x / G]++;
                }
            }

            res.Changed = changed > 40 || sizeDiffers;
            res.ChangedPixels = changed;
            res.DeletedPixels = deleted;
            res.AddedPixels = added;
            res.SampledPixels = Math.Max(1, sampled);

            // Cluster dirty cells (8-connected flood fill).
            var visited = new bool[cols * rows];
            var queue = new Queue<(int C, int R)>();
            var boxes = new List<(int X0, int Y0, int X1, int Y1)>();
            for (int r = 0; r < rows; r++)
            {
                for (int c = 0; c < cols; c++)
                {
                    int idx = r * cols + c;
                    if (visited[idx] || dirty[idx] < 6) continue;
                    int minC = c, maxC = c, minR = r, maxR = r, total = 0;
                    visited[idx] = true;
                    queue.Enqueue((c, r));
                    while (queue.Count > 0)
                    {
                        var (cc, cr) = queue.Dequeue();
                        total += dirty[cr * cols + cc];
                        minC = Math.Min(minC, cc); maxC = Math.Max(maxC, cc);
                        minR = Math.Min(minR, cr); maxR = Math.Max(maxR, cr);
                        for (int ddy = -1; ddy <= 1; ddy++)
                        {
                            for (int ddx = -1; ddx <= 1; ddx++)
                            {
                                if (ddx == 0 && ddy == 0) continue;
                                int nc = cc + ddx, nr = cr + ddy;
                                if (nc < 0 || nc >= cols || nr < 0 || nr >= rows) continue;
                                int nidx = nr * cols + nc;
                                if (visited[nidx] || dirty[nidx] < 3) continue;
                                visited[nidx] = true;
                                queue.Enqueue((nc, nr));
                            }
                        }
                    }
                    if (total >= 20)
                        boxes.Add((minC * G, minR * G, Math.Min(w, (maxC + 1) * G), Math.Min(h, (maxR + 1) * G)));
                }
            }

            // Merge boxes that touch or sit within one cell of each other.
            bool mergedAny = true;
            while (mergedAny)
            {
                mergedAny = false;
                for (int i = 0; i < boxes.Count && !mergedAny; i++)
                {
                    for (int j = i + 1; j < boxes.Count; j++)
                    {
                        var p = boxes[i];
                        var q = boxes[j];
                        if (p.X0 > q.X1 + G || q.X0 > p.X1 + G || p.Y0 > q.Y1 + G || q.Y0 > p.Y1 + G) continue;
                        boxes[i] = (Math.Min(p.X0, q.X0), Math.Min(p.Y0, q.Y0), Math.Max(p.X1, q.X1), Math.Max(p.Y1, q.Y1));
                        boxes.RemoveAt(j);
                        mergedAny = true;
                        break;
                    }
                }
            }
            res.Boxes.AddRange(boxes);
            return res;
        }

        private static int Lum(byte[] p, int i) => (p[i] * 299 + p[i + 1] * 587 + p[i + 2] * 114) / 1000;

        /// <summary>Squared perceptual colour distance in YIQ space (same metric as pixelmatch; max 35215).</summary>
        private static double Delta(byte[] p, int i, byte[] q, int j)
        {
            double dr = p[i] - q[j], dg = p[i + 1] - q[j + 1], db = p[i + 2] - q[j + 2];
            double y = dr * 0.29889531 + dg * 0.58662247 + db * 0.11448223;
            double ii = dr * 0.59597799 - dg * 0.27417610 - db * 0.32180189;
            double qq = dr * 0.21147017 - dg * 0.52261711 + db * 0.31114694;
            return 0.5053 * y * y + 0.299 * ii * ii + 0.1957 * qq * qq;
        }

        private static bool FoundNearby(byte[] src, int si, byte[] dst, int dstStride, int w, int h, int cx, int cy, double maxDelta)
        {
            for (int ny = cy - 1; ny <= cy + 1; ny++)
            {
                if (ny < 0 || ny >= h) continue;
                for (int nx = cx - 1; nx <= cx + 1; nx++)
                {
                    if (nx < 0 || nx >= w) continue;
                    if (Delta(src, si, dst, (ny * dstStride + nx) * 3) <= maxDelta) return true;
                }
            }
            return false;
        }

        /// <summary>Exhaustive SAD search on a sparse luminance grid. A shift is only accepted when it removes at least 40 % of the difference.</summary>
        private static (int Dx, int Dy) EstimateShift(byte[] before, int bw, byte[] after, int aw, int w, int h, int max)
        {
            if (w < 64 || h < 64) return (0, 0);
            long best = long.MaxValue, zero = 0;
            int bx = 0, by = 0;
            for (int dy = -max; dy <= max; dy++)
            {
                for (int dx = -max; dx <= max; dx++)
                {
                    long sad = 0;
                    for (int y = max; y < h - max; y += 3)
                        for (int x = max; x < w - max; x += 3)
                            sad += Math.Abs(Lum(before, (y * bw + x) * 3) - Lum(after, ((y + dy) * aw + x + dx) * 3));
                    if (dx == 0 && dy == 0) zero = sad;
                    if (sad < best || (sad == best && Math.Abs(dx) + Math.Abs(dy) < Math.Abs(bx) + Math.Abs(by)))
                    {
                        best = sad; bx = dx; by = dy;
                    }
                }
            }
            return zero > 0 && best < zero * 0.6 ? (bx, by) : (0, 0);
        }
    }
}
