import type { Metadata, Viewport } from "next";
import "./globals.css";
import { AppShell } from "@/components/app-shell";
import { WorkspaceProvider } from "@/components/workspace-provider";
import { ToastProvider } from "@/components/toast";

export const metadata: Metadata = {
  title: { default: "Docuzen PDF console", template: "%s · Docuzen" },
  description:
    "The desktop console for the Docuzen PDF engine: inspect, convert, restructure, redact, sign and compare documents with the same managed .NET code path that powers the CLI."
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#fbfcfa"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <WorkspaceProvider>
          <ToastProvider>
            <AppShell>{children}</AppShell>
          </ToastProvider>
        </WorkspaceProvider>
      </body>
    </html>
  );
}
