"use client";

import { Suspense, useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import clsx from "clsx";
import { ArrowLeftRight, CheckCircle2, FileDiff } from "lucide-react";
import { tools } from "@/lib/api";
import { useWorkspace } from "@/components/workspace-provider";
import { useToolRun } from "@/lib/use-tool-run";
import type { CompareReport } from "@/lib/types";
import { formatNumber } from "@/lib/format";
import { ResultPanel } from "@/components/result-panel";
import { ConfigCard, DocumentSelect, RunBar, SectionDivider } from "@/components/tool-form";
import { ReportSection } from "@/components/report-view";
import { Callout, Checkbox, NumberInput, PageHeader, Pill, Select, TextInput } from "@/components/ui";

export default function ComparePage() {
  // `useSearchParams` opts a page out of static prerendering; the boundary keeps the
  // rest of the route prerenderable and stops `next build` from failing on it.
  return (
    <Suspense fallback={<CompareFallback />}>
      <CompareWorkbench />
    </Suspense>
  );
}

function CompareFallback() {
  return (
    <div>
      <PageHeader eyebrow="Transform" title="Compare" description="Loading the comparison workbench…" />
    </div>
  );
}

function CompareWorkbench() {
  const { pdfs, currentId } = useWorkspace();
  const params = useSearchParams();
  const [before, setBefore] = useState(params.get("before") ?? "");
  const [after, setAfter] = useState(params.get("after") ?? "");
  const [visual, setVisual] = useState(true);
  const [mode, setMode] = useState("visual");
  const [dpi, setDpi] = useState("150");
  const [threshold, setThreshold] = useState("16");
  const [onlyChanged, setOnlyChanged] = useState(false);
  const { result, error, pending, run, reset } = useToolRun<CompareReport>();

  useEffect(() => {
    if (pdfs.length === 0) return;
    const current = pdfs.find((pdf) => pdf.id === currentId) ?? pdfs[pdfs.length - 1];
    const parent = current.parentId ? pdfs.find((pdf) => pdf.id === current.parentId) : undefined;
    const other = pdfs.find((pdf) => pdf.id !== current.id);
    setBefore((value) => value || parent?.id || other?.id || current.id);
    setAfter((value) => value || current.id);
    // Only seed the pickers once the workspace has documents.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pdfs.length, currentId]);

  const sameDocument = Boolean(before) && before === after;

  return (
    <div>
      <PageHeader
        eyebrow="Transform"
        title="Compare"
        description="Text deltas with move detection, page pairing, and a rendered visual diff written as its own PDF."
      />

      <div className="split-wrap">
        <ConfigCard
          description="Both documents must differ. The text walk always runs; the visual diff is optional."
          footer={
            <RunBar
              label="Compare documents"
              pending={pending}
              disabled={!before || !after || sameDocument}
              onRun={() =>
                run(() =>
                  tools.compare({
                    beforeId: before,
                    afterId: after,
                    visual,
                    mode,
                    dpi: Number(dpi),
                    threshold: Number(threshold),
                    onlyChangedPages: onlyChanged
                  })
                )
              }
              hint={sameDocument ? "Choose two different documents." : undefined}
            />
          }
        >
          <DocumentSelect
            label="Before"
            include="pdf"
            value={before}
            onChange={setBefore}
          />
          <div>
            <div className="mb-1 flex items-center justify-end">
              <button
                type="button"
                onClick={() => {
                  setBefore(after);
                  setAfter(before);
                }}
                title="Swap the two documents"
                className="inline-flex items-center gap-1 rounded text-[11px] font-medium text-muted transition hover:text-accent"
              >
                <ArrowLeftRight className="size-3" />
                Swap
              </button>
            </div>
            <DocumentSelect
              label="After"
              include="pdf"
              value={after}
              onChange={setAfter}
            />
          </div>

          <SectionDivider label="Visual diff" />
          <Checkbox label="Render a visual diff PDF" hint="Overlay or side-by-side pages with changed regions highlighted." checked={visual} onChange={setVisual} />
          {visual ? (
            <>
              <div>
                <span className="label">Mode</span>
                <Select
                  value={mode}
                  onChange={(event) => setMode(event.target.value)}
                  options={[
                    { value: "visual", label: "Overlay — differences highlighted in place" },
                    { value: "side-by-side", label: "Side by side" }
                  ]}
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <span className="label">Render dpi</span>
                  <NumberInput value={dpi} onChange={setDpi} min={36} max={600} step={12} />
                </div>
                <div>
                  <span className="label">Difference threshold</span>
                  <NumberInput value={threshold} onChange={setThreshold} min={1} max={200} />
                </div>
              </div>
              <Checkbox label="Only pages that differ" hint="Keeps the diff short for long documents." checked={onlyChanged} onChange={setOnlyChanged} />
            </>
          ) : null}
        </ConfigCard>

        <ResultPanel
          result={result}
          error={error}
          pending={pending}
          onReset={reset}
          emptyIcon={FileDiff}
          emptyTitle="No comparison yet"
          emptyDescription="Pick a before and an after revision. Text changes are listed per page; the visual diff PDF is rendered beside them."
          renderReport={(report) => <CompareView report={report} />}
        />
      </div>
    </div>
  );
}

function CompareView({ report }: { report: CompareReport }) {
  const identical = report.text.identical && (report.visual?.identical ?? true);
  const pages = report.text.pages;
  const changedPages = pages.filter((page) => page.changed || !page.beforeExists || !page.afterExists);

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center gap-2">
        <Pill tone={identical ? "accent" : "warn"}>{identical ? "identical" : "differences found"}</Pill>
        <Pill>{report.text.beforePages} → {report.text.afterPages} pages</Pill>
        <Pill tone={changedPages.length ? "warn" : "neutral"}>{changedPages.length} page{changedPages.length === 1 ? "" : "s"} changed</Pill>
        {report.visual ? (
          <>
            <Pill tone="accent">{formatNumber(report.visual.additions)} additions</Pill>
            <Pill tone="danger">{formatNumber(report.visual.deletions)} deletions</Pill>
            {report.visual.moves > 0 ? <Pill>{report.visual.moves} move{report.visual.moves === 1 ? "" : "s"}</Pill> : null}
            <Pill>{Math.round(report.visual.similarity * 100)}% similar</Pill>
          </>
        ) : null}
      </div>

      {identical ? (
        <Callout tone="success" title="The two revisions match">
          The text walk found no line changes and the raster comparison found no page differences above the threshold.
        </Callout>
      ) : null}

      {changedPages.length > 0 ? (
        <ReportSection title="Page changes" hint="Removed lines in red, added lines in green">
          <div className="space-y-2.5">
            {changedPages.map((page) => (
              <div key={page.page} className="overflow-hidden rounded-lg border border-line">
                <div className="flex items-center gap-2 border-b border-line bg-surface-muted px-3 py-1.5">
                  <span className="text-[11.5px] font-medium text-ink">Page {page.page}</span>
                  {!page.beforeExists ? <Pill tone="accent">added</Pill> : null}
                  {!page.afterExists ? <Pill tone="danger">removed</Pill> : null}
                  {page.visualChanged ? <Pill tone="warn">visual change</Pill> : null}
                </div>
                {page.removed.length === 0 && page.added.length === 0 ? (
                  <p className="px-3 py-2 text-[11.5px] text-muted">The page changed visually; no text lines differ.</p>
                ) : (
                  <div className="divide-y divide-line font-mono text-[11.5px] leading-[1.55]">
                    {page.removed.map((line, index) => (
                      <div key={`r-${index}`} className="flex gap-2 bg-[#fdf3f1] px-3 py-1 text-[#7c2d24]">
                        <span className="shrink-0 select-none opacity-60">−</span>
                        <span className="whitespace-pre-wrap break-words">{line}</span>
                      </div>
                    ))}
                    {page.added.map((line, index) => (
                      <div key={`a-${index}`} className="flex gap-2 bg-[#f0f8f2] px-3 py-1 text-[#14532d]">
                        <span className="shrink-0 select-none opacity-60">+</span>
                        <span className="whitespace-pre-wrap break-words">{line}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </ReportSection>
      ) : null}

      {report.visual && report.visual.changes.length > 0 ? (
        <ReportSection title="Classified changes" hint="From the raster diff">
          <div className="overflow-hidden rounded-lg border border-line">
            {report.visual.changes.slice(0, 60).map((change) => (
              <div key={change.id} className="flex items-start gap-3 border-b border-line px-3 py-2 text-[12px] last:border-b-0">
                <span
                  className={clsx(
                    "mt-0.5 shrink-0 rounded px-1.5 py-0.5 text-[10px] font-medium uppercase tracking-[0.04em]",
                    change.risk === "high" ? "bg-danger-soft text-danger" : change.risk === "medium" ? "bg-warn-soft text-warn" : "bg-[#eef1ee] text-muted"
                  )}
                >
                  {change.type}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="text-ink-soft">{change.note || change.type}</p>
                  <p className="text-[10.5px] text-faint">
                    page {change.beforePage || "—"} → {change.afterPage || "—"}
                    {change.deletedText ? ` · removed “${change.deletedText.slice(0, 60)}”` : ""}
                    {change.addedText ? ` · added “${change.addedText.slice(0, 60)}”` : ""}
                  </p>
                </div>
              </div>
            ))}
          </div>
          {report.visual.changesTruncated ? <p className="mt-2 text-[11px] text-faint">The change list was truncated; see the visual diff artifact for the full picture.</p> : null}
        </ReportSection>
      ) : null}

      {report.visual && report.visual.changes.length === 0 && !identical ? (
        <Callout tone="info" title="No classified changes">
          The raster diff found page-level differences but no discrete change records. The overlay PDF shows where the pixels moved.
        </Callout>
      ) : null}

      {report.warnings.length > 0 ? (
        <Callout tone="warn" title={`${report.warnings.length} warning(s)`}>
          <ul className="list-disc space-y-0.5 pl-4">
            {report.warnings.map((warning, index) => (
              <li key={index}>{warning}</li>
            ))}
          </ul>
        </Callout>
      ) : null}

      {identical ? <CheckCircle2 className="hidden size-0" /> : null}
    </div>
  );
}
