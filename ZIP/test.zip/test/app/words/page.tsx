"use client";

import { useEffect, useState } from "react";
import { BookDown, BookMarked, FileCode2, Layers, MessageSquare, Settings2, Shapes, Sparkles, Wand2 } from "lucide-react";
import { parseCsv, words as wordsApi } from "@/lib/engine-api";
import { useEngineDocument } from "@/lib/use-engine-document";
import { useHashTab } from "@/lib/use-hash-tab";
import { useWorkspace } from "@/components/workspace-provider";
import { useToolRun } from "@/lib/use-tool-run";
import { ResultPanel } from "@/components/result-panel";
import { ConfigCard, DocumentSelect, InlineFields, RunBar, SectionDivider } from "@/components/tool-form";
import { Callout, Checkbox, Field, NumberInput, PageHeader, Segmented, Select, Tabs, TextArea, TextInput } from "@/components/ui";
import { GenericReport } from "@/components/report-view";

const TABS = [
  { id: "author", label: "Author", icon: BookDown },
  { id: "convert", label: "Convert & extract", icon: FileCode2 },
  { id: "edit", label: "Replace", icon: Wand2 },
  { id: "fields", label: "Fields & properties", icon: BookMarked },
  { id: "merge", label: "Fill & merge", icon: Sparkles },
  { id: "compose", label: "Compose", icon: Layers },
  { id: "review", label: "Review", icon: MessageSquare },
  { id: "graphics", label: "Drawings", icon: Shapes },
  { id: "document", label: "Document", icon: Settings2 }
];

const CONVERT_TARGETS = [
  { id: "pdf", label: "PDF" },
  { id: "png", label: "PNG (page 1)" },
  { id: "svg", label: "SVG (page 1)" },
  { id: "html", label: "HTML" },
  { id: "markdown", label: "Markdown (GFM)" },
  { id: "rtf", label: "RTF" },
  { id: "text", label: "Plain text" }
];

const SAMPLE_MARKDOWN = `# Supplier onboarding memo

Northwind Analytics is moving invoice intake to a single queue from **1 December**.

## What changes

- One intake address for all suppliers
- Automated validation on receipt
- Two-step approval for anything above ₹2,00,000

## Contacts

| Team | Owner |
| --- | --- |
| Intake | Priya Raghavan |
| Escalation | Arun Mehta |
`;

/**
 * Review threads are a tree, not a table. The generic renderer flattened each reply into
 * one long cell, so a thread reads here as what it is: a comment, its replies, and whether
 * the file marks it resolved.
 */
function CommentsReport({ report }: { report: Record<string, unknown> }) {
  const comments = (report.comments as Array<Record<string, unknown>> | undefined) ?? [];
  const threads = comments.filter((comment) => comment.parentId == null);
  const repliesOf = (id: unknown) => comments.filter((comment) => comment.parentId === id);

  const line = (comment: Record<string, unknown>, depth: number) => (
    <div
      key={String(comment.id)}
      className={
        depth === 0
          ? "rounded-lg border border-line bg-surface px-3.5 py-3"
          : "ml-4 rounded-lg border border-line bg-surface-muted px-3 py-2"
      }
    >
      <div className="flex flex-wrap items-baseline gap-2">
        <span className="text-[12.5px] font-medium text-ink">{String(comment.author)}</span>
        <span className="font-mono text-[10.5px] text-faint">#{String(comment.id)}</span>
        {comment.isResolved ? (
          <span className="pill border border-accent-line bg-accent-soft px-1.5 py-px text-[10.5px] text-accent-strong">resolved</span>
        ) : null}
        <span className="ml-auto text-[10.5px] text-faint">
          {comment.date ? new Date(String(comment.date)).toLocaleDateString() : "no date stored"}
        </span>
      </div>
      <p className="mt-1 text-[12.5px] leading-[1.5] text-ink-soft">{String(comment.text)}</p>
    </div>
  );

  return (
    <div className="space-y-2.5">
      <div className="flex flex-wrap gap-x-6 gap-y-1 text-[11.5px] text-muted">
        <span>
          <span className="font-medium text-ink">{comments.length}</span> comments
        </span>
        <span>
          <span className="font-medium text-ink">{threads.length}</span> threads
        </span>
        <span>
          <span className="font-medium text-ink">{comments.filter((comment) => comment.isResolved).length}</span> resolved
        </span>
      </div>
      {threads.length === 0 ? (
        <p className="text-[12px] text-muted">This document carries no review thread.</p>
      ) : (
        threads.map((thread) => (
          <div key={String(thread.id)} className="space-y-2">
            {line(thread, 0)}
            {repliesOf(thread.id).map((reply) => line(reply, 1))}
          </div>
        ))
      )}
    </div>
  );
}

export default function WordsPage() {
  const { artifacts } = useWorkspace();
  const [tab, setTab] = useState("author");
  useHashTab(
    ["author", "convert", "edit", "fields", "merge", "compose", "review", "graphics", "document"],
    tab,
    setTab
  );
  const [documentId, setDocumentId] = useEngineDocument("word");

  /* author */
  const [source, setSource] = useState<"markdown" | "html" | "text">("markdown");
  const [body, setBody] = useState(SAMPLE_MARKDOWN);
  const [title, setTitle] = useState("Supplier onboarding memo");
  const author = useToolRun();

  /* convert */
  const [to, setTo] = useState("pdf");
  const [dpi, setDpi] = useState("144");
  const converter = useToolRun();

  /* replace */
  const [find, setFind] = useState("Northwind Analytics");
  const [replace, setReplace] = useState("Northwind Analytics Ltd");
  const replacer = useToolRun();

  /* fill + merge */
  const [tokens, setTokens] = useState(
    JSON.stringify({ client_name: "Cassia Foods", amount: "₹1,81,956.00", invoice_number: "DZ-1140", date: "13 November 2026", terms: "30", sender_name: "Arun Mehta" }, null, 2)
  );
  const [recordsCsv, setRecordsCsv] = useState(
    "client_name,amount,invoice_number,date,terms,sender_name\nCassia Foods,₹1,81,956.00,DZ-1140,13 November 2026,30,Arun Mehta\nHalcyon Retail,₹74,210.00,DZ-1141,13 November 2026,45,Priya Raghavan\n"
  );
  const [mergeTable, setMergeTable] = useState("data");
  const [cleanup, setCleanup] = useState(true);
  const filler = useToolRun();
  const merger = useToolRun();

  /* inspect */
  const inspector = useToolRun();
  const [authorFilter, setAuthorFilter] = useState("");
  const [revisionAction, setRevisionAction] = useState("accept");
  const revisions = useToolRun();

  /* extract */
  const [extractFormat, setExtractFormat] = useState("markdown");
  const extractor = useToolRun();

  /* fields */
  const [bookmarkValues, setBookmarkValues] = useState('{\n  "ClientName": "Cassia Foods"\n}');
  const bookmarks = useToolRun();
  const [controlValues, setControlValues] = useState('{\n  "tag:client": "Cassia Foods"\n}');
  const controls = useToolRun();
  const [propTitle, setPropTitle] = useState("");
  const [propCreator, setPropCreator] = useState("");
  const [propSubject, setPropSubject] = useState("");
  const [propKeywords, setPropKeywords] = useState("");
  const properties = useToolRun();

  /* compose */
  const [targetId, setTargetId] = useState("");
  const [sourceId, setSourceId] = useState("");
  const [scope, setScope] = useState("blocks");
  const [lenient, setLenient] = useState(true);
  const composer = useToolRun();

  const runAuthor = () =>
    author.run(() => wordsApi.create({ kind: source, content: body, title: title || undefined }));

  const runConvert = () => {
    extractor.reset();
    return converter.run(() => wordsApi.convert({ artifactId: documentId, to, dpi: Number(dpi) || 144 }));
  };

  const runReplace = () =>
    replacer.run(() => wordsApi.replace({ artifactId: documentId, find, replacement: replace }));

  const runFill = () => {
    let parsed: Record<string, string> = {};
    try {
      parsed = JSON.parse(tokens);
    } catch {
      parsed = {};
    }
    return filler.run(() => wordsApi.fill({ artifactId: documentId, values: parsed }));
  };

  const runMerge = () =>
    merger.run(() =>
      wordsApi.mailMerge({
        artifactId: documentId,
        rows: parseCsv(recordsCsv),
        table: mergeTable || undefined,
        cleanup: cleanup ? "all" : undefined
      })
    );

  const runInspect = () => inspector.run(() => wordsApi.inspect(documentId));

  const runRevisions = () =>
    revisions.run(() =>
      wordsApi.revisions({
        artifactId: documentId,
        action: revisionAction as "read" | "accept" | "reject",
        author: authorFilter || undefined
      })
    );

  const runExtract = () => {
    converter.reset();
    return extractor.run(() => wordsApi.extract({ artifactId: documentId, format: extractFormat }));
  };

  const readJson = (text: string): Record<string, string> => {
    try {
      const parsed = JSON.parse(text);
      return parsed && typeof parsed === "object" ? (parsed as Record<string, string>) : {};
    } catch {
      return {};
    }
  };

  const runBookmarks = (action: "read" | "write") => {
    controls.reset();
    properties.reset();
    return bookmarks.run(() =>
      wordsApi.fields("/api/words/bookmarks", {
        artifactId: documentId,
        action,
        values: action === "write" ? readJson(bookmarkValues) : undefined,
        lenient: lenient || undefined
      })
    );
  };

  const runControls = (action: "read" | "write") => {
    bookmarks.reset();
    properties.reset();
    return controls.run(() =>
      wordsApi.fields("/api/words/content-controls", {
        artifactId: documentId,
        action,
        values: action === "write" ? readJson(controlValues) : undefined,
        lenient: lenient || undefined
      })
    );
  };

  const runProperties = (write: boolean) => {
    bookmarks.reset();
    controls.reset();
    return properties.run(() =>
      wordsApi.properties({
        artifactId: documentId,
        values: write
          ? {
              title: propTitle || undefined,
              creator: propCreator || undefined,
              subject: propSubject || undefined,
              keywords: propKeywords || undefined
            }
          : undefined
      })
    );
  };

  // Default the guest to another Word document so the first compose is one click:
  // a disabled button with no explanation is not a demonstration. The choice settles
  // once — deriving it on every render would silently swap the guest for the file the
  // last run just wrote.
  const [guestDefault, setGuestDefault] = useState("");
  useEffect(() => {
    if (guestDefault || !documentId) return;
    // Prefer a seeded sample: the guest slot should not default to a file the last
    // compose run produced, which would make the empty case invisible. Among the samples
    // take the smallest, because composition refuses guests that reference parts it
    // cannot import (numbering, for instance) and a small authored note is the guest
    // least likely to carry any.
    const others = artifacts.filter((artifact) => artifact.kind === "word" && artifact.id !== documentId);
    const other =
      others
        .filter((artifact) => artifact.origin === "sample")
        .sort((left, right) => left.size - right.size)[0] ?? others[0];
    if (other) setGuestDefault(other.id);
  }, [artifacts, documentId, guestDefault]);

  const hostDoc = targetId || documentId;
  const guestDoc = sourceId || guestDefault;

  const runCompose = () =>
    composer.run(() =>
      wordsApi.compose({ targetId: hostDoc, sourceId: guestDoc, scope, lenient: lenient || undefined })
    );

  /* review: comments, fields, notes */
  const [reviewMode, setReviewMode] = useState<"comments" | "fields" | "notes">("comments");
  const [commentAuthor, setCommentAuthor] = useState("Priya Raghavan");
  const [commentText, setCommentText] = useState("Confirm the pass-rate denominator before this goes to the board.");
  const [commentParagraph, setCommentParagraph] = useState("5");
  const [resolveId, setResolveId] = useState("0");
  const comments = useToolRun();
  const docFields = useToolRun();
  const notes = useToolRun();

  /* drawings, building blocks, semantic chunks */
  const [drawingMode, setDrawingMode] = useState<"graphics" | "blocks" | "chunks">("graphics");
  const [chunkTokens, setChunkTokens] = useState("256");
  const graphics = useToolRun();
  const blocks = useToolRun();
  const chunks = useToolRun();

  /* document operations */
  const [watermarkText, setWatermarkText] = useState("CONFIDENTIAL");
  const [pageBackground, setPageBackground] = useState("#F4F7F2");
  const [protectionType, setProtectionType] = useState("readonly");
  const [protectionPassword, setProtectionPassword] = useState("");
  const [tocLevel, setTocLevel] = useState("2");
  const [tocTitle, setTocTitle] = useState("Contents");
  const [hyphenMin, setHyphenMin] = useState("6");
  const [splitMode, setSplitMode] = useState<"pages" | "range">("pages");
  const [splitStart, setSplitStart] = useState("1");
  const [splitEnd, setSplitEnd] = useState("2");
  const [compareRight, setCompareRight] = useState("");
  const [saveFormat, setSaveFormat] = useState("odt");
  const watermark = useToolRun();
  const background = useToolRun();
  const protector = useToolRun();
  const macros = useToolRun();
  const toc = useToolRun();
  const hyphen = useToolRun();
  const splitter = useToolRun();
  const comparer = useToolRun();
  const exporter = useToolRun();

  const runComments = (action: "read" | "add" | "resolve" | "reopen") =>
    comments.run(() =>
      wordsApi.comments({
        artifactId: documentId,
        action,
        author: action === "add" ? commentAuthor : undefined,
        text: action === "add" ? commentText : undefined,
        paragraph: action === "add" ? Number(commentParagraph) || 0 : undefined,
        id: action === "resolve" || action === "reopen" ? Number(resolveId) || 0 : undefined
      })
    );

  const runDocFields = (action: "read" | "update") =>
    docFields.run(() => wordsApi.documentFields({ artifactId: documentId, action }));

  const runNotes = () => notes.run(() => wordsApi.notes({ artifactId: documentId }));

  const runDrawings = () => {
    if (drawingMode === "graphics") graphics.run(() => wordsApi.graphics({ artifactId: documentId }));
    else if (drawingMode === "blocks") blocks.run(() => wordsApi.buildingBlocks({ artifactId: documentId }));
    else chunks.run(() => wordsApi.chunks({ artifactId: documentId, maxTokens: Number(chunkTokens) || 256 }));
  };

  const runWatermark = (action: "add" | "remove") =>
    watermark.run(() => wordsApi.watermark({ artifactId: documentId, action, text: action === "add" ? watermarkText : undefined }));

  const runProtection = (action: "read" | "apply" | "remove") =>
    protector.run(() =>
      wordsApi.protection({
        artifactId: documentId,
        action,
        type: action === "apply" ? protectionType : undefined,
        password: action === "apply" && protectionPassword ? protectionPassword : undefined
      })
    );

  const runMacros = (action: "read" | "remove") => macros.run(() => wordsApi.macros({ artifactId: documentId, action }));

  const runToc = (action: "add" | "update") =>
    toc.run(() =>
      wordsApi.toc({ artifactId: documentId, action, maxLevel: Number(tocLevel) || 2, title: action === "add" ? tocTitle : undefined })
    );

  const runHyphenate = () =>
    hyphen.run(() => wordsApi.hyphenate({ artifactId: documentId, minWordLength: Number(hyphenMin) || 6 }));

  const runSplit = () =>
    splitter.run(() =>
      wordsApi.split({
        artifactId: documentId,
        mode: splitMode,
        start: splitMode === "range" ? Number(splitStart) || 1 : undefined,
        end: splitMode === "range" ? Number(splitEnd) || Number(splitStart) || 1 : undefined
      })
    );

  const runCompare = () =>
    comparer.run(() =>
      wordsApi.compareDocuments({
        leftId: documentId,
        rightId: compareRight,
        author: "Console reviewer",
        granularity: "word"
      })
    );

  const runSaveAs = () => exporter.run(() => wordsApi.saveAs({ artifactId: documentId, format: saveFormat }));

  return (
    <div>
      <PageHeader
        eyebrow="Words engine"
        title="DOCX workbench"
        description="The engine's own OOXML reader and writer: author and export, replace, fill tokens and merge records, settle revisions, read comments, fields, notes and drawings, and run the package operations — split, compare, protect, watermark, table of contents and every save format."
        actions={
          <span className="pill border border-line bg-surface px-2.5 py-1 text-[11px] text-muted">
            docx · doc · rtf · odt
          </span>
        }
      />

      <div className="mb-4">
        <Tabs tabs={TABS} value={tab} onChange={setTab} />
      </div>

      <div className="split-wrap">
        <div className="min-w-0 space-y-4">

          {tab === "author" ? (
            <ConfigCard
              title="Create a document"
              description="Markdown and HTML are imported by the engine (headings, lists, tables, emphasis). Plain text keeps paragraphs only."
              footer={
                <RunBar
                  label="Create DOCX"
                  pending={author.pending}
                  disabled={!body.trim()}
                  hint="Written straight into the workspace library"
                  onRun={runAuthor}
                />
              }
            >
              <InlineFields>
                <Field label="Source" hint="How the text is interpreted">
                  <Select
                    value={source}
                    onChange={(event) => setSource(event.target.value as "markdown" | "html" | "text")}
                    options={[
                      { value: "markdown", label: "Markdown (GFM)" },
                      { value: "html", label: "HTML" },
                      { value: "text", label: "Plain text" }
                    ]}
                  />
                </Field>
                <Field label="Title" hint="Stored in the document properties">
                  <TextInput value={title} onChange={(event) => setTitle(event.target.value)} placeholder="Untitled" />
                </Field>
              </InlineFields>
              <Field label="Document body">
                <TextArea value={body} onChange={(event) => setBody(event.target.value)} rows={16} className="font-mono text-[11.5px]" />
              </Field>
              <SectionDivider label="Read an existing document" />
              <div className="flex flex-wrap items-end gap-3">
                <div className="min-w-[220px] flex-1">
                  <DocumentSelect label="Document" include="word" value={documentId} onChange={setDocumentId} />
                </div>
                <button
                  type="button"
                  className="btn btn-secondary btn-sm"
                  onClick={runInspect}
                  disabled={!documentId || inspector.pending}
                >
                  Inspect
                </button>
              </div>
            </ConfigCard>
          ) : null}

          {tab === "convert" ? (
            <ConfigCard
              title="Convert"
              description="PDF and images are rendered by the Words layout engine; Markdown, HTML, RTF and text are exported by the document writer."
              footer={
                <RunBar
                  label="Convert"
                  pending={converter.pending}
                  disabled={!documentId}
                  hint="The source document is never modified"
                  onRun={runConvert}
                />
              }
            >
              <DocumentSelect label="Source DOCX" include="word" value={documentId} onChange={setDocumentId} />
              <InlineFields>
                <Field label="Target" hint="Seven writers">
                  <Select
                    value={to}
                    onChange={(event) => setTo(event.target.value)}
                    options={CONVERT_TARGETS.map((target) => ({ value: target.id, label: target.label }))}
                  />
                </Field>
                {to === "png" || to === "pdf" ? (
                  <Field label="Raster dpi" hint="PNG only">
                    <NumberInput value={dpi} min={72} max={600} onChange={setDpi} />
                  </Field>
                ) : (
                  <Field label="Page" hint="For png and svg">
                    <NumberInput value={dpi} min={1} max={4000} onChange={setDpi} />
                  </Field>
                )}
              </InlineFields>

              <SectionDivider label="Extract the text layer" />
              <Field label="Extract as" hint="Written by the document writer, not the layout pass">
                <Select
                  value={extractFormat}
                  onChange={(event) => setExtractFormat(event.target.value)}
                  options={[
                    { value: "markdown", label: "Markdown (GFM)" },
                    { value: "text", label: "Plain text" },
                    { value: "html", label: "HTML" }
                  ]}
                />
              </Field>
              <button
                type="button"
                className="btn btn-secondary btn-sm w-full"
                onClick={runExtract}
                disabled={!documentId || extractor.pending}
              >
                Extract and save
              </button>
            </ConfigCard>
          ) : null}

          {tab === "fields" ? (
            <div className="space-y-4">
              <ConfigCard
                title="Bookmarks"
                description="Read the bookmarks the file already carries, or fill them by name. Every value is written where the bookmark sits."
                footer={
                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      className="btn btn-secondary btn-sm"
                      onClick={() => runBookmarks("read")}
                      disabled={!documentId || bookmarks.pending}
                    >
                      Read bookmarks
                    </button>
                    <button
                      type="button"
                      className="btn btn-primary btn-sm"
                      onClick={() => runBookmarks("write")}
                      disabled={!documentId || bookmarks.pending}
                    >
                      Fill bookmarks
                    </button>
                  </div>
                }
              >
                <DocumentSelect label="Source DOCX" include="word" value={documentId} onChange={setDocumentId} />
                <Field label="Values" hint="JSON object keyed by bookmark name">
                  <TextArea value={bookmarkValues} rows={5} onChange={(event) => setBookmarkValues(event.target.value)} className="font-mono text-[11.5px]" />
                </Field>
              </ConfigCard>

              <ConfigCard
                title="Content controls"
                description="Structured document tags. Selectors are exact: tag:name, alias:name or id:123."
                footer={
                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      className="btn btn-secondary btn-sm"
                      onClick={() => runControls("read")}
                      disabled={!documentId || controls.pending}
                    >
                      Read controls
                    </button>
                    <button
                      type="button"
                      className="btn btn-primary btn-sm"
                      onClick={() => runControls("write")}
                      disabled={!documentId || controls.pending}
                    >
                      Fill controls
                    </button>
                  </div>
                }
              >
                <Field label="Values" hint="JSON object keyed by tag:, alias: or id:">
                  <TextArea value={controlValues} rows={5} onChange={(event) => setControlValues(event.target.value)} className="font-mono text-[11.5px]" />
                </Field>
              </ConfigCard>

              <ConfigCard
                title="Core properties"
                description="Read what the package declares, or set the fields you fill in. Untouched fields keep their current value."
                footer={
                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      className="btn btn-secondary btn-sm"
                      onClick={() => runProperties(false)}
                      disabled={!documentId || properties.pending}
                    >
                      Read properties
                    </button>
                    <button
                      type="button"
                      className="btn btn-primary btn-sm"
                      onClick={() => runProperties(true)}
                      disabled={!documentId || properties.pending || !(propTitle || propCreator || propSubject || propKeywords)}
                    >
                      Save properties
                    </button>
                  </div>
                }
              >
                <InlineFields>
                  <Field label="Title">
                    <TextInput value={propTitle} onChange={(event) => setPropTitle(event.target.value)} placeholder="Leave unchanged" />
                  </Field>
                  <Field label="Creator">
                    <TextInput value={propCreator} onChange={(event) => setPropCreator(event.target.value)} placeholder="Leave unchanged" />
                  </Field>
                </InlineFields>
                <InlineFields>
                  <Field label="Subject">
                    <TextInput value={propSubject} onChange={(event) => setPropSubject(event.target.value)} placeholder="Leave unchanged" />
                  </Field>
                  <Field label="Keywords">
                    <TextInput value={propKeywords} onChange={(event) => setPropKeywords(event.target.value)} placeholder="Leave unchanged" />
                  </Field>
                </InlineFields>
                <Checkbox checked={lenient} onChange={setLenient} label="Continue past warnings and report them" />
              </ConfigCard>
            </div>
          ) : null}

          {tab === "compose" ? (
            <ConfigCard
              title="Compose"
              description="Append one document's content to another. Styles, numbering and media are remapped by the engine; the target is written as a new file."
              footer={
                <RunBar
                  label="Append source to target"
                  pending={composer.pending}
                  disabled={!guestDoc || !hostDoc || guestDoc === hostDoc}
                  hint={
                    !guestDoc || !hostDoc
                      ? "Pick both documents"
                      : guestDoc === hostDoc
                        ? "Pick two different documents"
                        : undefined
                  }
                  onRun={runCompose}
                />
              }
            >
              <InlineFields>
                <Field label="Target (host)">
                  <DocumentSelect label="Target DOCX" include="word" value={hostDoc} onChange={setTargetId} />
                </Field>
                <Field label="Source (guest)">
                  <DocumentSelect label="Source DOCX" include="word" value={guestDoc} onChange={setSourceId} />
                </Field>
              </InlineFields>
              <Field label="Scope" hint="How much of the guest is taken">
                <Select
                  value={scope}
                  onChange={(event) => setScope(event.target.value)}
                  options={[
                    { value: "bodytext", label: "Body text only" },
                    { value: "blocks", label: "Body blocks" },
                    { value: "media", label: "Body blocks with media" },
                    { value: "stories", label: "Body and stories (headers, footers, notes)" }
                  ]}
                />
              </Field>
              <Checkbox checked={lenient} onChange={setLenient} label="Continue past warnings and report them" />
            </ConfigCard>
          ) : null}

          {tab === "review" ? (
            <ConfigCard
              title="Review threads and fields"
              description="Comments with their replies, the fields the file actually carries, and footnotes and endnotes. Adding a comment or updating a field writes a new DOCX."
              footer={
                <div className="flex flex-wrap gap-2">
                  {reviewMode === "comments" ? (
                    <>
                      <button type="button" className="btn btn-secondary btn-sm" onClick={() => runComments("read")} disabled={!documentId || comments.pending}>
                        Read comments
                      </button>
                      <button type="button" className="btn btn-primary btn-sm" onClick={() => runComments("add")} disabled={!documentId || !commentText.trim() || comments.pending}>
                        Add comment
                      </button>
                      <button type="button" className="btn btn-secondary btn-sm" onClick={() => runComments("resolve")} disabled={!documentId || comments.pending}>
                        Resolve {resolveId}
                      </button>
                    </>
                  ) : reviewMode === "fields" ? (
                    <>
                      <button type="button" className="btn btn-secondary btn-sm" onClick={() => runDocFields("read")} disabled={!documentId || docFields.pending}>
                        Read fields
                      </button>
                      <button type="button" className="btn btn-primary btn-sm" onClick={() => runDocFields("update")} disabled={!documentId || docFields.pending}>
                        Update fields
                      </button>
                    </>
                  ) : (
                    <button type="button" className="btn btn-secondary btn-sm" onClick={runNotes} disabled={!documentId || notes.pending}>
                      Read notes
                    </button>
                  )}
                </div>
              }
            >
              <DocumentSelect label="Source DOCX" include="word" value={documentId} onChange={setDocumentId} />
              <Segmented
                value={reviewMode}
                onChange={setReviewMode}
                options={[
                  { value: "comments", label: "Comments" },
                  { value: "fields", label: "Fields" },
                  { value: "notes", label: "Notes" }
                ]}
              />
              {reviewMode === "comments" ? (
                <>
                  <InlineFields>
                    <Field label="Author">
                      <TextInput value={commentAuthor} onChange={(event) => setCommentAuthor(event.target.value)} />
                    </Field>
                    <Field label="Anchor paragraph" hint="0-based body index">
                      <TextInput value={commentParagraph} onChange={(event) => setCommentParagraph(event.target.value)} inputMode="numeric" />
                    </Field>
                  </InlineFields>
                  <Field label="Comment">
                    <TextArea value={commentText} rows={3} onChange={(event) => setCommentText(event.target.value)} />
                  </Field>
                  <Field label="Comment id" hint="Used by Resolve; the read report lists the ids">
                    <TextInput value={resolveId} onChange={(event) => setResolveId(event.target.value)} inputMode="numeric" />
                  </Field>
                </>
              ) : reviewMode === "fields" ? (
                <p className="text-[11.5px] leading-[1.5] text-muted">
                  Fields are read from the body and the header and footer stories. Updating recomputes the cached result of each
                  field the engine can evaluate and reports how many changed.
                </p>
              ) : (
                <p className="text-[11.5px] leading-[1.5] text-muted">
                  Footnotes and endnotes are read from their own package parts, with the mark and the text the file stores.
                </p>
              )}
            </ConfigCard>
          ) : null}

          {tab === "graphics" ? (
            <ConfigCard
              title="Drawings and chunks"
              description="The drawing inventory the reader can prove: charts with their series, shapes, SmartArt, equations and embedded objects — plus the semantic chunks the engine derives for retrieval."
              footer={
                <RunBar
                  label={
                    drawingMode === "graphics" ? "Read drawings" : drawingMode === "blocks" ? "Read building blocks" : "Split into chunks"
                  }
                  pending={graphics.pending || blocks.pending || chunks.pending}
                  disabled={!documentId}
                  hint="Read-only: nothing is written"
                  onRun={runDrawings}
                />
              }
            >
              <DocumentSelect label="Source DOCX" include="word" value={documentId} onChange={setDocumentId} />
              <Segmented
                value={drawingMode}
                onChange={setDrawingMode}
                options={[
                  { value: "graphics", label: "Drawings" },
                  { value: "blocks", label: "Building blocks" },
                  { value: "chunks", label: "Chunks" }
                ]}
              />
              {drawingMode === "chunks" ? (
                <Field label="Tokens per chunk" hint="The engine's own estimate, 16–8192">
                  <TextInput value={chunkTokens} onChange={(event) => setChunkTokens(event.target.value)} inputMode="numeric" />
                </Field>
              ) : null}
            </ConfigCard>
          ) : null}

          {tab === "document" ? (
            <>
              <ConfigCard
                title="Watermark and page background"
                description="A text watermark is written into the header story; the background is a page-level fill. Both write a new DOCX."
                footer={
                  <div className="flex flex-wrap gap-2">
                    <button type="button" className="btn btn-primary btn-sm" onClick={() => runWatermark("add")} disabled={!documentId || !watermarkText.trim() || watermark.pending}>
                      Add watermark
                    </button>
                    <button type="button" className="btn btn-secondary btn-sm" onClick={() => runWatermark("remove")} disabled={!documentId || watermark.pending}>
                      Remove watermark
                    </button>
                    <button
                      type="button"
                      className="btn btn-secondary btn-sm"
                      onClick={() => background.run(() => wordsApi.background({ artifactId: documentId, color: pageBackground }))}
                      disabled={!documentId || background.pending}
                    >
                      Set background
                    </button>
                  </div>
                }
              >
                <DocumentSelect label="Source DOCX" include="word" value={documentId} onChange={setDocumentId} />
                <InlineFields>
                  <Field label="Watermark text">
                    <TextInput value={watermarkText} onChange={(event) => setWatermarkText(event.target.value)} />
                  </Field>
                  <Field label="Page background" hint="Hex colour, or empty to clear">
                    <TextInput value={pageBackground} onChange={(event) => setPageBackground(event.target.value)} />
                  </Field>
                </InlineFields>
              </ConfigCard>

              <ConfigCard
                title="Protection, macros and contents"
                description="Editing protection with its mode, removal of a VBA project when the package carries one, and the table of contents."
                footer={
                  <div className="flex flex-wrap gap-2">
                    <button type="button" className="btn btn-secondary btn-sm" onClick={() => runProtection("read")} disabled={!documentId || protector.pending}>
                      Read protection
                    </button>
                    <button type="button" className="btn btn-primary btn-sm" onClick={() => runProtection("apply")} disabled={!documentId || protector.pending}>
                      Apply protection
                    </button>
                    <button type="button" className="btn btn-secondary btn-sm" onClick={() => runProtection("remove")} disabled={!documentId || protector.pending}>
                      Remove
                    </button>
                    <button type="button" className="btn btn-secondary btn-sm" onClick={() => runMacros("read")} disabled={!documentId || macros.pending}>
                      Read macros
                    </button>
                    <button type="button" className="btn btn-secondary btn-sm" onClick={() => runMacros("remove")} disabled={!documentId || macros.pending}>
                      Strip macros
                    </button>
                  </div>
                }
              >
                <InlineFields>
                  <Field label="Protection mode">
                    <Select
                      value={protectionType}
                      onChange={(event) => setProtectionType(event.target.value)}
                      options={[
                        { value: "readonly", label: "Read only" },
                        { value: "comments", label: "Comments only" },
                        { value: "revisions", label: "Revisions only" },
                        { value: "forms", label: "Form fields only" }
                      ]}
                    />
                  </Field>
                  <Field label="Password" hint="Optional; the engine hashes it into settings.xml">
                    <TextInput value={protectionPassword} onChange={(event) => setProtectionPassword(event.target.value)} />
                  </Field>
                </InlineFields>
                <SectionDivider label="Table of contents" />
                <InlineFields>
                  <Field label="Heading levels">
                    <TextInput value={tocLevel} onChange={(event) => setTocLevel(event.target.value)} inputMode="numeric" />
                  </Field>
                  <Field label="Title">
                    <TextInput value={tocTitle} onChange={(event) => setTocTitle(event.target.value)} />
                  </Field>
                </InlineFields>
                <div className="flex flex-wrap gap-2">
                  <button type="button" className="btn btn-primary btn-sm" onClick={() => runToc("add")} disabled={!documentId || toc.pending}>
                    Add contents
                  </button>
                  <button type="button" className="btn btn-secondary btn-sm" onClick={() => runToc("update")} disabled={!documentId || toc.pending}>
                    Update entries
                  </button>
                  <button type="button" className="btn btn-secondary btn-sm" onClick={runHyphenate} disabled={!documentId || hyphen.pending}>
                    Hyphenate ({hyphenMin}+ letters)
                  </button>
                  <TextInput
                    value={hyphenMin}
                    onChange={(event) => setHyphenMin(event.target.value)}
                    inputMode="numeric"
                    className="w-[84px]"
                  />
                </div>
              </ConfigCard>

              <ConfigCard
                title="Split, compare and save as"
                description="Split by the engine's page count or an explicit range, compare against a second document, and write any format the writer supports."
                footer={
                  <div className="flex flex-wrap gap-2">
                    <button type="button" className="btn btn-primary btn-sm" onClick={runSplit} disabled={!documentId || splitter.pending}>
                      Split document
                    </button>
                    <button type="button" className="btn btn-secondary btn-sm" onClick={runCompare} disabled={!documentId || !compareRight || comparer.pending}>
                      Compare
                    </button>
                    <button type="button" className="btn btn-secondary btn-sm" onClick={runSaveAs} disabled={!documentId || exporter.pending}>
                      Save as
                    </button>
                  </div>
                }
              >
                <InlineFields>
                  <Field label="Split by">
                    <Segmented
                      value={splitMode}
                      onChange={setSplitMode}
                      options={[
                        { value: "pages", label: "Pages" },
                        { value: "range", label: "Range" }
                      ]}
                    />
                  </Field>
                  <Field label="Format">
                    <Select
                      value={saveFormat}
                      onChange={(event) => setSaveFormat(event.target.value)}
                      options={[
                        { value: "docx", label: "DOCX" },
                        { value: "docm", label: "DOCM (macro-enabled)" },
                        { value: "dotx", label: "DOTX (template)" },
                        { value: "dotm", label: "DOTM (macro template)" },
                        { value: "flatopc", label: "Flat OPC (single XML)" },
                        { value: "odt", label: "ODT" },
                        { value: "mhtml", label: "MHTML" },
                        { value: "rtf", label: "RTF" },
                        { value: "html", label: "HTML" },
                        { value: "markdown", label: "Markdown" },
                        { value: "text", label: "Plain text" }
                      ]}
                    />
                  </Field>
                </InlineFields>
                {splitMode === "range" ? (
                  <InlineFields>
                    <Field label="First page">
                      <TextInput value={splitStart} onChange={(event) => setSplitStart(event.target.value)} inputMode="numeric" />
                    </Field>
                    <Field label="Last page">
                      <TextInput value={splitEnd} onChange={(event) => setSplitEnd(event.target.value)} inputMode="numeric" />
                    </Field>
                  </InlineFields>
                ) : (
                  <p className="text-[11.5px] leading-[1.5] text-muted">
                    Splitting uses the engine's own layout pass to decide where pages end; each page becomes its own DOCX.
                  </p>
                )}
                <SectionDivider label="Compare against" />
                <DocumentSelect label="Revised DOCX" include="word" value={compareRight} onChange={setCompareRight} />
              </ConfigCard>
            </>
          ) : null}

          {tab === "edit" ? (
            <ConfigCard
              title="Find & replace"
              description="Replacement runs over the document body and keeps formatting; the result is saved as a new DOCX."
              footer={
                <RunBar
                  label="Replace and save"
                  pending={replacer.pending}
                  disabled={!documentId || !find}
                  hint="The source file is never modified"
                  onRun={runReplace}
                />
              }
            >
              <DocumentSelect label="Source DOCX" include="word" value={documentId} onChange={setDocumentId} />
              <p className="text-[11.5px] leading-[1.5] text-muted">
                Matching is case-insensitive and runs across the whole body, including tables and headers where the file
                has them. The replacement is written to a new DOCX, so the source stays available for comparison.
              </p>
              <InlineFields>
                <Field label="Find">
                  <TextInput value={find} onChange={(event) => setFind(event.target.value)} />
                </Field>
                <Field label="Replace with">
                  <TextInput value={replace} onChange={(event) => setReplace(event.target.value)} />
                </Field>
              </InlineFields>
            </ConfigCard>
          ) : null}

          {tab === "merge" ? (
            <div className="space-y-4">
              <ConfigCard title="Template" description="One document feeds all three tools below.">
                <DocumentSelect label="Template DOCX" include="word" value={documentId} onChange={setDocumentId} />
              </ConfigCard>

              <ConfigCard
                title="Fill {{tokens}}"
                description="Each token is replaced in place; unmatched tokens are reported rather than guessed."
                footer={
                  <RunBar label="Fill document" pending={filler.pending} disabled={!documentId} hint="Values must be JSON" onRun={runFill} />
                }
              >
                <Field label="Token values" hint="JSON object of name → value">
                  <TextArea value={tokens} rows={8} onChange={(event) => setTokens(event.target.value)} className="font-mono text-[11.5px]" />
                </Field>
              </ConfigCard>

              <ConfigCard
                title="Mail merge"
                description="One row produces one document: the engine expands the CSV into a merged DOCX with the template's formatting intact."
                footer={
                  <RunBar label="Merge records" pending={merger.pending} disabled={!documentId || !recordsCsv.trim()} hint="First CSV row is the header" onRun={runMerge} />
                }
              >
                <InlineFields>
                  <Field label="Table name" hint="Leave as `data` unless the template names it">
                    <TextInput value={mergeTable} onChange={(event) => setMergeTable(event.target.value)} placeholder="data" />
                  </Field>
                  <Field label="Cleanup" hint="Strip the merge scaffolding">
                    <div className="pt-2">
                      <Checkbox checked={cleanup} onChange={setCleanup} label="Clean up after merging" />
                    </div>
                  </Field>
                </InlineFields>
                <Field label="Records (CSV)">
                  <TextArea value={recordsCsv} rows={7} onChange={(event) => setRecordsCsv(event.target.value)} className="font-mono text-[11.5px]" />
                </Field>
              </ConfigCard>

              <ConfigCard
                title="Tracked revisions"
                description="List, accept or reject the revisions the file already carries — no revision is invented."
                footer={
                  <RunBar
                    label={revisionAction === "list" ? "List revisions" : revisionAction === "accept" ? "Accept revisions" : "Reject revisions"}
                    pending={revisions.pending}
                    disabled={!documentId}
                    hint="Filtering by author keeps other reviewers' marks"
                    onRun={runRevisions}
                  />
                }
              >
                <InlineFields>
                  <Field label="Action">
                    <Select
                      value={revisionAction}
                      onChange={(event) => setRevisionAction(event.target.value)}
                      options={[
                        { value: "read", label: "List only (read-only)" },
                        { value: "accept", label: "Accept" },
                        { value: "reject", label: "Reject" }
                      ]}
                    />
                  </Field>
                  <Field label="Author filter" hint="Leave empty for every author">
                    <TextInput value={authorFilter} onChange={(event) => setAuthorFilter(event.target.value)} placeholder="All authors" />
                  </Field>
                </InlineFields>
              </ConfigCard>
            </div>
          ) : null}

          <Callout tone="info">
            Scope: the console drives Docuzen.Words in-process. Fonts, styles and numbering come from the file itself, and
            the engine reports what it could not map instead of substituting silently.
          </Callout>
        </div>

        <div className="min-w-0">
          {tab === "author" ? (
            <ResultPanel
              result={inspector.result ?? author.result}
              error={inspector.error ?? author.error}
              pending={inspector.pending || author.pending}
              emptyTitle="Nothing authored yet"
              emptyDescription="Write or paste a body to create a DOCX, or inspect a document already in the library."
              emptyIcon={BookDown}
              onReset={() => {
                inspector.reset();
                author.reset();
              }}
            />
          ) : null}
          {tab === "convert" ? (
            <ResultPanel
              result={converter.result ?? extractor.result}
              error={converter.error ?? extractor.error}
              pending={converter.pending || extractor.pending}
              emptyTitle="Nothing converted yet"
              emptyDescription="Pick a DOCX and a target. PDF and PNG renders show the engine's own page layout; extraction hands the text layer back as Markdown, HTML or plain text."
              emptyIcon={FileCode2}
              onReset={() => {
                converter.reset();
                extractor.reset();
              }}
            />
          ) : null}
          {tab === "edit" ? (
            <ResultPanel
              result={replacer.result}
              error={replacer.error}
              pending={replacer.pending}
              emptyTitle="Nothing replaced yet"
              emptyDescription="Replacements are written to a new DOCX so the source stays intact for comparison."
              emptyIcon={Wand2}
              onReset={replacer.reset}
            />
          ) : null}
          {tab === "fields" ? (
            <ResultPanel
              result={bookmarks.result ?? controls.result ?? properties.result}
              error={bookmarks.error ?? controls.error ?? properties.error}
              pending={bookmarks.pending || controls.pending || properties.pending}
              emptyTitle="Nothing read yet"
              emptyDescription="Read a bookmark, content control or property list; a write produces a new DOCX and reports what it changed."
              emptyIcon={BookMarked}
              onReset={() => {
                bookmarks.reset();
                controls.reset();
                properties.reset();
              }}
            />
          ) : null}
          {tab === "compose" ? (
            <ResultPanel
              result={composer.result}
              error={composer.error}
              pending={composer.pending}
              emptyTitle="Nothing composed yet"
              emptyDescription="Pick a host and a guest document. The engine appends the guest's content and remaps its styles and numbering."
              emptyIcon={Layers}
              onReset={composer.reset}
            />
          ) : null}
          {tab === "review" ? (
            <ResultPanel
              result={comments.result ?? docFields.result ?? notes.result}
              error={comments.error ?? docFields.error ?? notes.error}
              pending={comments.pending || docFields.pending || notes.pending}
              emptyTitle="Nothing read yet"
              emptyDescription="Read the review threads, the fields the file carries, or its footnotes and endnotes. Writing a comment returns a new DOCX."
              emptyIcon={MessageSquare}
              renderReport={(report) =>
                report && Array.isArray((report as Record<string, unknown>).comments) ? (
                  <CommentsReport report={report as Record<string, unknown>} />
                ) : (
                  <GenericReport report={report} />
                )
              }
              onReset={() => {
                comments.reset();
                docFields.reset();
                notes.reset();
              }}
            />
          ) : null}
          {tab === "graphics" ? (
            <ResultPanel
              result={graphics.result ?? blocks.result ?? chunks.result}
              error={graphics.error ?? blocks.error ?? chunks.error}
              pending={graphics.pending || blocks.pending || chunks.pending}
              emptyTitle="Nothing read yet"
              emptyDescription="The drawing inventory, the glossary's building blocks, or the document split into retrieval-sized chunks."
              emptyIcon={Shapes}
              onReset={() => {
                graphics.reset();
                blocks.reset();
                chunks.reset();
              }}
            />
          ) : null}
          {tab === "document" ? (
            <ResultPanel
              result={
                watermark.result ??
                background.result ??
                protector.result ??
                macros.result ??
                toc.result ??
                hyphen.result ??
                splitter.result ??
                comparer.result ??
                exporter.result
              }
              error={
                watermark.error ??
                background.error ??
                protector.error ??
                macros.error ??
                toc.error ??
                hyphen.error ??
                splitter.error ??
                comparer.error ??
                exporter.error
              }
              pending={
                watermark.pending ||
                background.pending ||
                protector.pending ||
                macros.pending ||
                toc.pending ||
                hyphen.pending ||
                splitter.pending ||
                comparer.pending ||
                exporter.pending
              }
              emptyTitle="Nothing done yet"
              emptyDescription="Watermark, protect, strip macros, build a table of contents, hyphenate, split, compare or save the document in another format."
              emptyIcon={Settings2}
              onReset={() => {
                watermark.reset();
                background.reset();
                protector.reset();
                macros.reset();
                toc.reset();
                hyphen.reset();
                splitter.reset();
                comparer.reset();
                exporter.reset();
              }}
            />
          ) : null}
          {tab === "merge" ? (
            <ResultPanel
              result={merger.result ?? filler.result ?? revisions.result}
              error={merger.error ?? filler.error ?? revisions.error}
              pending={merger.pending || filler.pending || revisions.pending}
              emptyTitle="Nothing merged yet"
              emptyDescription="Fill a template's tokens or merge a CSV of records; both write a new DOCX into the library."
              emptyIcon={Sparkles}
              onReset={() => {
                merger.reset();
                filler.reset();
                revisions.reset();
              }}
            />
          ) : null}
        </div>
      </div>
    </div>
  );
}
