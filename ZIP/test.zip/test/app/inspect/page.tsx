"use client";

import { useEffect, useState } from "react";
import { FileSearch, ScanLine, ShieldCheck } from "lucide-react";
import Link from "next/link";
import { tools } from "@/lib/api";
import { useWorkspace } from "@/components/workspace-provider";
import { useToolRun } from "@/lib/use-tool-run";
import type { InspectionReport, ValidationReport } from "@/lib/types";
import { ResultPanel } from "@/components/result-panel";
import { ConfigCard, DocumentSelect, RunBar, SectionDivider } from "@/components/tool-form";
import { InspectionView, ValidationView } from "@/components/inspect-report";
import { Callout, Checkbox, PageHeader, Select, Tabs, TextInput } from "@/components/ui";

const TABS = [
  { id: "inspect", label: "Inspect", icon: FileSearch },
  { id: "validate", label: "Validate", icon: ShieldCheck },
  { id: "pdfa", label: "Convert to PDF/A", icon: ScanLine }
];

export default function InspectPage() {
  const { currentId, current } = useWorkspace();
  const [tab, setTab] = useState("inspect");

  return (
    <div>
      <PageHeader
        eyebrow="Analyse"
        title="Inspect & validate"
        description="Read the object graph exactly as written, then check the document against the PDF/A, PDF/X and PDF/UA subsets the engine actually implements."
      />

      <Tabs tabs={TABS} value={tab} onChange={setTab} className="mb-5" />

      {tab === "inspect" ? <InspectTab defaultId={currentId ?? ""} documentName={current?.fileName} /> : null}
      {tab === "validate" ? <ValidateTab defaultId={currentId ?? ""} /> : null}
      {tab === "pdfa" ? <PdfaTab defaultId={currentId ?? ""} /> : null}
    </div>
  );
}

function InspectTab({ defaultId, documentName }: { defaultId: string; documentName?: string }) {
  const [artifactId, setArtifactId] = useState(defaultId);
  const [details, setDetails] = useState(true);
  const [checkPdfA, setCheckPdfA] = useState(true);
  const { result, error, pending, run, reset } = useToolRun<InspectionReport>();

  useEffect(() => {
    if (!artifactId && defaultId) setArtifactId(defaultId);
  }, [defaultId, artifactId]);

  return (
    <div className="split-wrap">
      <ConfigCard
        description="No repair, no rewriting: the reader reports what the bytes say."
        footer={
          <RunBar
            label="Inspect document"
            pending={pending}
            disabled={!artifactId}
            onRun={() => run(() => tools.inspect({ artifactId, details, checkPdfA }))}
            hint={documentName ? `Target · ${documentName}` : undefined}
          />
        }
      >
        <DocumentSelect value={artifactId} onChange={setArtifactId} label="Document" />
        <SectionDivider label="Detail" />
        <Checkbox
          label="Include per-page detail"
          hint="Widths, rotation, content bytes, fonts, images and annotation counts for every page."
          checked={details}
          onChange={setDetails}
        />
        <Checkbox
          label="Read the PDF/A declaration"
          hint="Reports the claimed part/conformance from XMP when one is present."
          checked={checkPdfA}
          onChange={setCheckPdfA}
        />
      </ConfigCard>

      <ResultPanel
        result={result}
        error={error}
        pending={pending}
        onReset={reset}
        emptyIcon={FileSearch}
        emptyTitle="No inspection yet"
        emptyDescription="Choose a document and run the reader. The report lists structure, metadata, fonts, fields and any diagnostics the parser raised."
        renderReport={(report) => <InspectionView report={report} />}
      />
    </div>
  );
}

function ValidateTab({ defaultId }: { defaultId: string }) {
  const [artifactId, setArtifactId] = useState(defaultId);
  const [standard, setStandard] = useState("pdfa");
  const [level, setLevel] = useState("2b");
  const [part, setPart] = useState("1");
  const [strict, setStrict] = useState(false);
  const { result, error, pending, run, reset } = useToolRun<ValidationReport>();

  useEffect(() => {
    if (!artifactId && defaultId) setArtifactId(defaultId);
  }, [defaultId, artifactId]);

  return (
    <div className="split-wrap">
      <ConfigCard
        description="Structural rules plus the profile walk. A pass means the implemented subset passed."
        footer={
          <RunBar
            label="Run validation"
            pending={pending}
            disabled={!artifactId}
            onRun={() =>
              run(() =>
                tools.validate({
                  artifactId,
                  standard,
                  level: standard === "pdfa" ? level : undefined,
                  part: standard === "pdfua" ? part : undefined,
                  strict
                })
              )
            }
          />
        }
      >
        <DocumentSelect value={artifactId} onChange={setArtifactId} label="Document" />
        <div>
          <span className="label">Standard</span>
          <Select
            value={standard}
            onChange={(event) => setStandard(event.target.value)}
            options={[
              { value: "pdfa", label: "PDF/A — archival" },
              { value: "pdfx", label: "PDF/X — print exchange" },
              { value: "pdfua", label: "PDF/UA — accessibility" },
              { value: "structural", label: "Structural checks only" }
            ]}
          />
        </div>
        {standard === "pdfa" ? (
          <div>
            <span className="label">Target level</span>
            <Select
              value={level}
              onChange={(event) => setLevel(event.target.value)}
              options={[
                { value: "1b", label: "PDF/A-1b" },
                { value: "2b", label: "PDF/A-2b" },
                { value: "3b", label: "PDF/A-3b" }
              ]}
            />
          </div>
        ) : null}
        {standard === "pdfua" ? (
          <div>
            <span className="label">Part</span>
            <Select
              value={part}
              onChange={(event) => setPart(event.target.value)}
              options={[
                { value: "1", label: "PDF/UA-1 (ISO 14289-1)" },
                { value: "2", label: "PDF/UA-2 (ISO 14289-2)" }
              ]}
            />
          </div>
        ) : null}
        <Checkbox
          label="Strict mode"
          hint="Promote advisory findings to errors where the profile allows it."
          checked={strict}
          onChange={setStrict}
        />
      </ConfigCard>

      <ResultPanel
        result={result}
        error={error}
        pending={pending}
        onReset={reset}
        emptyIcon={ShieldCheck}
        emptyTitle="No validation run yet"
        emptyDescription="Pick a profile and run it. Findings are listed with the rule that produced them, and a clean run says so explicitly."
        renderReport={(report) => <ValidationView report={report} />}
      />
    </div>
  );
}

function PdfaTab({ defaultId }: { defaultId: string }) {
  const [artifactId, setArtifactId] = useState(defaultId);
  const [level, setLevel] = useState("2b");
  const [verify, setVerify] = useState(true);
  const convert = useToolRun<Record<string, unknown>>();
  const validation = useToolRun<ValidationReport>();

  useEffect(() => {
    if (!artifactId && defaultId) setArtifactId(defaultId);
  }, [defaultId, artifactId]);

  return (
    <div className="space-y-5">
      <div className="split-wrap">
        <ConfigCard
          description="Rewrite the document for archival use, then optionally re-open the result and walk it again."
          footer={
            <RunBar
              label="Convert to PDF/A"
              pending={convert.pending || validation.pending}
              disabled={!artifactId}
              onRun={async () => {
                const response = await convert.run(() => tools.pdfa({ artifactId, level }));
                const output = response?.artifacts[0];
                if (verify && output) {
                  validation.run(() => tools.validate({ artifactId: output.id, standard: "pdfa", level }));
                }
              }}
            />
          }
        >
          <DocumentSelect value={artifactId} onChange={setArtifactId} label="Source document" />
          <div>
            <span className="label">Target conformance</span>
            <Select
              value={level}
              onChange={(event) => setLevel(event.target.value)}
              options={[
                { value: "1b", label: "PDF/A-1b — ISO 19005-1" },
                { value: "2b", label: "PDF/A-2b — ISO 19005-2" },
                { value: "3b", label: "PDF/A-3b — ISO 19005-3" }
              ]}
            />
          </div>
          <Checkbox
            label="Validate the produced file"
            hint="Runs the same PDF/A walk on the conversion output in one step."
            checked={verify}
            onChange={setVerify}
          />
          <Callout tone="info" title="What the converter does">
            It embeds what it can, writes the required XMP and output intent, and refuses inputs it cannot represent. Validation afterwards is the evidence, not the claim.
          </Callout>
        </ConfigCard>

        <ResultPanel
          result={convert.result}
          error={convert.error}
          pending={convert.pending}
          onReset={convert.reset}
          emptyIcon={ScanLine}
          emptyTitle="No PDF/A output yet"
          emptyDescription="Choose a document and a target level. The converted artifact and its report appear here."
          renderReport={(report) => <PdfaReport report={report} />}
        />
      </div>

      {validation.result ? (
        <div className="card px-4 py-4">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-[13px] font-semibold text-ink">Verification of the produced file</h2>
            <Link href="/inspect" className="text-[11.5px] font-medium text-accent-strong hover:underline">
              Open full validator
            </Link>
          </div>
          <ValidationView report={validation.result.report} />
        </div>
      ) : null}
      {validation.error ? <Callout tone="danger" title="The produced file failed the walk">{validation.error}</Callout> : null}
    </div>
  );
}

function PdfaReport({ report }: { report: Record<string, unknown> }) {
  const entries = Object.entries(report).filter(([, value]) => typeof value !== "object");
  const issues = Array.isArray(report.issues) ? (report.issues as Array<Record<string, unknown>>) : [];
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
        {entries.slice(0, 9).map(([key, value]) => (
          <div key={key} className="rounded-lg border border-line bg-surface-muted/60 px-3 py-2">
            <div className="text-[10px] font-medium uppercase tracking-[0.06em] text-faint">{key}</div>
            <div className="mt-0.5 break-words text-[12.5px] text-ink">{String(value)}</div>
          </div>
        ))}
      </div>
      {issues.length > 0 ? (
        <div className="overflow-hidden rounded-lg border border-[#f0dcba]">
          {issues.map((issue, index) => (
            <div key={index} className="border-b border-[#f0dcba] bg-warn-soft px-3 py-2 text-[12px] text-[#7a470f] last:border-b-0">
              {String(issue.message ?? JSON.stringify(issue))}
            </div>
          ))}
        </div>
      ) : (
        <Callout tone="success" title="Conversion completed">
          The output is a new artifact. Use the preview to read it and the verification block below to see whether it passes the walk.
        </Callout>
      )}
    </div>
  );
}
