"use client";

import { useState } from "react";
import clsx from "clsx";
import {
  ArrowRightLeft,
  FileCode2,
  FileDown,
  FileImage,
  FileText,
  FormInput,
  Lock,
  Package,
  Palette,
  Presentation,
  ScanText,
  ShieldCheck,
  Sparkles,
  Type
} from "lucide-react";
import { html as htmlApi } from "@/lib/engine-api";
import { useWorkspace } from "@/components/workspace-provider";
import { useEngineDocument } from "@/lib/use-engine-document";
import { useHashTab } from "@/lib/use-hash-tab";
import { useToolRun } from "@/lib/use-tool-run";
import { ResultPanel } from "@/components/result-panel";
import { ConfigCard, DocumentSelect, InlineFields, RunBar } from "@/components/tool-form";
import { Callout, Checkbox, Field, NumberInput, PageHeader, Segmented, Select, Tabs, TextArea, TextInput } from "@/components/ui";

const TABS = [
  { id: "source", label: "Source", icon: FileCode2 },
  { id: "convert", label: "Convert", icon: ArrowRightLeft },
  { id: "query", label: "Query", icon: ScanText },
  { id: "sanitize", label: "Sanitise", icon: Lock },
  { id: "markdown", label: "Markdown", icon: Type },
  { id: "a11y", label: "A11y", icon: ShieldCheck },
  { id: "forms", label: "Forms", icon: FormInput },
  { id: "text", label: "Text", icon: ScanText },
  { id: "packages", label: "Containers", icon: Package },
  { id: "css", label: "Cascade", icon: Palette }
];

const CONVERT_FORMATS = [
  {
    id: "docx",
    label: "Word (.docx)",
    badge: "Office",
    icon: FileText,
    description: "Native Word document with headings, paragraphs, tables, lists, and formatting."
  },
  {
    id: "pdf",
    label: "PDF (.pdf)",
    badge: "Document",
    icon: FileDown,
    description: "Complete CSS layout, page breaks, margins, headers, and footers."
  },
  {
    id: "pptx",
    label: "PowerPoint (.pptx)",
    badge: "Office",
    icon: Presentation,
    description: "Presentation slides generated from HTML sections."
  },
  {
    id: "md",
    label: "Markdown (.md)",
    badge: "Markup",
    icon: Type,
    description: "Clean GitHub-Flavored Markdown syntax."
  },
  {
    id: "png",
    label: "PNG Image (.png)",
    badge: "Raster",
    icon: FileImage,
    description: "High-resolution page raster rendered at custom DPI."
  },
  {
    id: "svg",
    label: "SVG Vector (.svg)",
    badge: "Vector",
    icon: FileCode2,
    description: "Scalable vector graphics page rewrite."
  },
  {
    id: "gif",
    label: "GIF Image (.gif)",
    badge: "Raster",
    icon: FileImage,
    description: "Indexed bitmap image."
  },
  {
    id: "txt",
    label: "Plain Text (.txt)",
    badge: "Text",
    icon: ScanText,
    description: "Decoded text content stripped of all HTML tags."
  }
];

const SAMPLE = `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Quarterly note</title>
  <style>
    body { font-family: Georgia, serif; margin: 32pt; color: #1f2933; }
    h1 { color: #14532d; }
    table { border-collapse: collapse; }
    th, td { border: 1px solid #cbd5cf; padding: 4pt 8pt; }
  </style>
</head>
<body>
  <h1>Quarterly note</h1>
  <p>Rendered by the engine's own CSS layout pass — no browser, no external service.</p>
  <table>
    <tr><th>Pipeline</th><th>Q3 pages</th></tr>
    <tr><td>Supplier invoices</td><td>108,750</td></tr>
    <tr><td>Customer statements</td><td>44,120</td></tr>
  </table>
</body>
</html>`;

export default function HtmlPage() {
  const { artifacts } = useWorkspace();
  const [tab, setTab] = useState("source");
  useHashTab(["source", "convert", "query", "sanitize", "markdown", "a11y", "forms", "text", "packages", "css"], tab, setTab);
  const [artifactId, setArtifactId] = useEngineDocument("html");

  const [source, setSource] = useState<"workspace" | "inline">("workspace");
  const [inlineHtml, setInlineHtml] = useState(SAMPLE);
  const [fileName, setFileName] = useState("quarterly-note.html");
  const creator = useToolRun();
  const inspector = useToolRun();

  const [to, setTo] = useState("docx");
  const [pageSize, setPageSize] = useState("A4");
  const [margin, setMargin] = useState("42");
  const [dpi, setDpi] = useState("144");
  const [landscape, setLandscape] = useState(false);
  const [header, setHeader] = useState("");
  const [footer, setFooter] = useState("");
  const converter = useToolRun();

  const [selector, setSelector] = useState("table tr");
  const [mode, setMode] = useState("text");
  const [attribute, setAttribute] = useState("href");
  const [prefixText, setPrefixText] = useState(true);
  const querier = useToolRun();
  const tabler = useToolRun();

  const sanitizer = useToolRun();

  /* markdown */
  const [markdownMode, setMarkdownMode] = useState<"to" | "from">("to");
  const [markdown, setMarkdown] = useState("# Supplier memo\n\n- One intake queue\n- Validation on receipt\n\n| Team | Owner |\n| --- | --- |\n| Intake | Priya |\n");
  const markdownRun = useToolRun();

  /* accessibility */
  const [contrast, setContrast] = useState(true);
  const [severity, setSeverity] = useState("all");
  const a11y = useToolRun();

  /* forms */
  const [formMode, setFormMode] = useState<"read" | "validate" | "fill" | "serialize">("read");
  const [formSelector, setFormSelector] = useState("form");
  const [formValues, setFormValues] = useState('{\n  "company": "Kestrel Mills",\n  "volume": "large",\n  "terms": ""\n}');
  const forms = useToolRun();

  /* text */
  const [textSelector, setTextSelector] = useState("");
  const textRun = useToolRun();

  /* packages */
  const [packageMode, setPackageMode] = useState<"epub" | "mhtml-read" | "mhtml-save" | "standalone">("epub");
  const [containerId, setContainerId] = useState("");
  const packages = useToolRun();

  /* css */
  const [cssSelector, setCssSelector] = useState("h1");
  const [extraCss, setExtraCss] = useState("");
  const cssRun = useToolRun();

  const htmlArtifact = artifacts.find((artifact) => artifact.id === artifactId && (artifact.kind === "html" || artifact.kind === "text"));

  const sourceBody = () =>
    source === "inline" ? { html: inlineHtml } : { artifactId: artifactId || htmlArtifact?.id };

  const runCreate = () => creator.run(() => htmlApi.create({ html: inlineHtml, fileName, title: fileName.replace(/\.html?$/i, "") }));
  const runInspect = () => inspector.run(() => htmlApi.inspect(sourceBody()));
  const runConvert = () =>
    converter.run(() =>
      htmlApi.convert({
        ...sourceBody(),
        to,
        page: to === "png" || to === "svg" || to === "gif" ? 1 : undefined,
        dpi: to === "png" ? Number(dpi) || 144 : undefined,
        pageSize: to === "pdf" ? pageSize : undefined,
        margin: to === "pdf" ? Number(margin) : undefined,
        landscape: to === "pdf" ? landscape : undefined,
        header: header || undefined,
        footer: footer || undefined
      })
    );
  const runQuery = () => querier.run(() => htmlApi.query({ ...sourceBody(), selector, mode, attribute }));
  const runTable = () => tabler.run(() => htmlApi.table({ ...sourceBody(), selector: selector || undefined, prefixText }));
  const runSanitize = () => sanitizer.run(() => htmlApi.sanitize(sourceBody()));

  const runMarkdown = () =>
    markdownRun.run(() =>
      markdownMode === "to"
        ? htmlApi.markdown({ ...sourceBody(), action: "to", fileName: "document.md" })
        : htmlApi.markdown({ action: "from", markdown, fileName: "markdown.html" })
    );

  const runAccessibility = () => a11y.run(() => htmlApi.accessibility({ ...sourceBody(), contrast, severity }));

  const runForms = () =>
    forms.run(() => {
      if (formMode !== "fill") {
        return htmlApi.forms({
          ...sourceBody(),
          action: formMode,
          selector: formMode === "serialize" ? formSelector : undefined
        });
      }
      let parsed: Record<string, string>;
      try {
        parsed = JSON.parse(formValues);
      } catch (error) {
        throw new Error(`Values must be a JSON object keyed by control name: ${(error as Error).message}`);
      }
      return htmlApi.forms({ ...sourceBody(), action: "fill", values: parsed });
    });

  const runText = () => textRun.run(() => htmlApi.text({ ...sourceBody(), selector: textSelector || undefined }));

  const runPackages = () => {
    const suffix = packageMode === "epub" ? ".epub" : ".mhtml";
    const archive = containerId || artifacts.find((artifact) => artifact.fileName.toLowerCase().endsWith(suffix))?.id;
    if (packageMode === "epub") return packages.run(() => htmlApi.epub({ artifactId: archive ?? "" }));
    if (packageMode === "mhtml-read") return packages.run(() => htmlApi.mhtml({ artifactId: archive ?? "", action: "read" }));
    if (packageMode === "mhtml-save") return packages.run(() => htmlApi.mhtml({ ...sourceBody(), action: "save", fileName: "document.mhtml" }));
    return packages.run(() => htmlApi.standalone({ ...sourceBody(), fileName: "document.html" }));
  };

  const runCss = () => cssRun.run(() => htmlApi.css({ ...sourceBody(), selector: cssSelector, extraCss: extraCss || undefined }));

  return (
    <div>
      <PageHeader
        eyebrow="HTML engine"
        title="HTML workbench"
        description="Parse markup into the engine's own DOM, inspect and query it, export tables and render to PDF, PNG, GIF, SVG, DOCX or PPTX — all offline, no browser involved."
        actions={<span className="pill border border-line bg-surface px-2.5 py-1 text-[11px] text-muted">html · css · png · gif · docx · pptx</span>}
      />

      <div className="mb-4">
        <Tabs tabs={TABS} value={tab} onChange={setTab} />
      </div>

      <div className="split-wrap">
        <div className="min-w-0 space-y-4">

          {tab !== "source" ? (
            <ConfigCard
              title="What is rendered"
              description="Point at a markup file already in the workspace, or edit markup inline. Inline markup is parsed in memory and never written to disk."
            >
              <InlineFields>
                <Field label="Source">
                  <Select
                    value={source}
                    onChange={(event) => setSource(event.target.value as "workspace" | "inline")}
                    options={[
                      { value: "workspace", label: "Workspace markup" },
                      { value: "inline", label: "Inline markup" }
                    ]}
                  />
                </Field>
                {source === "workspace" ? (
                  <DocumentSelect label="Markup file" include="html" value={artifactId} onChange={setArtifactId} />
                ) : (
                  <Field label="File name" hint="Used when the render writes a file">
                    <TextInput value={fileName} onChange={(event) => setFileName(event.target.value)} />
                  </Field>
                )}
              </InlineFields>
            </ConfigCard>
          ) : null}

          {tab === "source" ? (
            <ConfigCard
              title="Author or inspect"
              description="Saving writes the markup into the library so every other workbench can pick it up."
              footer={
                <div className="flex flex-wrap gap-2">
                  <button type="button" className="btn btn-primary btn-sm" onClick={runCreate} disabled={creator.pending || !inlineHtml.trim()}>
                    Save markup to library
                  </button>
                  <button type="button" className="btn btn-secondary btn-sm" onClick={runInspect} disabled={inspector.pending || (source === "workspace" && !artifactId)}>
                    Inspect structure
                  </button>
                </div>
              }
            >
              <InlineFields>
                <Field label="Source">
                  <Select
                    value={source}
                    onChange={(event) => setSource(event.target.value as "workspace" | "inline")}
                    options={[
                      { value: "workspace", label: "Workspace markup" },
                      { value: "inline", label: "Inline markup" }
                    ]}
                  />
                </Field>
                {source === "workspace" ? (
                  <DocumentSelect label="Markup file" include="html" value={artifactId} onChange={setArtifactId} />
                ) : (
                  <Field label="File name">
                    <TextInput value={fileName} onChange={(event) => setFileName(event.target.value)} />
                  </Field>
                )}
              </InlineFields>
              {source === "inline" ? (
                <Field label="Markup" hint="Parsed by the engine; nothing is executed">
                  <TextArea value={inlineHtml} rows={14} onChange={(event) => setInlineHtml(event.target.value)} className="font-mono text-[11.5px]" />
                </Field>
              ) : (
                <p className="text-[11.5px] leading-[1.5] text-muted">
                  The inspector reports element and text-node counts, the heading outline, images, references and any
                  findings it can prove from the markup alone: broken anchors, missing alt text, duplicate ids and
                  low-contrast inline colours.
                </p>
              )}
            </ConfigCard>
          ) : null}

          {tab === "convert" ? (
            <div className="space-y-4">
              <ConfigCard
                title="Convert HTML to Various Formats"
                description="Transform HTML documents or inline markup directly into Word (.docx), PDF, PowerPoint (.pptx), Markdown, Images, or Text using the engine's built-in parsers and layout writers."
                footer={
                  <RunBar
                    label={
                      to === "docx"
                        ? "Convert HTML to Word (.docx)"
                        : to === "pdf"
                          ? "Convert HTML to PDF"
                          : to === "pptx"
                            ? "Convert HTML to PowerPoint (.pptx)"
                            : to === "md"
                              ? "Convert HTML to Markdown"
                              : to === "png"
                                ? "Convert HTML to PNG Image"
                                : to === "svg"
                                  ? "Convert HTML to SVG Vector"
                                  : to === "gif"
                                    ? "Convert HTML to GIF"
                                    : "Convert HTML to Text"
                    }
                    pending={converter.pending}
                    disabled={source === "workspace" && !artifactId}
                    onRun={runConvert}
                    hint="Generates a new downloadable artifact in the workspace"
                  />
                }
              >
                {/* Format selection cards */}
                <div>
                  <label className="label mb-2">Target Format</label>
                  <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                    {CONVERT_FORMATS.map((fmt) => {
                      const Icon = fmt.icon;
                      const active = to === fmt.id;
                      return (
                        <button
                          key={fmt.id}
                          type="button"
                          onClick={() => setTo(fmt.id)}
                          className={clsx(
                            "flex flex-col items-start rounded-lg border p-3 text-left transition select-none",
                            active
                              ? "border-accent bg-accent/5 ring-1 ring-accent"
                              : "border-line bg-surface hover:border-line-strong hover:bg-surface-muted/60"
                          )}
                        >
                          <div className="mb-1.5 flex w-full items-center justify-between">
                            <Icon className={clsx("size-4", active ? "text-accent" : "text-muted")} />
                            <span className={clsx("rounded px-1.5 py-0.5 text-[9.5px] font-semibold uppercase tracking-wider", active ? "bg-accent/15 text-accent" : "bg-surface-muted text-muted")}>
                              {fmt.badge}
                            </span>
                          </div>
                          <span className={clsx("text-[12.5px] font-medium", active ? "text-accent font-semibold" : "text-ink")}>
                            {fmt.label}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Target details and options */}
                {to === "docx" ? (
                  <div className="rounded-lg border border-accent/25 bg-accent-soft/40 p-3.5 space-y-2.5">
                    <div className="flex items-center gap-2">
                      <FileText className="size-4 text-accent" />
                      <h3 className="text-[12.5px] font-semibold text-ink">HTML → Word (.docx) Conversion</h3>
                    </div>
                    <p className="text-[11.5px] leading-relaxed text-muted">
                      The engine converts HTML markup directly into a native Microsoft Word (.docx) OpenXML document:
                    </p>
                    <ul className="grid grid-cols-1 gap-1.5 text-[11px] text-muted sm:grid-cols-2">
                      <li className="flex items-center gap-1.5">
                        <span className="size-1 rounded-full bg-accent" />
                        <span>Headings (<code>&lt;h1&gt;</code>–<code>&lt;h6&gt;</code>) mapped to Word heading styles</span>
                      </li>
                      <li className="flex items-center gap-1.5">
                        <span className="size-1 rounded-full bg-accent" />
                        <span>Formatted tables (<code>&lt;table&gt;</code>, borders, cells, headers)</span>
                      </li>
                      <li className="flex items-center gap-1.5">
                        <span className="size-1 rounded-full bg-accent" />
                        <span>Lists (<code>&lt;ul&gt;</code>, <code>&lt;ol&gt;</code>) &amp; blockquotes</span>
                      </li>
                      <li className="flex items-center gap-1.5">
                        <span className="size-1 rounded-full bg-accent" />
                        <span>Inline formatting (<strong>bold</strong>, <em>italic</em>, hyperlinks)</span>
                      </li>
                    </ul>
                  </div>
                ) : null}

                {to === "pdf" ? (
                  <div className="space-y-3">
                    <InlineFields>
                      <Field label="Page size" hint="Named sizes are parsed by the engine">
                        <Select
                          value={pageSize}
                          onChange={(event) => setPageSize(event.target.value)}
                          options={[
                            { value: "A4", label: "A4 (210 × 297 mm)" },
                            { value: "Letter", label: "Letter (8.5 × 11 in)" },
                            { value: "Legal", label: "Legal (8.5 × 14 in)" },
                            { value: "A3", label: "A3 (297 × 420 mm)" }
                          ]}
                        />
                      </Field>
                      <Field label="Margin (pt)" hint="Page margins">
                        <NumberInput value={margin} min={0} max={200} onChange={setMargin} />
                      </Field>
                    </InlineFields>
                    <InlineFields>
                      <Field label="Orientation">
                        <div className="pt-2">
                          <Checkbox checked={landscape} onChange={setLandscape} label="Landscape orientation" />
                        </div>
                      </Field>
                      <div />
                    </InlineFields>
                    <InlineFields>
                      <Field label="Running header" hint="Optional, supports {page} and {pages}">
                        <TextInput value={header} onChange={(event) => setHeader(event.target.value)} placeholder="Header title" />
                      </Field>
                      <Field label="Running footer" hint="Optional, supports {page} and {pages}">
                        <TextInput value={footer} onChange={(event) => setFooter(event.target.value)} placeholder="Page {page} of {pages}" />
                      </Field>
                    </InlineFields>
                  </div>
                ) : null}

                {to === "pptx" ? (
                  <div className="rounded-lg border border-line bg-surface-muted/50 p-3 text-[11.5px] text-muted space-y-1">
                    <p className="font-medium text-ink">HTML → PowerPoint Presentation (.pptx)</p>
                    <p>Creates presentation slides from rendered HTML pages and slide sections.</p>
                  </div>
                ) : null}

                {to === "md" ? (
                  <div className="rounded-lg border border-line bg-surface-muted/50 p-3 text-[11.5px] text-muted space-y-1">
                    <p className="font-medium text-ink">HTML → GitHub Flavored Markdown (.md)</p>
                    <p>Converts HTML tags, tables, code blocks, and links into clean markdown syntax.</p>
                  </div>
                ) : null}

                {to === "png" || to === "gif" || to === "svg" ? (
                  <div className="space-y-3">
                    <InlineFields>
                      {to === "png" ? (
                        <Field label="Raster resolution (DPI)" hint="Higher DPI produces sharper images">
                          <NumberInput value={dpi} min={72} max={600} step={24} onChange={setDpi} />
                        </Field>
                      ) : null}
                      <Field label="Page number" hint="Page to render">
                        <NumberInput value="1" onChange={() => {}} min={1} max={100} disabled />
                      </Field>
                    </InlineFields>
                  </div>
                ) : null}

                {to === "txt" ? (
                  <div className="rounded-lg border border-line bg-surface-muted/50 p-3 text-[11.5px] text-muted space-y-1">
                    <p className="font-medium text-ink">HTML → Plain Text (.txt)</p>
                    <p>Extracts decoded readable text content with all HTML markup and scripts stripped.</p>
                  </div>
                ) : null}
              </ConfigCard>
            </div>
          ) : null}

          {tab === "query" ? (
            <div className="space-y-4">
              <ConfigCard
                title="Query the DOM"
                description="CSS selectors run against the parsed tree; text, attribute or html mode decides what comes back for each match."
                footer={<RunBar label="Run selector" pending={querier.pending} onRun={runQuery} hint="Deterministic CSS subset, no script" />}
              >
                <Field label="Selector">
                  <TextInput value={selector} onChange={(event) => setSelector(event.target.value)} placeholder="table tr" />
                </Field>
                <InlineFields>
                  <Field label="Return">
                    <Select
                      value={mode}
                      onChange={(event) => setMode(event.target.value)}
                      options={[
                        { value: "text", label: "Text content" },
                        { value: "attribute", label: "Attribute value" },
                        { value: "html", label: "Outer HTML" },
                        { value: "count", label: "Count only" }
                      ]}
                    />
                  </Field>
                  <Field label="Attribute" hint="Used by attribute mode">
                    <TextInput value={attribute} onChange={(event) => setAttribute(event.target.value)} disabled={mode !== "attribute"} />
                  </Field>
                </InlineFields>
              </ConfigCard>

              <ConfigCard
                title="Export a table"
                description="The first table matching the selector is written as tab-separated rows, exactly as the engine reports the grid."
                footer={<RunBar label="Export table as TSV" pending={tabler.pending} onRun={runTable} hint="Rows keep their column order" />}
              >
                <InlineFields>
                  <Field label="Table selector" hint="Empty selects the first table">
                    <TextInput value={selector} onChange={(event) => setSelector(event.target.value)} placeholder="table" />
                  </Field>
                  <Field label="Prefix">
                    <div className="pt-2">
                      <Checkbox checked={prefixText} onChange={setPrefixText} label="Include preceding label" />
                    </div>
                  </Field>
                </InlineFields>
              </ConfigCard>
            </div>
          ) : null}

          {tab === "sanitize" ? (
            <ConfigCard
              title="Sanitise markup"
              description="Allowlist reduction: scripts, event handlers, frames and dangerous URLs are removed and reported with a count, never silently."
              footer={<RunBar label="Sanitise" pending={sanitizer.pending} onRun={runSanitize} hint="Writes the reduced markup to the library" />}
            >
              <Callout tone="warn">
                This is a first pass over untrusted markup, not a browser-grade XSS boundary. Serve the result with a
                restrictive Content-Security-Policy.
              </Callout>
            </ConfigCard>
          ) : null}

          {tab === "markdown" ? (
            <ConfigCard
              title="Markdown bridge"
              description="The engine writes GFM from the parsed tree and reads Markdown back into it — headings, lists, tables, emphasis, code and links survive the round trip."
              footer={
                <RunBar
                  label={markdownMode === "to" ? "Convert to Markdown" : "Convert to HTML"}
                  pending={markdownRun.pending}
                  disabled={markdownMode === "from" && !markdown.trim()}
                  hint={markdownMode === "to" ? "Written to the library as .md" : "Written to the library as .html"}
                  onRun={runMarkdown}
                />
              }
            >
              <Segmented
                value={markdownMode}
                onChange={setMarkdownMode}
                options={[
                  { value: "to", label: "HTML → Markdown" },
                  { value: "from", label: "Markdown → HTML" }
                ]}
              />
              {markdownMode === "from" ? (
                <Field label="Markdown">
                  <TextArea value={markdown} rows={12} onChange={(event) => setMarkdown(event.target.value)} className="font-mono text-[11.5px]" />
                </Field>
              ) : (
                <p className="text-[11.5px] leading-[1.5] text-muted">
                  The markup above is parsed first; unsupported constructs are dropped rather than guessed at.
                </p>
              )}
            </ConfigCard>
          ) : null}

          {tab === "a11y" ? (
            <ConfigCard
              title="Accessibility triage"
              description="Structural findings — heading order, image alt text, form labels, link text — plus an opt-in contrast pass over the computed colours."
              footer={<RunBar label="Check markup" pending={a11y.pending} hint="Read-only: nothing is written" onRun={runAccessibility} />}
            >
              <Checkbox checked={contrast} onChange={setContrast} label="Evaluate contrast from the document's CSS" />
              <Field label="Severity filter">
                <Segmented
                  value={severity}
                  onChange={setSeverity}
                  options={[
                    { value: "all", label: "All" },
                    { value: "error", label: "Errors" },
                    { value: "warning", label: "Warnings" },
                    { value: "info", label: "Info" }
                  ]}
                />
              </Field>
              <Callout tone="info">
                A triage pass over structure and colour, not a WCAG conformance audit; the engine labels each finding with
                a stable code.
              </Callout>
            </ConfigCard>
          ) : null}

          {tab === "forms" ? (
            <ConfigCard
              title="Forms"
              description="Read the controls and their labels, check the label and constraint hints, fill values by control name, or serialise a form as application/x-www-form-urlencoded."
              footer={<RunBar label={formMode === "read" ? "Read form" : formMode === "validate" ? "Validate" : formMode === "fill" ? "Fill and save" : "Serialise"} pending={forms.pending} hint={formMode === "read" || formMode === "validate" ? "Read-only: nothing is written" : "Writes a new file to the library"} onRun={runForms} />}
            >
              <Segmented
                value={formMode}
                onChange={setFormMode}
                options={[
                  { value: "read", label: "Read" },
                  { value: "validate", label: "Validate" },
                  { value: "fill", label: "Fill" },
                  { value: "serialize", label: "Serialise" }
                ]}
              />
              {formMode === "fill" ? (
                <Field label="Values" hint="JSON object keyed by control name; empty string unchecks a box">
                  <TextArea value={formValues} rows={7} onChange={(event) => setFormValues(event.target.value)} className="font-mono text-[11.5px]" />
                </Field>
              ) : null}
              {formMode === "serialize" ? (
                <Field label="Form selector">
                  <TextInput value={formSelector} onChange={(event) => setFormSelector(event.target.value)} />
                </Field>
              ) : null}
            </ConfigCard>
          ) : null}

          {tab === "text" ? (
            <ConfigCard
              title="Extract text"
              description="Plain text from the parsed tree, optionally scoped to one selector. The extracted text is written to the library as a .txt artifact."
              footer={<RunBar label="Extract text" pending={textRun.pending} hint="Tables keep their cell boundaries" onRun={runText} />}
            >
              <Field label="Selector" hint="Empty reads the whole document">
                <TextInput value={textSelector} onChange={(event) => setTextSelector(event.target.value)} placeholder="article, main, #content" />
              </Field>
            </ConfigCard>
          ) : null}

          {tab === "packages" ? (
            <ConfigCard
              title="Containers and bundles"
              description="Read an EPUB package or a MIME (MHTML) archive back into HTML, bundle markup into a single MIME file, or write one self-contained HTML with its stylesheet inlined."
              footer={
                <RunBar
                  label={packageMode === "epub" ? "Read EPUB" : packageMode === "mhtml-read" ? "Read MHTML" : packageMode === "mhtml-save" ? "Write MHTML" : "Write standalone HTML"}
                  pending={packages.pending}
                  disabled={
                    (packageMode === "epub" || packageMode === "mhtml-read") &&
                    !containerId &&
                    !artifacts.some((artifact) => artifact.fileName.toLowerCase().endsWith(packageMode === "epub" ? ".epub" : ".mhtml"))
                  }
                  hint="Every result is a new artifact"
                  onRun={runPackages}
                />
              }
            >
              <Segmented
                value={packageMode}
                onChange={setPackageMode}
                options={[
                  { value: "epub", label: "EPUB" },
                  { value: "mhtml-read", label: "MHTML read" },
                  { value: "mhtml-save", label: "MHTML write" },
                  { value: "standalone", label: "Standalone" }
                ]}
              />
              {packageMode === "epub" ? (
                <DocumentSelect label="EPUB artifact" include="html" value={containerId} onChange={setContainerId} />
              ) : packageMode === "mhtml-read" ? (
                <DocumentSelect label="MHTML artifact" include="email" value={containerId} onChange={setContainerId} />
              ) : (
                <p className="text-[11.5px] leading-[1.5] text-muted">
                  The markup above is bundled: stylesheets and images that resolve locally are inlined, and anything that
                  would need a network fetch is reported as a warning instead.
                </p>
              )}
            </ConfigCard>
          ) : null}

          {tab === "css" ? (
            <ConfigCard
              title="CSS cascade"
              description="The winning author declarations for one element, the stylesheet inventory the document carries, and the cascade's own warnings."
              footer={<RunBar label="Resolve cascade" pending={cssRun.pending} disabled={!cssSelector.trim()} hint="Read-only: nothing is written" onRun={runCss} />}
            >
              <InlineFields>
                <Field label="Selector">
                  <TextInput value={cssSelector} onChange={(event) => setCssSelector(event.target.value)} />
                </Field>
                <Field label="Extra CSS" hint="Optional, appended as an author sheet">
                  <TextInput value={extraCss} onChange={(event) => setExtraCss(event.target.value)} placeholder="p { color: red }" />
                </Field>
              </InlineFields>
              <Callout tone="info">
                These are cascade winners, not browser computed styles: no layout, no inheritance substitution, no
                user-agent defaults beyond what the engine ships.
              </Callout>
            </ConfigCard>
          ) : null}
        </div>

        <div className="min-w-0">
          {tab === "source" ? (
            <ResultPanel
              result={creator.result ?? inspector.result}
              error={creator.error ?? inspector.error}
              pending={creator.pending || inspector.pending}
              emptyTitle="Nothing inspected yet"
              emptyDescription="Inspect a markup file to see its outline, references and findings, or save inline markup into the library."
              emptyIcon={FileCode2}
              onReset={() => {
                creator.reset();
                inspector.reset();
              }}
            />
          ) : null}
          {tab === "convert" ? (
            <ResultPanel
              result={converter.result}
              error={converter.error}
              pending={converter.pending}
              emptyTitle="Nothing rendered yet"
              emptyDescription="Render to PDF to see the engine's paginated layout, or to PNG for a single page raster."
              emptyIcon={Sparkles}
              onReset={converter.reset}
            />
          ) : null}
          {tab === "query" ? (
            <ResultPanel
              result={querier.result ?? tabler.result}
              error={querier.error ?? tabler.error}
              pending={querier.pending || tabler.pending}
              emptyTitle="Nothing queried yet"
              emptyDescription="Run a selector to list matches, or export the first matching table as TSV."
              emptyIcon={ScanText}
              onReset={() => {
                querier.reset();
                tabler.reset();
              }}
            />
          ) : null}
          {tab === "sanitize" ? (
            <ResultPanel
              result={sanitizer.result}
              error={sanitizer.error}
              pending={sanitizer.pending}
              emptyTitle="Nothing sanitised yet"
              emptyDescription="Pick a markup source, then reduce it to the engine's allowlist and read what was removed."
              emptyIcon={Lock}
              onReset={sanitizer.reset}
            />
          ) : null}
          {tab === "markdown" ? (
            <ResultPanel result={markdownRun.result} error={markdownRun.error} pending={markdownRun.pending} emptyTitle="Nothing converted yet" emptyDescription="Convert the markup above to Markdown, or write Markdown into a new HTML document." emptyIcon={Type} onReset={markdownRun.reset} />
          ) : null}
          {tab === "a11y" ? (
            <ResultPanel result={a11y.result} error={a11y.error} pending={a11y.pending} emptyTitle="Nothing checked yet" emptyDescription="Findings carry a stable code, a severity and the path to the element they describe." emptyIcon={ShieldCheck} onReset={a11y.reset} />
          ) : null}
          {tab === "forms" ? (
            <ResultPanel result={forms.result} error={forms.error} pending={forms.pending} emptyTitle="Nothing read yet" emptyDescription="Read the controls and labels, validate them, fill values by name, or serialise the form data." emptyIcon={FormInput} onReset={forms.reset} />
          ) : null}
          {tab === "text" ? (
            <ResultPanel result={textRun.result} error={textRun.error} pending={textRun.pending} emptyTitle="Nothing extracted yet" emptyDescription="Text comes from the parsed tree; the engine writes it out as a .txt artifact too." emptyIcon={ScanText} onReset={textRun.reset} />
          ) : null}
          {tab === "packages" ? (
            <ResultPanel result={packages.result} error={packages.error} pending={packages.pending} emptyTitle="Nothing read yet" emptyDescription="EPUB and MHTML read back into HTML; markup bundles out as MHTML or one standalone file." emptyIcon={Package} onReset={packages.reset} />
          ) : null}
          {tab === "css" ? (
            <ResultPanel result={cssRun.result} error={cssRun.error} pending={cssRun.pending} emptyTitle="Nothing resolved yet" emptyDescription="Pick a selector to see which declarations won and where the sheets came from." emptyIcon={Palette} onReset={cssRun.reset} />
          ) : null}
        </div>
      </div>
    </div>
  );
}
