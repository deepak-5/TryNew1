"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMemo, useRef, useState } from "react";
import clsx from "clsx";
import {
  BookDown,
  Download,
  FileCode2,
  FileJson,
  FileSpreadsheet,
  FileStack,
  FileText,
  Image as ImageIcon,
  Mail,
  Plus,
  Presentation,
  RefreshCw,
  Search,
  Trash2,
  Upload
} from "lucide-react";
import { useWorkspace } from "@/components/workspace-provider";
import { useToast } from "@/components/toast";
import { previewSrc } from "@/components/pdf-preview";
import { artifactTypeLabel, formatBytes, formatDate } from "@/lib/format";
import type { Artifact } from "@/lib/types";
import {
  Button,
  Card,
  ConfirmDialog,
  EmptyState,
  PageHeader,
  Pill,
  Select,
  TextInput
} from "@/components/ui";

type KindFilter = "all" | "pdf" | "image" | "html" | "word" | "sheet" | "slides" | "email" | "text" | "data";

export default function LibraryPage() {
  const { artifacts, pdfs, loading, upload, remove, restoreSamples } = useWorkspace();
  const { notify } = useToast();
  const router = useRouter();
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);
  const [busy, setBusy] = useState(false);
  const [query, setQuery] = useState("");
  const [kind, setKind] = useState<KindFilter>("all");
  const [sort, setSort] = useState("newest");
  const [pendingDelete, setPendingDelete] = useState<Artifact | null>(null);
  const [deleting, setDeleting] = useState(false);

  const filtered = useMemo(() => {
    const list = artifacts.filter((artifact) => {
      if (kind !== "all" && artifact.kind !== kind) return false;
      if (!query.trim()) return true;
      const needle = query.trim().toLowerCase();
      return artifact.fileName.toLowerCase().includes(needle) || (artifact.operation ?? "").toLowerCase().includes(needle);
    });
    return list.sort((a, b) => {
      if (sort === "name") return a.fileName.localeCompare(b.fileName);
      if (sort === "size") return b.size - a.size;
      return a.createdAt < b.createdAt ? 1 : -1;
    });
  }, [artifacts, kind, query, sort]);

  async function handleUpload(files: FileList | File[] | null) {
    if (!files || files.length === 0) return;
    setBusy(true);
    let added = 0;
    for (const file of Array.from(files)) {
      try {
        await upload(file);
        added += 1;
      } catch (cause) {
        notify({ title: `${file.name} was not accepted`, description: cause instanceof Error ? cause.message : "Unknown error", tone: "error" });
      }
    }
    if (added > 0) notify({ title: `${added} document${added === 1 ? "" : "s"} added to the workspace` });
    setBusy(false);
    setDragging(false);
    if (inputRef.current) inputRef.current.value = "";
  }

  async function confirmDelete() {
    if (!pendingDelete) return;
    setDeleting(true);
    try {
      await remove(pendingDelete.id);
      notify({ title: "Artifact removed", description: pendingDelete.fileName });
      setPendingDelete(null);
    } catch (cause) {
      notify({ title: "Could not remove the artifact", description: cause instanceof Error ? cause.message : "Unknown error", tone: "error" });
    } finally {
      setDeleting(false);
    }
  }

  return (
    <div>
      <PageHeader
        eyebrow="Workspace"
        title="Library"
        description="Uploads and every document the engine has written in this session. Files live outside the repository and are re-listed on each request."
        actions={
          <>
            <Button
              icon={RefreshCw}
              onClick={async () => {
                const created = await restoreSamples();
                notify({
                  title: created > 0 ? `${created} sample${created === 1 ? "" : "s"} restored` : "Samples are already present",
                  description: created > 0 ? "Written by each engine's own authoring API or importer." : undefined
                });
              }}
            >
              Restore samples
            </Button>
            <Button variant="primary" icon={Upload} onClick={() => inputRef.current?.click()}>
              Upload
            </Button>
          </>
        }
      />

      <input
        ref={inputRef}
        type="file"
        accept=".pdf,.docx,.doc,.rtf,.odt,.xlsx,.xlsm,.xls,.ods,.csv,.pptx,.pptm,.potx,.odp,.eml,.msg,.mht,.mhtml,.html,.htm,.txt,.md,.json,.xml,image/*"
        multiple
        className="hidden"
        onChange={(event) => handleUpload(event.target.files)}
      />

      <div
        onDragOver={(event) => {
          event.preventDefault();
          setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={(event) => {
          event.preventDefault();
          handleUpload(event.dataTransfer.files);
        }}
        onClick={() => inputRef.current?.click()}
        className={clsx(
          "mb-5 flex cursor-pointer items-center gap-4 rounded-xl border border-dashed px-5 py-4 transition",
          dragging ? "border-accent bg-accent-soft/60" : "border-line-strong bg-surface hover:border-accent-line hover:bg-surface-muted/60"
        )}
      >
        <span className="flex size-9 shrink-0 items-center justify-center rounded-lg border border-line bg-surface">
          {busy ? (
            <span className="size-3.5 animate-spin rounded-full border-2 border-line-strong border-t-accent" />
          ) : (
            <Upload className="size-4 text-accent" />
          )}
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-[13px] font-medium text-ink">
            {busy ? "Uploading…" : dragging ? "Drop the files to add them" : "Drop a document here, or click to browse"}
          </p>
          <p className="text-[11.5px] text-muted">
            PDF, Word, Excel, PowerPoint, email and HTML. Up to 128 MB per file; encrypted files are accepted and the
            operations that open them ask for the password.
          </p>
        </div>
        <span className="hidden shrink-0 rounded-md border border-line bg-surface px-2 py-1 text-[11px] text-muted sm:inline">
          PDF · DOCX · XLSX · PPTX · EML · HTML
        </span>
      </div>

      <Card className="overflow-hidden">
        <div className="flex flex-wrap items-center gap-2 border-b border-line px-4 py-3">
          <div className="relative min-w-[220px] flex-1">
            <Search className="pointer-events-none absolute left-2.5 top-1/2 size-3.5 -translate-y-1/2 text-faint" />
            <TextInput
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Search by file name or operation"
              className="h-8 pl-8 text-[12.5px]"
            />
          </div>
          <Select
            value={kind}
            onChange={(event) => setKind(event.target.value as KindFilter)}
            className="h-8 w-[150px] text-[12.5px]"
            options={[
              { value: "all", label: "All files" },
              { value: "pdf", label: "PDF" },
              { value: "image", label: "Images" },
              { value: "word", label: "Word documents" },
              { value: "sheet", label: "Workbooks" },
              { value: "slides", label: "Presentations" },
              { value: "email", label: "Messages" },
              { value: "html", label: "HTML" },
              { value: "text", label: "Text" },
              { value: "data", label: "Data" }
            ]}
          />
          <Select
            value={sort}
            onChange={(event) => setSort(event.target.value)}
            className="h-8 w-[150px] text-[12.5px]"
            options={[
              { value: "newest", label: "Newest first" },
              { value: "name", label: "Name A–Z" },
              { value: "size", label: "Largest first" }
            ]}
          />
          <span className="ml-auto text-[11.5px] tabular-nums text-faint">
            {filtered.length} of {artifacts.length}
          </span>
        </div>

        {loading ? (
          <div className="px-5 py-16 text-center text-[12.5px] text-muted">Reading the workspace…</div>
        ) : filtered.length === 0 ? (
          <EmptyState
            icon={FileStack}
            title={artifacts.length === 0 ? "The workspace is empty" : "No artifact matches these filters"}
            description={
              artifacts.length === 0
                ? "Upload a PDF, or restore the four samples the engine builds from HTML at startup."
                : "Clear the search or switch the kind filter to see the rest of the workspace."
            }
            action={
              artifacts.length === 0 ? (
                <Button variant="primary" icon={Plus} onClick={() => inputRef.current?.click()}>
                  Upload a PDF
                </Button>
              ) : null
            }
          />
        ) : (
          <table className="table-base">
            <thead>
              <tr>
                <th>File</th>
                <th>Kind</th>
                <th className="text-right">Pages</th>
                <th className="text-right">Size</th>
                <th>Source</th>
                <th>Added</th>
                <th className="w-9" />
              </tr>
            </thead>
            <tbody>
              {filtered.map((artifact) => (
                <tr key={artifact.id} className="group">
                  <td className="max-w-[380px]">
                    <div className="flex items-center gap-2.5">
                      {artifact.kind === "pdf" ? (
                        <span className="relative flex h-9 w-7 shrink-0 items-center justify-center overflow-hidden rounded border border-line bg-[#f5f7f4]">
                          {artifact.locked ? (
                            <FileText className="size-3.5 text-faint" />
                          ) : (
                            // eslint-disable-next-line @next/next/no-img-element
                            <img src={previewSrc(artifact, 1, 50)} alt="" className="h-full w-full bg-white object-contain p-0.5" />
                          )}
                        </span>
                      ) : (
                        <span className="flex size-7 shrink-0 items-center justify-center rounded border border-line bg-[#f5f7f4]">
                          {artifact.kind === "image" ? (
                            <ImageIcon className="size-3.5 text-faint" />
                          ) : artifact.kind === "data" ? (
                            <FileJson className="size-3.5 text-faint" />
                          ) : artifact.kind === "word" ? (
                            <BookDown className="size-3.5 text-faint" />
                          ) : artifact.kind === "sheet" ? (
                            <FileSpreadsheet className="size-3.5 text-faint" />
                          ) : artifact.kind === "slides" ? (
                            <Presentation className="size-3.5 text-faint" />
                          ) : artifact.kind === "email" ? (
                            <Mail className="size-3.5 text-faint" />
                          ) : artifact.kind === "html" ? (
                            <FileCode2 className="size-3.5 text-faint" />
                          ) : (
                            <FileText className="size-3.5 text-faint" />
                          )}
                        </span>
                      )}
                      <div className="min-w-0">
                        <Link
                          href={artifact.kind === "pdf" ? `/documents/${artifact.id}` : artifact.contentUrl}
                          target={artifact.kind === "pdf" ? undefined : "_blank"}
                          rel={artifact.kind === "pdf" ? undefined : "noreferrer"}
                          className="block truncate text-[12.5px] font-medium text-ink hover:text-accent-strong"
                        >
                          {artifact.fileName}
                        </Link>
                        <p className="truncate text-[11px] text-faint">{artifact.operation ?? "Uploaded by the tester"}</p>
                      </div>
                    </div>
                  </td>
                  <td>
                    <Pill tone={artifact.kind === "pdf" ? "accent" : "neutral"}>
                      {artifactTypeLabel(artifact)}
                    </Pill>
                  </td>
                  <td className="text-right tabular-nums text-muted">{artifact.pageCount ?? "—"}</td>
                  <td className="text-right tabular-nums text-muted">{formatBytes(artifact.size)}</td>
                  <td className="capitalize text-muted">{artifact.origin}</td>
                  <td className="whitespace-nowrap text-muted">{formatDate(artifact.createdAt)}</td>
                  <td>
                    <div className="flex items-center justify-end gap-0.5 opacity-0 transition group-hover:opacity-100 focus-within:opacity-100">
                      <a
                        href={`${artifact.contentUrl}?download=1`}
                        download={artifact.fileName}
                        className="rounded p-1.5 text-muted hover:bg-canvas hover:text-ink"
                        aria-label="Download"
                      >
                        <Download className="size-3.5" />
                      </a>
                      <button
                        type="button"
                        onClick={() => setPendingDelete(artifact)}
                        className="rounded p-1.5 text-muted hover:bg-danger-soft hover:text-danger"
                        aria-label="Delete"
                      >
                        <Trash2 className="size-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Card>

      <p className="mt-3 text-[11.5px] text-faint">
        {pdfs.length} PDF{pdfs.length === 1 ? "" : "s"} available as inputs. Artifacts are stored in the API workspace and are not committed to the repository.
      </p>

      <ConfirmDialog
        open={pendingDelete != null}
        title="Remove this artifact?"
        description={
          <>
            <span className="font-medium text-ink">{pendingDelete?.fileName}</span> will be deleted from the workspace. Documents produced from it stay in place.
          </>
        }
        confirmLabel="Remove"
        pending={deleting}
        onClose={() => setPendingDelete(null)}
        onConfirm={confirmDelete}
      />
    </div>
  );
}
