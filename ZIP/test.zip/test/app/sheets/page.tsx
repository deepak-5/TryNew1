"use client";

import { ReactNode, useState } from "react";
import { ClipboardList, FileCode2, FileSpreadsheet, FileStack, GitCompare, Grid3x3, Search, Wand2 } from "lucide-react";
import { sheets as sheetsApi } from "@/lib/engine-api";
import { useEngineDocument } from "@/lib/use-engine-document";
import { useHashTab } from "@/lib/use-hash-tab";
import { useToolRun } from "@/lib/use-tool-run";
import { ResultPanel } from "@/components/result-panel";
import { ConfigCard, DocumentSelect, InlineFields, RunBar } from "@/components/tool-form";
import { Callout, Checkbox, Field, PageHeader, Segmented, Select, Tabs, TextArea, TextInput } from "@/components/ui";

const TABS = [
  { id: "workbook", label: "Workbook", icon: FileSpreadsheet },
  { id: "convert", label: "Convert", icon: FileCode2 },
  { id: "calculate", label: "Recalculate", icon: Wand2 },
  { id: "structure", label: "Structure", icon: ClipboardList },
  { id: "cells", label: "Cells", icon: Grid3x3 },
  { id: "sheets", label: "Sheets", icon: FileStack },
  { id: "text", label: "Find", icon: Search },
  { id: "formats", label: "Formats", icon: FileCode2 },
  { id: "compare", label: "Compare", icon: GitCompare }
];

type WorkbookInfo = {
  worksheets?: number;
  names?: string[];
  charts?: number;
  definedNames?: Array<{ name?: string; formula?: string }>;
  workbook?: { sheetCount?: number; dateSystem?: string; hasVbaMacros?: boolean };
  note?: string;
};

function Fact({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="rounded-lg border border-line bg-surface px-3 py-2">
      <div className="section-label">{label}</div>
      <div className="mt-0.5 text-[13px] font-medium text-ink">{children}</div>
    </div>
  );
}

export default function SheetsPage() {
  const [tab, setTab] = useState("workbook");
  useHashTab(["workbook", "convert", "calculate", "structure", "cells", "sheets", "text", "formats", "compare"], tab, setTab);
  const [artifactId, setArtifactId] = useEngineDocument("sheet");
  const [sheet, setSheet] = useState("1");
  const [to, setTo] = useState("csv");
  const [gridLines, setGridLines] = useState(false);
  const [header, setHeader] = useState("");
  const [footer, setFooter] = useState("Page {page} of {pages}");
  const inspector = useToolRun<WorkbookInfo>();
  const exporter = useToolRun();
  const converter = useToolRun();
  const calculator = useToolRun();

  /* structural read */
  const structure = useToolRun();

  /* cell editing */
  const [cellAction, setCellAction] = useState<
    "read" | "write" | "formula" | "value" | "clear" | "fill" | "merge" | "unmerge" | "comment" | "freeze"
  >("read");
  const [cellRange, setCellRange] = useState("A1:F12");
  const [cellAddress, setCellAddress] = useState("A1");
  const [cellFormula, setCellFormula] = useState("=SUM(D2:D6)");
  const [cellValue, setCellValue] = useState("Reviewed");
  const [cellText, setCellText] = useState("Region\tUnits\nNorth\t1200");
  const [cellComment, setCellComment] = useState("Checked against the ledger");
  const [frozenRows, setFrozenRows] = useState("1");
  const [frozenColumns, setFrozenColumns] = useState("1");
  const cellsRun = useToolRun();

  /* worksheet operations */
  const [sheetAction, setSheetAction] = useState<"add" | "rename" | "clone" | "move" | "remove">("add");
  const [sheetName, setSheetName] = useState("Notes");
  const [sheetIndex, setSheetIndex] = useState("0");
  const sheetOpsRun = useToolRun();

  /* find and replace */
  const [textAction, setTextAction] = useState<"find" | "replace">("find");
  const [findText, setFindText] = useState("Northwind");
  const [replaceText, setReplaceText] = useState("Northwind Analytics");
  const [textTarget, setTextTarget] = useState<"values" | "formulas" | "comments" | "all">("values");
  const [matchCase, setMatchCase] = useState(false);
  const textRun = useToolRun();

  /* formats */
  const [formatTarget, setFormatTarget] = useState<"csv" | "json" | "html" | "print">("csv");
  const [formatFormulas, setFormatFormulas] = useState(false);
  const formatsRun = useToolRun();

  /* compare, merge and split */
  const [workbookAction, setWorkbookAction] = useState<"compare" | "merge" | "split">("compare");
  const [otherArtifactId, setOtherArtifactId] = useState("");
  const workbookRun = useToolRun();

  const runInspect = () => inspector.run(() => sheetsApi.inspect(artifactId));
  const runExport = () =>
    exporter.run(() =>
      sheetsApi.export({
        artifactId,
        sheet: Number(sheet) || 1,
        gridLines,
        header: header || undefined,
        footer: footer || undefined
      })
    );
  const runConvert = () => converter.run(() => sheetsApi.convert({ artifactId, to, sheet: Number(sheet) || 1 }));
  const runCalculate = () => calculator.run(() => sheetsApi.calculate(artifactId));
  const runStructure = () => structure.run(() => sheetsApi.read({ artifactId, sheet: Number(sheet) - 1 || undefined }));
  const runCells = () =>
    cellsRun.run(() =>
      sheetsApi.cells({
        artifactId,
        sheet: Number(sheet) - 1 || 0,
        action: cellAction,
        range: cellRange,
        address: cellAddress,
        formula: cellFormula,
        value: cellValue,
        text: cellText,
        author: "Docuzen user",
        frozenRows: Number(frozenRows) || 0,
        frozenColumns: Number(frozenColumns) || 0
      })
    );
  const runSheetOps = () =>
    sheetOpsRun.run(() =>
      sheetsApi.sheetOps({
        artifactId,
        action: sheetAction,
        sheet: Number(sheet) - 1 || 0,
        name: sheetName,
        newName: sheetName,
        targetIndex: Number(sheetIndex) || 0
      })
    );
  const runText = () =>
    textRun.run(() =>
      sheetsApi.text({
        artifactId,
        action: textAction,
        find: findText,
        replace: replaceText,
        target: textTarget,
        matchCase
      })
    );
  const runFormats = () => formatsRun.run(() => sheetsApi.formats({ artifactId, to: formatTarget, sheet: Number(sheet) - 1 || 0, formulas: formatFormulas }));
  const runWorkbook = () =>
    workbookRun.run(() =>
      sheetsApi.workbookOps({
        artifactId,
        action: workbookAction,
        otherArtifactId: workbookAction === "split" ? undefined : otherArtifactId || undefined
      })
    );

  const info = inspector.result?.report as WorkbookInfo | undefined;
  const sheetCount = info?.worksheets ?? 0;

  return (
    <div>
      <PageHeader
        eyebrow="Sheets engine"
        title="Workbook workbench"
        description="Read a workbook with the engine's own cell reader, recalculate through its evaluator, convert between twelve formats and print a sheet to PDF or PNG with the same layout geometry."
        actions={<span className="pill border border-line bg-surface px-2.5 py-1 text-[11px] text-muted">xlsx · xlsm · xls · ods · csv</span>}
      />

      <div className="mb-4">
        <Tabs tabs={TABS} value={tab} onChange={setTab} />
      </div>

      <div className="split-wrap">
        <div className="min-w-0 space-y-4">

          {tab === "workbook" || tab === "convert" || tab === "calculate" ? (
          <ConfigCard
            title="Workbook"
            description="Inspection reports the worksheets, their types and the cached values exactly as stored in the package."
            footer={
              <div className="flex flex-wrap gap-2">
                <button type="button" className="btn btn-secondary btn-sm" onClick={runInspect} disabled={!artifactId || inspector.pending}>
                  Inspect workbook
                </button>
              </div>
            }
          >
            <DocumentSelect label="Workbook" include="sheet" value={artifactId} onChange={setArtifactId} />
            {info ? (
              <div className="grid grid-cols-2 gap-2">
                <Fact label="Worksheets">{info.worksheets ?? 0}</Fact>
                <Fact label="Charts">{info.charts ?? 0}</Fact>
                <Fact label="Defined names">{info.definedNames?.length ?? 0}</Fact>
                <Fact label="Date system">{info.workbook?.dateSystem ?? "1900"}</Fact>
              </div>
            ) : null}
            {info?.names && info.names.length > 0 ? (
              <p className="text-[11.5px] leading-[1.5] text-muted">Sheets: {info.names.join(" · ")}</p>
            ) : null}
          </ConfigCard>
          ) : null}

          {tab === "workbook" || tab === "convert" ? (
            <ConfigCard
              title={tab === "convert" ? "Convert" : "Print & render"}
              description={
                tab === "convert"
                  ? "Each target is written by the engine's format writer. CSV and TSV export the selected sheet; the workbook formats keep every sheet."
                  : "PDF and PNG come from the same print layout, so row heights and column widths agree between the two."
              }
              footer={
                <RunBar
                  label={tab === "convert" ? `Convert to ${to.toUpperCase()}` : "Export PDF + PNG"}
                  pending={tab === "convert" ? converter.pending : exporter.pending}
                  disabled={!artifactId}
                  hint={sheetCount > 1 ? `${sheetCount} sheet(s) in this workbook` : undefined}
                  onRun={tab === "convert" ? runConvert : runExport}
                />
              }
            >
              <InlineFields>
                <Field label="Sheet" hint={sheetCount ? `1 – ${sheetCount}` : "1-based index"}>
                  <TextInput value={sheet} onChange={(event) => setSheet(event.target.value)} inputMode="numeric" />
                </Field>
                {tab === "convert" ? (
                  <Field label="Target">
                    <Select
                      value={to}
                      onChange={(event) => setTo(event.target.value)}
                      options={[
                        { value: "csv", label: "CSV" },
                        { value: "tsv", label: "TSV" },
                        { value: "md", label: "Markdown table" },
                        { value: "html", label: "HTML table" },
                        { value: "json", label: "JSON" },
                        { value: "xml", label: "XML" },
                        { value: "xlsx", label: "XLSX" },
                        { value: "ods", label: "ODS" },
                        { value: "xls", label: "XLS" }
                      ]}
                    />
                  </Field>
                ) : (
                  <Field label="Grid lines" hint="Excel's default print is off">
                    <div className="pt-2">
                      <Checkbox checked={gridLines} onChange={setGridLines} label="Draw cell borders" />
                    </div>
                  </Field>
                )}
              </InlineFields>
              {tab !== "convert" ? (
                <InlineFields>
                  <Field label="Header" hint="{page}, {pages}, {title}">
                    <TextInput value={header} onChange={(event) => setHeader(event.target.value)} placeholder="Optional" />
                  </Field>
                  <Field label="Footer">
                    <TextInput value={footer} onChange={(event) => setFooter(event.target.value)} placeholder="Optional" />
                  </Field>
                </InlineFields>
              ) : null}
            </ConfigCard>
          ) : null}

          {tab === "calculate" ? (
            <ConfigCard
              title="Recalculate"
              description="Runs the engine's evaluator over every formula in the workbook and writes a new XLSX with refreshed cached values."
              footer={
                <RunBar label="Recalculate and save" pending={calculator.pending} disabled={!artifactId} hint="Unsupported functions are reported, not guessed" onRun={runCalculate} />
              }
            >
              <p className="text-[11.5px] leading-[1.5] text-muted">
                The report lists evaluated, unsupported, error and circular formulas plus the operation count, so a
                disagreement with the cached values is visible rather than silent.
              </p>
            </ConfigCard>
          ) : null}
          {tab === "structure" ? (
            <ConfigCard
              title="Structural read"
              description="Every worksheet with its dimensions, merges, frozen panes, tables, comments and conditional-format rules, plus a capped grid preview."
              footer={<RunBar label="Read structure" pending={structure.pending} disabled={!artifactId} hint="Read-only: nothing is written" onRun={runStructure} />}
            >
              <DocumentSelect label="Workbook" include="sheet" value={artifactId} onChange={setArtifactId} />
              <InlineFields>
                <Field label="Sheet" hint="1-based; sent as an index">
                  <TextInput value={sheet} onChange={(event) => setSheet(event.target.value)} inputMode="numeric" />
                </Field>
              </InlineFields>
              <Callout tone="info" title="What the read reports">
                Formula sources and cached values are reported side by side, so a stale cache is visible instead of being
                silently trusted.
              </Callout>
            </ConfigCard>
          ) : null}

          {tab === "cells" ? (
            <ConfigCard
              title="Cells and ranges"
              description="Read a range, write a tab-separated block, set one formula or value, clear or fill a range, merge cells, attach a comment or freeze panes."
              footer={<RunBar label="Apply" pending={cellsRun.pending} disabled={!artifactId} hint={cellAction === "read" ? "Read-only: nothing is written" : "Writes a new XLSX next to the source"} onRun={runCells} />}
            >
              <DocumentSelect label="Workbook" include="sheet" value={artifactId} onChange={setArtifactId} />
              <Field label="Operation">
                <Select
                  value={cellAction}
                  onChange={(event) => setCellAction(event.target.value as typeof cellAction)}
                  options={[
                    { value: "read", label: "Read a range" },
                    { value: "write", label: "Write a block" },
                    { value: "formula", label: "Set a formula" },
                    { value: "value", label: "Set a value" },
                    { value: "clear", label: "Clear a range" },
                    { value: "fill", label: "Fill a range" },
                    { value: "merge", label: "Merge cells" },
                    { value: "unmerge", label: "Unmerge cells" },
                    { value: "comment", label: "Attach a comment" },
                    { value: "freeze", label: "Freeze panes" }
                  ]}
                />
              </Field>
              <InlineFields>
                <Field label="Sheet" hint="1-based; sent as an index">
                  <TextInput value={sheet} onChange={(event) => setSheet(event.target.value)} inputMode="numeric" />
                </Field>
                <Field label="Range" hint="A1:F12">
                  <TextInput value={cellRange} onChange={(event) => setCellRange(event.target.value)} />
                </Field>
              </InlineFields>
              {cellAction === "formula" || cellAction === "comment" ? (
                <Field label="Address">
                  <TextInput value={cellAddress} onChange={(event) => setCellAddress(event.target.value)} />
                </Field>
              ) : null}
              {cellAction === "formula" ? (
                <Field label="Formula">
                  <TextInput value={cellFormula} onChange={(event) => setCellFormula(event.target.value)} className="font-mono text-[11.5px]" />
                </Field>
              ) : null}
              {cellAction === "comment" ? (
                <Field label="Comment">
                  <TextInput value={cellComment} onChange={(event) => setCellComment(event.target.value)} />
                </Field>
              ) : null}
              {cellAction === "value" || cellAction === "fill" ? (
                <Field label="Value" hint={cellAction === "fill" ? "Repeated across the whole range" : undefined}>
                  <TextInput value={cellValue} onChange={(event) => setCellValue(event.target.value)} />
                </Field>
              ) : null}
              {cellAction === "clear" || cellAction === "merge" || cellAction === "unmerge" || cellAction === "value" || cellAction === "fill" ? null : cellAction === "freeze" ? (
                <InlineFields>
                  <Field label="Frozen rows">
                    <TextInput value={frozenRows} onChange={(event) => setFrozenRows(event.target.value)} inputMode="numeric" />
                  </Field>
                  <Field label="Frozen columns">
                    <TextInput value={frozenColumns} onChange={(event) => setFrozenColumns(event.target.value)} inputMode="numeric" />
                  </Field>
                </InlineFields>
              ) : cellAction === "write" ? (
                <Field label="Block" hint="Tab between columns, newline between rows">
                  <TextArea value={cellText} rows={6} onChange={(event) => setCellText(event.target.value)} className="font-mono text-[11.5px]" />
                </Field>
              ) : null}
            </ConfigCard>
          ) : null}

          {tab === "sheets" ? (
            <ConfigCard
              title="Worksheet operations"
              description="Add, rename, clone, reorder or delete a worksheet. References in formulas are rewritten for renames, so nothing is left dangling."
              footer={<RunBar label="Apply" pending={sheetOpsRun.pending} disabled={!artifactId} hint="Writes a new XLSX next to the source" onRun={runSheetOps} />}
            >
              <DocumentSelect label="Workbook" include="sheet" value={artifactId} onChange={setArtifactId} />
              <Field label="Operation">
                <Segmented
                  value={sheetAction}
                  onChange={setSheetAction}
                  options={[
                    { value: "add", label: "Add" },
                    { value: "rename", label: "Rename" },
                    { value: "clone", label: "Clone" },
                    { value: "move", label: "Move" },
                    { value: "remove", label: "Remove" }
                  ]}
                />
              </Field>
              <InlineFields>
                <Field label="Sheet" hint="1-based; sent as an index">
                  <TextInput value={sheet} onChange={(event) => setSheet(event.target.value)} inputMode="numeric" />
                </Field>
                <Field label={sheetAction === "move" ? "Target index" : "Name"}>
                  {sheetAction === "move" ? (
                    <TextInput value={sheetIndex} onChange={(event) => setSheetIndex(event.target.value)} inputMode="numeric" />
                  ) : (
                    <TextInput value={sheetName} onChange={(event) => setSheetName(event.target.value)} />
                  )}
                </Field>
              </InlineFields>
            </ConfigCard>
          ) : null}

          {tab === "text" ? (
            <ConfigCard
              title="Find and replace"
              description="A budgeted search across the workbook, with a non-backtracking regex option, over values, formulas or comments."
              footer={<RunBar label={textAction === "find" ? "Find" : "Replace all"} pending={textRun.pending} disabled={!artifactId || !findText.trim()} hint={textAction === "find" ? "Read-only: nothing is written" : "Writes a new XLSX next to the source"} onRun={runText} />}
            >
              <DocumentSelect label="Workbook" include="sheet" value={artifactId} onChange={setArtifactId} />
              <Segmented
                value={textAction}
                onChange={setTextAction}
                options={[
                  { value: "find", label: "Find" },
                  { value: "replace", label: "Replace" }
                ]}
              />
              <InlineFields>
                <Field label="Find">
                  <TextInput value={findText} onChange={(event) => setFindText(event.target.value)} />
                </Field>
                {textAction === "replace" ? (
                  <Field label="Replace with">
                    <TextInput value={replaceText} onChange={(event) => setReplaceText(event.target.value)} />
                  </Field>
                ) : null}
              </InlineFields>
              <InlineFields>
                <Field label="Search in">
                  <Segmented
                    value={textTarget}
                    onChange={setTextTarget}
                    options={[
                      { value: "values", label: "Values" },
                      { value: "formulas", label: "Formulas" },
                      { value: "comments", label: "Comments" },
                      { value: "all", label: "All" }
                    ]}
                  />
                </Field>
                <Field label="Options">
                  <div className="pt-1">
                    <Checkbox checked={matchCase} onChange={setMatchCase} label="Match case" />
                  </div>
                </Field>
              </InlineFields>
            </ConfigCard>
          ) : null}

          {tab === "formats" ? (
            <ConfigCard
              title="Sheet exports"
              description="Write the selected sheet as CSV, JSON or styled HTML, or ask the print pipeline how it would paginate."
              footer={<RunBar label={formatTarget === "print" ? "Preview pagination" : `Write ${formatTarget.toUpperCase()}`} pending={formatsRun.pending} disabled={!artifactId} hint={formatTarget === "print" ? "Report only: nothing is written" : "Saved into the workspace library"} onRun={runFormats} />}
            >
              <DocumentSelect label="Workbook" include="sheet" value={artifactId} onChange={setArtifactId} />
              <InlineFields>
                <Field label="Sheet" hint="1-based; sent as an index">
                  <TextInput value={sheet} onChange={(event) => setSheet(event.target.value)} inputMode="numeric" />
                </Field>
                <Field label="Target">
                  <Select
                    value={formatTarget}
                    onChange={(event) => setFormatTarget(event.target.value as "csv" | "json" | "html" | "print")}
                    options={[
                      { value: "csv", label: "CSV" },
                      { value: "json", label: "JSON" },
                      { value: "html", label: "HTML" },
                      { value: "print", label: "Print preview" }
                    ]}
                  />
                </Field>
              </InlineFields>
              {formatTarget === "csv" ? (
                <Checkbox checked={formatFormulas} onChange={setFormatFormulas} label="Write formulas instead of values" />
              ) : null}
            </ConfigCard>
          ) : null}

          {tab === "compare" ? (
            <ConfigCard
              title="Compare, merge and split"
              description="A cell-level diff against a second workbook, a merge of two workbooks into one, or one file per worksheet."
              footer={<RunBar label={workbookAction === "split" ? "Split workbook" : workbookAction === "merge" ? "Merge workbooks" : "Compare"} pending={workbookRun.pending} disabled={!artifactId || (workbookAction !== "split" && !otherArtifactId)} hint={workbookAction === "compare" ? "Read-only: nothing is written" : "Saved into the workspace library"} onRun={runWorkbook} />}
            >
              <DocumentSelect label="Workbook" include="sheet" value={artifactId} onChange={setArtifactId} />
              <Field label="Operation">
                <Segmented
                  value={workbookAction}
                  onChange={setWorkbookAction}
                  options={[
                    { value: "compare", label: "Compare" },
                    { value: "merge", label: "Merge" },
                    { value: "split", label: "Split" }
                  ]}
                />
              </Field>
              {workbookAction !== "split" ? (
                <DocumentSelect label="Second workbook" include="sheet" value={otherArtifactId} onChange={setOtherArtifactId} />
              ) : null}
            </ConfigCard>
          ) : null}

        </div>

        <div className="min-w-0">
          <ResultPanel
            result={
              tab === "convert"
                ? converter.result
                : tab === "calculate"
                  ? calculator.result
                  : tab === "structure"
                    ? structure.result
                    : tab === "cells"
                      ? cellsRun.result
                      : tab === "sheets"
                        ? sheetOpsRun.result
                        : tab === "text"
                          ? textRun.result
                          : tab === "formats"
                            ? formatsRun.result
                            : tab === "compare"
                              ? workbookRun.result
                              : exporter.result ?? inspector.result
            }
            error={
              tab === "convert"
                ? converter.error
                : tab === "calculate"
                  ? calculator.error
                  : tab === "structure"
                    ? structure.error
                    : tab === "cells"
                      ? cellsRun.error
                      : tab === "sheets"
                        ? sheetOpsRun.error
                        : tab === "text"
                          ? textRun.error
                          : tab === "formats"
                            ? formatsRun.error
                            : tab === "compare"
                              ? workbookRun.error
                              : exporter.error ?? inspector.error
            }
            pending={
              tab === "convert"
                ? converter.pending
                : tab === "calculate"
                  ? calculator.pending
                  : tab === "structure"
                    ? structure.pending
                    : tab === "cells"
                      ? cellsRun.pending
                      : tab === "sheets"
                        ? sheetOpsRun.pending
                        : tab === "text"
                          ? textRun.pending
                          : tab === "formats"
                            ? formatsRun.pending
                            : tab === "compare"
                              ? workbookRun.pending
                              : exporter.pending || inspector.pending
            }
            emptyTitle="Nothing read yet"
            emptyDescription="Inspect the workbook for its sheets and cached values, then export a sheet to PDF and PNG to see the print layout."
            emptyIcon={FileSpreadsheet}
            onReset={() => {
              inspector.reset();
              exporter.reset();
              converter.reset();
              calculator.reset();
              structure.reset();
              cellsRun.reset();
              sheetOpsRun.reset();
              textRun.reset();
              formatsRun.reset();
              workbookRun.reset();
            }}
          />
        </div>
      </div>
    </div>
  );
}
