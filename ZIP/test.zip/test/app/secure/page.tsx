"use client";

import { useEffect, useRef, useState } from "react";
import clsx from "clsx";
import { BadgeCheck, KeyRound, Lock, ShieldCheck, Upload } from "lucide-react";
import { tools } from "@/lib/api";
import { useWorkspace } from "@/components/workspace-provider";
import { useToast } from "@/components/toast";
import { useToolRun } from "@/lib/use-tool-run";
import { ResultPanel } from "@/components/result-panel";
import { ConfigCard, DocumentSelect, InlineFields, RunBar, SectionDivider, useDocumentSelection } from "@/components/tool-form";
import { DataTable, Facts, ReportSection } from "@/components/report-view";
import { Button, Callout, Checkbox, NumberInput, PageHeader, Pill, Select, Tabs, TextArea, TextInput } from "@/components/ui";

const TABS = [
  { id: "encrypt", label: "Encrypt", icon: Lock },
  { id: "decrypt", label: "Decrypt", icon: KeyRound },
  { id: "sign", label: "Sign", icon: BadgeCheck },
  { id: "verify", label: "Verify signatures", icon: ShieldCheck }
];

export default function SecurePage() {
  const [tab, setTab] = useState("encrypt");
  return (
    <div>
      <PageHeader
        eyebrow="Transform"
        title="Security"
        description="Standard security handlers and PKCS#7 signatures implemented with the BCL's own cryptography. Passwords stay in memory for the call only."
      />
      <Tabs tabs={TABS} value={tab} onChange={setTab} className="mb-5" />
      {tab === "encrypt" ? <EncryptTab /> : null}
      {tab === "decrypt" ? <DecryptTab /> : null}
      {tab === "sign" ? <SignTab /> : null}
      {tab === "verify" ? <VerifyTab /> : null}
    </div>
  );
}

const PERMISSIONS = [
  { id: "print", label: "Print" },
  { id: "print-hq", label: "High-quality print" },
  { id: "modify", label: "Modify contents" },
  { id: "copy", label: "Copy text" },
  { id: "annotate", label: "Annotate" },
  { id: "forms", label: "Fill forms" },
  { id: "accessibility", label: "Accessibility extraction" },
  { id: "assemble", label: "Assemble pages" }
];

function EncryptTab() {
  const [artifactId, setArtifactId] = useDocumentSelection();
  const [userPassword, setUserPassword] = useState("");
  const [ownerPassword, setOwnerPassword] = useState("");
  const [algorithm, setAlgorithm] = useState("aes256");
  const [permissions, setPermissions] = useState<string[]>(["print", "copy", "accessibility"]);
  const [encryptMetadata, setEncryptMetadata] = useState(true);
  const { result, error, pending, run, reset } = useToolRun<Record<string, unknown>>();

  return (
    <div className="split-wrap">
      <ConfigCard
        description="At least one password is required; an empty password encrypts nothing and is refused."
        footer={
          <RunBar
            label="Encrypt document"
            pending={pending}
            disabled={!artifactId || (!userPassword && !ownerPassword)}
            onRun={() => run(() => tools.encrypt({ artifactId, userPassword, ownerPassword, algorithm, permissions, encryptMetadata }))}
            hint="The produced artifact is opened in the workspace so you can continue with it."
          />
        }
      >
        <DocumentSelect value={artifactId} onChange={setArtifactId} label="Document" />
        <InlineFields>
          <div>
            <span className="label">User password</span>
            <TextInput type="password" value={userPassword} onChange={(event) => setUserPassword(event.target.value)} placeholder="opens the document" />
          </div>
          <div>
            <span className="label">Owner password</span>
            <TextInput type="password" value={ownerPassword} onChange={(event) => setOwnerPassword(event.target.value)} placeholder="changes permissions" />
          </div>
        </InlineFields>
        <div>
          <span className="label">Algorithm</span>
          <Select
            value={algorithm}
            onChange={(event) => setAlgorithm(event.target.value)}
            options={[
              { value: "aes256", label: "AES-256 (R6) — recommended" },
              { value: "aes128", label: "AES-128 (R4)" },
              { value: "rc4-128", label: "RC4 128-bit (R3)" },
              { value: "rc4-40", label: "RC4 40-bit (R2)" }
            ]}
          />
        </div>
        <SectionDivider label="Permissions" />
        <div className="grid grid-cols-2 gap-1.5">
          {PERMISSIONS.map((permission) => (
            <label key={permission.id} className="flex cursor-pointer items-center gap-2 text-[12px] text-ink-soft">
              <input
                type="checkbox"
                className="size-3.5 accent-[#0e6a45]"
                checked={permissions.includes(permission.id)}
                onChange={(event) =>
                  setPermissions((current) =>
                    event.target.checked ? [...current, permission.id] : current.filter((item) => item !== permission.id)
                  )
                }
              />
              {permission.label}
            </label>
          ))}
        </div>
        <div className="flex gap-2">
          <Button size="sm" onClick={() => setPermissions(["all"])}>
            Allow all
          </Button>
          <Button size="sm" onClick={() => setPermissions([])}>
            Deny all
          </Button>
        </div>
        <Checkbox label="Encrypt metadata" hint="When off, the metadata stream stays readable." checked={encryptMetadata} onChange={setEncryptMetadata} />
      </ConfigCard>

      <ResultPanel
        result={result}
        error={error}
        pending={pending}
        onReset={reset}
        emptyIcon={Lock}
        emptyTitle="Not encrypted yet"
        emptyDescription="Set a password and a permission set. The report records the handler, revision and the exact permission bitmask."
        renderReport={(report) => <EncryptionReport report={report} />}
      />
    </div>
  );
}

function EncryptionReport({ report }: { report: Record<string, unknown> }) {
  return (
    <div className="space-y-4">
      <Facts
        columns={2}
        data={{
          Algorithm: report.algorithm,
          Handler: report.handler,
          "Security revision": report.revision,
          Permissions: report.permissions,
          "User password": report.userPasswordSet ? "set" : "none",
          "Owner password": report.ownerPasswordSet ? "set" : "none",
          "Metadata encrypted": report.metadataEncrypted ? "yes" : "no"
        }}
      />
      {report.note ? <Callout tone="info">{String(report.note)}</Callout> : null}
    </div>
  );
}

function DecryptTab() {
  const [artifactId, setArtifactId] = useDocumentSelection();
  const [password, setPassword] = useState("");
  const { result, error, pending, run, reset } = useToolRun<Record<string, unknown>>();

  return (
    <div className="split-wrap">
      <ConfigCard
        description="Reads the document with an authorised password and writes a copy with no encryption dictionary."
        footer={
          <RunBar
            label="Remove encryption"
            pending={pending}
            disabled={!artifactId}
            onRun={() => run(() => tools.decrypt({ artifactId, password }))}
            hint="Encrypted artifacts are marked in the workspace; supply their user or owner password."
          />
        }
      >
        <DocumentSelect value={artifactId} onChange={setArtifactId} label="Document" />
        <div>
          <span className="label">Password</span>
          <TextInput type="password" value={password} onChange={(event) => setPassword(event.target.value)} placeholder="User or owner password" />
        </div>
        <Callout tone="info" title="Passwords are not stored">
          The engine opens the file, copies the page tree into a new document and writes it without the encryption dictionary.
        </Callout>
      </ConfigCard>

      <ResultPanel
        result={result}
        error={error}
        pending={pending}
        onReset={reset}
        emptyIcon={KeyRound}
        emptyTitle="No decryption run yet"
        emptyDescription="Pick an encrypted document, supply the password, and the cleaned copy is written as a new artifact."
        renderReport={(report) => <EncryptionReport report={report} />}
      />
    </div>
  );
}

function SignTab() {
  const [artifactId, setArtifactId] = useDocumentSelection();
  const { notify } = useToast();
  const [mode, setMode] = useState<"generate" | "pfx">("generate");
  const [subject, setSubject] = useState("CN=Docuzen Tester, O=Docuzen, C=IN");
  const [validityDays, setValidityDays] = useState("365");
  const [pfxBase64, setPfxBase64] = useState("");
  const [pfxPassword, setPfxPassword] = useState("");
  const [pfxName, setPfxName] = useState<string | null>(null);
  const [page, setPage] = useState("1");
  const [rect, setRect] = useState(["60", "60", "160", "44"]);
  const [reason, setReason] = useState("QA sign-off");
  const [location, setLocation] = useState("Bengaluru");
  const [contact, setContact] = useState("");
  const [signerName, setSignerName] = useState("");
  const [hash, setHash] = useState("sha256");
  const [docMdp, setDocMdp] = useState("2");
  const [pades, setPades] = useState(true);
  const fileRef = useRef<HTMLInputElement>(null);
  const sign = useToolRun<Record<string, unknown>>();
  const verify = useToolRun<Record<string, unknown>>();

  const certificate = (sign.result?.report as { certificate?: { base64?: string; subject?: string; thumbprint?: string } } | undefined)?.certificate;

  return (
    <div className="space-y-5">
      <div className="split-wrap">
        <ConfigCard
          description="A signature is appended incrementally: the original bytes remain and the signature covers them."
          footer={
            <RunBar
              label="Sign document"
              pending={sign.pending}
              disabled={!artifactId || (mode === "pfx" && !pfxBase64)}
              onRun={() => sign.run(() => tools.sign({
                artifactId,
                certificateMode: mode,
                pfxBase64: mode === "pfx" ? pfxBase64 : undefined,
                pfxPassword: mode === "pfx" ? pfxPassword : undefined,
                subject: mode === "generate" ? subject : undefined,
                validityDays: mode === "generate" ? Number(validityDays) : undefined,
                page: Number(page),
                rect: rect.map(Number),
                reason,
                location,
                contact,
                signerName,
                hashAlgorithm: hash,
                docMdp: Number(docMdp),
                pades
              }))}
            />
          }
        >
          <DocumentSelect value={artifactId} onChange={setArtifactId} label="Document" />
          <div>
            <span className="label">Certificate</span>
            <div className="inline-flex w-full items-center gap-0.5 rounded-lg border border-line bg-[#f1f4f0] p-0.5">
              {(
                [
                  ["generate", "Generate a test certificate"],
                  ["pfx", "Use a PKCS#12 file"]
                ] as Array<["generate" | "pfx", string]>
              ).map(([value, label]) => (
                <button
                  key={value}
                  type="button"
                  onClick={() => setMode(value)}
                  className={clsx(
                    "h-[28px] flex-1 rounded-[6px] px-2 text-[12px] font-medium transition",
                    mode === value ? "bg-surface text-ink shadow-[0_1px_2px_rgba(19,32,26,0.08)]" : "text-muted hover:text-ink"
                  )}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          {mode === "generate" ? (
            <>
              <div>
                <span className="label">Distinguished name</span>
                <TextInput value={subject} onChange={(event) => setSubject(event.target.value)} className="font-mono text-[12px]" />
              </div>
              <div>
                <span className="label">Validity (days)</span>
                <NumberInput value={validityDays} onChange={setValidityDays} min={1} max={3650} />
              </div>
              <Callout tone="info" title="Test certificate">
                A self-signed RSA-2048 certificate is created in memory for this run. Its public certificate is returned in the report so the
                signature can be verified with it as a trust anchor.
              </Callout>
            </>
          ) : (
            <>
              <input
                ref={fileRef}
                type="file"
                accept=".pfx,.p12,application/x-pkcs12"
                className="hidden"
                onChange={async (event) => {
                  const file = event.target.files?.[0];
                  if (!file) return;
                  const buffer = await file.arrayBuffer();
                  const base64 = btoa(String.fromCharCode(...new Uint8Array(buffer)));
                  setPfxBase64(base64);
                  setPfxName(file.name);
                  notify({ title: `${file.name} loaded`, description: "The PKCS#12 container stays in this browser tab." });
                }}
              />
              <div className="flex items-center gap-2">
                <Button icon={Upload} onClick={() => fileRef.current?.click()}>
                  {pfxName ? "Replace file" : "Choose .pfx / .p12"}
                </Button>
                <span className="min-w-0 truncate text-[11.5px] text-faint">{pfxName ?? "No container loaded"}</span>
              </div>
              <div>
                <span className="label">Container password (optional)</span>
                <TextInput type="password" value={pfxPassword} onChange={(event) => setPfxPassword(event.target.value)} />
              </div>
            </>
          )}

          <SectionDivider label="Appearance" />
          <InlineFields>
            <div>
              <span className="label">Signature page</span>
              <NumberInput value={page} onChange={setPage} min={1} />
            </div>
            <div>
              <span className="label">Hash algorithm</span>
              <Select
                value={hash}
                onChange={(event) => setHash(event.target.value)}
                options={[
                  { value: "sha256", label: "SHA-256" },
                  { value: "sha384", label: "SHA-384" },
                  { value: "sha512", label: "SHA-512" }
                ]}
              />
            </div>
          </InlineFields>
          <div>
            <span className="label">Visible rectangle · x, y, width, height</span>
            <div className="grid grid-cols-4 gap-1.5">
              {rect.map((value, index) => (
                <NumberInput
                  key={index}
                  value={value}
                  onChange={(next) => setRect((items) => items.map((item, itemIndex) => (itemIndex === index ? next : item)))}
                />
              ))}
            </div>
            <p className="mt-1 text-[11px] text-faint">Points from the lower-left origin. Leave all fields at zero for an invisible signature.</p>
          </div>
          <InlineFields>
            <div>
              <span className="label">Reason</span>
              <TextInput value={reason} onChange={(event) => setReason(event.target.value)} />
            </div>
            <div>
              <span className="label">Location</span>
              <TextInput value={location} onChange={(event) => setLocation(event.target.value)} />
            </div>
          </InlineFields>
          <InlineFields>
            <div>
              <span className="label">Signer name override</span>
              <TextInput value={signerName} onChange={(event) => setSignerName(event.target.value)} placeholder="optional" />
            </div>
            <div>
              <span className="label">Contact</span>
              <TextInput value={contact} onChange={(event) => setContact(event.target.value)} placeholder="optional" />
            </div>
          </InlineFields>
          <div>
            <span className="label">DocMDP permission</span>
            <Select
              value={docMdp}
              onChange={(event) => setDocMdp(event.target.value)}
              options={[
                { value: "0", label: "0 — certification signature, no changes" },
                { value: "1", label: "1 — forms allowed" },
                { value: "2", label: "2 — forms and annotations allowed" },
                { value: "3", label: "3 — unrestricted" }
              ]}
            />
          </div>
          <Checkbox label="PAdES sub-filter" hint="Writes an ETSI.CAdES.detached sub-filter instead of adbe.pkcs7.detached." checked={pades} onChange={setPades} />
        </ConfigCard>

        <div className="space-y-5">
          <ResultPanel
            result={sign.result}
            error={sign.error}
            pending={sign.pending}
            emptyIcon={BadgeCheck}
            emptyTitle="Not signed yet"
            emptyDescription="Sign with a generated test certificate or your own PKCS#12 container. The produced file keeps the original bytes and appends the signature."
            renderReport={(report) => <SignatureReport report={report} onVerify={(base64) => verify.run(() => tools.verify({ artifactId: (sign.result?.artifacts[0]?.id ?? artifactId), trustBase64: base64 ? [base64] : [] }))} />}
          />

          {verify.result || verify.error ? (
            <ResultPanel
              result={verify.result}
              error={verify.error}
              pending={verify.pending}
              onReset={verify.reset}
              showPreview={false}
              emptyTitle=""
              emptyDescription=""
              renderReport={(report) => <VerificationReport report={report as VerificationPayload} />}
            />
          ) : null}
        </div>
      </div>
    </div>
  );
}

function SignatureReport({ report, onVerify }: { report: Record<string, unknown>; onVerify: (base64?: string) => void }) {
  const certificate = report.certificate as { subject?: string; issuer?: string; thumbprint?: string; notBefore?: string; notAfter?: string; base64?: string } | undefined;
  return (
    <div className="space-y-4">
      <Facts
        columns={2}
        data={{
          Field: report.field,
          "Sub-filter": report.subFilter,
          Signer: report.signer,
          Hash: report.hash,
          DocMDP: report.docMdp,
          Visible: report.visible ? "yes" : "no",
          Page: report.page,
          "Byte range": Array.isArray(report.byteRange) ? report.byteRange.join(" ") : report.byteRange
        }}
      />
      {certificate ? (
        <ReportSection title="Signing certificate" hint={report.generatedCertificate ? "Generated for this run" : "Loaded from the PKCS#12 container"}>
          <div className="space-y-3 rounded-lg border border-line bg-surface-muted/50 px-3.5 py-3">
            <Facts
              columns={1}
              data={{
                Subject: certificate.subject,
                Issuer: certificate.issuer,
                Thumbprint: certificate.thumbprint,
                "Valid from": certificate.notBefore ? new Date(certificate.notBefore).toLocaleString() : undefined,
                "Valid to": certificate.notAfter ? new Date(certificate.notAfter).toLocaleString() : undefined
              }}
            />
            <div className="flex flex-wrap gap-2">
              <Button size="sm" icon={ShieldCheck} onClick={() => onVerify(certificate.base64)}>
                Verify against this certificate
              </Button>
              {certificate.base64 ? (
                <Button
                  size="sm"
                  onClick={() => {
                    navigator.clipboard.writeText(certificate.base64 ?? "");
                  }}
                >
                  Copy trust anchor
                </Button>
              ) : null}
            </div>
          </div>
        </ReportSection>
      ) : null}
      {report.note ? <Callout tone="info">{String(report.note)}</Callout> : null}
    </div>
  );
}

type VerificationPayload = {
  signatureCount: number;
  allValid: boolean;
  coversEntireFile: boolean;
  trustAnchorSupplied: boolean;
  signatures: Array<{
    field: string;
    valid: boolean;
    subFilter: string;
    signer: string;
    subject: string;
    issuer: string;
    serial: string;
    digestAlgorithm: string;
    signingTime: string;
    reason: string;
    location: string;
    byteRange: number[];
    coversWholeDocument: boolean;
    digestMatches: boolean;
    signatureValid: boolean;
    certificateChainTrusted: boolean;
    docMdp: string;
    issues: string[];
  }>;
};

function VerificationReport({ report }: { report: VerificationPayload }) {
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <Pill tone={report.allValid ? "accent" : "danger"}>{report.signatureCount} signature{report.signatureCount === 1 ? "" : "s"}</Pill>
        <Pill tone={report.allValid ? "accent" : "warn"}>{report.allValid ? "all valid" : "not all valid"}</Pill>
        <Pill tone={report.coversEntireFile ? "accent" : "warn"}>{report.coversEntireFile ? "covers the whole file" : "partial coverage"}</Pill>
        <Pill tone={report.trustAnchorSupplied ? "info" : "neutral"}>{report.trustAnchorSupplied ? "trust anchor supplied" : "chain untrusted"}</Pill>
      </div>

      {report.signatures.length === 0 ? (
        <Callout tone="warn" title="No signatures found">This file carries no signature dictionary. Sign it first, then verify the output.</Callout>
      ) : (
        <div className="space-y-3">
          {report.signatures.map((signature, index) => (
            <div key={index} className="overflow-hidden rounded-lg border border-line">
              <div className="flex flex-wrap items-center gap-2 border-b border-line bg-surface-muted px-3 py-2">
                <span className="font-mono text-[11.5px] text-ink">{signature.field || `signature ${index + 1}`}</span>
                <Pill tone={signature.valid ? "accent" : "danger"}>{signature.valid ? "valid" : "invalid"}</Pill>
                <span className="text-[11px] text-faint">{signature.subFilter}</span>
                {signature.docMdp && signature.docMdp !== "None" ? <Pill tone="info">{signature.docMdp}</Pill> : null}
              </div>
              <div className="space-y-3 px-3 py-3">
                <Facts
                  columns={2}
                  data={{
                    Signer: signature.signer,
                    Subject: signature.subject,
                    Issuer: signature.issuer,
                    Serial: signature.serial,
                    Digest: signature.digestAlgorithm,
                    "Signing time": signature.signingTime ? new Date(signature.signingTime).toLocaleString() : undefined,
                    Reason: signature.reason,
                    Location: signature.location
                  }}
                />
                <div className="flex flex-wrap gap-1.5">
                  {[
                    ["covers whole document", signature.coversWholeDocument],
                    ["digest matches", signature.digestMatches],
                    ["signature value valid", signature.signatureValid],
                    ["chain trusted", signature.certificateChainTrusted]
                  ].map(([label, value]) => (
                    <Pill key={String(label)} tone={value ? "accent" : "warn"}>
                      {value ? "✓" : "✕"} {String(label)}
                    </Pill>
                  ))}
                </div>
                {signature.issues.length > 0 ? (
                  <ul className="space-y-1">
                    {signature.issues.map((issue, issueIndex) => (
                      <li key={issueIndex} className="rounded border border-[#f0dcba] bg-warn-soft px-2 py-1 text-[11.5px] text-[#7a470f]">
                        {issue}
                      </li>
                    ))}
                  </ul>
                ) : null}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function VerifyTab() {
  const [artifactId, setArtifactId] = useDocumentSelection();
  const [trust, setTrust] = useState("");
  const [loadError, setLoadError] = useState<string | null>(null);
  const { result, error, pending, run, reset } = useToolRun<Record<string, unknown>>();

  const anchors = trust
    .split(/-----END CERTIFICATE-----/)
    .map((chunk) => chunk.replace(/-----[^-]+-----/g, "").replace(/\s+/g, ""))
    .filter(Boolean);

  useEffect(() => {
    setLoadError(null);
  }, [artifactId]);

  return (
    <div className="split-wrap">
      <ConfigCard
        description="Reads every signature dictionary, recomputes the digest over the byte ranges and reports each check separately."
        footer={
          <RunBar
            label="Verify signatures"
            pending={pending}
            disabled={!artifactId}
            onRun={() => run(() => tools.verify({ artifactId, trustBase64: anchors.length > 0 ? anchors : undefined }))}
            hint={anchors.length > 0 ? `${anchors.length} trust anchor${anchors.length === 1 ? "" : "s"} supplied` : "Without an anchor the chain is reported as untrusted."}
          />
        }
      >
        <DocumentSelect value={artifactId} onChange={setArtifactId} label="Document" />
        <div>
          <span className="label">Trust anchors (PEM or base64)</span>
          <TextArea
            rows={6}
            value={trust}
            onChange={(event) => setTrust(event.target.value)}
            placeholder={"-----BEGIN CERTIFICATE-----\n…\n-----END CERTIFICATE-----"}
            className="font-mono text-[10.5px]"
          />
          <p className="mt-1 text-[11px] text-faint">
            Sign a document first to obtain its certificate, or paste an existing anchor. Trust is only claimed when you supply one.
          </p>
        </div>
        {loadError ? <Callout tone="danger">{loadError}</Callout> : null}
      </ConfigCard>

      <ResultPanel
        result={result}
        error={error}
        pending={pending}
        onReset={reset}
        showPreview={false}
        emptyIcon={ShieldCheck}
        emptyTitle="No verification run yet"
        emptyDescription="Pick a signed document. Every signature is listed with its coverage, digest result and chain status."
        renderReport={(report) => <VerificationReport report={report as unknown as VerificationPayload} />}
      />
    </div>
  );
}
