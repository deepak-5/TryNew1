"use client";

import { useEffect, useState } from "react";
import clsx from "clsx";
import { FileCode2, FileImage, FileSpreadsheet, FileText, Files } from "lucide-react";
import { tools } from "@/lib/api";
import { useWorkspace } from "@/components/workspace-provider";
import { useToolRun } from "@/lib/use-tool-run";
import type { ConvertReport } from "@/lib/types";
import { formatBytes, formatNumber } from "@/lib/format";
import { ResultPanel } from "@/components/result-panel";
import { ConfigCard, DocumentSelect, RunBar, SectionDivider } from "@/components/tool-form";
import { ReportSection } from "@/components/report-view";
import { Callout, Checkbox, NumberInput, PageHeader, Pill, Select, TextInput } from "@/components/ui";

type FormatSpec = {
  id: string;
  label: string;
  extension: string;
  group: "raster" | "text" | "office";
  description: string;
};

const FORMATS: FormatSpec[] = [
  { id: "png", label: "PNG", extension: ".png", group: "raster", description: "Lossless page raster" },
  { id: "jpeg", label: "JPEG", extension: ".jpg", group: "raster", description: "Lossy, quality controlled" },
  { id: "tiff", label: "TIFF", extension: ".tif", group: "raster", description: "Archival raster" },
  { id: "bmp", label: "BMP", extension: ".bmp", group: "raster", description: "Uncompressed bitmap" },
  { id: "gif", label: "GIF", extension: ".gif", group: "raster", description: "Indexed raster" },
  { id: "svg", label: "SVG", extension: ".svg", group: "text", description: "Vector page rewrite" },
  { id: "html", label: "HTML", extension: ".html", group: "text", description: "Positioned page markup" },
  { id: "md", label: "Markdown", extension: ".md", group: "text", description: "Text with structure hints" },
  { id: "txt", label: "Text", extension: ".txt", group: "text", description: "Plain decoded text" },
  { id: "json", label: "JSON", extension: ".json", group: "text", description: "Pages, runs and bounds" },
  { id: "csv", label: "CSV", extension: ".csv", group: "text", description: "Inferred grids as rows" },
  { id: "xml", label: "XML", extension: ".xml", group: "text", description: "Structured page model" },
  { id: "docx", label: "DOCX", extension: ".docx", group: "office", description: "Word document" },
  { id: "xlsx", label: "XLSX", extension: ".xlsx", group: "office", description: "Typed table workbook" }
];

const GROUP_LABEL: Record<FormatSpec["group"], string> = {
  raster: "Raster images",
  text: "Text & data",
  office: "Office documents"
};

export default function ConvertPage() {
  const { currentId } = useWorkspace();
  const [artifactId, setArtifactId] = useState(currentId ?? "");
  const [format, setFormat] = useState("png");
  const [pages, setPages] = useState("");
  const [dpi, setDpi] = useState("144");
  const [scale, setScale] = useState("1");
  const [jpegQuality, setJpegQuality] = useState("85");
  const [docxMode, setDocxMode] = useState("default");
  const [layout, setLayout] = useState(false);
  const [includeImages, setIncludeImages] = useState(true);
  const { result, error, pending, run, reset } = useToolRun<ConvertReport>();

  useEffect(() => {
    if (!artifactId && currentId) setArtifactId(currentId);
  }, [currentId, artifactId]);

  const spec = FORMATS.find((entry) => entry.id === format) ?? FORMATS[0];
  const isRaster = spec.group === "raster";

  return (
    <div>
      <PageHeader
        eyebrow="Analyse"
        title="Convert"
        description="Fourteen export formats written by the engine's own writers — no external converter, no headless browser. Rasters are rendered at the dpi you choose."
      />

      <div className="split-wrap">
        <ConfigCard
          description="Pick a target format, then scope the pages and rendering."
          footer={
            <RunBar
              label={`Convert to ${spec.label}`}
              pending={pending}
              disabled={!artifactId}
              onRun={() =>
                run(() =>
                  tools.convert({
                    artifactId,
                    format,
                    pages: pages || undefined,
                    dpi: isRaster ? Number(dpi) || undefined : undefined,
                    scale: Number(scale) || undefined,
                    jpegQuality: format === "jpeg" ? Number(jpegQuality) || undefined : undefined,
                    docxMode: format === "docx" ? docxMode : undefined,
                    layout: isRaster ? undefined : layout,
                    includeImages: format === "docx" ? includeImages : undefined
                  })
                )
              }
            />
          }
        >
          <DocumentSelect value={artifactId} onChange={setArtifactId} label="Document" />
          <div>
            <span className="label">Pages</span>
            <TextInput value={pages} onChange={(event) => setPages(event.target.value)} placeholder="all pages, or 1-3,7" />
          </div>
          <SectionDivider label="Rendering" />
          {isRaster ? (
            <div className="grid grid-cols-2 gap-3">
              <div>
                <span className="label">Resolution (dpi)</span>
                <NumberInput value={dpi} onChange={setDpi} min={36} max={600} step={12} />
              </div>
              <div>
                <span className="label">Scale</span>
                <NumberInput value={scale} onChange={setScale} min={0.05} max={12} step={0.05} />
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-3">
              <div>
                <span className="label">Scale</span>
                <NumberInput value={scale} onChange={setScale} min={0.05} max={12} step={0.05} />
              </div>
              <div />
            </div>
          )}
          {format === "jpeg" ? (
            <div>
              <span className="label">JPEG quality</span>
              <NumberInput value={jpegQuality} onChange={setJpegQuality} min={10} max={100} />
            </div>
          ) : null}
          {format === "docx" ? (
            <>
              <div>
                <span className="label">Word layout mode</span>
                <Select
                  value={docxMode}
                  onChange={(event) => setDocxMode(event.target.value)}
                  options={[
                    { value: "default", label: "Exact layout — artwork backing + text boxes" },
                    { value: "semantic", label: "Semantic — headings, paragraphs, tables" },
                    { value: "raster", label: "Raster — page images only" }
                  ]}
                />
              </div>
              <Checkbox label="Embed page artwork" checked={includeImages} onChange={setIncludeImages} />
            </>
          ) : null}
          {!isRaster ? (
            <Checkbox
              label="Keep positioned layout"
              hint="Writes absolute text positions instead of a reflowed document."
              checked={layout}
              onChange={setLayout}
            />
          ) : null}
        </ConfigCard>

        <div className="space-y-5">
          <div className="card overflow-hidden">
            <div className="border-b border-line px-4 py-3">
              <h2 className="text-[13px] font-semibold text-ink">Target format</h2>
              <p className="text-[11.5px] text-muted">All fourteen writers ship with the engine.</p>
            </div>
            <div className="space-y-4 px-4 py-4">
              {(["raster", "text", "office"] as const).map((group) => (
                <div key={group}>
                  <div className="section-label mb-2">{GROUP_LABEL[group]}</div>
                  <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-3">
                    {FORMATS.filter((entry) => entry.group === group).map((entry) => {
                      const Icon = group === "raster" ? FileImage : group === "office" ? (entry.id === "xlsx" ? FileSpreadsheet : FileText) : FileCode2;
                      const active = entry.id === format;
                      return (
                        <button
                          key={entry.id}
                          type="button"
                          onClick={() => setFormat(entry.id)}
                          className={clsx(
                            "flex items-start gap-2 rounded-lg border px-2.5 py-2 text-left transition",
                            active
                              ? "border-accent bg-accent-soft/60 shadow-[0_0_0_1px_rgba(14,106,69,0.15)]"
                              : "border-line bg-surface hover:border-line-strong hover:bg-surface-muted"
                          )}
                        >
                          <Icon className={clsx("mt-0.5 size-3.5 shrink-0", active ? "text-accent" : "text-faint")} />
                          <span className="min-w-0">
                            <span className="block text-[12px] font-medium text-ink">{entry.label}</span>
                            <span className="block truncate text-[10.5px] leading-[1.3] text-faint">{entry.description}</span>
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <ResultPanel
            result={result}
            error={error}
            pending={pending}
            onReset={reset}
            emptyIcon={Files}
            emptyTitle="Nothing converted yet"
            emptyDescription="Choose a format and run the conversion. Raster outputs preview inline; text outputs can be read and downloaded as artifacts."
            renderReport={(report) => <ConvertReportView report={report} />}
          />
        </div>
      </div>
    </div>
  );
}

function ConvertReportView({ report }: { report: ConvertReport }) {
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <Pill tone="accent">{report.formatName}</Pill>
        <Pill>{report.files.length} file{report.files.length === 1 ? "" : "s"}</Pill>
        <Pill>{report.pages.length} page{report.pages.length === 1 ? "" : "s"}</Pill>
        <Pill>{formatBytes(report.totalBytes)}</Pill>
        {report.dpi ? <Pill>{report.dpi} dpi</Pill> : null}
        {report.scale !== 1 ? <Pill>scale {report.scale}</Pill> : null}
      </div>

      <ReportSection title="Files written">
        <div className="overflow-hidden rounded-lg border border-line">
          {report.files.map((file, index) => (
            <div key={`${file.name}-${index}`} className="flex items-center gap-3 border-b border-line px-3 py-2 text-[12px] last:border-b-0">
              <span className="min-w-0 flex-1 truncate font-mono text-[11.5px] text-ink-soft">{file.name}</span>
              <span className="shrink-0 text-faint">{file.page ? `page ${file.page}` : "document"}</span>
              <span className="w-[70px] shrink-0 text-right tabular-nums text-muted">{formatBytes(file.bytes)}</span>
            </div>
          ))}
        </div>
      </ReportSection>

      <div className="grid grid-cols-2 gap-3 text-[12px]">
        <div className="rounded-lg border border-line bg-surface-muted/60 px-3 py-2">
          <div className="text-[10.5px] uppercase tracking-[0.06em] text-faint">Docx mode</div>
          <div className="mt-0.5 text-ink-soft">{report.docxMode ?? "—"}</div>
        </div>
        <div className="rounded-lg border border-line bg-surface-muted/60 px-3 py-2">
          <div className="text-[10.5px] uppercase tracking-[0.06em] text-faint">Total pages</div>
          <div className="mt-0.5 tabular-nums text-ink-soft">{formatNumber(report.pages.length)}</div>
        </div>
      </div>

      {report.note ? <Callout tone="info">{report.note}</Callout> : null}
      {report.warnings && report.warnings.length > 0 ? (
        <Callout tone="warn" title={`${report.warnings.length} warning(s) while writing`}>
          <ul className="list-disc space-y-0.5 pl-4">
            {report.warnings.map((warning, index) => (
              <li key={index}>{warning}</li>
            ))}
          </ul>
        </Callout>
      ) : null}
    </div>
  );
}
