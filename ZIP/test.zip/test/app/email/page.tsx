"use client";

import { ReactNode, useEffect, useState } from "react";
import { Boxes, CalendarDays, FileCode2, Inbox, Lock, Mail, PenLine, ShieldCheck, UserRound } from "lucide-react";
import { email as emailApi } from "@/lib/engine-api";
import { useEngineDocument } from "@/lib/use-engine-document";
import { useWorkspace } from "@/components/workspace-provider";
import { useHashTab } from "@/lib/use-hash-tab";
import { useToolRun } from "@/lib/use-tool-run";
import { ResultPanel } from "@/components/result-panel";
import { ConfigCard, DocumentSelect, InlineFields, RunBar } from "@/components/tool-form";
import { Callout, Checkbox, Field, PageHeader, Segmented, Select, Tabs, TextArea, TextInput } from "@/components/ui";
import { formatBytes } from "@/lib/format";

const TABS = [
  { id: "message", label: "Message", icon: Mail },
  { id: "render", label: "Render", icon: FileCode2 },
  { id: "attachments", label: "Attachments", icon: Boxes },
  { id: "verify", label: "S/MIME", icon: Lock },
  { id: "compose", label: "Compose", icon: PenLine },
  { id: "headers", label: "Headers", icon: Inbox },
  { id: "storage", label: "Storage", icon: Boxes },
  { id: "calendar", label: "Calendar", icon: CalendarDays },
  { id: "contacts", label: "Contacts", icon: UserRound },
  { id: "body", label: "Body safety", icon: ShieldCheck }
];

type InspectReport = {
  from?: { address?: string; displayName?: string } | null;
  to?: Array<{ address?: string; displayName?: string }>;
  cc?: string[];
  subject?: string;
  bodyCharacters?: number;
  htmlBodyCharacters?: number;
  hasHtml?: boolean;
  attachments?: Array<{ fileName?: string; mediaType?: string; size?: number }>;
  headers?: Array<{ name?: string; value?: string }>;
};

function Row({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="flex gap-3 border-b border-line/70 py-1.5 last:border-0">
      <span className="w-[92px] shrink-0 text-[11px] uppercase tracking-[0.04em] text-faint">{label}</span>
      <span className="min-w-0 flex-1 break-words text-[12px] text-ink-soft">{children}</span>
    </div>
  );
}

const splitList = (value: string) =>
  value
    .split(",")
    .map((entry) => entry.trim())
    .filter((entry) => entry.length > 0);

export default function EmailPage() {
  const [tab, setTab] = useState("message");
  useHashTab(["message", "render", "attachments", "verify", "compose", "headers", "storage", "calendar", "contacts", "body"], tab, setTab);
  const [artifactId, setArtifactId] = useEngineDocument("email");
  const { artifacts } = useWorkspace();
  const [calendarId, setCalendarId] = useState("");
  const [contactId, setContactId] = useState("");

  // The calendar and contact readers need their own defaults: the shared picker settles
  // on a message, and a message is not an .ics or a .vcf.
  useEffect(() => {
    if (calendarId) return;
    const found = artifacts.find((artifact) => artifact.kind === "email" && artifact.fileName.toLowerCase().endsWith(".ics"));
    if (found) setCalendarId(found.id);
  }, [artifacts, calendarId]);

  useEffect(() => {
    if (contactId) return;
    const found = artifacts.find((artifact) => artifact.kind === "email" && artifact.fileName.toLowerCase().endsWith(".vcf"));
    if (found) setContactId(found.id);
  }, [artifacts, contactId]);
  const [to, setTo] = useState("pdf");
  const [attachmentName, setAttachmentName] = useState("");
  const inspector = useToolRun<InspectReport>();
  const converter = useToolRun();
  const extractor = useToolRun();
  const verifier = useToolRun();

  /* compose + edit */
  const [composeMode, setComposeMode] = useState<"create" | "edit">("create");
  const [fromAddress, setFromAddress] = useState("arun.mehta@northwind.example");
  const [toAddresses, setToAddresses] = useState("priya.raghavan@northwind.example");
  const [ccAddresses, setCcAddresses] = useState("audit@cassia.example");
  const [subject, setSubject] = useState("Intake review");
  const [textBody, setTextBody] = useState("The intake numbers for October are attached.");
  const [htmlBody, setHtmlBody] = useState("<p>The intake numbers for October are attached.</p>");
  const [editFormat, setEditFormat] = useState("eml");
  const composeRun = useToolRun();

  /* headers */
  const [headerName, setHeaderName] = useState("");
  const headersRun = useToolRun();

  /* storage */
  const [storageAction, setStorageAction] = useState<"to-msg" | "from-msg" | "read-mbox" | "write-mbox" | "read-pst">("to-msg");
  const [storageIndex, setStorageIndex] = useState("0");
  const storageRun = useToolRun();

  /* calendar + contacts */
  const [calendarMode, setCalendarMode] = useState<"read" | "write">("read");
  const [icsText, setIcsText] = useState("BEGIN:VCALENDAR\nVERSION:2.0\nBEGIN:VEVENT\nUID:urn:uuid:console-invite\nDTSTAMP:20261101T040000Z\nDTSTART:20261112T043000Z\nDTEND:20261112T050000Z\nSUMMARY:Console invite\nORGANIZER:mailto:arun.mehta@northwind.example\nATTENDEE;CN=Priya Raghavan:mailto:priya.raghavan@northwind.example\nEND:VEVENT\nEND:VCALENDAR\n");
  const contactMode = useState<"read" | "write">("read")[0];
  const calendarRun = useToolRun();
  const contactRun = useToolRun();

  /* body safety */
  const [blockRemote, setBlockRemote] = useState(true);
  const bodyRun = useToolRun();
  const safetyRun = useToolRun();

  const runInspect = () => inspector.run(() => emailApi.inspect(artifactId));
  const runConvert = () => converter.run(() => emailApi.convert({ artifactId, to }));
  const runExtract = () => extractor.run(() => emailApi.attachments({ artifactId, name: attachmentName || undefined }));
  const runVerify = () => verifier.run(() => emailApi.verify(artifactId));

  const runCompose = () =>
    composeRun.run(() =>
      composeMode === "create"
        ? emailApi.create({
            from: fromAddress || undefined,
            to: splitList(toAddresses),
            cc: splitList(ccAddresses),
            subject,
            text: textBody || undefined,
            html: htmlBody || undefined
          })
        : emailApi.edit({
            artifactId,
            subject,
            to: toAddresses || undefined,
            cc: ccAddresses || undefined,
            text: textBody,
            html: htmlBody,
            format: editFormat as "eml" | "msg"
          })
    );

  const runHeaders = () => headersRun.run(() => emailApi.headers({ artifactId, name: headerName || undefined }));
  const runStorage = () =>
    storageRun.run(() =>
      emailApi.storage({ artifactId, action: storageAction, index: storageAction === "read-mbox" ? Number(storageIndex) || 0 : undefined })
    );
  const runCalendar = () =>
    calendarRun.run(() =>
      calendarMode === "read" ? emailApi.calendar({ artifactId: calendarId, action: "read" }) : emailApi.calendar({ action: "write", ics: icsText })
    );
  const runContact = () => contactRun.run(() => emailApi.contact({ artifactId: contactId, action: contactMode }));
  const runBody = () => bodyRun.run(() => emailApi.sanitizeBody({ artifactId, blockRemoteImages: blockRemote }));
  const runSafety = () => safetyRun.run(() => emailApi.attachmentSafety({ artifactId }));

  const info = inspector.result?.report;

  return (
    <div>
      <PageHeader
        eyebrow="Email engine"
        title="Message workbench"
        description="Parse an .eml with the engine's own MIME reader: headers, alternative bodies, attachments and CMS signatures. Nothing is fetched from the network and no HTML is executed."
        actions={<span className="pill border border-line bg-surface px-2.5 py-1 text-[11px] text-muted">eml · mime · smime</span>}
      />

      <div className="mb-4">
        <Tabs tabs={TABS} value={tab} onChange={setTab} />
      </div>

      <div className="split-wrap">
        <div className="min-w-0 space-y-4">

          {tab === "message" || tab === "render" || tab === "attachments" || tab === "verify" ? (
          <ConfigCard
            title="Message"
            description="Every tab reads the same file; the picker stays shared so you can move between reading, rendering and verifying."
            footer={
              <RunBar
                label={tab === "verify" ? "Verify signature" : tab === "attachments" ? "Extract attachments" : tab === "render" ? `Render to ${to.toUpperCase()}` : "Read message"}
                pending={inspector.pending || converter.pending || extractor.pending || verifier.pending}
                disabled={!artifactId}
                hint="Read-only except where a file is written"
                onRun={tab === "verify" ? runVerify : tab === "attachments" ? runExtract : tab === "render" ? runConvert : runInspect}
              />
            }
          >
            <DocumentSelect label="Message" include="email" value={artifactId} onChange={setArtifactId} />

            {tab === "render" ? (
              <Field label="Target">
                <Select
                  value={to}
                  onChange={(event) => setTo(event.target.value)}
                  options={[
                    { value: "pdf", label: "PDF" },
                    { value: "html", label: "HTML body" },
                    { value: "mhtml", label: "MHTML archive" },
                    { value: "eml", label: "EML round trip" }
                  ]}
                />
              </Field>
            ) : null}

            {tab === "attachments" ? (
              <Field label="Attachment name" hint="Leave empty to extract all of them">
                <TextInput value={attachmentName} onChange={(event) => setAttachmentName(event.target.value)} placeholder="approval-note.txt" />
              </Field>
            ) : null}

            {tab === "verify" ? (
              <Callout tone="info">
                CMS/PKCS#7 verification uses the BCL's cryptography only. Trust anchors are not downloaded, so a valid
                signature on an unknown chain reports `certificateChainTrusted: false` — that is the honest answer, not a
                failure of the tool.
              </Callout>
            ) : null}

            {info && tab === "message" ? (
              <div className="rounded-lg border border-line bg-surface px-3 py-1.5">
                <Row label="Subject">{info.subject || "—"}</Row>
                <Row label="From">{info.from ? `${info.from.displayName} <${info.from.address}>` : "—"}</Row>
                <Row label="To">{info.to?.map((address) => address.address).join(", ") || "—"}</Row>
                {info.cc && info.cc.length > 0 ? <Row label="Cc">{info.cc.join(", ")}</Row> : null}
                <Row label="Body">
                  {info.bodyCharacters} characters of text
                  {info.hasHtml ? `, ${info.htmlBodyCharacters} of HTML` : ", text only"}
                </Row>
                <Row label="Parts">
                  {info.attachments?.length ?? 0} attachment{(info.attachments?.length ?? 0) === 1 ? "" : "s"}
                </Row>
              </div>
            ) : null}

            {info && tab === "message" && (info.attachments?.length ?? 0) > 0 ? (
              <div className="space-y-1.5">
                <div className="section-label">Attachment parts</div>
                {info.attachments?.map((attachment) => (
                  <div key={attachment.fileName} className="flex items-center gap-2 rounded-md border border-line bg-surface px-2.5 py-1.5">
                    <span className="flex size-6 items-center justify-center rounded bg-[#f1f4f0] text-muted">
                      <Boxes className="size-3" />
                    </span>
                    <span className="min-w-0 flex-1 truncate text-[12px] text-ink">{attachment.fileName || "(unnamed)"}</span>
                    <span className="text-[11px] text-faint">
                      {attachment.mediaType} · {formatBytes(attachment.size ?? 0)}
                    </span>
                  </div>
                ))}
              </div>
            ) : null}
          </ConfigCard>
          ) : null}

          {tab === "compose" ? (
            <ConfigCard
              title={composeMode === "create" ? "Compose a message" : "Edit the selected message"}
              description="Compose writes a new RFC 5322 message; edit rewrites the selected one as EML or as an Outlook MSG."
              footer={
                <RunBar
                  label={composeMode === "create" ? "Write EML" : editFormat === "msg" ? "Write MSG" : "Write EML"}
                  pending={composeRun.pending}
                  disabled={composeMode === "create" ? !subject.trim() || splitList(toAddresses).length === 0 : !artifactId}
                  hint="Saved into the workspace library"
                  onRun={runCompose}
                />
              }
            >
              <Segmented
                value={composeMode}
                onChange={setComposeMode}
                options={[
                  { value: "create", label: "Compose" },
                  { value: "edit", label: "Edit selected" }
                ]}
              />
              {composeMode === "edit" ? (
                <DocumentSelect label="Message" include="email" value={artifactId} onChange={setArtifactId} />
              ) : null}
              <InlineFields>
                <Field label="From">
                  <TextInput value={fromAddress} onChange={(event) => setFromAddress(event.target.value)} />
                </Field>
                <Field label="To" hint="Comma separated">
                  <TextInput value={toAddresses} onChange={(event) => setToAddresses(event.target.value)} />
                </Field>
              </InlineFields>
              <InlineFields>
                <Field label="Cc" hint="Comma separated">
                  <TextInput value={ccAddresses} onChange={(event) => setCcAddresses(event.target.value)} />
                </Field>
                {composeMode === "edit" ? (
                  <Field label="Write as">
                    <Segmented
                      value={editFormat}
                      onChange={setEditFormat}
                      options={[
                        { value: "eml", label: "EML" },
                        { value: "msg", label: "MSG" }
                      ]}
                    />
                  </Field>
                ) : null}
              </InlineFields>
              <Field label="Subject">
                <TextInput value={subject} onChange={(event) => setSubject(event.target.value)} />
              </Field>
              <Field label="Text body">
                <TextArea value={textBody} rows={4} onChange={(event) => setTextBody(event.target.value)} />
              </Field>
              <Field label="HTML body" hint="Sent as the text/html alternative">
                <TextArea value={htmlBody} rows={4} onChange={(event) => setHtmlBody(event.target.value)} className="font-mono text-[11.5px]" />
              </Field>
            </ConfigCard>
          ) : null}

          {tab === "headers" ? (
            <ConfigCard
              title="Header-only read"
              description="The envelope and every header the file carries, read without decoding bodies or attachments."
              footer={<RunBar label="Read headers" pending={headersRun.pending} disabled={!artifactId} hint="Read-only: nothing is written" onRun={runHeaders} />}
            >
              <DocumentSelect label="Message" include="email" value={artifactId} onChange={setArtifactId} />
              <Field label="Header filter" hint="Optional, case-insensitive">
                <TextInput value={headerName} onChange={(event) => setHeaderName(event.target.value)} placeholder="Received, Authentication-Results" />
              </Field>
            </ConfigCard>
          ) : null}

          {tab === "storage" ? (
            <ConfigCard
              title="Storage formats"
              description="Convert between EML and Outlook MSG, write or read an mbox archive, and inventory a PST store."
              footer={<RunBar label="Run conversion" pending={storageRun.pending} disabled={!artifactId} hint="The source file is never modified" onRun={runStorage} />}
            >
              <DocumentSelect label="Message or archive" include="email" value={artifactId} onChange={setArtifactId} />
              <Field label="Operation">
                <Segmented
                  value={storageAction}
                  onChange={setStorageAction}
                  options={[
                    { value: "to-msg", label: "EML → MSG" },
                    { value: "from-msg", label: "MSG → EML" },
                    { value: "write-mbox", label: "→ MBOX" },
                    { value: "read-mbox", label: "MBOX →" },
                    { value: "read-pst", label: "PST" }
                  ]}
                />
              </Field>
              {storageAction === "read-mbox" ? (
                <Field label="Export message index" hint="0-based; writes that message out as EML">
                  <TextInput value={storageIndex} onChange={(event) => setStorageIndex(event.target.value)} inputMode="numeric" />
                </Field>
              ) : null}
            </ConfigCard>
          ) : null}

          {tab === "calendar" ? (
            <ConfigCard
              title="Calendar invitations"
              description="Read an .ics with its recurrence rule expanded by the engine, or write iCalendar text into a new .ics file."
              footer={<RunBar label={calendarMode === "read" ? "Read invitation" : "Write iCalendar"} pending={calendarRun.pending} disabled={calendarMode === "read" ? !calendarId : !icsText.trim()} hint={calendarMode === "read" ? "Read-only: nothing is written" : "Saved into the workspace library"} onRun={runCalendar} />}
            >
              <Segmented
                value={calendarMode}
                onChange={setCalendarMode}
                options={[
                  { value: "read", label: "Read" },
                  { value: "write", label: "Write" }
                ]}
              />
              {calendarMode === "read" ? (
                <DocumentSelect label="Calendar file" include="email" value={calendarId} onChange={setCalendarId} />
              ) : (
                <Field label="iCalendar text">
                  <TextArea value={icsText} rows={12} onChange={(event) => setIcsText(event.target.value)} className="font-mono text-[11.5px]" />
                </Field>
              )}
            </ConfigCard>
          ) : null}

          {tab === "contacts" ? (
            <ConfigCard
              title="Contacts"
              description="Read a vCard file — names, organisation, emails, phones — and write the parsed contact back out."
              footer={<RunBar label="Read contact" pending={contactRun.pending} disabled={!contactId} hint="Read-only: nothing is written" onRun={runContact} />}
            >
              <DocumentSelect label="vCard file" include="email" value={contactId} onChange={setContactId} />
            </ConfigCard>
          ) : null}

          {tab === "body" ? (
            <>
              <ConfigCard
                title="Sanitise the body"
                description="Scripts, event handlers and forms are stripped from the HTML body; remote images are blocked by default."
                footer={<RunBar label="Sanitise body" pending={bodyRun.pending} disabled={!artifactId} hint="Writes the cleaned body as HTML" onRun={runBody} />}
              >
                <DocumentSelect label="Message" include="email" value={artifactId} onChange={setArtifactId} />
                <Checkbox checked={blockRemote} onChange={setBlockRemote} label="Block remote images" />
              </ConfigCard>
              <ConfigCard
                title="Attachment safety"
                description="A policy pass over attachment names, extensions and archive shape: executables, spoofed extensions, path traversal and decompression bombs."
                footer={<RunBar label="Inspect attachments" pending={safetyRun.pending} disabled={!artifactId} hint="Nothing is opened or executed" onRun={runSafety} />}
              >
                <p className="text-[11.5px] leading-[1.5] text-muted">
                  Each attachment is reported with the violations the policy found, and the count of unsafe parts is in the
                  report header.
                </p>
              </ConfigCard>
            </>
          ) : null}

        </div>

        <div className="min-w-0">
          <ResultPanel
            result={
              composeRun.result ??
              headersRun.result ??
              storageRun.result ??
              calendarRun.result ??
              contactRun.result ??
              bodyRun.result ??
              safetyRun.result ??
              inspector.result ??
              converter.result ??
              extractor.result ??
              verifier.result
            }
            error={
              composeRun.error ??
              headersRun.error ??
              storageRun.error ??
              calendarRun.error ??
              contactRun.error ??
              bodyRun.error ??
              safetyRun.error ??
              inspector.error ??
              converter.error ??
              extractor.error ??
              verifier.error
            }
            pending={
              composeRun.pending ||
              headersRun.pending ||
              storageRun.pending ||
              calendarRun.pending ||
              contactRun.pending ||
              bodyRun.pending ||
              safetyRun.pending ||
              inspector.pending ||
              converter.pending ||
              extractor.pending ||
              verifier.pending
            }
            emptyTitle="Nothing read yet"
            emptyDescription="Read a message to see its headers and parts, render it to PDF, pull out attachments or verify a signature."
            emptyIcon={Mail}
            onReset={() => {
              composeRun.reset();
              headersRun.reset();
              storageRun.reset();
              calendarRun.reset();
              contactRun.reset();
              bodyRun.reset();
              safetyRun.reset();
              inspector.reset();
              converter.reset();
              extractor.reset();
              verifier.reset();
            }}
          />
        </div>
      </div>
    </div>
  );
}
