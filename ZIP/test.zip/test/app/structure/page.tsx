"use client";

import { useEffect, useState } from "react";
import clsx from "clsx";
import {
  Anchor,
  BadgeCheck,
  BookMarked,
  Bookmark,
  FileSignature,
  Info,
  Paperclip,
  Plus,
  Trash2
} from "lucide-react";
import { api, tools } from "@/lib/api";
import { useWorkspace } from "@/components/workspace-provider";
import { useToolRun } from "@/lib/use-tool-run";
import { formatBytes, formatNumber } from "@/lib/format";
import type {
  AnnotationList,
  Artifact,
  AttachmentList,
  Bookmark as BookmarkNode,
  FieldsResponse,
  MetadataReport
} from "@/lib/types";
import { ResultPanel } from "@/components/result-panel";
import { ConfigCard, DocumentSelect, InlineFields, RunBar, SectionDivider, useDocumentSelection } from "@/components/tool-form";
import { DataTable, GenericReport } from "@/components/report-view";
import { Button, Callout, Checkbox, EmptyState, Field, NumberInput, PageHeader, Pill, Select, Tabs, TextArea, TextInput } from "@/components/ui";

const TABS = [
  { id: "metadata", label: "Metadata", icon: Info },
  { id: "bookmarks", label: "Bookmarks", icon: Bookmark },
  { id: "annotations", label: "Annotations", icon: BookMarked },
  { id: "attachments", label: "Attachments", icon: Paperclip },
  { id: "forms", label: "Forms", icon: FileSignature },
  { id: "conformance", label: "Conformance", icon: BadgeCheck },
  { id: "destinations", label: "Destinations", icon: Anchor }
];

export default function StructurePage() {
  const [tab, setTab] = useState("metadata");
  return (
    <div>
      <PageHeader
        eyebrow="Organise"
        title="Structure"
        description="Metadata, navigation, annotations, embedded files and AcroForm fields — read exactly as stored, then written back through the engine's own editors."
      />
      <Tabs tabs={TABS} value={tab} onChange={setTab} className="mb-5" />
      {tab === "metadata" ? <MetadataTab /> : null}
      {tab === "bookmarks" ? <BookmarksTab /> : null}
      {tab === "annotations" ? <AnnotationsTab /> : null}
      {tab === "attachments" ? <AttachmentsTab /> : null}
      {tab === "forms" ? <FormsTab /> : null}
      {tab === "conformance" ? <ConformanceTab /> : null}
      {tab === "destinations" ? <DestinationsTab /> : null}
    </div>
  );
}

/* --------------------------------------------------------------- metadata */

const EDITABLE_KEYS = ["Title", "Author", "Subject", "Keywords", "Creator"];

function MetadataTab() {
  const [artifactId, setArtifactId] = useDocumentSelection();
  const [metadata, setMetadata] = useState<MetadataReport | null>(null);
  const [values, setValues] = useState<Record<string, string>>({});
  const [dropXmp, setDropXmp] = useState(false);
  const [incremental, setIncremental] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const write = useToolRun<Record<string, unknown>>();

  useEffect(() => {
    if (!artifactId) return;
    let cancelled = false;
    setLoadError(null);
    api
      .metadata(artifactId)
      .then((response) => {
        if (cancelled) return;
        setMetadata(response.metadata);
        setValues(
          Object.fromEntries(EDITABLE_KEYS.map((key) => [key, response.metadata.info[key] ?? ""]))
        );
      })
      .catch((cause) => {
        if (!cancelled) setLoadError(cause instanceof Error ? cause.message : "Metadata could not be read");
      });
    return () => {
      cancelled = true;
    };
  }, [artifactId]);

  const customKeys = metadata ? Object.keys(metadata.info).filter((key) => !EDITABLE_KEYS.includes(key)) : [];

  return (
    <div className="space-y-5">
      <div className="split-wrap">
        <ConfigCard
          description="An empty value removes the key. XMP is rebuilt from the merged view unless it is dropped."
          footer={
            <RunBar
              label={incremental ? "Append incremental update" : "Write metadata"}
              pending={write.pending}
              disabled={!artifactId}
              onRun={async () => {
                const set: Record<string, string | null> = {};
                for (const key of EDITABLE_KEYS) set[key] = values[key]?.trim() ? values[key] : null;
                const response = await write.run(() => tools.metadataWrite({ artifactId, set: set as Record<string, string>, dropXmp, incremental }));
                const produced = response?.artifacts[0];
                if (produced) setArtifactId(produced.id);
              }}
            />
          }
        >
          <DocumentSelect value={artifactId} onChange={setArtifactId} label="Document" />
          <div className="space-y-3">
            {EDITABLE_KEYS.map((key) => (
              <div key={key}>
                <span className="label">{key}</span>
                <TextInput
                  value={values[key] ?? ""}
                  onChange={(event) => setValues((current) => ({ ...current, [key]: event.target.value }))}
                  placeholder={metadata?.info[key] ? undefined : `No ${key.toLowerCase()} set`}
                />
              </div>
            ))}
          </div>
          {customKeys.length > 0 ? (
            <Callout tone="info" title="Other keys are preserved">
              {customKeys.join(", ")} stay as they are. Clear a standard key above to remove it.
            </Callout>
          ) : null}
          <SectionDivider label="Write options" />
          <div className="grid grid-cols-2 gap-2">
            <Checkbox label="Drop XMP" hint="Write the Info dictionary only." checked={dropXmp} onChange={setDropXmp} />
            <Checkbox label="Incremental" hint="Append, keep revisions." checked={incremental} onChange={setIncremental} />
          </div>
        </ConfigCard>

        <div className="card overflow-hidden">
          <div className="flex items-center justify-between border-b border-line px-4 py-3">
            <div>
              <h2 className="text-[13px] font-semibold text-ink">As stored</h2>
              <p className="text-[11.5px] text-muted">Read straight from the document, not from the form above.</p>
            </div>
            {metadata ? <Pill tone="accent">PDF {metadata.version}</Pill> : null}
          </div>
          <div className="px-4 py-4">
            {loadError ? <Callout tone="danger" title="Could not read metadata">{loadError}</Callout> : null}
            {!metadata ? (
              <p className="py-8 text-center text-[12px] text-muted">Reading the Info dictionary…</p>
            ) : (
              <div className="space-y-4">
                <div>
                  <div className="mb-1.5 section-label">Info dictionary</div>
                  {Object.keys(metadata.info).length === 0 ? (
                    <p className="text-[12px] text-muted">Empty.</p>
                  ) : (
                    <div className="overflow-hidden rounded-lg border border-line">
                      {Object.entries(metadata.info).map(([key, value]) => (
                        <div key={key} className="flex gap-3 border-b border-line px-3 py-1.5 text-[12px] last:border-b-0">
                          <span className="w-[110px] shrink-0 text-faint">{key}</span>
                          <span className="min-w-0 break-words text-ink-soft">{value}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                <div>
                  <div className="mb-1.5 flex items-center gap-2">
                    <span className="section-label">XMP</span>
                    <Pill tone={metadata.hasXmp ? "accent" : "neutral"}>{metadata.hasXmp ? "present" : "none"}</Pill>
                  </div>
                  {Object.keys(metadata.xmp).length === 0 ? (
                    <p className="text-[12px] text-muted">No metadata stream.</p>
                  ) : (
                    <div className="flex flex-wrap gap-1.5">
                      {Object.entries(metadata.xmp).map(([key, value]) => (
                        <span key={key} className="rounded-md border border-line bg-surface-muted px-2 py-1 text-[11.5px]" title={value}>
                          <span className="text-faint">{key}</span>
                          <span className="mx-1 text-line-strong">·</span>
                          <span className="text-ink-soft">{String(value).slice(0, 48)}</span>
                        </span>
                      ))}
                    </div>
                  )}
                </div>
                <p className="text-[11px] text-faint">
                  Standard keys recognised by the engine: {metadata.standardKeys.join(", ")}.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      {write.result || write.error ? (
        <ResultPanel
          result={write.result}
          error={write.error}
          pending={write.pending}
          onReset={write.reset}
          emptyTitle=""
          emptyDescription=""
          showPreview={false}
          renderReport={(report) => <GenericReport report={report} />}
        />
      ) : null}
    </div>
  );
}

/* -------------------------------------------------------------- bookmarks */

function BookmarksTab() {
  const [artifactId, setArtifactId] = useDocumentSelection();
  const [tree, setTree] = useState<BookmarkNode[] | null>(null);
  const [json, setJson] = useState("");
  const [action, setAction] = useState<"add" | "import" | "clear">("add");
  const [title, setTitle] = useState("Section 1");
  const [page, setPage] = useState("1");
  const [color, setColor] = useState("");
  const [loadError, setLoadError] = useState<string | null>(null);
  const write = useToolRun<Record<string, unknown>>();

  function load() {
    if (!artifactId) return;
    setLoadError(null);
    api
      .bookmarks(artifactId)
      .then((response) => {
        setTree(response.bookmarks);
        if (!json) setJson(response.json);
      })
      .catch((cause) => setLoadError(cause instanceof Error ? cause.message : "Bookmarks could not be read"));
  }

  useEffect(load, [artifactId]);

  const count = countBookmarks(tree ?? []);

  return (
    <div className="space-y-5">
      <div className="split-wrap">
        <ConfigCard
          description="The outline is a tree of destinations. Import replaces it with a JSON tree; clear removes it."
          footer={
            <RunBar
              label={action === "add" ? "Add bookmark" : action === "import" ? "Import outline" : "Clear outline"}
              pending={write.pending}
              disabled={!artifactId || (action === "import" && !json.trim())}
              onRun={async () => {
                const response = await write.run(() =>
                  tools.bookmarksWrite({
                    artifactId,
                    action,
                    title: action === "add" ? title : undefined,
                    page: action === "add" ? Number(page) : undefined,
                    color: action === "add" && color ? color : undefined,
                    json: action === "import" ? json : undefined
                  })
                );
                const produced = response?.artifacts[0];
                if (produced) setArtifactId(produced.id);
                else load();
              }}
            />
          }
        >
          <DocumentSelect value={artifactId} onChange={setArtifactId} label="Document" />
          <Select
            value={action}
            onChange={(event) => setAction(event.target.value as typeof action)}
            options={[
              { value: "add", label: "Add a single entry" },
              { value: "import", label: "Import a JSON tree" },
              { value: "clear", label: "Clear the outline" }
            ]}
          />

          {action === "add" ? (
            <>
              <div>
                <span className="label">Title</span>
                <TextInput value={title} onChange={(event) => setTitle(event.target.value)} />
              </div>
              <InlineFields>
                <div>
                  <span className="label">Page</span>
                  <NumberInput value={page} onChange={setPage} min={1} />
                </div>
                <div>
                  <span className="label">Colour (optional)</span>
                  <TextInput value={color} onChange={(event) => setColor(event.target.value)} placeholder="#0e6a45" />
                </div>
              </InlineFields>
            </>
          ) : null}

          {action === "import" ? (
            <div>
              <span className="label">Outline JSON</span>
              <TextArea rows={10} value={json} onChange={(event) => setJson(event.target.value)} className="font-mono text-[11px]" />
              <p className="mt-1 text-[11px] text-faint">Shape: [{`{ "title", "page", "children" }`}]. Destinations are one-based pages.</p>
            </div>
          ) : null}

          {action === "clear" ? <Callout tone="warn" title="The outline will be removed">Bookmarks are not recoverable from this document once cleared.</Callout> : null}
        </ConfigCard>

        <div className="card overflow-hidden">
          <div className="flex items-center justify-between border-b border-line px-4 py-3">
            <div>
              <h2 className="text-[13px] font-semibold text-ink">Outline</h2>
              <p className="text-[11.5px] text-muted">Read from the catalog's /Outlines tree.</p>
            </div>
            <Pill tone={count > 0 ? "accent" : "neutral"}>{count} {count === 1 ? "entry" : "entries"}</Pill>
          </div>
          <div className="px-4 py-3">
            {loadError ? <Callout tone="danger" title="Could not read the outline">{loadError}</Callout> : null}
            {!tree ? (
              <p className="py-8 text-center text-[12px] text-muted">Reading the outline…</p>
            ) : tree.length === 0 ? (
              <EmptyState icon={Bookmark} title="No bookmarks" description="Add one above, or import a tree to see how the engine stores it." compact />
            ) : (
              <ul className="space-y-0.5">{tree.map((node, index) => <BookmarkRow key={index} node={node} depth={0} />)}</ul>
            )}
          </div>
        </div>
      </div>

      {write.result || write.error ? (
        <ResultPanel
          result={write.result}
          error={write.error}
          pending={write.pending}
          onReset={write.reset}
          emptyTitle=""
          emptyDescription=""
          showPreview={false}
          renderReport={(report) => <GenericReport report={report} />}
        />
      ) : null}
    </div>
  );
}

function countBookmarks(nodes: BookmarkNode[]): number {
  return nodes.reduce((sum, node) => sum + 1 + countBookmarks(node.children ?? []), 0);
}

function BookmarkRow({ node, depth }: { node: BookmarkNode; depth: number }) {
  return (
    <li>
      <div className="flex items-center gap-2 rounded-md px-2 py-1.5 hover:bg-surface-muted" style={{ paddingLeft: 8 + depth * 16 }}>
        <Bookmark className="size-3 shrink-0 text-faint" />
        <span className="min-w-0 flex-1 truncate text-[12.5px] text-ink">{node.title}</span>
        {node.uri ? <Pill tone="info">URI</Pill> : <span className="shrink-0 text-[11px] tabular-nums text-faint">page {node.page}</span>}
      </div>
      {node.children?.length ? (
        <ul className="space-y-0.5">{node.children.map((child, index) => <BookmarkRow key={index} node={child} depth={depth + 1} />)}</ul>
      ) : null}
    </li>
  );
}

/* ------------------------------------------------------------ annotations */

function AnnotationsTab() {
  const [artifactId, setArtifactId] = useDocumentSelection();
  const [list, setList] = useState<AnnotationList | null>(null);
  const [type, setType] = useState("highlight");
  const [page, setPage] = useState("1");
  const [rect, setRect] = useState(["80", "640", "300", "660"]);
  const [text, setText] = useState("Reviewed");
  const [author, setAuthor] = useState("QA");
  const [color, setColor] = useState("#f2c94c");
  const [opacity, setOpacity] = useState("0.6");
  const [uri, setUri] = useState("");
  const [destPage, setDestPage] = useState("");
  const [incremental, setIncremental] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const write = useToolRun<Record<string, unknown>>();

  function load() {
    if (!artifactId) return;
    api
      .annotations(artifactId)
      .then(setList)
      .catch((cause) => setLoadError(cause instanceof Error ? cause.message : "Annotations could not be read"));
  }

  useEffect(load, [artifactId]);

  return (
    <div className="space-y-5">
      <div className="split-wrap">
        <ConfigCard
          description="Annotations are appended as new objects. Link targets are either a URI or a page index."
          footer={
            <RunBar
              label="Add annotation"
              pending={write.pending}
              disabled={!artifactId}
              onRun={async () => {
                const response = await write.run(() =>
                  tools.annotationsWrite({
                    artifactId,
                    type,
                    page: Number(page),
                    rect: rect.map(Number),
                    text: type === "link" ? undefined : text,
                    author,
                    color,
                    opacity: Number(opacity),
                    uri: type === "link" && uri ? uri : undefined,
                    destPage: type === "link" && destPage ? Number(destPage) : undefined,
                    incremental
                  })
                );
                const produced = response?.artifacts[0];
                if (produced) setArtifactId(produced.id);
                else load();
              }}
            />
          }
        >
          <DocumentSelect value={artifactId} onChange={setArtifactId} label="Document" />
          <InlineFields>
            <div>
              <span className="label">Type</span>
              <Select
                value={type}
                onChange={(event) => setType(event.target.value)}
                options={[
                  { value: "highlight", label: "Highlight" },
                  { value: "note", label: "Sticky note" },
                  { value: "link", label: "Link" },
                  { value: "square", label: "Square" },
                  { value: "circle", label: "Circle" }
                ]}
              />
            </div>
            <div>
              <span className="label">Page</span>
              <NumberInput value={page} onChange={setPage} min={1} />
            </div>
          </InlineFields>
          <div>
            <span className="label">Rectangle · llx, lly, urx, ury</span>
            <div className="grid grid-cols-4 gap-1.5">
              {rect.map((value, index) => (
                <NumberInput
                  key={index}
                  value={value}
                  onChange={(next) => setRect((items) => items.map((item, itemIndex) => (itemIndex === index ? next : item)))}
                />
              ))}
            </div>
          </div>
          {type === "link" ? (
            <InlineFields>
              <div>
                <span className="label">URI</span>
                <TextInput value={uri} onChange={(event) => setUri(event.target.value)} placeholder="https://…" />
              </div>
              <div>
                <span className="label">Or destination page</span>
                <NumberInput value={destPage} onChange={setDestPage} placeholder="page" />
              </div>
            </InlineFields>
          ) : (
            <div>
              <span className="label">Contents</span>
              <TextArea rows={2} value={text} onChange={(event) => setText(event.target.value)} />
            </div>
          )}
          <InlineFields>
            <div>
              <span className="label">Author</span>
              <TextInput value={author} onChange={(event) => setAuthor(event.target.value)} />
            </div>
            <div>
              <span className="label">Colour</span>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={color}
                  onChange={(event) => setColor(event.target.value)}
                  className="size-9 shrink-0 cursor-pointer rounded-md border border-line-strong bg-surface p-0.5"
                />
                <TextInput value={color} onChange={(event) => setColor(event.target.value)} className="font-mono text-[12px]" />
              </div>
            </div>
          </InlineFields>
          <div>
            <span className="label">Opacity · {Math.round(Number(opacity) * 100)}%</span>
            <input
              type="range"
              min={0.05}
              max={1}
              step={0.05}
              value={opacity}
              onChange={(event) => setOpacity(event.target.value)}
              className="w-full accent-[#0e6a45]"
            />
          </div>
          <Checkbox label="Incremental append" hint="Writes a classic cross-reference update instead of a full rewrite." checked={incremental} onChange={setIncremental} />
        </ConfigCard>

        <div className="card overflow-hidden">
          <div className="flex items-center justify-between border-b border-line px-4 py-3">
            <div>
              <h2 className="text-[13px] font-semibold text-ink">Annotations</h2>
              <p className="text-[11.5px] text-muted">From every page's /Annots array.</p>
            </div>
            {list ? <Pill tone={list.count ? "accent" : "neutral"}>{list.count}</Pill> : null}
          </div>
          <div className="px-4 py-4">
            {loadError ? <Callout tone="danger" title="Could not read annotations">{loadError}</Callout> : null}
            {!list ? (
              <p className="py-8 text-center text-[12px] text-muted">Reading annotations…</p>
            ) : list.annotations.length === 0 ? (
              <EmptyState icon={BookMarked} title="No annotations" description="Highlight, note, link, square and circle annotations can be added." compact />
            ) : (
              <DataTable
                columns={[
                  { key: "page", label: "Page", align: "right" },
                  { key: "type", label: "Type" },
                  { key: "contents", label: "Contents" },
                  { key: "author", label: "Author" },
                  { key: "rect", label: "Rect", mono: true }
                ]}
                rows={list.annotations.map((annotation) => ({
                  page: annotation.page,
                  type: annotation.type,
                  contents: annotation.contents || (annotation.uri ? annotation.uri : "—"),
                  author: annotation.author || "—",
                  rect: annotation.rect.map((value) => Math.round(value)).join(", ")
                }))}
              />
            )}
          </div>
        </div>
      </div>

      {write.result || write.error ? (
        <ResultPanel
          result={write.result}
          error={write.error}
          pending={write.pending}
          onReset={write.reset}
          emptyTitle=""
          emptyDescription=""
          showPreview={false}
          renderReport={(report) => <GenericReport report={report} />}
        />
      ) : null}
    </div>
  );
}

/* ------------------------------------------------------------ attachments */

function AttachmentsTab() {
  const [artifactId, setArtifactId] = useDocumentSelection();
  const { artifacts } = useWorkspace();
  const [list, setList] = useState<AttachmentList | null>(null);
  const [sourceId, setSourceId] = useState("");
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [mime, setMime] = useState("");
  const [removeName, setRemoveName] = useState("");
  const [loadError, setLoadError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const write = useToolRun<Record<string, unknown>>();
  const extract = useToolRun<Record<string, unknown>>();

  function load() {
    if (!artifactId) return;
    api
      .attachments(artifactId)
      .then(setList)
      .catch((cause) => setLoadError(cause instanceof Error ? cause.message : "Attachments could not be read"));
  }

  useEffect(load, [artifactId]);

  const sources = artifacts.filter((artifact) => artifact.id !== artifactId);

  async function run(action: "add" | "remove" | "clear") {
    const response = await write.run(() =>
      tools.attachmentsWrite({
        artifactId,
        action,
        name: action === "add" ? name || sources.find((source) => source.id === sourceId)?.fileName : undefined,
        description: action === "add" ? description || undefined : undefined,
        mimeType: action === "add" ? mime || undefined : undefined,
        sourceArtifactId: action === "add" ? sourceId : undefined,
        removeName: action === "remove" ? removeName : undefined
      })
    );
    const produced = response?.artifacts[0];
    if (produced) setArtifactId(produced.id);
    return response;
  }

  return (
    <div className="space-y-5">
      <div className="split-wrap">
        <ConfigCard
          description="Embedded files are ordinary file specifications in the name tree. Names must be unique and safe."
          footer={
            <div className="space-y-2">
              <RunBar
                label="Add attachment"
                pending={write.pending || busy}
                disabled={!artifactId || !sourceId}
                onRun={async () => {
                  const response = await run("add");
                  if (response) load();
                }}
              />
              <Button
                size="sm"
                className="w-full"
                disabled={!artifactId || (list?.count ?? 0) === 0}
                loading={extract.pending}
                onClick={async () => {
                  const response = await extract.run(() => tools.attachmentsWrite({ artifactId, action: "extract" }));
                  if (response?.artifacts.length) load();
                }}
              >
                Extract all as artifacts
              </Button>
            </div>
          }
        >
          <DocumentSelect value={artifactId} onChange={setArtifactId} label="Document" />
          <div>
            <label className="label" htmlFor="attachment-source">
              Source artifact
            </label>
            <Select
              id="attachment-source"
              value={sourceId}
              onChange={(event) => {
                setSourceId(event.target.value);
                const found = artifacts.find((artifact) => artifact.id === event.target.value);
                if (found && !name) setName(found.fileName);
              }}
              options={[{ value: "", label: "Choose a file to embed…" }, ...sources.map((source) => ({ value: source.id, label: `${source.fileName} (${formatBytes(source.size)})` }))]}
            />
          </div>
          <div>
            <span className="label">Name inside the PDF</span>
            <TextInput value={name} onChange={(event) => setName(event.target.value)} placeholder="attachment.pdf" />
          </div>
          <InlineFields>
            <div>
              <span className="label">Media type</span>
              <TextInput value={mime} onChange={(event) => setMime(event.target.value)} placeholder="application/pdf" />
            </div>
            <div>
              <span className="label">Description</span>
              <TextInput value={description} onChange={(event) => setDescription(event.target.value)} placeholder="Optional" />
            </div>
          </InlineFields>

          <SectionDivider label="Remove" />
          <div>
            <span className="label">Existing name</span>
            <Select
              value={removeName}
              onChange={(event) => setRemoveName(event.target.value)}
              options={[{ value: "", label: "Select an attachment…" }, ...(list?.attachments ?? []).map((attachment) => ({ value: attachment.name, label: attachment.name }))]}
            />
          </div>
          <div className="flex items-center gap-1.5">
            <Button size="sm" variant="danger" icon={Trash2} disabled={!removeName} onClick={async () => { if (await run("remove")) load(); }}>
              Remove
            </Button>
            <Button
              size="sm"
              variant="ghost"
              disabled={(list?.count ?? 0) === 0}
              onClick={async () => {
                if (await run("clear")) load();
              }}
            >
              Clear all
            </Button>
          </div>
        </ConfigCard>

        <div className="card overflow-hidden">
          <div className="flex items-center justify-between border-b border-line px-4 py-3">
            <div>
              <h2 className="text-[13px] font-semibold text-ink">Embedded files</h2>
              <p className="text-[11.5px] text-muted">Read from the catalog's /Names /EmbeddedFiles tree.</p>
            </div>
            {list ? <Pill tone={list.count ? "accent" : "neutral"}>{list.count}</Pill> : null}
          </div>
          <div className="px-4 py-4">
            {loadError ? <Callout tone="danger" title="Could not read attachments">{loadError}</Callout> : null}
            {!list ? (
              <p className="py-8 text-center text-[12px] text-muted">Reading the embedded file tree…</p>
            ) : list.attachments.length === 0 ? (
              <EmptyState icon={Paperclip} title="No embedded files" description="Attach any artifact from the workspace to see it listed here." compact />
            ) : (
              <div className="overflow-hidden rounded-lg border border-line">
                {list.attachments.map((attachment) => (
                  <div key={attachment.name} className="flex items-center gap-3 border-b border-line px-3 py-2 text-[12px] last:border-b-0">
                    <Paperclip className="size-3.5 shrink-0 text-faint" />
                    <div className="min-w-0 flex-1">
                      <p className="truncate font-medium text-ink">{attachment.name}</p>
                      <p className="truncate text-[11px] text-faint">
                        {attachment.description || "no description"} · {attachment.mimeType ?? "unknown type"}
                      </p>
                    </div>
                    <span className="shrink-0 tabular-nums text-muted">{formatBytes(attachment.size)}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {write.result || write.error || extract.result || extract.error ? (
        <ResultPanel
          result={extract.result ?? write.result}
          error={extract.error ?? write.error}
          pending={write.pending || extract.pending}
          onReset={() => {
            write.reset();
            extract.reset();
          }}
          emptyTitle=""
          emptyDescription=""
          showPreview={false}
          renderReport={(report) => <GenericReport report={report} />}
        />
      ) : null}
    </div>
  );
}

/* ------------------------------------------------------------------ forms */

function FormsTab() {
  const [artifactId, setArtifactId] = useDocumentSelection();
  const [fields, setFields] = useState<FieldsResponse | null>(null);
  const [values, setValues] = useState<Record<string, string>>({});
  const [flatten, setFlatten] = useState(false);
  const [incremental, setIncremental] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [builder, setBuilder] = useState({ name: "customer_name", type: "text", page: "1", rect: ["72", "680", "320", "704"], options: "", defaultValue: "" });
  const [busy, setBusy] = useState(false);
  const fill = useToolRun<Record<string, unknown>>();
  const create = useToolRun<Record<string, unknown>>();
  const [lastAction, setLastAction] = useState<"fill" | "create">("create");

  function load() {
    if (!artifactId) return;
    api
      .fields(artifactId)
      .then((response) => {
        setFields(response);
        setValues(Object.fromEntries(response.fields.map((field) => [field.name, field.value == null ? "" : String(field.value)])));
      })
      .catch((cause) => setLoadError(cause instanceof Error ? cause.message : "Fields could not be read"));
  }

  useEffect(load, [artifactId]);

  const hasFields = (fields?.fields.length ?? 0) > 0;

  return (
    <div className="space-y-5">
      <div className="split-wrap">
        <ConfigCard
          description="Fields are read from the AcroForm dictionary; filling writes new appearance streams."
          footer={
            <Button
              variant="primary"
              className="w-full"
              loading={fill.pending}
              disabled={!artifactId || !hasFields}
              onClick={async () => {
                const changed = Object.fromEntries(Object.entries(values).filter(([, value]) => value !== ""));
                if (Object.keys(changed).length === 0) return;
                setLastAction("fill");
                create.reset();
                const response = await fill.run(() => tools.formFill({ artifactId, values: changed, flatten, incremental }));
                const produced = response?.artifacts[0];
                if (produced) setArtifactId(produced.id);
                else load();
              }}
            >
              {hasFields ? `Fill ${fields!.fields.length} field${fields!.fields.length === 1 ? "" : "s"}` : "Fill fields"}
            </Button>
          }
        >
          <DocumentSelect value={artifactId} onChange={setArtifactId} label="Document" />
          {loadError ? <Callout tone="danger" title="Could not read the form">{loadError}</Callout> : null}
          {fields?.hasXfa ? (
            <Callout tone="warn" title="XFA form">
              Only the AcroForm layer is read. Flattening XFA is refused when there is nothing to paint.
            </Callout>
          ) : null}
          {fields?.hasDocMdp || fields?.hasSignatureValue ? (
            <Callout tone="warn" title="Signed form">
              Full rewrites are refused; use the incremental option to keep the signature valid.
            </Callout>
          ) : null}

          {hasFields ? (
            <div className="space-y-2.5">
              {fields!.fields.map((field) => (
                <div key={field.name}>
                  <div className="mb-1 flex items-baseline justify-between gap-2">
                    <label className="label mb-0 truncate font-mono text-[11.5px]" htmlFor={`field-${field.name}`}>
                      {field.name}
                    </label>
                    <span className="shrink-0 text-[10.5px] text-faint">
                      {field.type}
                      {field.page ? ` · p${field.page}` : ""}
                      {field.flags.readOnly ? " · read-only" : ""}
                      {field.flags.required ? " · required" : ""}
                    </span>
                  </div>
                  {field.type === "checkbox" ? (
                    <Select
                      value={values[field.name] ?? ""}
                      onChange={(event) => setValues((current) => ({ ...current, [field.name]: event.target.value }))}
                      options={[
                        { value: "", label: "unset" },
                        { value: "true", label: "checked" },
                        { value: "false", label: "unchecked" }
                      ]}
                    />
                  ) : field.type === "combo" || field.type === "list" ? (
                    <Select
                      value={values[field.name] ?? ""}
                      onChange={(event) => setValues((current) => ({ ...current, [field.name]: event.target.value }))}
                      options={[{ value: "", label: "unset" }, ...field.options.map((option) => ({ value: option.value, label: option.label }))]}
                    />
                  ) : (
                    <TextInput
                      id={`field-${field.name}`}
                      value={values[field.name] ?? ""}
                      onChange={(event) => setValues((current) => ({ ...current, [field.name]: event.target.value }))}
                      disabled={field.flags.readOnly}
                      className="h-8 text-[12.5px]"
                    />
                  )}
                </div>
              ))}
              <div className="grid grid-cols-2 gap-2 pt-1">
                <Checkbox label="Flatten after fill" checked={flatten} onChange={setFlatten} disabled={incremental} />
                <Checkbox label="Incremental update" checked={incremental} onChange={setIncremental} disabled={flatten} />
              </div>
            </div>
          ) : (
            <div className="rounded-lg border border-dashed border-line-strong px-3 py-5 text-center">
              <p className="text-[12px] font-medium text-ink">This document has no form fields</p>
              <p className="mt-0.5 text-[11.5px] text-muted">Create one below; the engine writes a real AcroForm widget.</p>
            </div>
          )}

          <SectionDivider label="Create a field" />
          <div className="space-y-2.5">
            <InlineFields>
              <div>
                <span className="label">Name</span>
                <TextInput value={builder.name} onChange={(event) => setBuilder((current) => ({ ...current, name: event.target.value }))} className="font-mono text-[12px]" />
              </div>
              <div>
                <span className="label">Type</span>
                <Select
                  value={builder.type}
                  onChange={(event) => setBuilder((current) => ({ ...current, type: event.target.value }))}
                  options={[
                    { value: "text", label: "Text" },
                    { value: "checkbox", label: "Checkbox" },
                    { value: "combo", label: "Dropdown" },
                    { value: "list", label: "List" }
                  ]}
                />
              </div>
            </InlineFields>
            <div className="grid grid-cols-[64px_repeat(4,1fr)] gap-1.5">
              <div>
                <span className="label text-[10.5px]">Page</span>
                <NumberInput value={builder.page} onChange={(value) => setBuilder((current) => ({ ...current, page: value }))} className="h-8 px-1.5 text-[12px]" />
              </div>
              {["llx", "lly", "urx", "ury"].map((label, index) => (
                <div key={label}>
                  <span className="label text-[10.5px]">{label}</span>
                  <NumberInput
                    value={builder.rect[index]}
                    onChange={(value) =>
                      setBuilder((current) => ({ ...current, rect: current.rect.map((item, itemIndex) => (itemIndex === index ? value : item)) }))
                    }
                    className="h-8 px-1.5 text-[12px]"
                  />
                </div>
              ))}
            </div>
            {builder.type === "combo" || builder.type === "list" ? (
              <div>
                <span className="label">Options (comma separated)</span>
                <TextInput value={builder.options} onChange={(event) => setBuilder((current) => ({ ...current, options: event.target.value }))} placeholder="Alpha, Beta, Gamma" />
              </div>
            ) : null}
            <Button
              size="sm"
              icon={Plus}
              loading={create.pending || busy}
              disabled={!artifactId || !builder.name.trim()}
              onClick={async () => {
                setBusy(true);
                const response = await create.run(() =>
                  tools.formFieldCreate({
                    artifactId,
                    action: "add",
                    name: builder.name,
                    type: builder.type,
                    page: Number(builder.page),
                    rect: builder.rect.map(Number),
                    options: builder.options ? builder.options.split(",").map((option) => option.trim()).filter(Boolean) : undefined,
                    defaultValue: builder.defaultValue || undefined
                  })
                );
                setBusy(false);
                setLastAction("create");
                fill.reset();
                const produced = response?.artifacts[0];
                if (produced) {
                  // A new field only exists in the written artifact, so continue there.
                  setArtifactId(produced.id);
                } else {
                  load();
                }
              }}
            >
              Create field
            </Button>
            <p className="text-[11px] text-faint">
              The new field is written to a new artifact, and the console switches to it so you can fill it immediately.
            </p>
          </div>
        </ConfigCard>

        <div className="card overflow-hidden">
          <div className="flex items-center justify-between border-b border-line px-4 py-3">
            <div>
              <h2 className="text-[13px] font-semibold text-ink">Field inventory</h2>
              <p className="text-[11.5px] text-muted">Terminal fields with type, value and widget geometry.</p>
            </div>
            {fields ? <Pill tone={fields.count ? "accent" : "neutral"}>{fields.count} field{fields.count === 1 ? "" : "s"}</Pill> : null}
          </div>
          <div className="px-4 py-4">
            {!fields ? (
              <p className="py-8 text-center text-[12px] text-muted">Reading the AcroForm…</p>
            ) : fields.fields.length === 0 ? (
              <EmptyState icon={FileSignature} title="No fields yet" description="Create a field with the builder on the left; it becomes writable immediately." compact />
            ) : (
              <DataTable
                columns={[
                  { key: "name", label: "Name", mono: true },
                  { key: "type", label: "Type" },
                  { key: "value", label: "Value" },
                  { key: "page", label: "Page", align: "right" },
                  { key: "flags", label: "Flags" }
                ]}
                rows={fields.fields.map((field) => ({
                  name: field.name,
                  type: field.type,
                  value: field.value == null || field.value === "" ? "—" : String(field.value),
                  page: field.page ?? "—",
                  flags: [field.flags.readOnly ? "read-only" : "", field.flags.required ? "required" : "", field.flags.multiline ? "multiline" : ""]
                    .filter(Boolean)
                    .join(", ") || "—"
                }))}
              />
            )}
            {fields?.warnings.length ? (
              <div className="mt-3 flex flex-wrap gap-1.5">
                {fields.warnings.map((warning, index) => (
                  <Pill key={index} tone="warn">
                    {warning}
                  </Pill>
                ))}
              </div>
            ) : null}
          </div>
        </div>
      </div>

      {fill.result || fill.error || create.result || create.error ? (
        <ResultPanel
          result={lastAction === "create" ? create.result : fill.result}
          error={lastAction === "create" ? create.error : fill.error}
          pending={fill.pending || create.pending}
          onReset={() => {
            fill.reset();
            create.reset();
          }}
          emptyTitle=""
          emptyDescription=""
          renderReport={(report) => <GenericReport report={report} />}
        />
      ) : null}
    </div>
  );
}

/* ----------------------------------------------------------- conformance */

function ConformanceTab() {
  const [artifactId, setArtifactId] = useDocumentSelection();
  const [profile, setProfile] = useState("ua");
  const [part, setPart] = useState("1");
  const run = useToolRun<Record<string, unknown>>();

  const isX = profile.startsWith("pdfx") || profile === "all";

  return (
    <div className="space-y-4">
      <div className="split-wrap">
        <ConfigCard
          title="Conformance checks"
          description="PDF/UA accessibility and the PDF/X print profiles, checked against what this engine actually implements."
          footer={
            <RunBar
              label={isX ? "Check PDF/X" : "Check PDF/UA"}
              pending={run.pending}
              disabled={!artifactId}
              hint="Read-only: nothing is written"
              onRun={() => run.run(() => tools.conformance({ artifactId, profile, part }))}
            />
          }
        >
          <DocumentSelect label="Document" include="pdf" value={artifactId} onChange={setArtifactId} />
          <InlineFields>
            <Field label="Profile">
              <Select
                value={profile}
                onChange={(event) => setProfile(event.target.value)}
                options={[
                  { value: "ua", label: "PDF/UA-1" },
                  { value: "ua2", label: "PDF/UA-2" },
                  { value: "pdfx1a", label: "PDF/X-1a" },
                  { value: "pdfx3", label: "PDF/X-3" },
                  { value: "pdfx4", label: "PDF/X-4" },
                  { value: "all", label: "All PDF/X profiles" }
                ]}
              />
            </Field>
            {isX ? null : (
              <Field label="Part" hint="Only UA-1 and UA-2 are implemented">
                <Select
                  value={part}
                  onChange={(event) => setPart(event.target.value)}
                  options={[
                    { value: "1", label: "Part 1" },
                    { value: "2", label: "Part 2" }
                  ]}
                />
              </Field>
            )}
          </InlineFields>
          <Callout tone="info" title="A checked subset, not a certificate">
            The report lists only the checks this engine runs — tagging, alternative text, language and reading order for
            PDF/UA, output intent and transparency for PDF/X. Passing means passing those checks, and the report says so
            in its own verdict line.
          </Callout>
        </ConfigCard>
      </div>

      {run.result || run.error ? (
        <ResultPanel
          result={run.result}
          error={run.error}
          pending={run.pending}
          onReset={run.reset}
          emptyTitle=""
          emptyDescription=""
          showPreview={false}
          renderReport={(report) => <GenericReport report={report} />}
        />
      ) : null}
    </div>
  );
}

/* ------------------------------------------------------------ destinations */

function DestinationsTab() {
  const [artifactId, setArtifactId] = useDocumentSelection();
  const run = useToolRun<Record<string, unknown>>();

  return (
    <div className="space-y-4">
      <div className="split-wrap">
        <ConfigCard
          title="Named destinations"
          description="Every named destination in the file and the page view it resolves to, so an internal jump can be checked rather than trusted."
          footer={
            <RunBar
              label="List destinations"
              pending={run.pending}
              disabled={!artifactId}
              hint="Read-only: nothing is written"
              onRun={() => run.run(() => tools.destinations({ artifactId }))}
            />
          }
        >
          <DocumentSelect label="Document" include="pdf" value={artifactId} onChange={setArtifactId} />
          <Callout tone="info">
            Fit and XYZ destinations resolve to a page number. A name whose target is itself a name is reported as nested
            instead of being followed, and a file with no name tree honestly reports zero.
          </Callout>
        </ConfigCard>
      </div>

      {run.result || run.error ? (
        <ResultPanel
          result={run.result}
          error={run.error}
          pending={run.pending}
          onReset={run.reset}
          emptyTitle=""
          emptyDescription=""
          showPreview={false}
          renderReport={(report) => <GenericReport report={report} />}
        />
      ) : null}
    </div>
  );
}
