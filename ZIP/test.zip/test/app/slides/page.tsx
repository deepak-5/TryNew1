"use client";

import { ReactNode, useState } from "react";
import { FileDown, KeyRound, Layers3, ListTree, MessageSquare, Presentation, Search, Shapes, Sparkles, Type, Wand2 } from "lucide-react";
import { slides as slidesApi } from "@/lib/engine-api";
import { useEngineDocument } from "@/lib/use-engine-document";
import { useHashTab } from "@/lib/use-hash-tab";
import { useToolRun } from "@/lib/use-tool-run";
import { ResultPanel } from "@/components/result-panel";
import { GenericReport } from "@/components/report-view";
import { ConfigCard, DocumentSelect, InlineFields, RunBar, SectionDivider } from "@/components/tool-form";
import { Field, PageHeader, Segmented, Select, Tabs, TextArea, TextInput } from "@/components/ui";

type Report = Record<string, unknown>;

const TABS = [
  { id: "deck", label: "Deck", icon: Presentation },
  { id: "author", label: "Author", icon: Wand2 },
  { id: "structure", label: "Structure", icon: ListTree },
  { id: "text", label: "Text", icon: Search },
  { id: "notes", label: "Notes & comments", icon: MessageSquare },
  { id: "arrange", label: "Arrange", icon: Layers3 },
  { id: "motion", label: "Motion", icon: Sparkles },
  { id: "theme", label: "Theme", icon: Shapes },
  { id: "export", label: "Export", icon: FileDown },
  { id: "protect", label: "Protect", icon: KeyRound }
];

const SAMPLE_SPEC = `[
  {
    "title": "Supplier intake review",
    "subtitle": "Northwind Analytics · November 2026"
  },
  {
    "title": "What changes",
    "bullets": ["One intake address", "Validation on receipt", "Two-step approval above ₹2,00,000"],
    "notes": "Keep this to three bullets and one minute."
  },
  {
    "title": "Volume",
    "chart": true,
    "chartKind": "Column",
    "chartCategories": ["Jul", "Aug", "Sep", "Oct"],
    "chartSeries": { "Invoices": [18120, 19480, 21020, 22650] }
  }
]`;

type SlideShape = {
  id: number;
  name: string;
  kind: string;
  xPt?: number;
  yPt?: number;
  widthPt?: number;
  heightPt?: number;
  text?: string;
  chart?: { kind?: string; series?: string[] };
  table?: { rows?: number; columns?: number };
};

type SlideRead = {
  index: number;
  slideId?: number;
  hidden?: boolean;
  layout?: { name?: string; type?: string };
  shapes?: SlideShape[];
  notes?: string;
  comments?: Array<{ authorName?: string; text?: string }>;
  transition?: { type?: string } | null;
  animations?: { main?: unknown[] };
};

/**
 * The structure report is a tree of shapes, so the generic table squeezed whole
 * shape lists into one cell. Each slide reads here as a card with its shapes.
 */
function DeckStructure({ report }: { report: Report }) {
  const slides = (report.content as SlideRead[] | undefined) ?? [];
  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-x-6 gap-y-1 text-[11.5px] text-muted">
        <span>
          <span className="font-medium text-ink">{slides.length}</span> slides
        </span>
        <span>
          <span className="font-medium text-ink">{slides.reduce((total, slide) => total + (slide.shapes?.length ?? 0), 0)}</span> shapes
        </span>
        <span>
          <span className="font-medium text-ink">{slides.filter((slide) => slide.notes).length}</span> with notes
        </span>
        <span>
          <span className="font-medium text-ink">{slides.filter((slide) => (slide.comments?.length ?? 0) > 0).length}</span> with comments
        </span>
      </div>
      {slides.map((slide) => (
        <div key={slide.index} className="rounded-lg border border-line bg-surface">
          <div className="flex flex-wrap items-baseline gap-2 border-b border-line px-3 py-2">
            <span className="text-[12.5px] font-medium text-ink">Slide {slide.index}</span>
            <span className="text-[11.5px] text-muted">{slide.layout?.name ?? "no layout"}{slide.layout?.type ? ` · ${slide.layout.type}` : ""}</span>
            {slide.hidden ? <span className="pill border border-line bg-surface-muted px-1.5 py-px text-[10.5px] text-muted">hidden</span> : null}
            {slide.transition?.type ? (
              <span className="pill border border-accent-line bg-accent-soft px-1.5 py-px text-[10.5px] text-accent-strong">{slide.transition.type}</span>
            ) : null}
            <span className="ml-auto font-mono text-[10.5px] text-faint">
              {(slide.shapes?.length ?? 0)} shapes · {(slide.comments?.length ?? 0)} comments · {(slide.animations?.main?.length ?? 0) as number} effects
            </span>
          </div>
          {(slide.shapes?.length ?? 0) === 0 ? (
            <p className="px-3 py-2 text-[12px] text-muted">No shape on this slide.</p>
          ) : (
            <div className="divide-y divide-line">
              {slide.shapes!.map((shape, index) => (
                <div key={`${slide.index}-${index}`} className="flex flex-wrap items-baseline gap-2 px-3 py-1.5">
                  <span className="font-mono text-[10.5px] text-faint">#{index}</span>
                  <span className="text-[12px] font-medium text-ink-soft">{shape.name || shape.kind}</span>
                  <span className="text-[10.5px] text-faint">{shape.kind}</span>
                  <span className="font-mono text-[10.5px] text-faint">
                    {shape.xPt ?? 0},{shape.yPt ?? 0} · {shape.widthPt ?? 0}×{shape.heightPt ?? 0} pt
                  </span>
                  {shape.chart?.kind ? <span className="text-[10.5px] text-muted">chart {shape.chart.kind}</span> : null}
                  {shape.table?.rows ? <span className="text-[10.5px] text-muted">table {shape.table.rows}×{shape.table.columns}</span> : null}
                  {shape.text ? (
                    <span className="w-full truncate text-[11.5px] text-muted">{shape.text.replace(/\n/g, " ⏎ ")}</span>
                  ) : null}
                </div>
              ))}
            </div>
          )}
          {slide.notes ? (
            <div className="border-t border-line bg-surface-muted px-3 py-1.5 text-[11.5px] text-muted">
              <span className="font-medium text-ink-soft">Notes:</span> {slide.notes}
            </div>
          ) : null}
        </div>
      ))}
    </div>
  );
}

function Fact({ label, value }: { label: string; value: ReactNode }) {
  return (
    <div className="rounded-lg border border-line bg-surface px-3 py-2">
      <div className="section-label">{label}</div>
      <div className="mt-0.5 text-[13px] font-medium text-ink">{value}</div>
    </div>
  );
}

const TRANSITIONS = ["None", "Fade", "Push", "Wipe", "Split", "Cut", "RandomBar", "Dissolve", "Checker", "Blinds", "Zoom", "Random", "Morph", "Cover"];
const EFFECTS = ["Fade", "Appear", "FlyIn", "Zoom", "Wipe"];
const TRIGGERS = ["OnClick", "WithPrevious", "AfterPrevious"];

export default function SlidesPage() {
  const [artifactId, setArtifactId] = useEngineDocument("slides");
  const [tab, setTab] = useState("deck");
  useHashTab(TABS.map((entry) => entry.id), tab, setTab);

  /* deck */
  const [to, setTo] = useState("pdf");
  const [slide, setSlide] = useState("1");
  const inspector = useToolRun<Report>();
  const converter = useToolRun<Report>();

  /* author */
  const [specTitle, setSpecTitle] = useState("Supplier intake review");
  const [specBody, setSpecBody] = useState(SAMPLE_SPEC);
  const [specSize, setSpecSize] = useState("16:9");
  const author = useToolRun<Report>();

  /* read */
  const reader = useToolRun<Report>();

  /* text */
  const [textMode, setTextMode] = useState<"find" | "replace">("find");
  const [find, setFind] = useState("invoice");
  const [replacement, setReplacement] = useState("bill");
  const [matchCase, setMatchCase] = useState(false);
  const textRun = useToolRun<Report>();

  /* notes + comments */
  const [sideMode, setSideMode] = useState<"notes" | "comments">("notes");
  const [notesSlide, setNotesSlide] = useState("1");
  const [notesText, setNotesText] = useState("Say the numbers slowly, then take questions.");
  const [commentAuthor, setCommentAuthor] = useState("Priya Raghavan");
  const [commentText, setCommentText] = useState("Tighten this slide.");
  const notesRun = useToolRun<Report>();
  const commentsRun = useToolRun<Report>();

  /* arrange */
  const [arrangeAction, setArrangeAction] = useState("read");
  const [arrangeIndex, setArrangeIndex] = useState("1");
  const [arrangeTo, setArrangeTo] = useState("1");
  const [arrangeLayout, setArrangeLayout] = useState("TitleAndContent");
  const [appendId, setAppendId] = useState("");
  const [appendIndex, setAppendIndex] = useState("1");
  const [sectionName, setSectionName] = useState("Opening");
  const [sectionSlides, setSectionSlides] = useState("1,2");
  const arrangeRun = useToolRun<Report>();
  const sectionsRun = useToolRun<Report>();

  /* motion */
  const [motionMode, setMotionMode] = useState<"transition" | "animation">("transition");
  const [motionSlide, setMotionSlide] = useState("1");
  const [transitionType, setTransitionType] = useState("Fade");
  const [transitionSeconds, setTransitionSeconds] = useState("2.5");
  const [effectType, setEffectType] = useState("Fade");
  const [effectTrigger, setEffectTrigger] = useState("OnClick");
  const [effectDuration, setEffectDuration] = useState("700");
  const [effectShape, setEffectShape] = useState("0");
  const motionRun = useToolRun<Report>();

  /* theme */
  const themeRun = useToolRun<Report>();

  /* export */
  const [exportFormat, setExportFormat] = useState("player");
  const [exportSlide, setExportSlide] = useState("1");
  const exporter = useToolRun<Report>();

  /* protect */
  const [protectAction, setProtectAction] = useState<"read" | "apply" | "remove" | "check" | "encrypt" | "decrypt">("read");
  const [password, setPassword] = useState("");
  const protectRun = useToolRun<Report>();

  const info = inspector.result?.report as
    | { slides?: number; parts?: number; widthPt?: number; heightPt?: number; aspect?: number; hasMacros?: boolean; hasDigitalSignatures?: boolean }
    | undefined;

  const indexOf = (value: string) => Math.max(0, (Number(value) || 1) - 1);
  const slideList = (value: string) =>
    value
      .split(",")
      .map((entry) => Number(entry.trim()))
      .filter((entry) => Number.isFinite(entry) && entry > 0);

  const runInspect = () => inspector.run(() => slidesApi.inspect(artifactId));
  const runConvert = () => converter.run(() => slidesApi.convert({ artifactId, to, slide: to === "svg" ? Number(slide) || 1 : undefined }));

  const runAuthor = () =>
    author.run(async () => {
      let parsed: Array<Record<string, unknown>>;
      try {
        parsed = JSON.parse(specBody);
      } catch (error) {
        throw new Error(`The slide list is not valid JSON: ${(error as Error).message}`);
      }
      return slidesApi.create({ title: specTitle, fileName: specTitle.toLowerCase().replace(/[^a-z0-9]+/g, "-"), size: specSize, slides: parsed });
    });

  const runText = () =>
    textRun.run(() =>
      slidesApi.text({
        artifactId,
        action: textMode,
        find,
        replacement: textMode === "replace" ? replacement : undefined,
        matchCase: matchCase || undefined
      })
    );

  const runNotes = (action: "read" | "write") =>
    notesRun.run(() =>
      slidesApi.notes({ artifactId, action, slide: indexOf(notesSlide) + 1, text: action === "write" ? notesText : undefined })
    );

  const runComments = (action: "read" | "add") =>
    commentsRun.run(() =>
      slidesApi.comments({
        artifactId,
        action,
        slide: indexOf(notesSlide) + 1,
        author: action === "add" ? commentAuthor : undefined,
        text: action === "add" ? commentText : undefined
      })
    );

  const runArrange = (action: string) =>
    arrangeRun.run(() =>
      slidesApi.slideOps({
        artifactId,
        action: action as "read",
        index: action === "read" ? undefined : indexOf(arrangeIndex),
        to: action === "move" ? indexOf(arrangeTo) : undefined,
        layout: action === "add" ? arrangeLayout : undefined,
        sourceId: action === "append" ? appendId || undefined : undefined,
        sourceIndex: action === "append" ? indexOf(appendIndex) : undefined
      })
    );

  const runSections = (action: "read" | "add-section" | "add-show") =>
    sectionsRun.run(() =>
      slidesApi.sections({
        artifactId,
        action,
        name: action === "read" ? undefined : sectionName,
        slideIndexes: action === "read" ? undefined : slideList(sectionSlides)
      })
    );

  const runMotion = (action: "set" | "read" | "add") => {
    if (motionMode === "transition") {
      motionRun.run(() =>
        slidesApi.transitions(
          action === "set"
            ? { artifactId, action: "set", slide: indexOf(motionSlide) + 1, type: transitionType, advanceAfterSeconds: Number(transitionSeconds) || undefined }
            : { artifactId, action: "read" }
        )
      );
      return;
    }
    motionRun.run(() =>
      slidesApi.animations(
        action === "add"
          ? {
              artifactId,
              action: "add",
              slide: indexOf(motionSlide) + 1,
              shape: Number(effectShape) || 0,
              effect: effectType,
              trigger: effectTrigger,
              durationMs: Number(effectDuration) || 500
            }
          : { artifactId, action: "read" }
      )
    );
  };

  const runExport = () =>
    exporter.run(() =>
      slidesApi.export({ artifactId, format: exportFormat, slide: exportFormat === "svg" ? Number(exportSlide) || 1 : undefined })
    );

  const runProtect = () => protectRun.run(() => slidesApi.protect({ artifactId, action: protectAction, password: password || undefined }));

  return (
    <div>
      <PageHeader
        eyebrow="Slides engine"
        title="Deck workbench"
        description="Author a deck from a slide list, read every part the file carries — shapes, tables, charts, notes, comments, transitions, animations, sections — then search, rearrange, restyle, export and protect it."
        actions={<span className="pill border border-line bg-surface px-2.5 py-1 text-[11px] text-muted">pptx · pptm · potx · odp</span>}
      />

      <div className="mb-4">
        <Tabs tabs={TABS} value={tab} onChange={setTab} />
      </div>

      <div className="split-wrap">
        <div className="min-w-0 space-y-4">
          {tab === "deck" ? (
            <ConfigCard
              title="Deck"
              description="Inspect what the file actually contains before exporting; the part list is the package's own inventory."
              footer={
                <button type="button" className="btn btn-secondary btn-sm" onClick={runInspect} disabled={!artifactId || inspector.pending}>
                  Inspect deck
                </button>
              }
            >
              <DocumentSelect label="Presentation" include="slides" value={artifactId} onChange={setArtifactId} />
              {info ? (
                <div className="grid grid-cols-2 gap-2">
                  <Fact label="Slides" value={info.slides ?? "—"} />
                  <Fact label="Parts" value={info.parts ?? "—"} />
                  <Fact
                    label="Slide size"
                    value={
                      info.widthPt && info.heightPt
                        ? `${info.widthPt} × ${info.heightPt} pt${info.aspect ? ` · ${info.aspect === 1.78 ? "16:9" : info.aspect === 1.33 ? "4:3" : info.aspect + ":1"}` : ""}`
                        : "—"
                    }
                  />
                  <Fact label="Macros" value={info.hasMacros ? "present" : "none"} />
                </div>
              ) : null}
            </ConfigCard>
          ) : null}

          {tab === "author" ? (
            <ConfigCard
              title="Author a deck"
              description="A slide list in JSON. Each entry may carry a title, subtitle, bullets, speaker notes, a table (headers and rows) or a chart (kind, categories, series)."
              footer={
                <RunBar label="Write PPTX" pending={author.pending} disabled={!specBody.trim()} hint="Saved into the workspace library" onRun={runAuthor} />
              }
            >
              <InlineFields>
                <Field label="Title">
                  <TextInput value={specTitle} onChange={(event) => setSpecTitle(event.target.value)} />
                </Field>
                <Field label="Slide size">
                  <Segmented
                    value={specSize}
                    onChange={setSpecSize}
                    options={[
                      { value: "16:9", label: "16:9" },
                      { value: "4:3", label: "4:3" }
                    ]}
                  />
                </Field>
              </InlineFields>
              <Field label="Slides" hint="JSON array; chartKind is Column, Bar, Line, Pie, Doughnut or AreaStacked">
                <TextArea value={specBody} rows={18} onChange={(event) => setSpecBody(event.target.value)} className="font-mono text-[11.5px]" />
              </Field>
            </ConfigCard>
          ) : null}

          {tab === "structure" ? (
            <ConfigCard
              title="Read the structure"
              description="Every slide with its layout, shapes and their geometry, table cells, chart series, notes, comments, transitions, animations, sections and custom shows."
              footer={<RunBar label="Read deck" pending={reader.pending} disabled={!artifactId} hint="Read-only: nothing is written" onRun={() => reader.run(() => slidesApi.read({ artifactId }))} />}
            >
              <DocumentSelect label="Presentation" include="slides" value={artifactId} onChange={setArtifactId} />
            </ConfigCard>
          ) : null}

          {tab === "text" ? (
            <ConfigCard
              title="Find and replace"
              description="Search runs across text boxes, tables and groups. Replacing writes a new PPTX so the source stays intact."
              footer={<RunBar label={textMode === "find" ? "Find text" : "Replace and save"} pending={textRun.pending} disabled={!artifactId || !find} hint={textMode === "find" ? "Reports every match with its slide" : "The source deck is never modified"} onRun={runText} />}
            >
              <DocumentSelect label="Presentation" include="slides" value={artifactId} onChange={setArtifactId} />
              <Segmented
                value={textMode}
                onChange={setTextMode}
                options={[
                  { value: "find", label: "Find" },
                  { value: "replace", label: "Replace" }
                ]}
              />
              <InlineFields>
                <Field label="Find">
                  <TextInput value={find} onChange={(event) => setFind(event.target.value)} />
                </Field>
                {textMode === "replace" ? (
                  <Field label="Replacement">
                    <TextInput value={replacement} onChange={(event) => setReplacement(event.target.value)} />
                  </Field>
                ) : null}
              </InlineFields>
              <label className="flex items-center gap-2 text-[12px] text-ink-soft">
                <input type="checkbox" checked={matchCase} onChange={(event) => setMatchCase(event.target.checked)} />
                Match case
              </label>
            </ConfigCard>
          ) : null}

          {tab === "notes" ? (
            <ConfigCard
              title="Speaker notes and review comments"
              description="Notes live in their own part and are created on demand. Comments are the legacy per-slide thread with author, initials and timestamp."
              footer={
                <div className="flex flex-wrap gap-2">
                  {sideMode === "notes" ? (
                    <>
                      <button type="button" className="btn btn-secondary btn-sm" onClick={() => runNotes("read")} disabled={!artifactId || notesRun.pending}>
                        Read notes
                      </button>
                      <button type="button" className="btn btn-primary btn-sm" onClick={() => runNotes("write")} disabled={!artifactId || notesRun.pending}>
                        Write notes
                      </button>
                    </>
                  ) : (
                    <>
                      <button type="button" className="btn btn-secondary btn-sm" onClick={() => runComments("read")} disabled={!artifactId || commentsRun.pending}>
                        Read comments
                      </button>
                      <button type="button" className="btn btn-primary btn-sm" onClick={() => runComments("add")} disabled={!artifactId || !commentText.trim() || commentsRun.pending}>
                        Add comment
                      </button>
                    </>
                  )}
                </div>
              }
            >
              <DocumentSelect label="Presentation" include="slides" value={artifactId} onChange={setArtifactId} />
              <Segmented
                value={sideMode}
                onChange={setSideMode}
                options={[
                  { value: "notes", label: "Notes" },
                  { value: "comments", label: "Comments" }
                ]}
              />
              <Field label="Slide number" hint="1-based">
                <TextInput value={notesSlide} onChange={(event) => setNotesSlide(event.target.value)} inputMode="numeric" />
              </Field>
              {sideMode === "notes" ? (
                <Field label="Note text">
                  <TextArea value={notesText} rows={4} onChange={(event) => setNotesText(event.target.value)} />
                </Field>
              ) : (
                <>
                  <Field label="Author">
                    <TextInput value={commentAuthor} onChange={(event) => setCommentAuthor(event.target.value)} />
                  </Field>
                  <Field label="Comment">
                    <TextArea value={commentText} rows={3} onChange={(event) => setCommentText(event.target.value)} />
                  </Field>
                </>
              )}
            </ConfigCard>
          ) : null}

          {tab === "arrange" ? (
            <>
              <ConfigCard
                title="Slide list surgery"
                description="Add a slide on any layout, clone one, move it, delete it, hide it from the show, or append a slide from another deck in the library."
                footer={
                  <div className="flex flex-wrap gap-2">
                    <button type="button" className="btn btn-secondary btn-sm" onClick={() => runArrange("read")} disabled={!artifactId || arrangeRun.pending}>
                      Read list
                    </button>
                    <button type="button" className="btn btn-primary btn-sm" onClick={() => runArrange(arrangeAction)} disabled={!artifactId || arrangeAction === "read" || arrangeRun.pending}>
                      {arrangeAction === "append" ? "Append slide" : `Apply ${arrangeAction}`}
                    </button>
                  </div>
                }
              >
                <DocumentSelect label="Presentation" include="slides" value={artifactId} onChange={setArtifactId} />
                <Field label="Operation">
                  <Segmented
                    value={arrangeAction}
                    onChange={setArrangeAction}
                    options={[
                      { value: "add", label: "Add" },
                      { value: "clone", label: "Clone" },
                      { value: "move", label: "Move" },
                      { value: "delete", label: "Delete" },
                      { value: "hide", label: "Hide" },
                      { value: "show", label: "Show" },
                      { value: "append", label: "Append" }
                    ]}
                  />
                </Field>
                <InlineFields>
                  <Field label="Slide number" hint="1-based">
                    <TextInput value={arrangeIndex} onChange={(event) => setArrangeIndex(event.target.value)} inputMode="numeric" />
                  </Field>
                  {arrangeAction === "move" ? (
                    <Field label="Move to">
                      <TextInput value={arrangeTo} onChange={(event) => setArrangeTo(event.target.value)} inputMode="numeric" />
                    </Field>
                  ) : null}
                  {arrangeAction === "add" ? (
                    <Field label="Layout">
                      <Select
                        value={arrangeLayout}
                        onChange={(event) => setArrangeLayout(event.target.value)}
                        options={[
                          { value: "Blank", label: "Blank" },
                          { value: "Title", label: "Title" },
                          { value: "TitleAndContent", label: "Title and content" },
                          { value: "SectionHeader", label: "Section header" },
                          { value: "TwoContent", label: "Two content" }
                        ]}
                      />
                    </Field>
                  ) : null}
                </InlineFields>
                {arrangeAction === "append" ? (
                  <>
                    <DocumentSelect label="Source deck" include="slides" value={appendId} onChange={setAppendId} />
                    <Field label="Source slide number">
                      <TextInput value={appendIndex} onChange={(event) => setAppendIndex(event.target.value)} inputMode="numeric" />
                    </Field>
                  </>
                ) : null}
              </ConfigCard>

              <ConfigCard
                title="Sections and custom shows"
                description="Both are written into presentation.xml: sections power the section list in PowerPoint, custom shows name a subset of slides."
                footer={
                  <div className="flex flex-wrap gap-2">
                    <button type="button" className="btn btn-secondary btn-sm" onClick={() => runSections("read")} disabled={!artifactId || sectionsRun.pending}>
                      Read sections
                    </button>
                    <button type="button" className="btn btn-primary btn-sm" onClick={() => runSections("add-section")} disabled={!artifactId || !sectionName.trim() || sectionsRun.pending}>
                      Add section
                    </button>
                    <button type="button" className="btn btn-secondary btn-sm" onClick={() => runSections("add-show")} disabled={!artifactId || !sectionName.trim() || sectionsRun.pending}>
                      Add custom show
                    </button>
                  </div>
                }
              >
                <InlineFields>
                  <Field label="Name">
                    <TextInput value={sectionName} onChange={(event) => setSectionName(event.target.value)} />
                  </Field>
                  <Field label="Slides" hint="Comma-separated 1-based numbers">
                    <TextInput value={sectionSlides} onChange={(event) => setSectionSlides(event.target.value)} />
                  </Field>
                </InlineFields>
              </ConfigCard>
            </>
          ) : null}

          {tab === "motion" ? (
            <ConfigCard
              title="Transitions and animations"
              description="A slide transition with its advance timing, or an entrance effect on one shape. Animations are written to the timing tree PowerPoint reads."
              footer={
                <div className="flex flex-wrap gap-2">
                  <button type="button" className="btn btn-secondary btn-sm" onClick={() => runMotion("read")} disabled={!artifactId || motionRun.pending}>
                    Read {motionMode === "transition" ? "transitions" : "animations"}
                  </button>
                  <button type="button" className="btn btn-primary btn-sm" onClick={() => runMotion(motionMode === "transition" ? "set" : "add")} disabled={!artifactId || motionRun.pending}>
                    {motionMode === "transition" ? "Set transition" : "Add effect"}
                  </button>
                </div>
              }
            >
              <DocumentSelect label="Presentation" include="slides" value={artifactId} onChange={setArtifactId} />
              <Segmented
                value={motionMode}
                onChange={setMotionMode}
                options={[
                  { value: "transition", label: "Transition" },
                  { value: "animation", label: "Animation" }
                ]}
              />
              <InlineFields>
                <Field label="Slide number">
                  <TextInput value={motionSlide} onChange={(event) => setMotionSlide(event.target.value)} inputMode="numeric" />
                </Field>
                {motionMode === "transition" ? (
                  <>
                    <Field label="Transition">
                      <Select value={transitionType} onChange={(event) => setTransitionType(event.target.value)} options={TRANSITIONS.map((name) => ({ value: name, label: name }))} />
                    </Field>
                    <Field label="Advance after (s)" hint="Empty keeps it on click">
                      <TextInput value={transitionSeconds} onChange={(event) => setTransitionSeconds(event.target.value)} inputMode="decimal" />
                    </Field>
                  </>
                ) : (
                  <>
                    <Field label="Shape index" hint="0-based">
                      <TextInput value={effectShape} onChange={(event) => setEffectShape(event.target.value)} inputMode="numeric" />
                    </Field>
                    <Field label="Effect">
                      <Select value={effectType} onChange={(event) => setEffectType(event.target.value)} options={EFFECTS.map((name) => ({ value: name, label: name }))} />
                    </Field>
                    <Field label="Trigger">
                      <Select value={effectTrigger} onChange={(event) => setEffectTrigger(event.target.value)} options={TRIGGERS.map((name) => ({ value: name, label: name }))} />
                    </Field>
                    <Field label="Duration (ms)">
                      <TextInput value={effectDuration} onChange={(event) => setEffectDuration(event.target.value)} inputMode="numeric" />
                    </Field>
                  </>
                )}
              </InlineFields>
            </ConfigCard>
          ) : null}

          {tab === "theme" ? (
            <ConfigCard title="Theme, masters and layouts"
              description="The resolved colour scheme, every slide master with its layouts, the placeholders each layout declares, and the package's slide size."
              footer={<RunBar label="Read theme" pending={themeRun.pending} disabled={!artifactId} hint="Read-only: nothing is written" onRun={() => themeRun.run(() => slidesApi.theme({ artifactId }))} />}
            >
              <DocumentSelect label="Presentation" include="slides" value={artifactId} onChange={setArtifactId} />
            </ConfigCard>
          ) : null}

          {tab === "export" ? (
            <ConfigCard
              title="Exporters"
              description="A self-contained player, static HTML, one slide as SVG, PDF, the deck's media, or a normalised PPTX written back by the engine."
              footer={<RunBar label="Export" pending={exporter.pending} disabled={!artifactId} hint="The source deck is never modified" onRun={runExport} />}
            >
              <DocumentSelect label="Presentation" include="slides" value={artifactId} onChange={setArtifactId} />
              <Field label="Format">
                <Segmented
                  value={exportFormat}
                  onChange={setExportFormat}
                  options={[
                    { value: "player", label: "Player" },
                    { value: "html", label: "HTML" },
                    { value: "svg", label: "SVG" },
                    { value: "pdf", label: "PDF" },
                    { value: "media", label: "Media" },
                    { value: "pptx", label: "PPTX" }
                  ]}
                />
              </Field>
              {exportFormat === "svg" ? (
                <InlineFields>
                  <Field label="Slide number" hint="1-based">
                    <TextInput value={exportSlide} onChange={(event) => setExportSlide(event.target.value)} inputMode="numeric" />
                  </Field>
                </InlineFields>
              ) : null}
            </ConfigCard>
          ) : null}

          {tab === "protect" ? (
            <ConfigCard
              title="Protection and encryption"
              description="Write protection (the password PowerPoint asks before editing), the signature references the package stores, and Agile encryption of the whole container."
              footer={<RunBar label={protectAction === "read" ? "Read protection" : `Apply ${protectAction}`} pending={protectRun.pending} disabled={!artifactId || protectAction !== "read" && !password} hint="Passwords are never stored in a report" onRun={runProtect} />}
            >
              <DocumentSelect label="Presentation" include="slides" value={artifactId} onChange={setArtifactId} />
              <Field label="Action">
                <Segmented
                  value={protectAction}
                  onChange={setProtectAction}
                  options={[
                    { value: "read", label: "Read" },
                    { value: "apply", label: "Protect" },
                    { value: "remove", label: "Unprotect" },
                    { value: "check", label: "Check" },
                    { value: "encrypt", label: "Encrypt" },
                    { value: "decrypt", label: "Decrypt" }
                  ]}
                />
              </Field>
              {protectAction !== "read" ? (
                <Field label="Password" hint={protectAction === "decrypt" ? "The password the deck was encrypted with" : "Required for protect, encrypt and decrypt"}>
                  <TextInput type="password" value={password} onChange={(event) => setPassword(event.target.value)} />
                </Field>
              ) : null}
              <SectionDivider label="Encrypted decks" />
              <p className="text-[11.5px] leading-[1.5] text-muted">
                Encryption wraps the package in the Agile compound file PowerPoint expects; decrypt takes an encrypted artifact and writes the
                readable PPTX back into the library.
              </p>
            </ConfigCard>
          ) : null}
        </div>

        <div className="min-w-0">
          {tab === "deck" ? (
            <ResultPanel
              result={converter.result ?? inspector.result}
              error={converter.error ?? inspector.error}
              pending={converter.pending || inspector.pending}
              emptyTitle="Nothing read yet"
              emptyDescription="Inspect the deck for its part inventory, or export it: PDF and HTML cover the whole deck, SVG renders a single slide."
              emptyIcon={Presentation}
              onReset={() => {
                converter.reset();
                inspector.reset();
              }}
            />
          ) : null}
          {tab === "author" ? (
            <ResultPanel result={author.result} error={author.error} pending={author.pending} emptyTitle="Nothing authored yet" emptyDescription="The slide list is written by the engine's own writer into a PPTX you can export or read back." emptyIcon={Wand2} onReset={author.reset} />
          ) : null}
          {tab === "structure" ? (
            <ResultPanel
              result={reader.result}
              error={reader.error}
              pending={reader.pending}
              emptyTitle="Nothing read yet"
              emptyDescription="Every shape, table cell, chart series, note and comment the file carries, with its geometry in points."
              emptyIcon={ListTree}
              renderReport={(report) =>
                report && Array.isArray((report as Report).content) ? (
                  <DeckStructure report={report as Report} />
                ) : (
                  <GenericReport report={report} />
                )
              }
              onReset={reader.reset}
            />
          ) : null}
          {tab === "text" ? (
            <ResultPanel result={textRun.result} error={textRun.error} pending={textRun.pending} emptyTitle="Nothing searched yet" emptyDescription="Find reports each match with its slide and shape; replace writes a new deck." emptyIcon={Search} onReset={textRun.reset} />
          ) : null}
          {tab === "notes" ? (
            <ResultPanel
              result={notesRun.result ?? commentsRun.result}
              error={notesRun.error ?? commentsRun.error}
              pending={notesRun.pending || commentsRun.pending}
              emptyTitle="Nothing read yet"
              emptyDescription="Notes are per slide and created on demand; comments carry their author, initials and timestamp."
              emptyIcon={MessageSquare}
              onReset={() => {
                notesRun.reset();
                commentsRun.reset();
              }}
            />
          ) : null}
          {tab === "arrange" ? (
            <ResultPanel
              result={arrangeRun.result ?? sectionsRun.result}
              error={arrangeRun.error ?? sectionsRun.error}
              pending={arrangeRun.pending || sectionsRun.pending}
              emptyTitle="Nothing arranged yet"
              emptyDescription="Adding, cloning, moving or deleting a slide writes a new deck; sections and custom shows are read from presentation.xml."
              emptyIcon={Layers3}
              onReset={() => {
                arrangeRun.reset();
                sectionsRun.reset();
              }}
            />
          ) : null}
          {tab === "motion" ? (
            <ResultPanel result={motionRun.result} error={motionRun.error} pending={motionRun.pending} emptyTitle="Nothing set yet" emptyDescription="Transitions and entrance effects are written to the slide's own timing tree." emptyIcon={Sparkles} onReset={motionRun.reset} />
          ) : null}
          {tab === "theme" ? (
            <ResultPanel result={themeRun.result} error={themeRun.error} pending={themeRun.pending} emptyTitle="Nothing read yet" emptyDescription="The resolved scheme colours, masters, layouts and placeholders." emptyIcon={Shapes} onReset={themeRun.reset} />
          ) : null}
          {tab === "export" ? (
            <ResultPanel result={exporter.result} error={exporter.error} pending={exporter.pending} emptyTitle="Nothing exported yet" emptyDescription="Player HTML, static HTML, SVG, PDF, media or a normalised PPTX." emptyIcon={FileDown} onReset={exporter.reset} />
          ) : null}
          {tab === "protect" ? (
            <ResultPanel result={protectRun.result} error={protectRun.error} pending={protectRun.pending} emptyTitle="Nothing read yet" emptyDescription="Write protection, signature references and Agile encryption; passwords never appear in a report." emptyIcon={KeyRound} onReset={protectRun.reset} />
          ) : null}
        </div>
      </div>
    </div>
  );
}
