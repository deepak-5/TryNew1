"use client";

import { useEffect, useState } from "react";
import clsx from "clsx";
import { Eraser, Plus, Replace, ShieldOff, Trash2, Wand2 } from "lucide-react";
import { tools } from "@/lib/api";
import { useWorkspace } from "@/components/workspace-provider";
import { useToolRun } from "@/lib/use-tool-run";
import { ResultPanel } from "@/components/result-panel";
import { ConfigCard, DocumentSelect, InlineFields, RunBar, useDocumentSelection } from "@/components/tool-form";
import { Button, Callout, Checkbox, NumberInput, PageHeader, Pill, Segmented, Select, Tabs, TextArea, TextInput } from "@/components/ui";
import { GenericReport } from "@/components/report-view";

const TABS = [
  { id: "replace", label: "Find & replace", icon: Replace },
  { id: "redact", label: "Redact text", icon: Eraser },
  { id: "regions", label: "Redact regions", icon: ShieldOff },
  { id: "maintain", label: "Repair & optimise", icon: Wand2 }
];

export default function EditPage() {
  const { currentId } = useWorkspace();
  const [tab, setTab] = useState("replace");
  return (
    <div>
      <PageHeader
        eyebrow="Transform"
        title="Edit & repair"
        description="Change what the pages say, then prove it with a render. Redaction removes glyphs and pixels; it does not cover them."
      />
      <Tabs tabs={TABS} value={tab} onChange={setTab} className="mb-5" />
      {tab === "replace" ? <ReplaceTab defaultId={currentId ?? ""} /> : null}
      {tab === "redact" ? <RedactTab defaultId={currentId ?? ""} /> : null}
      {tab === "regions" ? <RegionsTab defaultId={currentId ?? ""} /> : null}
      {tab === "maintain" ? <MaintainTab defaultId={currentId ?? ""} /> : null}
    </div>
  );
}

function useDocument(_defaultId: string) {
  return useDocumentSelection();
}

function ReplaceTab({ defaultId }: { defaultId: string }) {
  const [artifactId, setArtifactId] = useDocument(defaultId);
  const [find, setFind] = useState("");
  const [replacement, setReplacement] = useState("");
  const [regex, setRegex] = useState(false);
  const [ignoreCase, setIgnoreCase] = useState(true);
  const [pages, setPages] = useState("");
  const [color, setColor] = useState("#111827");
  const { result, error, pending, run, reset } = useToolRun<Record<string, unknown>>();

  return (
    <div className="split-wrap">
      <ConfigCard
        description="Matched glyph runs are re-encoded in place with the document's own font when the glyphs exist."
        footer={
          <RunBar
            label="Replace text"
            pending={pending}
            disabled={!artifactId || !find}
            onRun={() => run(() => tools.replace({ artifactId, find, replace: replacement, regex, ignoreCase, pages: pages || undefined, color }))}
          />
        }
      >
        <DocumentSelect value={artifactId} onChange={setArtifactId} label="Document" />
        <div>
          <span className="label">Find</span>
          <TextArea rows={2} value={find} onChange={(event) => setFind(event.target.value)} placeholder="Exact text or pattern" />
        </div>
        <div>
          <span className="label">Replace with</span>
          <TextArea rows={2} value={replacement} onChange={(event) => setReplacement(event.target.value)} placeholder="Leave empty to delete the match" />
        </div>
        <InlineFields>
          <div>
            <span className="label">Pages</span>
            <TextInput value={pages} onChange={(event) => setPages(event.target.value)} placeholder="all pages" />
          </div>
          <div>
            <span className="label">Replacement colour</span>
            <div className="flex items-center gap-1.5">
              <input
                type="color"
                value={color}
                onChange={(event) => setColor(event.target.value)}
                className="size-9 shrink-0 cursor-pointer rounded-md border border-line-strong bg-surface p-0.5"
              />
              <TextInput value={color} onChange={(event) => setColor(event.target.value)} className="font-mono text-[12px]" />
            </div>
          </div>
        </InlineFields>
        <div className="grid grid-cols-2 gap-2">
          <Checkbox label="Regular expression" checked={regex} onChange={setRegex} />
          <Checkbox label="Ignore case" checked={ignoreCase} onChange={setIgnoreCase} />
        </div>
        <Callout tone="info" title="In-place, not reflowed">
          Replacement keeps the run's position and size. Longer text may overflow the space the original occupied — the render is the proof.
        </Callout>
      </ConfigCard>

      <ResultPanel
        result={result}
        error={error}
        pending={pending}
        onReset={reset}
        emptyIcon={Replace}
        emptyTitle="No replacement yet"
        emptyDescription="Enter a phrase that exists in the document. The engine reports how many runs changed and which pages were touched."
        renderReport={(report) => <EditReport report={report} />}
      />
    </div>
  );
}

function RedactTab({ defaultId }: { defaultId: string }) {
  const [artifactId, setArtifactId] = useDocument(defaultId);
  const [find, setFind] = useState("");
  const [regex, setRegex] = useState(false);
  const [ignoreCase, setIgnoreCase] = useState(true);
  const [pages, setPages] = useState("");
  const [color, setColor] = useState("#000000");
  const [overlayText, setOverlayText] = useState("");
  const { result, error, pending, run, reset } = useToolRun<Record<string, unknown>>();

  return (
    <div className="split-wrap">
      <ConfigCard
        description="Matched text is removed from the content stream and a filled rectangle is painted where it was."
        footer={
          <RunBar
            label="Redact matches"
            pending={pending}
            disabled={!artifactId || !find}
            onRun={() => run(() => tools.redact({ artifactId, find, regex, ignoreCase, pages: pages || undefined, color, overlayText }))}
          />
        }
      >
        <DocumentSelect value={artifactId} onChange={setArtifactId} label="Document" />
        <div>
          <span className="label">Text to remove</span>
          <TextArea rows={2} value={find} onChange={(event) => setFind(event.target.value)} placeholder="e.g. an account number or a name" />
        </div>
        <InlineFields>
          <div>
            <span className="label">Pages</span>
            <TextInput value={pages} onChange={(event) => setPages(event.target.value)} placeholder="all pages" />
          </div>
          <div>
            <span className="label">Box colour</span>
            <div className="flex items-center gap-1.5">
              <input
                type="color"
                value={color}
                onChange={(event) => setColor(event.target.value)}
                className="size-9 shrink-0 cursor-pointer rounded-md border border-line-strong bg-surface p-0.5"
              />
              <TextInput value={color} onChange={(event) => setColor(event.target.value)} className="font-mono text-[12px]" />
            </div>
          </div>
        </InlineFields>
        <div>
          <span className="label">Overlay label (optional)</span>
          <TextInput value={overlayText} onChange={(event) => setOverlayText(event.target.value)} placeholder="REDACTED" />
        </div>
        <div className="grid grid-cols-2 gap-2">
          <Checkbox label="Regular expression" checked={regex} onChange={setRegex} />
          <Checkbox label="Ignore case" checked={ignoreCase} onChange={setIgnoreCase} />
        </div>
        <Callout tone="warn" title="Detection is separate from removal">
          Use PII candidates in Extract to find likely values, then either paste them here or redact every candidate's bounds in the next tab.
        </Callout>
      </ConfigCard>

      <ResultPanel
        result={result}
        error={error}
        pending={pending}
        onReset={reset}
        emptyIcon={Eraser}
        emptyTitle="Nothing redacted yet"
        emptyDescription="Redaction is destructive by design. The report lists the removed runs and the painted regions; the render shows the result."
        renderReport={(report) => <EditReport report={report} />}
      />
    </div>
  );
}

type Region = { page: string; x: string; y: string; width: string; height: string };

function RegionsTab({ defaultId }: { defaultId: string }) {
  const [artifactId, setArtifactId] = useDocument(defaultId);
  const [regions, setRegions] = useState<Region[]>([{ page: "", x: "80", y: "600", width: "220", height: "40" }]);
  const [pii, setPii] = useState(false);
  const [dpi, setDpi] = useState("144");
  const [color, setColor] = useState("#000000");
  const [dryRun, setDryRun] = useState(false);
  const [allowRenderWarnings, setAllowRenderWarnings] = useState(false);
  const { result, error, pending, run, reset } = useToolRun<Record<string, unknown>>();

  function update(index: number, key: keyof Region, value: string) {
    setRegions((items) => items.map((item, itemIndex) => (itemIndex === index ? { ...item, [key]: value } : item)));
  }

  return (
    <div className="split-wrap">
      <ConfigCard
        description="Rectangles are burned into rendered pixels: every selected page is flattened to an image page."
        footer={
          <RunBar
            label={pii ? "Redact every PII candidate" : dryRun ? "Preview the redaction" : "Redact regions"}
            pending={pending}
            disabled={!artifactId || (!pii && regions.length === 0)}
            onRun={() =>
              run(() =>
                tools.redactRegions({
                  artifactId,
                  pii,
                  pages: pii ? undefined : undefined,
                  dpi: Number(dpi),
                  color,
                  dryRun,
                  allowRenderWarnings,
                  regions: pii
                    ? undefined
                    : regions.map((region) => ({
                        page: region.page ? Number(region.page) : undefined,
                        x: Number(region.x),
                        y: Number(region.y),
                        width: Number(region.width),
                        height: Number(region.height)
                      }))
                })
              )
            }
          />
        }
      >
        <DocumentSelect value={artifactId} onChange={setArtifactId} label="Document" />

        <Checkbox
          label="Derive rectangles from PII candidates"
          hint="Runs the PII finder and redacts the bounds it reports. Explicit rectangles are ignored."
          checked={pii}
          onChange={setPii}
        />

        {!pii ? (
          <div className="space-y-2">
            <div className="grid grid-cols-[64px_1fr_1fr_1fr_1fr_24px] gap-1.5">
              {["Page", "X", "Y", "Width", "Height", ""].map((label) => (
                <span key={label} className="text-[10px] font-medium uppercase tracking-[0.05em] text-faint">
                  {label}
                </span>
              ))}
            </div>
            {regions.map((region, index) => (
              <div key={index} className="grid grid-cols-[64px_1fr_1fr_1fr_1fr_24px] items-center gap-1.5">
                <NumberInput value={region.page} onChange={(value) => update(index, "page", value)} placeholder="all" className="h-8 px-1.5 text-[12px]" />
                <NumberInput value={region.x} onChange={(value) => update(index, "x", value)} className="h-8 px-1.5 text-[12px]" />
                <NumberInput value={region.y} onChange={(value) => update(index, "y", value)} className="h-8 px-1.5 text-[12px]" />
                <NumberInput value={region.width} onChange={(value) => update(index, "width", value)} className="h-8 px-1.5 text-[12px]" />
                <NumberInput value={region.height} onChange={(value) => update(index, "height", value)} className="h-8 px-1.5 text-[12px]" />
                <button
                  type="button"
                  onClick={() => setRegions((items) => items.filter((_, itemIndex) => itemIndex !== index))}
                  className="rounded p-1 text-muted hover:bg-danger-soft hover:text-danger"
                  aria-label="Remove region"
                >
                  <Trash2 className="size-3" />
                </button>
              </div>
            ))}
            <Button size="sm" icon={Plus} onClick={() => setRegions((items) => [...items, { page: "", x: "80", y: "500", width: "200", height: "40" }])}>
              Add region
            </Button>
            <p className="text-[11px] text-faint">Coordinates are PDF points from the lower-left corner. Leave page empty to apply to every page.</p>
          </div>
        ) : null}

        <InlineFields>
          <div>
            <span className="label">Render dpi</span>
            <NumberInput value={dpi} onChange={setDpi} min={72} max={300} step={12} />
          </div>
          <div>
            <span className="label">Box colour</span>
            <div className="flex items-center gap-1.5">
              <input
                type="color"
                value={color}
                onChange={(event) => setColor(event.target.value)}
                className="size-9 shrink-0 cursor-pointer rounded-md border border-line-strong bg-surface p-0.5"
              />
              <TextInput value={color} onChange={(event) => setColor(event.target.value)} className="font-mono text-[12px]" />
            </div>
          </div>
        </InlineFields>

        <div className="grid grid-cols-2 gap-2">
          <Checkbox label="Dry run" hint="Report only, no file." checked={dryRun} onChange={setDryRun} />
          <Checkbox label="Allow render warnings" checked={allowRenderWarnings} onChange={setAllowRenderWarnings} />
        </div>

        <Callout tone="warn" title="Flattening is permanent">
          Redacted pages become raster images. Text, links and structure in those pages are gone — that is what makes the redaction reliable.
        </Callout>
      </ConfigCard>

      <ResultPanel
        result={result}
        error={error}
        pending={pending}
        onReset={reset}
        emptyIcon={ShieldOff}
        emptyTitle="No regions redacted yet"
        emptyDescription="Add a rectangle or derive them from PII candidates. The render shows the burned-in result on the produced document."
        renderReport={(report) => <RegionReport report={report} />}
      />
    </div>
  );
}

function RegionReport({ report }: { report: Record<string, unknown> }) {
  const inner = (report.report ?? report) as Record<string, unknown>;
  const entries = Object.entries(inner).filter(([, value]) => typeof value !== "object");
  return (
    <div className="space-y-3">
      {entries.length > 0 ? (
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
          {entries.slice(0, 6).map(([key, value]) => (
            <div key={key} className="rounded-lg border border-line bg-surface-muted/60 px-3 py-2">
              <div className="text-[10px] font-medium uppercase tracking-[0.06em] text-faint">{key}</div>
              <div className="mt-0.5 text-[12.5px] text-ink">{String(value)}</div>
            </div>
          ))}
        </div>
      ) : null}
      <GenericReport report={report} />
    </div>
  );
}

type MaintainMode = "sanitize" | "optimize" | "linearize" | "repair";

function MaintainTab({ defaultId }: { defaultId: string }) {
  const [artifactId, setArtifactId] = useDocument(defaultId);
  const [mode, setMode] = useState<MaintainMode>("sanitize");
  const [removeMetadata, setRemoveMetadata] = useState(true);
  const [dryRun, setDryRun] = useState(false);
  const [maxImageDpi, setMaxImageDpi] = useState("150");
  const [jpegQuality, setJpegQuality] = useState("82");
  const { result, error, pending, run, reset } = useToolRun<Record<string, unknown>>();

  const runMaintenance = () => {
    if (mode === "sanitize") return tools.sanitize({ artifactId, removeMetadata, dryRun });
    if (mode === "optimize") return tools.optimize({ artifactId, maxImageDpi: Number(maxImageDpi) || undefined, jpegQuality: Number(jpegQuality) || undefined });
    if (mode === "linearize") return tools.linearize({ artifactId });
    return tools.repair({ artifactId });
  };

  return (
    <div className="split-wrap">
      <ConfigCard
        description="Housekeeping the engine can prove: removed active content, smaller objects, a Fast Web View layout, or rebuilt cross-references."
        footer={<RunBar label={MODE_LABEL[mode]} pending={pending} disabled={!artifactId} onRun={() => run(runMaintenance)} />}
      >
        <DocumentSelect value={artifactId} onChange={setArtifactId} label="Document" />
        <Segmented
          value={mode}
          onChange={setMode}
          className="w-full"
          options={[
            { value: "sanitize", label: "Sanitize" },
            { value: "optimize", label: "Optimize" },
            { value: "linearize", label: "Linearize" },
            { value: "repair", label: "Repair" }
          ]}
        />

        {mode === "sanitize" ? (
          <>
            <Checkbox label="Remove document metadata" hint="Clears the Info dictionary and XMP after active content is stripped." checked={removeMetadata} onChange={setRemoveMetadata} />
            <Checkbox label="Dry run" hint="Report what would change without writing a file." checked={dryRun} onChange={setDryRun} />
            <p className="hint">Removes JavaScript, additional actions, XFA, embedded files, media and auto-launch entries.</p>
          </>
        ) : null}

        {mode === "optimize" ? (
          <>
            <InlineFields>
              <div>
                <span className="label">Downsample images above (dpi)</span>
                <NumberInput value={maxImageDpi} onChange={setMaxImageDpi} min={36} max={600} />
              </div>
              <div>
                <span className="label">JPEG quality</span>
                <NumberInput value={jpegQuality} onChange={setJpegQuality} min={10} max={100} />
              </div>
            </InlineFields>
            <p className="hint">Streams are compressed, duplicate objects merged, unreferenced objects pruned and images recompressed.</p>
          </>
        ) : null}

        {mode === "linearize" ? (
          <Callout tone="info" title="Fast Web View">
            Writes hint streams so the first page can be displayed before the whole file arrives. Encrypted inputs are refused.
          </Callout>
        ) : null}

        {mode === "repair" ? (
          <Callout tone="info" title="Object walk">
            Rebuilds cross-reference tables by walking every object in the file, then writes a clean document. Use it on truncated or mis-numbered files.
          </Callout>
        ) : null}
      </ConfigCard>

      <ResultPanel
        result={result}
        error={error}
        pending={pending}
        onReset={reset}
        emptyIcon={Wand2}
        emptyTitle="No maintenance run yet"
        emptyDescription="Each mode writes a new document and a report of exactly what changed — byte sizes before and after included."
        renderReport={(report) => <MaintenanceReport report={report} />}
      />
    </div>
  );
}

const MODE_LABEL: Record<MaintainMode, string> = {
  sanitize: "Sanitize document",
  optimize: "Optimize document",
  linearize: "Linearize document",
  repair: "Repair document"
};

function MaintenanceReport({ report }: { report: Record<string, unknown> }) {
  const entries = Object.entries(report).filter(([, value]) => typeof value !== "object" && value != null);
  const removed = Array.isArray(report.removed) ? (report.removed as string[]) : [];
  return (
    <div className="space-y-4">
      {entries.length > 0 ? (
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
          {entries.map(([key, value]) => (
            <div key={key} className="rounded-lg border border-line bg-surface-muted/60 px-3 py-2">
              <div className="text-[10px] font-medium uppercase tracking-[0.06em] text-faint">{key}</div>
              <div className="mt-0.5 break-words text-[12.5px] text-ink">{String(value)}</div>
            </div>
          ))}
        </div>
      ) : null}
      {removed.length > 0 ? (
        <div>
          <div className="mb-1.5 section-label">Removed</div>
          <div className="flex flex-wrap gap-1.5">
            {removed.map((item) => (
              <Pill key={item} tone="warn">
                {item}
              </Pill>
            ))}
          </div>
        </div>
      ) : null}
      <GenericReport report={report} skipKeys={Object.keys(report).filter((key) => typeof report[key] !== "object")} />
    </div>
  );
}

function EditReport({ report }: { report: Record<string, unknown> }) {
  const entries = Object.entries(report).filter(([, value]) => typeof value !== "object" && value != null);
  return (
    <div className="space-y-4">
      {entries.length > 0 ? (
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
          {entries.slice(0, 9).map(([key, value]) => (
            <div
              key={key}
              className={clsx(
                "rounded-lg border px-3 py-2",
                key.toLowerCase().includes("replace") || key.toLowerCase().includes("redact") ? "border-accent-line bg-accent-soft/50" : "border-line bg-surface-muted/60"
              )}
            >
              <div className="text-[10px] font-medium uppercase tracking-[0.06em] text-faint">{key}</div>
              <div className="mt-0.5 text-[13px] font-medium tabular-nums text-ink">{String(value)}</div>
            </div>
          ))}
        </div>
      ) : null}
      <GenericReport report={report} skipKeys={entries.map(([key]) => key)} />
    </div>
  );
}
