"use client";

import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import {
  ArrowLeftRight,
  ArrowRight,
  BookOpen,
  CheckCircle2,
  Copy,
  Download,
  FileJson,
  FileSearch,
  FileWarning,
  Layers,
  Lock,
  ScanText,
  ShieldCheck,
  Wand2
} from "lucide-react";
import { api, tools } from "@/lib/api";
import { formatBytes, formatDate, titleCase } from "@/lib/format";
import type { Artifact, InspectionReport, ValidationReport } from "@/lib/types";
import { useWorkspace } from "@/components/workspace-provider";
import { useToast } from "@/components/toast";
import { PdfPreview, PageThumb } from "@/components/pdf-preview";
import { InspectionView, ValidationView } from "@/components/inspect-report";
import { GenericReport, WarningsList } from "@/components/report-view";
import { useToolRun } from "@/lib/use-tool-run";
import {
  Button,
  Card,
  CardHeader,
  EmptyState,
  JsonBlock,
  PageHeader,
  Pill,
  Select,
  Tabs,
  TextInput
} from "@/components/ui";
import { ResultPanel } from "@/components/result-panel";

export default function DocumentPage() {
  const params = useParams<{ id: string }>();
  const id = params.id;
  const { artifacts, currentId, setCurrent, loading } = useWorkspace();
  const { notify } = useToast();
  const router = useRouter();

  const fromWorkspace = artifacts.find((artifact) => artifact.id === id) ?? null;
  const [fetched, setFetched] = useState<Artifact | null>(null);
  const [missing, setMissing] = useState(false);

  const artifact = fromWorkspace ?? fetched;

  useEffect(() => {
    if (fromWorkspace || loading) return;
    let cancelled = false;
    api
      .getArtifact(id)
      .then((value) => {
        if (!cancelled) setFetched(value);
      })
      .catch(() => {
        if (!cancelled) setMissing(true);
      });
    return () => {
      cancelled = true;
    };
  }, [id, fromWorkspace, loading]);

  const [tab, setTab] = useState("overview");
  const [page, setPage] = useState(1);

  const inspectRun = useToolRun<InspectionReport>();
  const validateRun = useToolRun<ValidationReport>();
  const [standard, setStandard] = useState("pdfa");
  const [pdfaLevel, setPdfaLevel] = useState("2b");
  const [pdfuaPart, setPdfuaPart] = useState("1");

  const children = useMemo(() => artifacts.filter((item) => item.parentId === id), [artifacts, id]);
  const parent = useMemo(() => (artifact?.parentId ? artifacts.find((item) => item.id === artifact.parentId) : null), [artifacts, artifact]);

  useEffect(() => {
    if (tab !== "inspect" || inspectRun.result || inspectRun.pending || !artifact) return;
    inspectRun.run(() => tools.inspect({ artifactId: artifact.id, details: true, checkPdfA: true })).catch(() => undefined);
  }, [tab, artifact, inspectRun]);

  if (missing) {
    return (
      <Card>
        <EmptyState
          icon={FileWarning}
          title="This document is no longer in the workspace"
          description="It may have been removed. Upload it again or pick another document from the library."
          action={
            <Link href="/library" className="btn btn-primary">
              Open the library
            </Link>
          }
        />
      </Card>
    );
  }

  if (!artifact) {
    return <div className="py-24 text-center text-[12.5px] text-muted">Loading document…</div>;
  }

  const isPdf = artifact.kind === "pdf";
  const pages = artifact.pageCount ?? 0;

  return (
    <div>
      <div className="mb-3 flex items-center gap-1.5 text-[11.5px] text-faint">
        <Link href="/library" className="hover:text-ink">
          Library
        </Link>
        <span>/</span>
        <span className="truncate text-muted">{artifact.fileName}</span>
      </div>

      <PageHeader
        title={<span className="break-all">{artifact.fileName}</span>}
        description={
          <span className="flex flex-wrap items-center gap-x-2 gap-y-1">
            <span>{isPdf ? `${pages || "?"} page${pages === 1 ? "" : "s"}` : titleCase(artifact.kind)}</span>
            <span className="text-line-strong">·</span>
            <span>{formatBytes(artifact.size)}</span>
            <span className="text-line-strong">·</span>
            <span className="capitalize">{artifact.origin}</span>
            <span className="text-line-strong">·</span>
            <span>{formatDate(artifact.createdAt)}</span>
            {artifact.encrypted ? <Pill tone="warn">Encrypted</Pill> : null}
            {artifact.warnings.length > 0 ? <Pill tone="warn">{artifact.warnings.length} warnings</Pill> : null}
          </span>
        }
        actions={
          <>
            {currentId !== artifact.id && isPdf ? (
              <Button
                onClick={() => {
                  setCurrent(artifact.id);
                  notify({ title: "Set as the current document", description: artifact.fileName });
                }}
              >
                Use as current
              </Button>
            ) : null}
            {isPdf ? (
              <Link href={`/compare?before=${parent?.id ?? artifact.id}&after=${artifact.id}`} className="btn btn-secondary">
                <ArrowLeftRight className="size-3.5" />
                Compare
              </Link>
            ) : null}
            <a href={`${artifact.contentUrl}?download=1`} download={artifact.fileName} className="btn btn-primary">
              <Download className="size-3.5" />
              Download
            </a>
          </>
        }
      />

      <div className="grid gap-5 xl:grid-cols-[minmax(0,1.15fr)_minmax(0,1fr)]">
        <div className="space-y-5">
          <Card className="overflow-hidden">
            <CardHeader
              title="Render"
              description="Rasterised by the engine from the page content — the same pixels an operator would see."
              actions={isPdf ? <Pill tone="neutral">engine render</Pill> : null}
            />
            {isPdf ? (
              <PdfPreview artifact={artifact} initialPage={page} onPageChange={setPage} maxHeight="62vh" />
            ) : artifact.kind === "image" ? (
              // eslint-disable-next-line @next/next/no-img-element
              <div className="bg-[#eef1ec] p-4">
                <img src={artifact.contentUrl} alt={artifact.fileName} className="mx-auto max-h-[70vh] rounded bg-white paper-shadow" />
              </div>
            ) : (
              <TextContent artifact={artifact} />
            )}
          </Card>

        </div>

        <div className="space-y-5">
        <Card className="overflow-hidden self-start">
          <Tabs
            className="px-2"
            value={tab}
            onChange={setTab}
            tabs={[
              { id: "overview", label: "Overview" },
              { id: "pages", label: "Pages", badge: isPdf && pages > 0 ? pages : undefined },
              { id: "inspect", label: "Inspect" },
              { id: "validate", label: "Validate" },
              ...(artifact.hasReport ? [{ id: "report", label: "Report", icon: FileJson }] : [])
            ]}
          />

          <div className="px-4 py-4">
            {tab === "overview" ? (
              <div className="space-y-5">
                <dl className="grid grid-cols-2 gap-x-4 gap-y-3">
                  {[
                    ["Pages", isPdf ? String(artifact.pageCount ?? "—") : "—"],
                    ["PDF version", artifact.pdfVersion ?? "—"],
                    ["Size", formatBytes(artifact.size)],
                    ["Encrypted", artifact.encrypted ? "yes" : "no"],
                    ["Origin", titleCase(artifact.origin)],
                    ["Added", formatDate(artifact.createdAt)]
                  ].map(([label, value]) => (
                    <div key={label}>
                      <dt className="text-[10.5px] font-medium uppercase tracking-[0.06em] text-faint">{label}</dt>
                      <dd className="mt-0.5 text-[12.5px] text-ink">{value}</dd>
                    </div>
                  ))}
                </dl>

                <div>
                  <div className="mb-1 flex items-center justify-between">
                    <span className="text-[10.5px] font-medium uppercase tracking-[0.06em] text-faint">SHA-256</span>
                    <button
                      type="button"
                      onClick={async () => {
                        await navigator.clipboard.writeText(artifact.sha256);
                        notify({ title: "Checksum copied" });
                      }}
                      className="inline-flex items-center gap-1 text-[11px] text-muted hover:text-ink"
                    >
                      <Copy className="size-3" />
                      copy
                    </button>
                  </div>
                  <p className="break-all rounded-md border border-line bg-surface-muted px-2 py-1.5 font-mono text-[10.5px] leading-[1.5] text-ink-soft">
                    {artifact.sha256}
                  </p>
                </div>

                <div className="space-y-2 rounded-lg border border-line bg-surface-muted/50 px-3 py-2.5 text-[12px]">
                  <div className="flex items-start justify-between gap-3">
                    <span className="text-muted">Operation</span>
                    <span className="text-right text-ink-soft">{artifact.operation ?? "Uploaded"}</span>
                  </div>
                  {parent ? (
                    <div className="flex items-start justify-between gap-3">
                      <span className="text-muted">Derived from</span>
                      <Link href={`/documents/${parent.id}`} className="max-w-[220px] truncate text-right text-accent-strong hover:underline">
                        {parent.fileName}
                      </Link>
                    </div>
                  ) : null}
                </div>

                {artifact.warnings.length > 0 ? <WarningsList warnings={artifact.warnings} title="Recorded while writing" /> : null}

                {children.length > 0 ? (
                  <div>
                    <div className="mb-2 section-label">Documents produced from this one</div>
                    <div className="space-y-1">
                      {children.slice(0, 8).map((child) => (
                        <Link
                          key={child.id}
                          href={`/documents/${child.id}`}
                          className="flex items-center gap-2 rounded-md border border-line px-2.5 py-1.5 text-[12px] text-ink-soft transition hover:border-accent-line hover:bg-accent-soft/30"
                        >
                          <FileSearch className="size-3.5 text-accent" />
                          <span className="min-w-0 flex-1 truncate">{child.fileName}</span>
                          <span className="shrink-0 text-[10.5px] text-faint">{formatDate(child.createdAt)}</span>
                        </Link>
                      ))}
                      {children.length > 8 ? <p className="px-1 text-[11px] text-faint">+{children.length - 8} more</p> : null}
                    </div>
                  </div>
                ) : null}
              </div>
            ) : null}

            {tab === "pages" ? (
              isPdf && pages > 0 ? (
                <div>
                  <p className="mb-3 text-[11.5px] text-muted">
                    Click a page to render it. Each thumbnail is a fresh engine raster at 60 dpi.
                  </p>
                  <div className="grid grid-cols-3 gap-2.5 sm:grid-cols-4">
                    {Array.from({ length: Math.min(pages, 48) }, (_, index) => index + 1).map((number) => (
                      <PageThumb key={number} artifact={artifact} page={number} active={number === page} onClick={() => setPage(number)} />
                    ))}
                  </div>
                  {pages > 48 ? <p className="mt-3 text-[11.5px] text-faint">Showing the first 48 of {pages} pages.</p> : null}
                </div>
              ) : (
                <EmptyState icon={Layers} title="No pages to show" description="This artifact is not a paginated PDF." compact />
              )
            ) : null}

            {tab === "inspect" ? (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <p className="text-[12px] text-muted">Structure read directly from the file, without repairing it.</p>
                  <Button
                    size="sm"
                    icon={FileSearch}
                    loading={inspectRun.pending}
                    onClick={() => inspectRun.run(() => tools.inspect({ artifactId: artifact.id, details: true, checkPdfA: true }))}
                  >
                    Re-run
                  </Button>
                </div>
                {inspectRun.pending && !inspectRun.result ? (
                  <p className="py-10 text-center text-[12px] text-muted">Reading the object graph…</p>
                ) : inspectRun.result ? (
                  <InspectionView report={inspectRun.result.report} />
                ) : null}
              </div>
            ) : null}

            {tab === "validate" ? (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-2">
                  <Select
                    value={standard}
                    onChange={(event) => setStandard(event.target.value)}
                    options={[
                      { value: "pdfa", label: "PDF/A" },
                      { value: "pdfx", label: "PDF/X" },
                      { value: "pdfua", label: "PDF/UA" },
                      { value: "structural", label: "Structural checks" }
                    ]}
                  />
                  {standard === "pdfa" ? (
                    <Select
                      value={pdfaLevel}
                      onChange={(event) => setPdfaLevel(event.target.value)}
                      options={[
                        { value: "1b", label: "PDF/A-1b" },
                        { value: "2b", label: "PDF/A-2b" },
                        { value: "3b", label: "PDF/A-3b" }
                      ]}
                    />
                  ) : standard === "pdfua" ? (
                    <Select
                      value={pdfuaPart}
                      onChange={(event) => setPdfuaPart(event.target.value)}
                      options={[
                        { value: "1", label: "PDF/UA-1" },
                        { value: "2", label: "PDF/UA-2" }
                      ]}
                    />
                  ) : (
                    <div />
                  )}
                </div>
                <Button
                  variant="primary"
                  className="w-full"
                  icon={ShieldCheck}
                  loading={validateRun.pending}
                  onClick={() =>
                    validateRun.run(() =>
                      tools.validate({
                        artifactId: artifact.id,
                        standard,
                        level: standard === "pdfua" ? undefined : pdfaLevel,
                        part: standard === "pdfua" ? pdfuaPart : undefined
                      })
                    )
                  }
                >
                  Run the {standard.toUpperCase()} walk
                </Button>
                {validateRun.result ? <ValidationView report={validateRun.result.report} /> : null}
                {validateRun.error ? <p className="text-[12px] text-danger">{validateRun.error}</p> : null}
              </div>
            ) : null}

            {tab === "report" ? <StoredReport id={artifact.id} /> : null}
          </div>
        </Card>

        {isPdf ? (
          <Card className="overflow-hidden">
            <CardHeader title="Open in a workbench" description="These tools act on the document selected in the header." />
            <div className="grid grid-cols-2 gap-1.5 p-3 sm:grid-cols-3">
              {[
                { href: "/inspect", label: "Inspect & validate", icon: FileSearch },
                { href: "/extract", label: "Extract content", icon: ScanText },
                { href: "/convert", label: "Convert", icon: Layers },
                { href: "/pages", label: "Pages & layout", icon: Layers },
                { href: "/structure", label: "Structure", icon: BookOpen },
                { href: "/secure", label: "Security", icon: Lock }
              ].map((action) => {
                const Icon = action.icon;
                return (
                  <button
                    key={action.href}
                    type="button"
                    onClick={() => {
                      setCurrent(artifact.id);
                      router.push(action.href);
                    }}
                    className="flex items-center gap-2 rounded-lg border border-line bg-surface px-2.5 py-2 text-left text-[12px] font-medium text-ink-soft transition hover:border-accent-line hover:bg-accent-soft/40"
                  >
                    <Icon className="size-3.5 text-accent" />
                    {action.label}
                  </button>
                );
              })}
            </div>
          </Card>
        ) : null}
        </div>
      </div>
    </div>
  );
}

function StoredReport({ id }: { id: string }) {
  const [report, setReport] = useState<Record<string, unknown> | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api
      .report(id)
      .then(setReport)
      .catch((cause) => setError(cause instanceof Error ? cause.message : "Could not read the report"));
  }, [id]);

  if (error) return <p className="text-[12px] text-danger">{error}</p>;
  if (!report) return <p className="py-8 text-center text-[12px] text-muted">Reading the stored report…</p>;
  return (
    <div className="space-y-4">
      <GenericReport report={report} />
      <JsonBlock value={report} label="Stored report JSON" />
    </div>
  );
}

function TextContent({ artifact }: { artifact: Artifact }) {
  const [text, setText] = useState<string | null>(null);
  useEffect(() => {
    let cancelled = false;
    api
      .textContent(artifact)
      .then((value) => {
        if (!cancelled) setText(value.slice(0, 120_000));
      })
      .catch(() => {
        if (!cancelled) setText(null);
      });
    return () => {
      cancelled = true;
    };
  }, [artifact]);

  return (
    <div className="px-4 py-3">
      {text == null ? (
        <p className="py-8 text-center text-[12px] text-muted">Reading content…</p>
      ) : (
        <pre className="scroll-thin max-h-[62vh] overflow-auto font-mono text-[11.5px] leading-[1.65] text-ink-soft">{text}</pre>
      )}
    </div>
  );
}
