"use client";

import { useState } from "react";
import { Barcode, Code2, FilePlus2, Sparkles } from "lucide-react";
import { tools } from "@/lib/api";
import { useToolRun } from "@/lib/use-tool-run";
import { ResultPanel } from "@/components/result-panel";
import { ConfigCard, InlineFields, RunBar, SectionDivider } from "@/components/tool-form";
import { GenericReport } from "@/components/report-view";
import { useWorkspace } from "@/components/workspace-provider";
import { Callout, Checkbox, NumberInput, PageHeader, Select, Tabs, TextArea, TextInput } from "@/components/ui";

const TABS = [
  { id: "html", label: "HTML to PDF", icon: Code2 },
  { id: "barcode", label: "Barcode", icon: Barcode }
];

const PRESETS: Record<string, { label: string; html: string }> = {
  blank: {
    label: "Minimal page",
    html: `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>New document</title>
<style>
  body { font-family: Helvetica, sans-serif; color: #111827; font-size: 11pt; }
  h1 { font-size: 20pt; margin: 0 0 6pt 0; }
  p { line-height: 1.5; }
</style>
</head>
<body>
  <h1>New document</h1>
  <p>Written by the Docuzen HTML layout engine. Replace this content and run again.</p>
</body>
</html>`
  },
  invoice: {
    label: "Invoice",
    html: `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Invoice</title>
<style>
  body { font-family: Helvetica, sans-serif; color: #111827; font-size: 10pt; }
  .row { width: 100%; }
  .brand { font-size: 18pt; font-weight: bold; letter-spacing: 0.5pt; }
  .muted { color: #6b7280; font-size: 8.5pt; }
  table { width: 100%; border-collapse: collapse; margin-top: 14pt; }
  th { text-align: left; font-size: 8pt; text-transform: uppercase; letter-spacing: 0.6pt;
       color: #6b7280; border-bottom: 1pt solid #111827; padding: 5pt 3pt; }
  td { padding: 5pt 3pt; border-bottom: 0.5pt solid #e5e7eb; font-size: 9.5pt; }
  .amount { text-align: right; }
  .total { font-weight: bold; border-bottom: none; }
</style>
</head>
<body>
  <div class="brand">NORTHWIND ANALYTICS</div>
  <div class="muted">14 Foundry Lane, Bengaluru 560001 · accounts@northwind.example</div>
  <h2>Invoice DZ-2081</h2>
  <p class="muted">Issued 12 November 2026 · due 12 December 2026</p>
  <p><strong>Billed to</strong><br>Harbour Logistics<br>22 Dock Road, Kochi 682003</p>
  <table>
    <tr><th>Description</th><th>Qty</th><th class="amount">Unit price</th><th class="amount">Amount</th></tr>
    <tr><td>Docuzen PDF engine — annual licence</td><td>25</td><td class="amount">4,800.00</td><td class="amount">1,20,000.00</td></tr>
    <tr><td>Conversion review service</td><td>40</td><td class="amount">145.00</td><td class="amount">5,800.00</td></tr>
    <tr><td>Priority support — 12 months</td><td>1</td><td class="amount">9,900.00</td><td class="amount">9,900.00</td></tr>
    <tr><td colspan="3" class="amount">Subtotal</td><td class="amount">1,35,700.00</td></tr>
    <tr><td colspan="3" class="amount total">Total due</td><td class="amount total">1,60,126.00</td></tr>
  </table>
</body>
</html>`
  },
  report: {
    label: "Short report",
    html: `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Engine status report</title>
<style>
  body { font-family: Helvetica, sans-serif; font-size: 10.5pt; color: #111827; }
  h1 { font-size: 19pt; margin-bottom: 2pt; }
  h2 { font-size: 12pt; margin: 16pt 0 5pt; }
  p { line-height: 1.55; }
  .lede { color: #4b5563; font-size: 9.5pt; }
  ul { margin: 4pt 0 4pt 14pt; padding: 0; }
  li { margin-bottom: 3pt; line-height: 1.5; }
  .callout { background: #f3f4f6; padding: 8pt 10pt; border-left: 2pt solid #0e6a45; }
</style>
</head>
<body>
  <h1>Engine status report</h1>
  <p class="lede">Docuzen PDF 0.2.0 · prepared 12 November 2026</p>
  <h2>Summary</h2>
  <p>The managed engine renders, converts, edits and signs documents without native interop or a browser engine. This page exists to show
  the layout engine's treatment of headings, running text, lists and callouts.</p>
  <div class="callout">All output on this page is laid out by the same code path that produced the workbench samples.</div>
  <h2>Observations</h2>
  <ul>
    <li>Text is shaped with the embedded or fallback font, not by a platform text stack.</li>
    <li>Tables are laid out from content widths; long cells wrap instead of clipping.</li>
    <li>Tagged output is written for every page so accessibility checks have something to read.</li>
  </ul>
  <h2>Next steps</h2>
  <p>Convert this document to PDF/A, then validate it. Compare the result against the previous revision with the visual diff.</p>
</body>
</html>`
  }
};

export default function CreatePage() {
  const [tab, setTab] = useState("html");
  return (
    <div>
      <PageHeader
        eyebrow="Build"
        title="Create documents"
        description="Write a page with the engine's own HTML/CSS layout pass, or draw a vector Code 128 barcode. Nothing here uses a browser engine."
      />
      <Tabs tabs={TABS} value={tab} onChange={setTab} className="mb-5" />
      {tab === "html" ? <HtmlTab /> : <BarcodeTab />}
    </div>
  );
}

function HtmlTab() {
  const [preset, setPreset] = useState("blank");
  const [html, setHtml] = useState(PRESETS.blank.html);
  const [pageSize, setPageSize] = useState("A4");
  const [landscape, setLandscape] = useState(false);
  const [margins, setMargins] = useState({ top: "54", right: "48", bottom: "54", left: "48" });
  const [fontSize, setFontSize] = useState("11");
  const [title, setTitle] = useState("New document");
  const [author, setAuthor] = useState("");
  const [header, setHeader] = useState("");
  const [footer, setFooter] = useState("Page {page} of {pages}");
  const [css, setCss] = useState("");
  const [fileName, setFileName] = useState("");
  const { result, error, pending, run, reset } = useToolRun<Record<string, unknown>>();
  const { setCurrent } = useWorkspace();

  function applyPreset(id: string) {
    setPreset(id);
    setHtml(PRESETS[id].html);
    setTitle(PRESETS[id].label);
  }

  return (
    <div className="space-y-5">
      <div className="grid items-start gap-5 xl:grid-cols-[minmax(0,1fr)_330px]">
        <ConfigCard
          title="Page source"
          description="A bounded CSS subset: block layout, tables, lists, borders, colours and images from data URIs."
          footer={
            <RunBar
              label="Lay out PDF"
              pending={pending}
              disabled={!html.trim()}
              onRun={() =>
                run(() =>
                  tools.createHtml({
                    html,
                    pageSize,
                    landscape,
                    margins: [Number(margins.top), Number(margins.right), Number(margins.bottom), Number(margins.left)],
                    fontSize: Number(fontSize) || undefined,
                    title,
                    author,
                    header,
                    footer,
                    css: css || undefined,
                    fileName: fileName || (title.trim() ? `${slug(title)}.pdf` : undefined)
                  }).then((response) => {
                    const produced = response?.artifacts[0];
                    if (produced) setCurrent(produced.id);
                    return response;
                  })
                )
              }
            />
          }
        >
          <div>
            <span className="label">Template</span>
            <Select value={preset} onChange={(event) => applyPreset(event.target.value)} options={Object.entries(PRESETS).map(([id, value]) => ({ value: id, label: value.label }))} />
          </div>
          <div>
            <div className="mb-1 flex items-baseline justify-between">
              <span className="label mb-0">HTML</span>
              <span className="text-[10.5px] tabular-nums text-faint">{html.length.toLocaleString()} characters</span>
            </div>
            <TextArea
              value={html}
              onChange={(event) => setHtml(event.target.value)}
              rows={18}
              spellCheck={false}
              className="font-mono text-[11px] leading-[1.55]"
            />
          </div>
          <div>
            <span className="label">Extra CSS</span>
            <TextArea value={css} onChange={(event) => setCss(event.target.value)} rows={3} placeholder="Optional overrides appended to the document stylesheet" className="font-mono text-[11px]" />
          </div>
        </ConfigCard>

        <ConfigCard title="Page setup">
          <InlineFields>
            <div>
              <span className="label">Page size</span>
              <Select
                value={pageSize}
                onChange={(event) => setPageSize(event.target.value)}
                options={[
                  { value: "A4", label: "A4" },
                  { value: "A3", label: "A3" },
                  { value: "A5", label: "A5" },
                  { value: "letter", label: "US Letter" },
                  { value: "legal", label: "US Legal" }
                ]}
              />
            </div>
            <div>
              <span className="label">Base font size (pt)</span>
              <NumberInput value={fontSize} onChange={setFontSize} min={6} max={48} />
            </div>
          </InlineFields>
          <div className="grid grid-cols-4 gap-2">
            {(["top", "right", "bottom", "left"] as const).map((side) => (
              <div key={side}>
                <span className="label text-[11px] capitalize">{side}</span>
                <NumberInput value={margins[side]} onChange={(value) => setMargins((current) => ({ ...current, [side]: value }))} min={0} max={300} />
              </div>
            ))}
          </div>
          <Checkbox label="Landscape" checked={landscape} onChange={setLandscape} />
          <SectionDivider label="Document properties" />
          <InlineFields>
            <div>
              <span className="label">Title</span>
              <TextInput value={title} onChange={(event) => setTitle(event.target.value)} />
            </div>
            <div>
              <span className="label">Author</span>
              <TextInput value={author} onChange={(event) => setAuthor(event.target.value)} placeholder="optional" />
            </div>
          </InlineFields>
          <div>
            <span className="label">Running header</span>
            <TextInput value={header} onChange={(event) => setHeader(event.target.value)} placeholder="optional" />
          </div>
          <div>
            <span className="label">Running footer</span>
            <TextInput value={footer} onChange={(event) => setFooter(event.target.value)} placeholder="Page {page} of {pages}" />
          </div>
          <div>
            <span className="label">Output file name</span>
            <TextInput value={fileName} onChange={(event) => setFileName(event.target.value)} placeholder="derived from the title" />
          </div>
        </ConfigCard>
      </div>

      <ResultPanel
        result={result}
        error={error}
        pending={pending}
        onReset={reset}
        emptyIcon={Sparkles}
        emptyTitle="Nothing laid out yet"
        emptyDescription="Edit the HTML or start from a template, then run the layout pass. The produced PDF is tagged and rendered beside the report."
        renderReport={(report) => <HtmlReport report={report} />}
      />
    </div>
  );
}

function HtmlReport({ report }: { report: Record<string, unknown> }) {
  const pageSize = report.pageSize as { width?: number; height?: number } | undefined;
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        <div className="rounded-lg border border-line bg-surface-muted/60 px-3 py-2">
          <div className="text-[10px] font-medium uppercase tracking-[0.06em] text-faint">Pages</div>
          <div className="mt-0.5 text-[15px] font-semibold tabular-nums text-ink">{String(report.pages ?? "—")}</div>
        </div>
        <div className="rounded-lg border border-line bg-surface-muted/60 px-3 py-2">
          <div className="text-[10px] font-medium uppercase tracking-[0.06em] text-faint">Tagged</div>
          <div className="mt-0.5 text-[15px] font-semibold text-ink">{report.tagged === false ? "no" : "yes"}</div>
        </div>
        {pageSize ? (
          <div className="rounded-lg border border-line bg-surface-muted/60 px-3 py-2 sm:col-span-2">
            <div className="text-[10px] font-medium uppercase tracking-[0.06em] text-faint">Page size (pt)</div>
            <div className="mt-0.5 text-[13px] font-medium tabular-nums text-ink">
              {pageSize.width} × {pageSize.height}
            </div>
          </div>
        ) : null}
      </div>
      <GenericReport report={report} skipKeys={["pages", "tagged", "pageSize"]} />
    </div>
  );
}

function BarcodeTab() {
  const { setCurrent } = useWorkspace();
  const [text, setText] = useState("DOCUZEN-2026-11");
  const [type, setType] = useState("code128");
  const [moduleWidth, setModuleWidth] = useState("1.4");
  const [height, setHeight] = useState("56");
  const [label, setLabel] = useState(true);
  const { result, error, pending, run, reset } = useToolRun<Record<string, unknown>>();

  return (
    <div className="split-wrap">
      <ConfigCard
        description="Vector Code 128-B or 128-C bars drawn into a single-page PDF. Code 39, EAN-13 and QR are refused rather than approximated."
        footer={
          <RunBar
            label="Generate barcode"
            pending={pending}
            disabled={!text.trim()}
            onRun={() =>
              run(() =>
                tools.createBarcode({ text, type, moduleWidth: Number(moduleWidth), height: Number(height), label }).then((response) => {
                  const produced = response?.artifacts[0];
                  if (produced) setCurrent(produced.id);
                  return response;
                })
              )
            }
          />
        }
      >
        <div>
          <span className="label">Payload</span>
          <TextInput value={text} onChange={(event) => setText(event.target.value)} className="font-mono" />
          <p className="mt-1 text-[11px] text-faint">Code 128-B accepts printable ASCII; the C variant expects digit pairs.</p>
        </div>
        <InlineFields>
          <div>
            <span className="label">Symbology</span>
            <Select
              value={type}
              onChange={(event) => setType(event.target.value)}
              options={[
                { value: "code128", label: "Code 128 (B)" },
                { value: "code128c", label: "Code 128-C (numeric)" }
              ]}
            />
          </div>
          <div>
            <span className="label">Bar height (pt)</span>
            <NumberInput value={height} onChange={setHeight} min={8} max={400} />
          </div>
        </InlineFields>
        <div>
          <span className="label">Module width (pt)</span>
          <NumberInput value={moduleWidth} onChange={setModuleWidth} min={0.25} max={6} step={0.05} />
        </div>
        <Checkbox label="Human-readable label" hint="Prints the payload under the bars." checked={label} onChange={setLabel} />
        <Callout tone="info" title="Bars are vector paths">
          The barcode is drawn as filled rectangles, so it prints cleanly at any size and stays editable in the PDF.
        </Callout>
      </ConfigCard>

      <ResultPanel
        result={result}
        error={error}
        pending={pending}
        onReset={reset}
        emptyIcon={FilePlus2}
        emptyTitle="No barcode yet"
        emptyDescription="Enter a payload and generate. The page renders here so the bars and label can be checked before use."
        renderReport={(report) => <GenericReport report={report} />}
      />
    </div>
  );
}

function slug(value: string): string {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60) || "document";
}
