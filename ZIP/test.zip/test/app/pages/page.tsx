"use client";

import { useEffect, useState } from "react";
import clsx from "clsx";
import {
  ArrowDown,
  ArrowUp,
  Crop,
  Layers,
  LayoutGrid,
  Plus,
  RotateCw,
  Scissors,
  Stamp,
  Trash2
} from "lucide-react";
import { tools } from "@/lib/api";
import { useWorkspace } from "@/components/workspace-provider";
import { useToolRun } from "@/lib/use-tool-run";
import { ResultPanel } from "@/components/result-panel";
import { ConfigCard, DocumentSelect, InlineFields, RunBar, SectionDivider, useDocumentSelection } from "@/components/tool-form";
import { Button, Callout, Checkbox, NumberInput, PageHeader, Pill, Segmented, Select, Tabs, TextArea, TextInput } from "@/components/ui";
import type { Artifact } from "@/lib/types";

const TABS = [
  { id: "assemble", label: "Merge & split", icon: Layers },
  { id: "edits", label: "Page edits", icon: RotateCw },
  { id: "layout", label: "Crop & impose", icon: Crop },
  { id: "stamp", label: "Stamp", icon: Stamp }
];

export default function PagesPage() {
  const { currentId } = useWorkspace();
  const [tab, setTab] = useState("assemble");
  return (
    <div>
      <PageHeader
        eyebrow="Organise"
        title="Pages & layout"
        description="Assemble, cut, reorder and reshape the page tree. Every operation writes a new document and reports the page references it produced."
      />
      <Tabs tabs={TABS} value={tab} onChange={setTab} className="mb-5" />
      {tab === "assemble" ? <AssembleTab defaultId={currentId ?? ""} /> : null}
      {tab === "edits" ? <EditsTab defaultId={currentId ?? ""} /> : null}
      {tab === "layout" ? <LayoutTab defaultId={currentId ?? ""} /> : null}
      {tab === "stamp" ? <StampTab defaultId={currentId ?? ""} /> : null}
    </div>
  );
}

function useDocument(_defaultId: string) {
  return useDocumentSelection();
}

/* -------------------------------------------------------------- assemble */

function AssembleTab({ defaultId }: { defaultId: string }) {
  const { pdfs, artifacts, currentId } = useWorkspace();
  const [artifactId, setArtifactId] = useDocument(defaultId);
  const [mode, setMode] = useState<"merge" | "extract" | "split">("merge");
  const [queue, setQueue] = useState<Artifact[]>([]);
  const [outline, setOutline] = useState(true);
  const [pages, setPages] = useState("");
  const [each, setEach] = useState("1");
  const [toAdd, setToAdd] = useState("");
  const { result, error, pending, run, reset } = useToolRun<Record<string, unknown>>();

  useEffect(() => {
    if (queue.length > 0 || pdfs.length === 0) return;
    // Seed the queue once so the first run is meaningful: the current document
    // first, then a second document so a merge actually changes something.
    const preferred = pdfs.find((pdf) => pdf.id === currentId) ?? pdfs[0];
    const second = pdfs.find((pdf) => pdf.id !== preferred.id);
    setQueue(second ? [preferred, second] : [preferred]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pdfs.length, currentId]);

  function move(index: number, direction: -1 | 1) {
    setQueue((items) => {
      const next = [...items];
      const target = index + direction;
      if (target < 0 || target >= next.length) return items;
      [next[index], next[target]] = [next[target], next[index]];
      return next;
    });
  }

  return (
    <div className="split-wrap">
      <ConfigCard
        description="Merge concatenates page trees; extract keeps a selection in the order given; split writes one file per page or per N pages."
        footer={
          <RunBar
            label={mode === "merge" ? "Merge documents" : mode === "extract" ? "Extract pages" : "Split document"}
            pending={pending}
            disabled={mode === "merge" ? queue.length === 0 : !artifactId}
            onRun={() =>
              run(() =>
                mode === "merge"
                  ? tools.merge({ artifactIds: queue.map((item) => item.id), outline })
                  : mode === "extract"
                    ? tools.extractPages({ artifactId, pages })
                    : tools.split({ artifactId, pages: pages || undefined, each: Number(each) || 1 })
              )
            }
          />
        }
      >
        <Segmented
          value={mode}
          onChange={setMode}
          className="w-full"
          options={[
            { value: "merge", label: "Merge" },
            { value: "extract", label: "Extract" },
            { value: "split", label: "Split" }
          ]}
        />

        {mode === "merge" ? (
          <div className="space-y-3">
            <div>
              <span className="label">Document order</span>
              <div className="space-y-1.5">
                {queue.length === 0 ? (
                  <p className="rounded-md border border-dashed border-line-strong px-3 py-4 text-center text-[11.5px] text-faint">
                    Add at least one document.
                  </p>
                ) : (
                  queue.map((item, index) => (
                    <div key={`${item.id}-${index}`} className="flex items-center gap-2 rounded-md border border-line bg-surface px-2 py-1.5">
                      <span className="w-4 text-center text-[11px] tabular-nums text-faint">{index + 1}</span>
                      <span className="min-w-0 flex-1 truncate text-[12px] text-ink">{item.fileName}</span>
                      <span className="shrink-0 text-[10.5px] text-faint">
                        {item.pageCount ?? "?"} {item.pageCount === 1 ? "page" : "pages"}
                      </span>
                      <button type="button" onClick={() => move(index, -1)} disabled={index === 0} className="rounded p-0.5 text-muted hover:bg-canvas disabled:opacity-30" aria-label="Move up">
                        <ArrowUp className="size-3" />
                      </button>
                      <button
                        type="button"
                        onClick={() => move(index, 1)}
                        disabled={index === queue.length - 1}
                        className="rounded p-0.5 text-muted hover:bg-canvas disabled:opacity-30"
                        aria-label="Move down"
                      >
                        <ArrowDown className="size-3" />
                      </button>
                      <button
                        type="button"
                        onClick={() => setQueue((items) => items.filter((_, i) => i !== index))}
                        className="rounded p-0.5 text-muted hover:bg-danger-soft hover:text-danger"
                        aria-label="Remove"
                      >
                        <Trash2 className="size-3" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
            <div className="flex gap-1.5">
              <Select
                value={toAdd}
                onChange={(event) => setToAdd(event.target.value)}
                className="h-8 text-[12px]"
                options={[{ value: "", label: "Add a document…" }, ...pdfs.map((pdf) => ({ value: pdf.id, label: pdf.fileName }))]}
              />
              <Button
                size="sm"
                icon={Plus}
                disabled={!toAdd}
                onClick={() => {
                  const found = artifacts.find((artifact) => artifact.id === toAdd);
                  if (found) setQueue((items) => [...items, found]);
                  setToAdd("");
                }}
              >
                Add
              </Button>
            </div>
            <Checkbox label="Carry the outline" hint="Merges bookmark trees into the combined document." checked={outline} onChange={setOutline} />
          </div>
        ) : (
          <div className="space-y-3">
            <DocumentSelect value={artifactId} onChange={setArtifactId} label="Document" />
            <div>
              <span className="label">Pages</span>
              <TextInput value={pages} onChange={(event) => setPages(event.target.value)} placeholder={mode === "extract" ? "1-2,5" : "all pages"} />
              <p className="mt-1 text-[11px] text-faint">
                {mode === "extract" ? "Required: the order given is preserved." : "Leave empty to split the whole document."}
              </p>
            </div>
            {mode === "split" ? (
              <div>
                <span className="label">Pages per file</span>
                <NumberInput value={each} onChange={setEach} min={1} max={500} />
              </div>
            ) : null}
            {mode === "extract" && !pages.trim() ? (
              <Callout tone="warn" title="Pages are required">Give at least one page number, for example 1 or 2-3.</Callout>
            ) : null}
          </div>
        )}
      </ConfigCard>

      <ResultPanel
        result={result}
        error={error}
        pending={pending}
        onReset={reset}
        emptyIcon={Layers}
        emptyTitle="No pages produced yet"
        emptyDescription="Merge, extract or split and every produced document is listed with its preview and page count."
        renderReport={(report) => <GenericPagesReport report={report} />}
      />
    </div>
  );
}

/* ----------------------------------------------------------------- edits */

type EditMode = "rotate" | "insert" | "delete" | "move" | "clone" | "scale";

function EditsTab({ defaultId }: { defaultId: string }) {
  const [artifactId, setArtifactId] = useDocument(defaultId);
  const [mode, setMode] = useState<EditMode>("rotate");
  const [angle, setAngle] = useState("90");
  const [page, setPage] = useState("1");
  const [destination, setDestination] = useState("1");
  const [factor, setFactor] = useState("0.9");
  const [at, setAt] = useState("1");
  const [pageSize, setPageSize] = useState("A4");
  const [width, setWidth] = useState("595");
  const [height, setHeight] = useState("842");
  const { result, error, pending, run, reset } = useToolRun<Record<string, unknown>>();

  const runEdit = () => {
    if (mode === "rotate") return tools.rotate({ artifactId, angle: Number(angle), pages: "all" });
    if (mode === "insert")
      return tools.insert({
        artifactId,
        at: Number(at) || undefined,
        pageSize: pageSize === "custom" ? undefined : pageSize,
        width: pageSize === "custom" ? Number(width) : undefined,
        height: pageSize === "custom" ? Number(height) : undefined
      });
    if (mode === "delete") return tools.pageOp("remove", { artifactId, page: Number(page) });
    if (mode === "move") return tools.pageOp("move", { artifactId, page: Number(page), destination: Number(destination) });
    if (mode === "clone") return tools.pageOp("clone", { artifactId, page: Number(page) });
    return tools.pageOp("scale", { artifactId, page: Number(page), factor: Number(factor) });
  };

  const label =
    mode === "rotate" ? "Rotate pages" : mode === "insert" ? "Insert blank page" : mode === "delete" ? "Delete page" : mode === "move" ? "Move page" : mode === "clone" ? "Clone page" : "Scale page";

  return (
    <div className="split-wrap">
      <ConfigCard
        description="Single-page structural edits walk the page tree and refuse documents whose structure they cannot preserve."
        footer={<RunBar label={label} pending={pending} disabled={!artifactId} onRun={() => run(runEdit)} />}
      >
        <DocumentSelect value={artifactId} onChange={setArtifactId} label="Document" />

        <div className="grid grid-cols-3 gap-1.5">
          {(
            [
              ["rotate", "Rotate"],
              ["insert", "Insert"],
              ["delete", "Delete"],
              ["move", "Move"],
              ["clone", "Clone"],
              ["scale", "Scale"]
            ] as Array<[EditMode, string]>
          ).map(([value, text]) => (
            <button
              key={value}
              type="button"
              onClick={() => setMode(value)}
              className={clsx(
                "rounded-md border px-2 py-1.5 text-[11.5px] font-medium transition",
                mode === value ? "border-accent bg-accent-soft/60 text-ink" : "border-line bg-surface text-muted hover:border-line-strong"
              )}
            >
              {text}
            </button>
          ))}
        </div>

        {mode === "rotate" ? (
          <>
            <div>
              <span className="label">Angle</span>
              <Segmented
                value={angle}
                onChange={setAngle}
                className="w-full"
                options={[
                  { value: "90", label: "90°" },
                  { value: "180", label: "180°" },
                  { value: "270", label: "270°" }
                ]}
              />
            </div>
            <p className="hint">Rotation applies to every page and is added to any existing /Rotate entry.</p>
          </>
        ) : null}

        {mode === "insert" ? (
          <>
            <InlineFields>
              <div>
                <span className="label">Insert at position</span>
                <NumberInput value={at} onChange={setAt} min={1} />
              </div>
              <div>
                <span className="label">Page size</span>
                <Select
                  value={pageSize}
                  onChange={(event) => setPageSize(event.target.value)}
                  options={[
                    { value: "A4", label: "A4" },
                    { value: "A3", label: "A3" },
                    { value: "A5", label: "A5" },
                    { value: "letter", label: "US Letter" },
                    { value: "legal", label: "US Legal" },
                    { value: "ledger", label: "Ledger" },
                    { value: "tabloid", label: "Tabloid" },
                    { value: "custom", label: "Custom (points)" }
                  ]}
                />
              </div>
            </InlineFields>
            {pageSize === "custom" ? (
              <InlineFields>
                <div>
                  <span className="label">Width (pt)</span>
                  <NumberInput value={width} onChange={setWidth} min={1} />
                </div>
                <div>
                  <span className="label">Height (pt)</span>
                  <NumberInput value={height} onChange={setHeight} min={1} />
                </div>
              </InlineFields>
            ) : null}
          </>
        ) : null}

        {mode !== "rotate" && mode !== "insert" ? (
          <div>
            <span className="label">Page number (one-based)</span>
            <NumberInput value={page} onChange={setPage} min={1} />
          </div>
        ) : null}

        {mode === "move" ? (
          <div>
            <span className="label">Destination position</span>
            <NumberInput value={destination} onChange={setDestination} min={1} />
          </div>
        ) : null}

        {mode === "scale" ? (
          <div>
            <span className="label">Scale factor</span>
            <NumberInput value={factor} onChange={setFactor} min={0.1} max={4} step={0.05} />
            <p className="mt-1 text-[11px] text-faint">The page is resized around its lower-left origin; content is not re-laid out.</p>
          </div>
        ) : null}

        <Callout tone="info" title="Why a run may be refused">
          These operations will not touch a page that carries annotations or a structure tree. The refusal is reported with the reason instead
          of a silently damaged document.
        </Callout>
      </ConfigCard>

      <ResultPanel
        result={result}
        error={error}
        pending={pending}
        onReset={reset}
        emptyIcon={RotateCw}
        emptyTitle="No page edit yet"
        emptyDescription="Pick an operation and run it. The produced document is rendered so the structural change is visible, not just claimed."
        renderReport={(report) => <GenericPagesReport report={report} />}
      />
    </div>
  );
}

/* ---------------------------------------------------------------- layout */

function LayoutTab({ defaultId }: { defaultId: string }) {
  const [artifactId, setArtifactId] = useDocument(defaultId);
  const [mode, setMode] = useState<"crop" | "impose">("crop");
  const [box, setBox] = useState("CropBox");
  const [boxMode, setBoxMode] = useState<"margins" | "rect">("margins");
  const [margins, setMargins] = useState(["18", "18", "18", "18"]);
  const [rect, setRect] = useState(["40", "40", "555", "800"]);
  const [nUp, setNUp] = useState("2");
  const [layout, setLayout] = useState("auto");
  const [sheetSize, setSheetSize] = useState("A4");
  const [landscape, setLandscape] = useState(false);
  const [margin, setMargin] = useState("18");
  const [gutter, setGutter] = useState("18");
  const [trimMarks, setTrimMarks] = useState(true);
  const [foldMarks, setFoldMarks] = useState(false);
  const { result, error, pending, run, reset } = useToolRun<Record<string, unknown>>();

  return (
    <div className="split-wrap">
      <ConfigCard
        description="Page boxes are rewired in the page dictionary; imposition composes several source pages onto one sheet."
        footer={
          <RunBar
            label={mode === "crop" ? "Apply page boxes" : `Impose ${nUp}-up`}
            pending={pending}
            disabled={!artifactId}
            onRun={() =>
              run(() =>
                mode === "crop"
                  ? tools.crop({
                      artifactId,
                      box,
                      margins: boxMode === "margins" ? margins.map(Number) : undefined,
                      rect: boxMode === "rect" ? rect.map(Number) : undefined
                    })
                  : tools.impose({
                      artifactId,
                      nUp: Number(nUp),
                      layout,
                      sheetSize,
                      landscape,
                      margin: [Number(margin), Number(margin), Number(margin), Number(margin)],
                      gutter: Number(gutter),
                      trimMarks,
                      foldMarks
                    })
              )
            }
          />
        }
      >
        <Segmented
          value={mode}
          onChange={setMode}
          className="w-full"
          options={[
            { value: "crop", label: "Page boxes" },
            { value: "impose", label: "Imposition" }
          ]}
        />
        <DocumentSelect value={artifactId} onChange={setArtifactId} label="Document" />

        {mode === "crop" ? (
          <>
            <div>
              <span className="label">Box</span>
              <Select
                value={box}
                onChange={(event) => setBox(event.target.value)}
                options={[
                  { value: "CropBox", label: "CropBox — the visible area" },
                  { value: "MediaBox", label: "MediaBox — the physical page" },
                  { value: "TrimBox", label: "TrimBox — finished size" },
                  { value: "BleedBox", label: "BleedBox" },
                  { value: "ArtBox", label: "ArtBox" }
                ]}
              />
            </div>
            <Segmented
              value={boxMode}
              onChange={setBoxMode}
              className="w-full"
              options={[
                { value: "margins", label: "Inset by margins" },
                { value: "rect", label: "Explicit rectangle" }
              ]}
            />
            {boxMode === "margins" ? (
              <div className="grid grid-cols-4 gap-2">
                {["Left", "Bottom", "Right", "Top"].map((label, index) => (
                  <div key={label}>
                    <span className="label text-[11px]">{label}</span>
                    <NumberInput
                      value={margins[index]}
                      onChange={(value) => setMargins((items) => items.map((item, itemIndex) => (itemIndex === index ? value : item)))}
                    />
                  </div>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-4 gap-2">
                {["llx", "lly", "urx", "ury"].map((label, index) => (
                  <div key={label}>
                    <span className="label text-[11px]">{label}</span>
                    <NumberInput
                      value={rect[index]}
                      onChange={(value) => setRect((items) => items.map((item, itemIndex) => (itemIndex === index ? value : item)))}
                    />
                  </div>
                ))}
              </div>
            )}
            <p className="hint">Coordinates are in points from the lower-left origin.</p>
          </>
        ) : (
          <>
            <div>
              <span className="label">Pages per sheet</span>
              <Segmented
                value={nUp}
                onChange={setNUp}
                className="w-full"
                options={[
                  { value: "2", label: "2-up" },
                  { value: "4", label: "4-up" },
                  { value: "8", label: "8-up" }
                ]}
              />
            </div>
            <InlineFields>
              <div>
                <span className="label">Layout</span>
                <Select
                  value={layout}
                  onChange={(event) => setLayout(event.target.value)}
                  options={[
                    { value: "auto", label: "Automatic" },
                    { value: "side-by-side", label: "Side by side" },
                    { value: "stacked", label: "Stacked" },
                    { value: "grid", label: "Grid" },
                    { value: "booklet", label: "Booklet" }
                  ]}
                />
              </div>
              <div>
                <span className="label">Sheet size</span>
                <Select
                  value={sheetSize}
                  onChange={(event) => setSheetSize(event.target.value)}
                  options={[
                    { value: "A4", label: "A4" },
                    { value: "A3", label: "A3" },
                    { value: "A5", label: "A5" },
                    { value: "letter", label: "US Letter" },
                    { value: "legal", label: "US Legal" }
                  ]}
                />
              </div>
            </InlineFields>
            <InlineFields>
              <div>
                <span className="label">Margin (pt)</span>
                <NumberInput value={margin} onChange={setMargin} min={0} />
              </div>
              <div>
                <span className="label">Gutter (pt)</span>
                <NumberInput value={gutter} onChange={setGutter} min={0} />
              </div>
            </InlineFields>
            <Checkbox label="Landscape sheets" checked={landscape} onChange={setLandscape} />
            <div className="grid grid-cols-2 gap-2">
              <Checkbox label="Trim marks" checked={trimMarks} onChange={setTrimMarks} />
              <Checkbox label="Fold marks" checked={foldMarks} onChange={setFoldMarks} />
            </div>
          </>
        )}
      </ConfigCard>

      <ResultPanel
        result={result}
        error={error}
        pending={pending}
        onReset={reset}
        emptyIcon={LayoutGrid}
        emptyTitle="No layout change yet"
        emptyDescription="Adjust a page box or compose an imposition sheet. The output is rendered with the same rasterizer used by print preview."
        renderReport={(report) => <GenericPagesReport report={report} />}
      />
    </div>
  );
}

/* ----------------------------------------------------------------- stamp */

function StampTab({ defaultId }: { defaultId: string }) {
  const { artifacts } = useWorkspace();
  const [artifactId, setArtifactId] = useDocument(defaultId);
  const [mode, setMode] = useState<"text" | "image">("text");
  const [text, setText] = useState("APPROVED");
  const [imageId, setImageId] = useState("");
  const [fontSize, setFontSize] = useState("36");
  const [color, setColor] = useState("#b91c1c");
  const [opacity, setOpacity] = useState("0.5");
  const [angle, setAngle] = useState("0");
  const [x, setX] = useState("120");
  const [y, setY] = useState("380");
  const [center, setCenter] = useState(false);
  const [multiline, setMultiline] = useState(false);
  const [maxWidth, setMaxWidth] = useState("420");
  const [align, setAlign] = useState("left");
  const [width, setWidth] = useState("180");
  const [height, setHeight] = useState("90");
  const { result, error, pending, run, reset } = useToolRun<Record<string, unknown>>();

  const images = artifacts.filter((artifact) => artifact.kind === "image");
  const selected = artifacts.find((artifact) => artifact.id === artifactId);
  const untagged =
    artifacts.find((artifact) => artifact.kind === "pdf" && !artifact.tagged && artifact.origin === "sample") ??
    artifacts.find((artifact) => artifact.kind === "pdf" && !artifact.tagged);

  useEffect(() => {
    if (!imageId && images.length > 0) setImageId(images[0].id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [images.length]);

  return (
    <div className="split-wrap">
      <ConfigCard
        description="Text stamps are drawn with an embedded font; image stamps place an existing image artifact with opacity."
        footer={
          <RunBar
            label="Apply stamp"
            pending={pending}
            disabled={!artifactId || (mode === "text" ? !text.trim() : !imageId)}
            onRun={() =>
              run(() =>
                tools.stamp(
                  mode === "text"
                    ? {
                        artifactId,
                        text,
                        fontSize: Number(fontSize),
                        color,
                        opacity: Number(opacity),
                        angle: Number(angle),
                        x: Number(x),
                        y: Number(y),
                        center,
                        multiline,
                        maxWidth: multiline ? Number(maxWidth) : undefined,
                        align
                      }
                    : { artifactId, imageArtifactId: imageId, width: Number(width), height: Number(height), opacity: Number(opacity) }
                )
              )
            }
          />
        }
      >
        <Segmented
          value={mode}
          onChange={setMode}
          className="w-full"
          options={[
            { value: "text", label: "Text stamp" },
            { value: "image", label: "Image stamp" }
          ]}
        />
        <DocumentSelect value={artifactId} onChange={setArtifactId} label="Document" />

        {mode === "text" ? (
          <>
            <div>
              <span className="label">Text</span>
              <TextArea rows={2} value={text} onChange={(event) => setText(event.target.value)} />
            </div>
            <InlineFields>
              <div>
                <span className="label">Font size (pt)</span>
                <NumberInput value={fontSize} onChange={setFontSize} min={4} max={400} />
              </div>
              <div>
                <span className="label">Colour</span>
                <div className="flex items-center gap-1.5">
                  <input
                    type="color"
                    value={color}
                    onChange={(event) => setColor(event.target.value)}
                    className="size-9 shrink-0 cursor-pointer rounded-md border border-line-strong bg-surface p-0.5"
                  />
                  <TextInput value={color} onChange={(event) => setColor(event.target.value)} className="font-mono text-[12px]" />
                </div>
              </div>
            </InlineFields>
            <InlineFields columns={3}>
              <div>
                <span className="label">X (pt)</span>
                <NumberInput value={x} onChange={setX} />
              </div>
              <div>
                <span className="label">Y (pt)</span>
                <NumberInput value={y} onChange={setY} />
              </div>
              <div>
                <span className="label">Angle (°)</span>
                <NumberInput value={angle} onChange={setAngle} min={-360} max={360} />
              </div>
            </InlineFields>
            <div>
              <span className="label">Opacity · {Math.round(Number(opacity) * 100)}%</span>
              <input
                type="range"
                min={0.05}
                max={1}
                step={0.05}
                value={opacity}
                onChange={(event) => setOpacity(event.target.value)}
                className="w-full accent-[#0e6a45]"
              />
            </div>
            <Checkbox label="Centre on the page" hint="Overrides the X/Y position." checked={center} onChange={setCenter} />
            <Checkbox label="Multi-line block" hint="Wraps the text to a maximum width with the chosen alignment." checked={multiline} onChange={setMultiline} />
            {multiline ? (
              <InlineFields>
                <div>
                  <span className="label">Max width (pt)</span>
                  <NumberInput value={maxWidth} onChange={setMaxWidth} min={20} />
                </div>
                <div>
                  <span className="label">Alignment</span>
                  <Select
                    value={align}
                    onChange={(event) => setAlign(event.target.value)}
                    options={[
                      { value: "left", label: "Left" },
                      { value: "center", label: "Centre" },
                      { value: "right", label: "Right" }
                    ]}
                  />
                </div>
              </InlineFields>
            ) : null}
          </>
        ) : (
          <>
            <div>
              <span className="label">Image artifact</span>
              <Select
                value={imageId}
                onChange={(event) => setImageId(event.target.value)}
                options={images.length === 0 ? [{ value: "", label: "No image artifacts yet" }] : images.map((image) => ({ value: image.id, label: image.fileName }))}
              />
              {images.length === 0 ? <p className="mt-1 text-[11px] text-faint">Extract images from a document first, then stamp with them.</p> : null}
            </div>
            <InlineFields>
              <div>
                <span className="label">Width (pt)</span>
                <NumberInput value={width} onChange={setWidth} min={4} />
              </div>
              <div>
                <span className="label">Height (pt)</span>
                <NumberInput value={height} onChange={setHeight} min={4} />
              </div>
            </InlineFields>
            <div>
              <span className="label">Opacity · {Math.round(Number(opacity) * 100)}%</span>
              <input
                type="range"
                min={0.05}
                max={1}
                step={0.05}
                value={opacity}
                onChange={(event) => setOpacity(event.target.value)}
                className="w-full accent-[#0e6a45]"
              />
            </div>
          </>
        )}
        <SectionDivider label="Note" />
        {selected?.tagged ? (
          <Callout
            tone="warn"
            title="This document is tagged"
            action={
              untagged ? (
                <Button size="sm" variant="ghost" onClick={() => setArtifactId(untagged.id)}>
                  Use {untagged.fileName}
                </Button>
              ) : undefined
            }
          >
            The catalog carries a structure tree, so a stamp is refused rather than written as content nothing describes. Switch to an
            untagged document, or flatten the tagging first.
          </Callout>
        ) : (
          <Callout tone="info" title="Untagged documents only">
            Stamps are refused on documents whose tagged structure tree would be invalidated by the added content.
          </Callout>
        )}
      </ConfigCard>

      <ResultPanel
        result={result}
        error={error}
        pending={pending}
        onReset={reset}
        emptyIcon={Stamp}
        emptyTitle="No stamp yet"
        emptyDescription="Stamp an untagged document and the render shows exactly where the mark landed."
        renderReport={(report) => <GenericPagesReport report={report} />}
      />
    </div>
  );
}

function GenericPagesReport({ report }: { report: Record<string, unknown> }) {
  const entries = Object.entries(report).filter(([, value]) => typeof value !== "object");
  const pageNumbers = Array.isArray(report.pages) ? report.pages : Array.isArray(report.inputPages) ? report.inputPages : null;
  return (
    <div className="space-y-3">
      {entries.length > 0 ? (
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
          {entries.slice(0, 6).map(([key, value]) => (
            <div key={key} className="rounded-lg border border-line bg-surface-muted/60 px-3 py-2">
              <div className="text-[10px] font-medium uppercase tracking-[0.06em] text-faint">{key}</div>
              <div className="mt-0.5 break-words text-[12.5px] text-ink">{String(value)}</div>
            </div>
          ))}
        </div>
      ) : null}
      {pageNumbers ? (
        <div className="flex flex-wrap items-center gap-1.5">
          <span className="text-[11.5px] text-muted">Pages:</span>
          {(pageNumbers as number[]).slice(0, 40).map((number) => (
            <Pill key={number}>p{number}</Pill>
          ))}
          {(pageNumbers as number[]).length > 40 ? <span className="text-[11px] text-faint">+{(pageNumbers as number[]).length - 40}</span> : null}
        </div>
      ) : null}
    </div>
  );
}
