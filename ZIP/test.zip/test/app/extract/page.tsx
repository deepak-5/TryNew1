"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { AlertTriangle, FileImage, Grid3x3, ScanText, UserRoundSearch } from "lucide-react";
import { api, tools } from "@/lib/api";
import { useWorkspace } from "@/components/workspace-provider";
import { useToolRun } from "@/lib/use-tool-run";
import type { ImagesReport, PiiReport, TablesReport, TextReport } from "@/lib/types";
import { formatBytes, formatNumber } from "@/lib/format";
import { ResultPanel } from "@/components/result-panel";
import { ConfigCard, DocumentSelect, RunBar, useDocumentSelection } from "@/components/tool-form";
import { MarkdownTable } from "@/components/markdown-table";
import { DataTable, ReportSection } from "@/components/report-view";
import { Button, Callout, Checkbox, PageHeader, Pill, Select, Tabs, TextInput } from "@/components/ui";

const TABS = [
  { id: "text", label: "Text", icon: ScanText },
  { id: "tables", label: "Tables", icon: Grid3x3 },
  { id: "pii", label: "PII candidates", icon: UserRoundSearch },
  { id: "images", label: "Images", icon: FileImage }
];

export default function ExtractPage() {
  const { currentId } = useWorkspace();
  const [tab, setTab] = useState("text");

  return (
    <div>
      <PageHeader
        eyebrow="Analyse"
        title="Extract content"
        description="Read what the page actually contains: decoded text runs, inferred grids, candidate personal data and every image XObject the content stream paints."
      />
      <Tabs tabs={TABS} value={tab} onChange={setTab} className="mb-5" />
      {tab === "text" ? <TextTab defaultId={currentId ?? ""} /> : null}
      {tab === "tables" ? <TablesTab defaultId={currentId ?? ""} /> : null}
      {tab === "pii" ? <PiiTab defaultId={currentId ?? ""} /> : null}
      {tab === "images" ? <ImagesTab defaultId={currentId ?? ""} /> : null}
    </div>
  );
}

function useDocument(_defaultId: string) {
  return useDocumentSelection();
}

function TextTab({ defaultId }: { defaultId: string }) {
  const [artifactId, setArtifactId] = useDocument(defaultId);
  const [pages, setPages] = useState("");
  const [layout, setLayout] = useState(false);
  const { result, error, pending, run, reset } = useToolRun<TextReport>();

  return (
    <div className="split-wrap">
      <ConfigCard
        description="Glyph runs are decoded through each font's ToUnicode map. Scanned pages yield nothing — this is not OCR."
        footer={
          <RunBar
            label="Extract text"
            pending={pending}
            disabled={!artifactId}
            onRun={() => run(() => tools.text({ artifactId, pages: pages || undefined, layout }))}
          />
        }
      >
        <DocumentSelect value={artifactId} onChange={setArtifactId} label="Document" />
        <div>
          <span className="label">Pages</span>
          <TextInput value={pages} onChange={(event) => setPages(event.target.value)} placeholder="all pages, or 1-3,7" />
          <p className="mt-1 text-[11px] text-faint">One-based ranges. Leave empty to read every page.</p>
        </div>
        <Checkbox
          label="Include positioned runs"
          hint="Adds x/y, font size and font name for every decoded run."
          checked={layout}
          onChange={setLayout}
        />
      </ConfigCard>

      <ResultPanel
        result={result}
        error={error}
        pending={pending}
        onReset={reset}
        showPreview={false}
        emptyIcon={ScanText}
        emptyTitle="No text read yet"
        emptyDescription="Choose a document and extract. Each page is shown with its character count so empty (scanned) pages are obvious."
        renderReport={(report) => <TextReportView report={report} />}
      />
    </div>
  );
}

function TextReportView({ report }: { report: TextReport }) {
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <Pill tone="accent">{formatNumber(report.characters)} characters</Pill>
        <Pill>{report.pageCount} page{report.pageCount === 1 ? "" : "s"}</Pill>
        {report.note ? <span className="text-[11px] text-faint">{report.note}</span> : null}
      </div>

      {report.pages.map((page) => (
        <div key={page.page} className="overflow-hidden rounded-lg border border-line">
          <div className="flex items-center justify-between border-b border-line bg-surface-muted px-3 py-1.5">
            <span className="text-[11.5px] font-medium text-ink-soft">Page {page.page}</span>
            <span className="text-[11px] tabular-nums text-faint">{formatNumber(page.characters)} characters</span>
          </div>
          {page.text.trim() ? (
            <pre className="scroll-thin max-h-[300px] overflow-auto whitespace-pre-wrap px-3.5 py-3 font-mono text-[11.5px] leading-[1.6] text-ink-soft">
              {page.text}
            </pre>
          ) : (
            <p className="px-3.5 py-4 text-[12px] text-muted">No decodable text on this page. It is probably a scan or vector artwork.</p>
          )}
          {page.runs && page.runs.length > 0 ? (
            <div className="border-t border-line">
              <DataTable
                dense
                maxHeight={240}
                columns={[
                  { key: "x", label: "X", align: "right" },
                  { key: "y", label: "Y", align: "right" },
                  { key: "fontSize", label: "Size", align: "right" },
                  { key: "font", label: "Font", mono: true },
                  { key: "text", label: "Text" }
                ]}
                rows={page.runs.slice(0, 400) as unknown as Array<Record<string, unknown>>}
              />
            </div>
          ) : null}
        </div>
      ))}
      {report.warnings.length > 0 ? (
        <div className="space-y-1.5">
          {report.warnings.map((warning, index) => (
            <Callout key={index} tone="warn">
              {warning}
            </Callout>
          ))}
        </div>
      ) : null}
    </div>
  );
}

function TablesTab({ defaultId }: { defaultId: string }) {
  const [artifactId, setArtifactId] = useDocument(defaultId);
  const [pages, setPages] = useState("");
  const [format, setFormat] = useState("json");
  const [borderless, setBorderless] = useState(true);
  const { result, error, pending, run, reset } = useToolRun<TablesReport>();

  return (
    <div className="split-wrap">
      <ConfigCard
        description="Column inference from text positions, not a layout model. Continuation hints mark grids that likely continue on the next page."
        footer={
          <RunBar
            label="Detect tables"
            pending={pending}
            disabled={!artifactId}
            onRun={() => run(() => tools.tables({ artifactId, pages: pages || undefined, format, borderless }))}
          />
        }
      >
        <DocumentSelect value={artifactId} onChange={setArtifactId} label="Document" />
        <div>
          <span className="label">Pages</span>
          <TextInput value={pages} onChange={(event) => setPages(event.target.value)} placeholder="all pages, or 1-3" />
        </div>
        <div>
          <span className="label">Export format</span>
          <Select
            value={format}
            onChange={(event) => setFormat(event.target.value)}
            options={[
              { value: "json", label: "JSON — cells, bounds, continuation" },
              { value: "csv", label: "CSV" },
              { value: "markdown", label: "Markdown" },
              { value: "xlsx", label: "XLSX — typed cells" }
            ]}
          />
        </div>
        <Checkbox
          label="Infer borderless grids"
          hint="Uses column gaps when no ruling lines are drawn."
          checked={borderless}
          onChange={setBorderless}
        />
      </ConfigCard>

      <ResultPanel
        result={result}
        error={error}
        pending={pending}
        onReset={reset}
        showPreview={false}
        emptyIcon={Grid3x3}
        emptyTitle="No tables detected yet"
        emptyDescription="Run the detector to see every inferred grid with its page, size and markdown rendering. The chosen export is written as an artifact."
        renderReport={(report) => <TablesReportView report={report} />}
      />
    </div>
  );
}

function TablesReportView({ report }: { report: TablesReport }) {
  if (report.count === 0) {
    return (
      <Callout tone="info" title="No grids found">
        The detector found no column structure on the selected pages. A ruled table is easier to infer than a borderless one; try including
        borderless inference or a different page range.
      </Callout>
    );
  }
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <Pill tone="accent">{report.count} table{report.count === 1 ? "" : "s"}</Pill>
        <Pill>{report.format.toUpperCase()} export</Pill>
      </div>
      {report.tables.map((table) => (
        <div key={`${table.page}-${table.tableIndex}`} className="space-y-2">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-[12px] font-medium text-ink">
              Page {table.page} · table {table.tableIndex + 1}
            </span>
            <Pill>{table.rows} rows</Pill>
            <Pill>{table.columns} columns</Pill>
            <Pill tone={table.ruled ? "info" : "neutral"}>{table.ruled ? "ruled" : "borderless"}</Pill>
            {table.continuation ? <Pill tone="warn">continues</Pill> : null}
          </div>
          <MarkdownTable markdown={table.markdown} />
        </div>
      ))}
    </div>
  );
}

function PiiTab({ defaultId }: { defaultId: string }) {
  const [artifactId, setArtifactId] = useDocument(defaultId);
  const [pages, setPages] = useState("");
  const { result, error, pending, run, reset } = useToolRun<PiiReport>();

  return (
    <div className="split-wrap">
      <ConfigCard
        description="Pattern detection over decoded text. Nothing is modified and matched values are masked in the report."
        footer={
          <RunBar
            label="Find PII candidates"
            pending={pending}
            disabled={!artifactId}
            onRun={() => run(() => tools.pii({ artifactId, pages: pages || undefined }))}
          />
        }
      >
        <DocumentSelect value={artifactId} onChange={setArtifactId} label="Document" />
        <div>
          <span className="label">Pages</span>
          <TextInput value={pages} onChange={(event) => setPages(event.target.value)} placeholder="all pages" />
        </div>
        <Callout tone="info" title="Detection is not removal">
          The engine finds email addresses, SSNs and card-number candidates. Use Redaction in Edit &amp; repair to physically remove them.
        </Callout>
      </ConfigCard>

      <ResultPanel
        result={result}
        error={error}
        pending={pending}
        onReset={reset}
        showPreview={false}
        emptyIcon={UserRoundSearch}
        emptyTitle="No scan yet"
        emptyDescription="Run the detector to see candidate values with their page and bounds. Bounds can be fed straight into region redaction."
        renderReport={(report) => <PiiReportView report={report} />}
      />
    </div>
  );
}

function PiiReportView({ report }: { report: PiiReport }) {
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <Pill tone={report.count > 0 ? "warn" : "accent"}>{report.count} candidate{report.count === 1 ? "" : "s"}</Pill>
        {Object.entries(report.byKind).map(([kind, count]) => (
          <Pill key={kind}>
            {kind} · {count}
          </Pill>
        ))}
      </div>

      {report.note ? <Callout tone="warn" title="Detection only">{report.note}</Callout> : null}

      {report.count > 0 ? (
        <>
          <ReportSection title="Candidates" hint="Masked values with the rectangle the engine attributed to them">
            <DataTable
              columns={[
                { key: "page", label: "Page", align: "right" },
                { key: "kind", label: "Kind" },
                { key: "masked", label: "Masked value", mono: true },
                {
                  key: "bounds",
                  label: "Bounds (pt)",
                  mono: true
                }
              ]}
              rows={report.findings.map((finding) => ({
                page: finding.page,
                kind: finding.kind,
                masked: finding.masked,
                bounds: `${finding.bounds.left.toFixed(1)}, ${finding.bounds.bottom.toFixed(1)} → ${finding.bounds.right.toFixed(1)}, ${finding.bounds.top.toFixed(1)}`
              }))}
            />
          </ReportSection>
          <Link href="/edit" className="btn btn-primary btn-sm">
            <AlertTriangle className="size-3.5" />
            Redact these values
          </Link>
        </>
      ) : (
        <Callout tone="success" title="No candidates found">
          No email, SSN or card-number pattern was matched in the decoded text of these pages.
        </Callout>
      )}
    </div>
  );
}

function ImagesTab({ defaultId }: { defaultId: string }) {
  const [artifactId, setArtifactId] = useDocument(defaultId);
  const [placements, setPlacements] = useState<ImagesReport | null>(null);
  const [scanning, setScanning] = useState(false);
  const [scanError, setScanError] = useState<string | null>(null);
  const extract = useToolRun<Record<string, unknown>>();

  useEffect(() => {
    if (!artifactId) return;
    let cancelled = false;
    setScanning(true);
    setScanError(null);
    api
      .images(artifactId)
      .then((report) => {
        if (!cancelled) setPlacements(report);
      })
      .catch((cause) => {
        if (!cancelled) setScanError(cause instanceof Error ? cause.message : "The image list could not be read");
      })
      .finally(() => {
        if (!cancelled) setScanning(false);
      });
    return () => {
      cancelled = true;
    };
  }, [artifactId]);

  return (
    <div className="space-y-5">
      <div className="split-wrap">
        <ConfigCard
          description="Placements come from the page's XObject resources; extraction writes each distinct image as its own artifact."
          footer={
            <RunBar
              label="Extract images"
              pending={extract.pending}
              disabled={!artifactId || (placements?.images.length ?? 0) === 0}
              onRun={() => extract.run(() => tools.extractImages({ artifactId }))}
              hint="Unavailable when the document paints no images."
            />
          }
        >
          <DocumentSelect value={artifactId} onChange={setArtifactId} label="Document" />
          <div className="rounded-lg border border-line bg-surface-muted/60 px-3 py-2.5">
            <p className="text-[11.5px] leading-[1.5] text-muted">
              Extraction preserves the encoded image where the filter allows it, and re-encodes to PNG only when the stream is not directly
              usable.
            </p>
          </div>
        </ConfigCard>

        <div className="card overflow-hidden">
          <div className="flex items-center justify-between border-b border-line px-4 py-3">
            <div>
              <h2 className="text-[13px] font-semibold text-ink">Placed images</h2>
              <p className="text-[11.5px] text-muted">Every image XObject painted by the selected pages.</p>
            </div>
            {scanning ? <Pill>reading…</Pill> : placements ? <Pill tone="accent">{placements.images.length}</Pill> : null}
          </div>
          <div className="px-4 py-4">
            {scanError ? (
              <Callout tone="danger" title="The image list could not be read">{scanError}</Callout>
            ) : placements && placements.images.length > 0 ? (
              <DataTable
                columns={[
                  { key: "page", label: "Page", align: "right" },
                  { key: "label", label: "Object", mono: true },
                  { key: "pixels", label: "Pixels", nowrap: true },
                  { key: "dpi", label: "Effective dpi", nowrap: true },
                  { key: "colour", label: "Colour" },
                  { key: "filter", label: "Filter", mono: true },
                  { key: "bytes", label: "Encoded", align: "right" }
                ]}
                rows={placements.images.map((image) => ({
                  page: image.page,
                  label: `${image.objectNumber} · ${image.format}`,
                  pixels: `${image.pixelWidth}×${image.pixelHeight}`,
                  dpi: `${Math.round(image.dpiX)}×${Math.round(image.dpiY)}`,
                  colour: `${image.colourSpace ?? "—"} ${image.bitsPerComponent}b`,
                  filter: image.filter ?? "—",
                  bytes: formatBytes(image.encodedBytes)
                }))}
                maxHeight={360}
              />
            ) : (
              <div className="py-10 text-center text-[12px] text-muted">
                {scanning ? "Reading the resource dictionaries…" : "This document paints no images — it is vector text and graphics only."}
              </div>
            )}
          </div>
        </div>
      </div>

      {extract.result || extract.error ? (
        <ResultPanel
          result={extract.result}
          error={extract.error}
          pending={extract.pending}
          onReset={extract.reset}
          emptyTitle=""
          emptyDescription=""
          showPreview={false}
          renderReport={(report) => <GenericImagesReport report={report as { count: number; warnings: string[] }} />}
        />
      ) : null}
    </div>
  );
}

function GenericImagesReport({ report }: { report: { count: number; warnings: string[] } }) {
  return (
    <div className="space-y-3">
      <Pill tone="accent">{report.count} image{report.count === 1 ? "" : "s"} written</Pill>
      <p className="text-[12px] text-muted">Each file is listed above with its size and can be downloaded or opened directly.</p>
    </div>
  );
}
