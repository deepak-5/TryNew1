"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import {
  ArrowRight,
  ArrowUpRight,
  ArrowLeftRight,
  Braces,
  FilePlus2,
  FileSearch,
  FileText,
  Layers,
  Lock,
  ScanText,
  Sparkles,
  Upload,
  Wand2,
  BookOpen,
  Plus
} from "lucide-react";
import { api } from "@/lib/api";
import type { Artifact, Capabilities } from "@/lib/types";
import { artifactTypeLabel, formatBytes, formatDate, formatNumber, titleCase } from "@/lib/format";
import { useWorkspace } from "@/components/workspace-provider";
import { useToast } from "@/components/toast";
import { previewSrc } from "@/components/pdf-preview";
import { Button, Card, CardHeader, EmptyState, PageHeader, Pill, Stat } from "@/components/ui";
import { ENGINES, ENGINE_ICONS } from "@/lib/engines";

const AREA_ROUTES: Record<string, string> = {
  create: "/create",
  analyse: "/inspect",
  extract: "/extract",
  convert: "/convert",
  pages: "/pages",
  edit: "/edit",
  structure: "/structure",
  secure: "/secure",
  compare: "/compare"
};

const QUICK_ACTIONS = [
  {
    href: "/create",
    title: "Create from HTML",
    description: "Lay out a document with the built-in HTML/CSS engine.",
    icon: Sparkles
  },
  {
    href: "/inspect",
    title: "Inspect & validate",
    description: "Structure, fonts, xref and PDF/A · PDF/UA checks.",
    icon: FileSearch
  },
  {
    href: "/extract",
    title: "Extract content",
    description: "Text, tables, PII candidates and placed images.",
    icon: ScanText
  },
  {
    href: "/compare",
    title: "Compare revisions",
    description: "Text deltas and a rendered visual diff.",
    icon: ArrowLeftRight
  }
];

export default function OverviewPage() {
  const { artifacts, pdfs, current, health, engineRoutes, loading, upload, restoreSamples } = useWorkspace();
  const { notify } = useToast();
  const router = useRouter();
  const fileRef = useRef<HTMLInputElement>(null);
  const [capabilities, setCapabilities] = useState<Capabilities | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api
      .capabilities()
      .then(setCapabilities)
      .catch(() => setCapabilities(null));
  }, []);

  const totalBytes = artifacts.reduce((sum, artifact) => sum + artifact.size, 0);
  const recent = [...artifacts].sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1)).slice(0, 6);
  const capabilityCount = capabilities?.areas.reduce((sum, area) => sum + area.capabilities.length, 0) ?? 0;

  async function handleUpload(files: FileList | null) {
    if (!files?.length) return;
    setBusy(true);
    try {
      const artifact = await upload(files[0]);
      notify({ title: `${artifact.fileName} added to the workspace` });
      router.push(`/documents/${artifact.id}`);
    } catch (cause) {
      notify({ title: "Upload failed", description: cause instanceof Error ? cause.message : "Unknown error", tone: "error" });
    } finally {
      setBusy(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  }

  return (
    <div>
      <PageHeader
        eyebrow="Console"
        title="Document console"
        description="Six Docuzen engines, each driven in-process through one managed code path. Choose a document, run an operation, and read the engine's own report and render as evidence."
      />

      <div className="mb-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
        {ENGINES.map((engine) => {
          const Icon = ENGINE_ICONS[engine.id];
          return (
            <Link
              key={engine.id}
              href={engine.href}
              className="group flex items-start gap-3 rounded-[10px] border border-line bg-surface px-3.5 py-3 transition hover:border-[#c8d6cc] hover:bg-surface-muted/50"
            >
              <span className="mt-0.5 flex size-8 shrink-0 items-center justify-center rounded-lg bg-[#eef4f0] text-accent">
                <Icon className="size-4" />
              </span>
              <span className="min-w-0 flex-1">
                <span className="flex items-baseline gap-2">
                  <span className="text-[12.5px] font-semibold text-ink">{engine.label}</span>
                  <span className="ml-auto font-mono text-[10px] text-faint">
                    {engineRoutes[engine.id] ? `${engineRoutes[engine.id]} routes` : ""}
                  </span>
                </span>
                <span className="mt-0.5 block text-[11.5px] leading-[1.45] text-muted">{engine.blurb}</span>
              </span>
              <ArrowUpRight className="mt-1 size-3.5 shrink-0 text-faint transition group-hover:text-ink" />
            </Link>
          );
        })}
      </div>

      <input
        ref={fileRef}
        type="file"
        accept="application/pdf,.pdf"
        className="hidden"
        onChange={(event) => handleUpload(event.target.files)}
      />

      <Card className="mb-5 grid grid-cols-2 divide-line lg:grid-cols-4 lg:divide-x">
        <Stat label="Documents" value={loading ? "—" : formatNumber(pdfs.length)} hint="PDFs in the workspace" />
        <Stat label="Artifacts" value={loading ? "—" : formatNumber(artifacts.length)} hint="Uploads and engine outputs" />
        <Stat label="Workspace size" value={loading ? "—" : formatBytes(totalBytes)} hint="On disk, outside the repo" />
        <Stat
          label="PDF capabilities"
          value={capabilityCount || "—"}
          hint={capabilities ? `${capabilities.engineVersion} · 14 export formats` : "Catalogue unavailable"}
          tone="accent"
        />
      </Card>

      <div className="grid gap-5 xl:grid-cols-[minmax(0,1.65fr)_minmax(0,1fr)]">
        <div className="space-y-5">
          <Card className="overflow-hidden">
            <CardHeader
              title="Current document"
              description="Shared across every workbench in the console."
              actions={
                current ? (
                  <Link href={`/documents/${current.id}`} className="btn btn-secondary btn-sm">
                    Open
                    <ArrowRight className="size-3.5" />
                  </Link>
                ) : null
              }
            />
            {current ? (
              <CurrentDocument artifact={current} />
            ) : (
              <EmptyState
                icon={FileText}
                title={loading ? "Loading the workspace…" : "No documents yet"}
                description="Upload a PDF or restore the seeded samples, which are generated by the engine's own HTML layout pass."
                action={
                  <div className="flex gap-2">
                    <Button icon={Upload} onClick={() => fileRef.current?.click()}>
                      Upload
                    </Button>
                    <Button
                      onClick={async () => {
                        const created = await restoreSamples();
                        notify({ title: `${created} sample${created === 1 ? "" : "s"} restored` });
                      }}
                    >
                      Restore samples
                    </Button>
                  </div>
                }
              />
            )}
          </Card>

          <Card className="overflow-hidden">
            <CardHeader
              title="Recent activity"
              description="The newest files in the workspace, newest first."
              actions={
                <Link href="/library" className="btn btn-ghost btn-sm">
                  All files
                  <ArrowRight className="size-3.5" />
                </Link>
              }
            />
            {recent.length === 0 ? (
              <EmptyState icon={Layers} title="Nothing here yet" description="Files you upload and everything the engine writes will appear here." compact />
            ) : (
              <table className="table-base">
                <thead>
                  <tr>
                    <th>Document</th>
                    <th>Source</th>
                    <th className="text-right">Size</th>
                    <th>Created</th>
                  </tr>
                </thead>
                <tbody>
                  {recent.map((artifact) => (
                    <tr key={artifact.id}>
                      <td>
                        <Link href={`/documents/${artifact.id}`} className="flex min-w-0 items-center gap-2 text-ink hover:text-accent-strong">
                          <FileText className="size-3.5 shrink-0 text-faint" />
                          <span className="max-w-[300px] truncate font-medium">{artifact.fileName}</span>
                          {artifact.kind !== "pdf" ? <Pill>{artifactTypeLabel(artifact)}</Pill> : null}
                        </Link>
                        <p className="mt-0.5 truncate pl-6 text-[11px] text-faint">{artifact.operation ?? artifact.origin}</p>
                      </td>
                      <td className="capitalize text-muted">{artifact.origin}</td>
                      <td className="text-right tabular-nums text-muted">{formatBytes(artifact.size)}</td>
                      <td className="whitespace-nowrap text-muted">{formatDate(artifact.createdAt)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </Card>
        </div>

        <div className="space-y-5">
          <Card className="overflow-hidden">
            <CardHeader title="Quick actions" description="Start a flow without leaving the overview." />
            <div className="divide-y divide-line">
              {QUICK_ACTIONS.map((action) => {
                const Icon = action.icon;
                return (
                  <Link key={action.href} href={action.href} className="group flex items-start gap-3 px-4 py-3 transition hover:bg-surface-muted/70">
                    <span className="mt-0.5 flex size-7 shrink-0 items-center justify-center rounded-md border border-line bg-surface-muted">
                      <Icon className="size-3.5 text-accent" />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block text-[12.5px] font-medium text-ink">{action.title}</span>
                      <span className="mt-0.5 block text-[11.5px] leading-[1.4] text-muted">{action.description}</span>
                    </span>
                    <ArrowUpRight className="mt-1 size-3.5 shrink-0 text-faint transition group-hover:text-ink" />
                  </Link>
                );
              })}
            </div>
          </Card>

          <Card className="overflow-hidden">
            <CardHeader
              title="Capability areas"
              description="What this console can actually do — read from the API, not from a mock."
            />
            <div className="px-4 py-3">
              {capabilities ? (
                <div className="space-y-1">
                  {capabilities.areas.map((area) => (
                    <Link
                      key={area.id}
                      href={AREA_ROUTES[area.id] ?? "/library"}
                      className="group flex items-center gap-2.5 rounded-md px-1.5 py-1.5 transition hover:bg-surface-muted"
                    >
                      <span className="flex size-6 items-center justify-center rounded bg-[#f1f4f0] text-[10.5px] font-semibold text-ink-soft">
                        {area.capabilities.length}
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block text-[12.5px] font-medium text-ink">{area.title}</span>
                        <span className="block truncate text-[11px] text-faint">
                          {area.capabilities.map((capability) => capability.title).join(" · ")}
                        </span>
                      </span>
                      <ArrowRight className="size-3 shrink-0 text-faint opacity-0 transition group-hover:opacity-100" />
                    </Link>
                  ))}
                </div>
              ) : (
                <p className="px-1 py-3 text-[12px] text-muted">The capability catalogue is not reachable.</p>
              )}
            </div>
          </Card>

          <Card className="overflow-hidden">
            <CardHeader title="Environment" />
            <dl className="space-y-2.5 px-4 py-3.5 text-[12px]">
              <div className="flex items-baseline justify-between gap-3">
                <dt className="text-muted">Engine</dt>
                <dd className="text-right font-medium text-ink">
                  {health ? `${health.product} ${health.engineVersion}` : "offline"}
                </dd>
              </div>
              <div className="flex items-baseline justify-between gap-3">
                <dt className="text-muted">Runtime</dt>
                <dd className="text-right text-ink-soft">{health?.runtime ?? "—"}</dd>
              </div>
              <div className="flex items-baseline justify-between gap-3">
                <dt className="text-muted">Upload limit</dt>
                <dd className="text-right tabular-nums text-ink-soft">
                  {capabilities?.requestedLimit ? formatBytes(capabilities.requestedLimit.maxUploadBytes) : "—"}
                </dd>
              </div>
              <div>
                <dt className="text-muted">Workspace</dt>
                <dd className="mt-0.5 truncate rounded bg-[#f5f7f4] px-2 py-1 font-mono text-[10.5px] text-ink-soft">
                  {health?.workspace.root ?? "—"}
                </dd>
              </div>
            </dl>
          </Card>
        </div>
      </div>
    </div>
  );
}

function CurrentDocument({ artifact }: { artifact: Artifact }) {
  return (
    <div className="grid gap-4 px-4 py-4 sm:grid-cols-[190px_minmax(0,1fr)]">
      <div className="relative overflow-hidden rounded-lg border border-line bg-[#eef1ec]">
        {artifact.locked ? (
          <div className="flex h-[220px] flex-col items-center justify-center gap-1.5 text-center">
            <Lock className="size-4 text-warn" />
            <span className="text-[11px] text-muted">Password protected</span>
          </div>
        ) : (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={previewSrc(artifact, 1, 90)}
            alt={artifact.fileName}
            className="h-[220px] w-full object-contain py-2"
          />
        )}
        <span className="absolute bottom-1.5 left-1.5 rounded bg-white/90 px-1.5 py-0.5 text-[10px] font-medium tabular-nums text-ink-soft">
          {artifact.pageCount ?? "?"} {artifact.pageCount === 1 ? "page" : "pages"}
        </span>
      </div>

      <div className="min-w-0">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <h3 className="truncate text-[14px] font-semibold text-ink">{artifact.fileName}</h3>
            <p className="mt-0.5 text-[11.5px] text-muted">
              {artifact.origin === "sample" ? "Seeded sample" : titleCase(artifact.origin)} · added {formatDate(artifact.createdAt)}
            </p>
          </div>
          <div className="flex shrink-0 gap-1.5">
            {artifact.encrypted ? <Pill tone="warn">Encrypted</Pill> : null}
            {artifact.warnings.length > 0 ? <Pill tone="warn">{artifact.warnings.length} warning{artifact.warnings.length === 1 ? "" : "s"}</Pill> : null}
          </div>
        </div>

        <dl className="mt-4 grid grid-cols-2 gap-x-4 gap-y-3">
          {[
            ["Pages", String(artifact.pageCount ?? "—")],
            ["Version", artifact.pdfVersion ?? "—"],
            ["Size", formatBytes(artifact.size)],
            ["Checksum", `${artifact.sha256.slice(0, 12)}…`]
          ].map(([label, value]) => (
            <div key={label}>
              <dt className="text-[10.5px] font-medium uppercase tracking-[0.06em] text-faint">{label}</dt>
              <dd className="mt-0.5 text-[12.5px] text-ink">{value}</dd>
            </div>
          ))}
        </dl>

        <div className="mt-4 flex flex-wrap gap-1.5">
          <Link href="/inspect" className="btn btn-secondary btn-sm">
            <FileSearch className="size-3.5" />
            Inspect
          </Link>
          <Link href="/edit" className="btn btn-secondary btn-sm">
            <Wand2 className="size-3.5" />
            Edit
          </Link>
          <Link href="/structure" className="btn btn-secondary btn-sm">
            <BookOpen className="size-3.5" />
            Structure
          </Link>
          <Link href="/secure" className="btn btn-secondary btn-sm">
            <Lock className="size-3.5" />
            Secure
          </Link>
        </div>
      </div>
    </div>
  );
}
