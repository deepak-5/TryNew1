"use client";

import clsx from "clsx";
import { ChevronRight, Loader2 } from "lucide-react";
import { useId } from "react";

/* ----------------------------------------------------------------- button */

type ButtonVariant = "primary" | "secondary" | "ghost" | "danger";

export function Button({
  variant = "secondary",
  size = "md",
  loading = false,
  icon: Icon,
  className,
  children,
  ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: ButtonVariant;
  size?: "md" | "sm";
  loading?: boolean;
  icon?: React.ComponentType<{ className?: string }>;
}) {
  const variantClass =
    variant === "primary"
      ? "btn-primary"
      : variant === "ghost"
        ? "btn-ghost"
        : variant === "danger"
          ? "btn-danger"
          : "btn-secondary";
  return (
    <button
      type="button"
      {...props}
      disabled={props.disabled || loading}
      className={clsx("btn", variantClass, size === "sm" && "btn-sm", className)}
    >
      {loading ? <Loader2 className="size-3.5 animate-spin" /> : Icon ? <Icon className="size-3.5" /> : null}
      {children}
    </button>
  );
}

/* ------------------------------------------------------------------- card */

export function Card({ className, children }: { className?: string; children: React.ReactNode }) {
  return <div className={clsx("card", className)}>{children}</div>;
}

export function CardHeader({
  title,
  description,
  actions,
  className
}: {
  title: React.ReactNode;
  description?: React.ReactNode;
  actions?: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={clsx("flex items-start justify-between gap-4 border-b border-line px-5 py-4", className)}>
      <div className="min-w-0">
        <h2 className="text-[13.5px] font-semibold tracking-[-0.01em] text-ink">{title}</h2>
        {description ? <p className="mt-0.5 text-[12px] leading-[1.45] text-muted">{description}</p> : null}
      </div>
      {actions ? <div className="flex shrink-0 items-center gap-2">{actions}</div> : null}
    </div>
  );
}

export function Panel({
  title,
  description,
  actions,
  children,
  className,
  bodyClassName
}: {
  title?: React.ReactNode;
  description?: React.ReactNode;
  actions?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
  bodyClassName?: string;
}) {
  return (
    <Card className={className}>
      {title ? <CardHeader title={title} description={description} actions={actions} /> : null}
      <div className={clsx("px-5 py-4", bodyClassName)}>{children}</div>
    </Card>
  );
}

/* ------------------------------------------------------------------ fields */

export function Field({
  label,
  hint,
  htmlFor,
  required,
  error,
  children,
  className
}: {
  label?: React.ReactNode;
  hint?: React.ReactNode;
  htmlFor?: string;
  required?: boolean;
  error?: string | null;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={className}>
      {label ? (
        <label className="label" htmlFor={htmlFor}>
          {label}
          {required ? <span className="ml-0.5 text-danger">*</span> : null}
        </label>
      ) : null}
      {children}
      {error ? <p className="mt-1 text-[11.5px] text-danger">{error}</p> : null}
      {hint && !error ? <p className="mt-1 text-[11.5px] leading-[1.4] text-faint">{hint}</p> : null}
    </div>
  );
}

export function TextInput({
  className,
  ...props
}: React.InputHTMLAttributes<HTMLInputElement>) {
  return <input {...props} className={clsx("input", className)} />;
}

export function NumberInput({
  value,
  onChange,
  min,
  max,
  step,
  placeholder,
  className,
  disabled,
  id
}: {
  value: number | string;
  onChange: (value: string) => void;
  min?: number;
  max?: number;
  step?: number;
  placeholder?: string;
  className?: string;
  disabled?: boolean;
  id?: string;
}) {
  return (
    <input
      id={id}
      type="number"
      className={clsx("input", className)}
      value={value}
      min={min}
      max={max}
      step={step}
      placeholder={placeholder}
      disabled={disabled}
      onChange={(event) => onChange(event.target.value)}
    />
  );
}

export function TextArea({
  className,
  ...props
}: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea {...props} className={clsx("input", className)} />;
}

export function Select({
  options,
  className,
  ...props
}: React.SelectHTMLAttributes<HTMLSelectElement> & {
  options: Array<{ value: string; label: string }>;
}) {
  return (
    <select {...props} className={clsx("input", className)}>
      {options.map((option) => (
        <option key={option.value} value={option.value}>
          {option.label}
        </option>
      ))}
    </select>
  );
}

export function Checkbox({
  label,
  hint,
  checked,
  onChange,
  disabled
}: {
  label: React.ReactNode;
  hint?: React.ReactNode;
  checked: boolean;
  onChange: (checked: boolean) => void;
  disabled?: boolean;
}) {
  return (
    <label
      className={clsx(
        "flex cursor-pointer items-start gap-2.5 rounded-lg border border-line bg-surface px-3 py-2.5 transition",
        checked && "border-accent-line bg-accent-soft/40",
        disabled && "cursor-not-allowed opacity-60"
      )}
    >
      <input
        type="checkbox"
        className="mt-0.5 size-3.5 shrink-0 accent-[#0e6a45]"
        checked={checked}
        disabled={disabled}
        onChange={(event) => onChange(event.target.checked)}
      />
      <span className="min-w-0">
        <span className="block text-[12.5px] font-medium leading-4 text-ink-soft">{label}</span>
        {hint ? <span className="mt-0.5 block text-[11.5px] leading-[1.4] text-faint">{hint}</span> : null}
      </span>
    </label>
  );
}

export function Toggle({
  checked,
  onChange,
  label,
  hint
}: {
  checked: boolean;
  onChange: (checked: boolean) => void;
  label: string;
  hint?: string;
}) {
  const id = useId();
  return (
    <div className="flex items-center justify-between gap-4 py-1">
      <div className="min-w-0">
        <label htmlFor={id} className="block text-[12.5px] font-medium text-ink-soft">
          {label}
        </label>
        {hint ? <p className="text-[11.5px] leading-[1.4] text-faint">{hint}</p> : null}
      </div>
      <button
        id={id}
        type="button"
        role="switch"
        aria-checked={checked}
        onClick={() => onChange(!checked)}
        className={clsx(
          "relative h-[20px] w-[34px] shrink-0 rounded-full border transition",
          checked ? "border-accent bg-accent" : "border-line-strong bg-[#e6ebe6]"
        )}
      >
        <span
          className={clsx(
            "absolute top-[2px] size-[14px] rounded-full bg-white shadow-sm transition-all",
            checked ? "left-[17px]" : "left-[2px]"
          )}
        />
      </button>
    </div>
  );
}

export function Segmented<T extends string>({
  options,
  value,
  onChange,
  className
}: {
  options: Array<{ value: T; label: React.ReactNode }>;
  value: T;
  onChange: (value: T) => void;
  className?: string;
}) {
  return (
    <div className={clsx("inline-flex items-center gap-0.5 rounded-lg border border-line bg-[#f1f4f0] p-0.5", className)}>
      {options.map((option) => (
        <button
          key={option.value}
          type="button"
          onClick={() => onChange(option.value)}
          className={clsx(
            "inline-flex h-[28px] items-center justify-center gap-1.5 rounded-[6px] px-3 text-[12.5px] font-medium transition",
            value === option.value
              ? "bg-surface text-ink shadow-[0_1px_2px_rgba(19,32,26,0.08)]"
              : "text-muted hover:text-ink"
          )}
        >
          {option.label}
        </button>
      ))}
    </div>
  );
}

/* -------------------------------------------------------------------- tabs */

export interface TabItem {
  id: string;
  label: string;
  icon?: React.ComponentType<{ className?: string }>;
  badge?: React.ReactNode;
}

export function Tabs({
  tabs,
  value,
  onChange,
  className
}: {
  tabs: TabItem[];
  value: string;
  onChange: (id: string) => void;
  className?: string;
}) {
  return (
    <div className={clsx("scroll-thin flex items-center gap-1 overflow-x-auto border-b border-line", className)} role="tablist">
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const active = tab.id === value;
        return (
          <button
            key={tab.id}
            role="tab"
            aria-selected={active}
            type="button"
            onClick={() => onChange(tab.id)}
            className={clsx(
              "-mb-px inline-flex h-9 shrink-0 items-center gap-1.5 whitespace-nowrap border-b-2 px-3 text-[12.5px] font-medium transition",
              active
                ? "border-accent text-ink"
                : "border-transparent text-muted hover:border-line-strong hover:text-ink-soft"
            )}
          >
            {Icon ? <Icon className="size-3.5" /> : null}
            {tab.label}
            {tab.badge != null ? (
              <span
                className={clsx(
                  "ml-0.5 rounded-full px-1.5 py-px text-[10.5px] font-semibold tabular-nums",
                  active ? "bg-accent-soft text-accent-strong" : "bg-[#eef1ee] text-muted"
                )}
              >
                {tab.badge}
              </span>
            ) : null}
          </button>
        );
      })}
    </div>
  );
}

/* ------------------------------------------------------------------- pills */

export function Pill({
  tone = "neutral",
  dot = false,
  children,
  className
}: {
  tone?: "neutral" | "accent" | "warn" | "danger" | "info";
  dot?: boolean;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <span className={clsx("pill", `pill-${tone}`, className)}>
      {dot ? (
        <span
          className={clsx(
            "size-1.5 rounded-full",
            tone === "accent" && "bg-accent",
            tone === "warn" && "bg-warn",
            tone === "danger" && "bg-danger",
            tone === "info" && "bg-info",
            tone === "neutral" && "bg-faint"
          )}
        />
      ) : null}
      {children}
    </span>
  );
}

/* -------------------------------------------------------------- page header */

export function PageHeader({
  eyebrow,
  title,
  description,
  actions
}: {
  eyebrow?: React.ReactNode;
  title: React.ReactNode;
  description?: React.ReactNode;
  actions?: React.ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-wrap items-start justify-between gap-4">
      <div className="min-w-0">
        {eyebrow ? <div className="section-label mb-1.5">{eyebrow}</div> : null}
        <h1 className="text-[21px] font-semibold leading-7 tracking-[-0.02em] text-ink">{title}</h1>
        {description ? <p className="mt-1 max-w-[70ch] text-[13px] leading-[1.55] text-muted">{description}</p> : null}
      </div>
      {actions ? <div className="flex shrink-0 flex-wrap items-center gap-2">{actions}</div> : null}
    </div>
  );
}

/* ---------------------------------------------------------------- feedback */

export function Spinner({ className }: { className?: string }) {
  return <Loader2 className={clsx("animate-spin text-accent", className ?? "size-4")} />;
}

export function EmptyState({
  icon: Icon,
  title,
  description,
  action,
  compact = false
}: {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  description?: string;
  action?: React.ReactNode;
  compact?: boolean;
}) {
  return (
    <div className={clsx("flex flex-col items-center justify-center text-center", compact ? "px-6 py-10" : "px-6 py-16")}>
      <div className="mb-3 flex size-10 items-center justify-center rounded-full border border-line bg-surface-muted">
        <Icon className="size-4.5 text-faint" />
      </div>
      <p className="text-[13px] font-medium text-ink">{title}</p>
      {description ? <p className="mt-1 max-w-[46ch] text-[12px] leading-[1.5] text-muted">{description}</p> : null}
      {action ? <div className="mt-4">{action}</div> : null}
    </div>
  );
}

export function Callout({
  tone = "info",
  title,
  children,
  className,
  action
}: {
  tone?: "info" | "warn" | "danger" | "success";
  title?: React.ReactNode;
  children?: React.ReactNode;
  className?: string;
  action?: React.ReactNode;
}) {
  const toneClass =
    tone === "warn"
      ? "border-[#f0dcba] bg-warn-soft text-[#7a470f]"
      : tone === "danger"
        ? "border-[#f2cdc9] bg-danger-soft text-[#8a251c]"
        : tone === "success"
          ? "border-accent-line bg-accent-soft text-accent-strong"
          : "border-[#cfe0f4] bg-info-soft text-[#1d4a7c]";
  return (
    <div className={clsx("flex flex-wrap items-start gap-x-3 gap-y-2 rounded-lg border px-3.5 py-2.5 text-[12.5px] leading-[1.5]", toneClass, className)}>
      {/* basis keeps the copy readable in a narrow card: the action drops to its own row
          instead of squeezing the sentence into a column of single words. */}
      <div className="min-w-0 flex-1 basis-[15rem]">
        {title ? <p className="font-semibold">{title}</p> : null}
        {children ? <div className={title ? "mt-0.5 opacity-90" : "opacity-90"}>{children}</div> : null}
      </div>
      {action ? <div className="ml-auto shrink-0">{action}</div> : null}
    </div>
  );
}

export function ErrorNote({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <Callout
      tone="danger"
      title="The engine refused this run"
      action={
        onRetry ? (
          <Button size="sm" variant="secondary" onClick={onRetry}>
            Retry
          </Button>
        ) : null
      }
    >
      {message}
    </Callout>
  );
}

/* ------------------------------------------------------------------ data */

export function KeyValue({
  items,
  columns = 2,
  className
}: {
  items: Array<{ label: React.ReactNode; value: React.ReactNode; mono?: boolean }>;
  columns?: 1 | 2 | 3;
  className?: string;
}) {
  return (
    <dl
      className={clsx(
        "grid gap-x-6 gap-y-3",
        columns === 1 ? "grid-cols-1" : columns === 3 ? "grid-cols-3" : "grid-cols-2",
        className
      )}
    >
      {items.map((item, index) => (
        <div key={index} className="min-w-0">
          <dt className="text-[11px] font-medium uppercase tracking-[0.05em] text-faint">{item.label}</dt>
          <dd className={clsx("mt-0.5 break-words text-[13px] text-ink", item.mono && "font-mono text-[12px]")}>
            {item.value === "" || item.value == null ? <span className="text-faint">—</span> : item.value}
          </dd>
        </div>
      ))}
    </dl>
  );
}

export function Stat({
  label,
  value,
  hint,
  tone = "neutral"
}: {
  label: string;
  value: React.ReactNode;
  hint?: React.ReactNode;
  tone?: "neutral" | "accent" | "warn" | "danger";
}) {
  return (
    <div className="px-5 py-4">
      <div className="text-[11px] font-medium uppercase tracking-[0.06em] text-faint">{label}</div>
      <div
        className={clsx(
          "mt-1 text-[22px] font-semibold leading-7 tracking-[-0.02em] tabular-nums",
          tone === "accent" && "text-accent-strong",
          tone === "warn" && "text-warn",
          tone === "danger" && "text-danger",
          tone === "neutral" && "text-ink"
        )}
      >
        {value}
      </div>
      {hint ? <div className="mt-0.5 text-[11.5px] text-muted">{hint}</div> : null}
    </div>
  );
}

export function JsonBlock({ value, label = "Raw response" }: { value: unknown; label?: string }) {
  const text = JSON.stringify(value, null, 2);
  return (
    <details className="group rounded-lg border border-line bg-surface-muted">
      <summary className="flex cursor-pointer list-none items-center gap-1.5 px-3 py-2 text-[12px] font-medium text-muted transition hover:text-ink">
        <ChevronRight className="size-3.5 transition group-open:rotate-90" />
        {label}
        <span className="ml-auto font-mono text-[11px] text-faint">{(text.length / 1024).toFixed(1)} KB</span>
      </summary>
      <pre className="scroll-thin max-h-[420px] overflow-auto border-t border-line px-3 py-2.5 font-mono text-[11.5px] leading-[1.55] text-ink-soft">
        {text}
      </pre>
    </details>
  );
}

export function Divider({ className }: { className?: string }) {
  return <div className={clsx("h-px w-full bg-line", className)} />;
}

/* ------------------------------------------------------------------ modal */

export function Modal({
  open,
  onClose,
  title,
  description,
  children,
  footer,
  width = 440
}: {
  open: boolean;
  onClose: () => void;
  title: React.ReactNode;
  description?: React.ReactNode;
  children?: React.ReactNode;
  footer?: React.ReactNode;
  width?: number;
}) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[90] flex items-start justify-center overflow-y-auto px-4 py-[10vh]">
      <div className="fixed inset-0 bg-[#13201a]/30 backdrop-blur-[2px]" onClick={onClose} />
      <div
        role="dialog"
        aria-modal="true"
        className="animate-in relative w-full rounded-xl border border-line bg-surface shadow-pop"
        style={{ maxWidth: width }}
      >
        <div className="border-b border-line px-5 py-4">
          <h2 className="text-[14px] font-semibold text-ink">{title}</h2>
          {description ? <p className="mt-1 text-[12px] leading-[1.5] text-muted">{description}</p> : null}
        </div>
        {children ? <div className="px-5 py-4">{children}</div> : null}
        {footer ? <div className="flex items-center justify-end gap-2 border-t border-line bg-surface-muted/60 px-5 py-3">{footer}</div> : null}
      </div>
    </div>
  );
}

export function ConfirmDialog({
  open,
  title,
  description,
  confirmLabel = "Delete",
  onConfirm,
  onClose,
  pending
}: {
  open: boolean;
  title: string;
  description: React.ReactNode;
  confirmLabel?: string;
  onConfirm: () => void;
  onClose: () => void;
  pending?: boolean;
}) {
  return (
    <Modal
      open={open}
      onClose={onClose}
      title={title}
      description={description}
      footer={
        <>
          <Button onClick={onClose} disabled={pending}>
            Cancel
          </Button>
          <Button variant="danger" onClick={onConfirm} loading={pending}>
            {confirmLabel}
          </Button>
        </>
      }
    />
  );
}
