"use client";

import clsx from "clsx";
import {
  ArrowUpRight,
  CheckCircle2,
  Download,
  FileJson,
  FileText,
  Image as ImageIcon,
  Loader2,
  RotateCcw,
  TriangleAlert
} from "lucide-react";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { artifactTypeLabel, formatBytes, formatDuration } from "@/lib/format";
import type { Artifact, OperationResponse } from "@/lib/types";
import { Button, Card, ErrorNote, JsonBlock, Pill, Spinner, Tabs } from "./ui";
import { PdfPreview } from "./pdf-preview";
import { GenericReport, WarningsList } from "./report-view";
import { useWorkspace } from "./workspace-provider";
import { useToast } from "./toast";

export interface ResultPanelProps {
  result: OperationResponse<never> | OperationResponse<any> | null;
  error: string | null;
  pending: boolean;
  emptyTitle: string;
  emptyDescription: string;
  emptyIcon?: React.ComponentType<{ className?: string }>;
  renderReport?: (report: any, result: OperationResponse<any>) => React.ReactNode;
  showPreview?: boolean;
  onReset?: () => void;
  pendingLabel?: string;
}

export function ResultPanel({
  result,
  error,
  pending,
  emptyTitle,
  emptyDescription,
  emptyIcon: EmptyIcon = ArrowUpRight,
  renderReport,
  showPreview = true,
  onReset,
  pendingLabel = "Running in the engine…"
}: ResultPanelProps) {
  const [tab, setTab] = useState("preview");

  useEffect(() => {
    if (!result) return;
    const first = result.artifacts[0];
    if (first && showPreview && (first.kind === "pdf" || first.kind === "image")) setTab("preview");
    // A binary package has nothing to show inline — its "File" tab is a download and a
    // note. When the run described what it did, that description is the useful view.
    else if (renderReport || (first && isPackage(first) && result.report)) setTab("report");
    else if (first) setTab("content");
    else setTab("report");
  }, [result, showPreview, renderReport]);

  if (pending) {
    return (
      <Card className="flex min-h-[420px] flex-col items-center justify-center px-8 py-16 text-center">
        <div className="relative flex size-11 items-center justify-center rounded-full border border-accent-line bg-accent-soft">
          <Spinner className="size-5" />
        </div>
        <p className="mt-4 text-[13.5px] font-medium text-ink">{pendingLabel}</p>
        <p className="mt-1 max-w-[40ch] text-[12px] leading-[1.5] text-muted">
          The document is being read and rewritten in-process. Nothing leaves this machine.
        </p>
        <div className="mt-6 w-full max-w-[280px] space-y-2">
          {[92, 74, 58, 40].map((width, index) => (
            <div
              key={index}
              className="h-2 animate-pulse rounded-full bg-[#edf1ec]"
              style={{ width: `${width}%`, animationDelay: `${index * 120}ms` }}
            />
          ))}
        </div>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="px-5 py-5">
        <ErrorNote message={error} onRetry={undefined} />
        <div className="mt-3 flex items-center gap-2">
          <p className="text-[11.5px] text-faint">
            Engine refusals are deliberate: the operation is not able to preserve the document's structure, so nothing was written.
          </p>
          {onReset ? (
            <Button size="sm" variant="ghost" onClick={onReset} className="ml-auto shrink-0">
              Clear
            </Button>
          ) : null}
        </div>
      </Card>
    );
  }

  if (!result) {
    return (
      <Card className="flex min-h-[420px] flex-col items-center justify-center px-8 py-16 text-center">
        <div className="mb-3 flex size-10 items-center justify-center rounded-full border border-line bg-surface-muted">
          <EmptyIcon className="size-4.5 text-faint" />
        </div>
        <p className="text-[13px] font-medium text-ink">{emptyTitle}</p>
        <p className="mt-1 max-w-[44ch] text-[12px] leading-[1.5] text-muted">{emptyDescription}</p>
      </Card>
    );
  }

  const first = result.artifacts[0] ?? null;
  const hasPreviewable = showPreview && first && (first.kind === "pdf" || first.kind === "image");
  const hasContent = first && (first.kind === "text" || first.kind === "data" || isPackage(first));
  const warnings = result.warnings ?? [];

  const tabs = [
    ...(hasPreviewable ? [{ id: "preview", label: "Preview", icon: ImageIcon }] : []),
    ...(!hasPreviewable && hasContent ? [{ id: "content", label: isPackage(first!) ? "File" : "Output", icon: FileText }] : []),
    { id: "report", label: "Report", icon: FileJson },
    ...(warnings.length > 0 ? [{ id: "warnings", label: "Warnings", icon: TriangleAlert, badge: warnings.length }] : [])
  ];

  return (
    <Card className="overflow-hidden">
      <div className="flex flex-wrap items-center gap-2 border-b border-line bg-surface-muted/60 px-4 py-2.5">
        <span className="flex items-center gap-1.5 text-[12px] font-semibold text-ink">
          <CheckCircle2 className="size-3.5 text-accent" />
          Run complete
        </span>
        <span className="text-[11.5px] text-faint">{formatDuration(result.elapsedMs)}</span>
        {warnings.length > 0 ? (
          <Pill tone="warn">
            <TriangleAlert className="size-3" />
            {warnings.length} warning{warnings.length === 1 ? "" : "s"}
          </Pill>
        ) : null}
        <div className="ml-auto flex items-center gap-1.5">
          {onReset ? (
            <button
              type="button"
              onClick={onReset}
              className="inline-flex items-center gap-1 rounded-md px-1.5 py-1 text-[11.5px] text-muted transition hover:bg-canvas hover:text-ink"
            >
              <RotateCcw className="size-3" />
              Clear
            </button>
          ) : null}
        </div>
      </div>

      {result.artifacts.length > 0 ? (
        <div className="border-b border-line px-4 py-3">
          <div className="mb-2 section-label">
            Output · {result.artifacts.length} file{result.artifacts.length === 1 ? "" : "s"}
          </div>
          <div className="space-y-1.5">
            {result.artifacts.map((artifact) => (
              <ArtifactRow key={artifact.id} artifact={artifact} />
            ))}
          </div>
        </div>
      ) : (
        <div className="border-b border-line px-4 py-2.5">
          <p className="text-[11.5px] text-muted">
            <span className="font-medium text-ink-soft">Read-only run.</span> The engine reported on the document and wrote no files.
          </p>
        </div>
      )}

      <Tabs tabs={tabs} value={tab} onChange={setTab} className="px-3" />

      <div className="min-h-[320px] px-4 py-4">
        {tab === "preview" && first ? (
          first.kind === "pdf" ? (
            <div className="overflow-hidden rounded-lg border border-line">
              <PdfPreview artifact={first} maxHeight="58vh" />
            </div>
          ) : (
            <a href={first.contentUrl} target="_blank" rel="noreferrer" className="block overflow-hidden rounded-lg border border-line bg-[#eef1ec] p-3">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={first.contentUrl} alt={first.fileName} className="mx-auto max-h-[58vh] rounded bg-white paper-shadow" />
            </a>
          )
        ) : null}

        {tab === "content" && first ? (
          isPackage(first) ? <PackageArtifact artifact={first} /> : <TextArtifact artifact={first} />
        ) : null}

        {tab === "report" ? (
          <div className="space-y-4">
            {renderReport ? renderReport(result.report, result as OperationResponse<any>) : <GenericReport report={result.report} />}
            <JsonBlock value={result.report} label="Report JSON" />
          </div>
        ) : null}

        {tab === "warnings" ? <WarningsList warnings={warnings} /> : null}
      </div>
    </Card>
  );
}

/**
 * Office/e-mail outputs are containers; the console shows their facts and lets you
 * download. Text formats a package can be converted to (CSV, Markdown, HTML, text)
 * are still readable inline, so they keep the text view.
 */
const TEXTUAL = ["csv", "tsv", "md", "html", "htm", "json", "xml", "txt"];

export function isPackage(artifact: Artifact | null | undefined): boolean {
  if (!artifact) return false;
  if (!["word", "sheet", "slides", "email"].includes(artifact.kind)) return false;
  const extension = artifact.fileName.split(".").pop()?.toLowerCase() ?? "";
  return !TEXTUAL.includes(extension);
}

function PackageArtifact({ artifact }: { artifact: Artifact }) {
  return (
    <div className="rounded-lg border border-line bg-surface p-4">
      <div className="flex items-start gap-3">
        <span className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-[#eef4f0] text-accent">
          <FileText className="size-4.5" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="truncate text-[13px] font-medium text-ink">{artifact.fileName}</p>
          <p className="mt-0.5 text-[11.5px] text-muted">
            {artifactTypeLabel(artifact)} · {formatBytes(artifact.size)}
            {artifact.operation ? ` · ${artifact.operation}` : ""}
          </p>
          {isPackage(artifact) ? (
            <p className="mt-2 text-[11.5px] leading-[1.5] text-muted">
              This {artifact.kind === "slides" ? "presentation" : artifact.kind === "sheet" ? "workbook" : artifact.kind === "email" ? "message" : "document"} is a
              binary package, so there is nothing to show inline. Convert it with the same engine to read it as PDF, PNG or text.
            </p>
          ) : null}
          <a
            href={`${artifact.contentUrl}?download=1`}
            download={artifact.fileName}
            className="btn btn-secondary btn-sm mt-3 inline-flex"
          >
            <Download className="size-3.5" />
            Download
          </a>
        </div>
      </div>
    </div>
  );
}

function ArtifactRow({ artifact }: { artifact: Artifact }) {
  const { setCurrent } = useWorkspace();
  const { notify } = useToast();
  const router = useRouter();
  const isPdf = artifact.kind === "pdf";

  const icon = isPdf ? FileText : artifact.kind === "image" ? ImageIcon : artifact.kind === "data" ? FileJson : FileText;

  return (
    <div className="flex items-center gap-2.5 rounded-lg border border-line bg-surface px-2.5 py-2">
      <span
        className={clsx(
          "flex size-7 shrink-0 items-center justify-center rounded-md",
          isPdf ? "bg-accent-soft text-accent" : "bg-[#f1f4f0] text-muted"
        )}
      >
        {(() => {
          const Icon = icon;
          return <Icon className="size-3.5" />;
        })()}
      </span>
      <div className="min-w-0 flex-1">
        <p className="truncate text-[12.5px] font-medium text-ink">{artifact.fileName}</p>
        <p className="truncate text-[11px] text-faint">
          {artifactTypeLabel(artifact)} · {formatBytes(artifact.size)}
          {artifact.pageCount ? ` · ${artifact.pageCount} page${artifact.pageCount === 1 ? "" : "s"}` : ""}
          {artifact.operation ? ` · ${artifact.operation}` : ""}
        </p>
      </div>
      <div className="flex shrink-0 items-center gap-1">
        {isPdf ? (
          <button
            type="button"
            onClick={() => {
              setCurrent(artifact.id);
              notify({ title: "Opened as the current document", description: artifact.fileName });
              router.push(`/documents/${artifact.id}`);
            }}
            className="btn btn-secondary btn-sm"
          >
            Open
          </button>
        ) : null}
        <a
          href={`${artifact.contentUrl}?download=1`}
          download={artifact.fileName}
          className="rounded-md p-1.5 text-muted transition hover:bg-canvas hover:text-ink"
          aria-label={`Download ${artifact.fileName}`}
        >
          <Download className="size-3.5" />
        </a>
      </div>
    </div>
  );
}

function TextArtifact({ artifact }: { artifact: Artifact }) {
  const [text, setText] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    setText(null);
    setError(null);
    fetch(artifact.contentUrl)
      .then((response) => {
        if (!response.ok) throw new Error(`Content read failed (${response.status})`);
        return response.text();
      })
      .then((value) => {
        if (!cancelled) setText(value.length > 300_000 ? `${value.slice(0, 300_000)}\n\n… truncated for display (${formatBytes(value.length)})` : value);
      })
      .catch((cause) => {
        if (!cancelled) setError(cause instanceof Error ? cause.message : "Could not read the output");
      });
    return () => {
      cancelled = true;
    };
  }, [artifact.contentUrl, artifact.id]);

  if (error) return <ErrorNote message={error} />;
  if (text == null) {
    return (
      <div className="flex items-center justify-center gap-2 py-16 text-[12px] text-muted">
        <Loader2 className="size-3.5 animate-spin" />
        Reading output…
      </div>
    );
  }

  const isJson = artifact.mediaType === "application/json" || artifact.fileName.endsWith(".json");
  return (
    <div className="overflow-hidden rounded-lg border border-line">
      <div className="flex items-center justify-between border-b border-line bg-surface-muted px-3 py-1.5">
        <span className="font-mono text-[11px] text-faint">{artifact.fileName}</span>
        <span className="text-[11px] text-faint">{formatBytes(artifact.size)}</span>
      </div>
      <pre className="scroll-thin max-h-[56vh] overflow-auto bg-surface px-4 py-3 font-mono text-[11.5px] leading-[1.65] text-ink-soft">
        {isJson ? prettyJson(text) : text}
      </pre>
    </div>
  );
}

function prettyJson(text: string): string {
  try {
    return JSON.stringify(JSON.parse(text), null, 2);
  } catch {
    return text;
  }
}
