"use client";

function parseRow(line: string): string[] {
  return line
    .trim()
    .replace(/^\|/, "")
    .replace(/\|$/, "")
    .split("|")
    .map((cell) => cell.trim());
}

export function MarkdownTable({ markdown }: { markdown: string }) {
  const lines = markdown.trim().split(/\r?\n/).filter(Boolean);
  if (lines.length === 0) return null;
  const header = parseRow(lines[0]);
  const bodyStart = lines.length > 1 && /^[\s|:-]+$/.test(lines[1]) ? 2 : 1;
  const body = lines.slice(bodyStart).map(parseRow);

  return (
    <div className="scroll-thin overflow-auto rounded-lg border border-line">
      <table className="table-base">
        <thead>
          <tr>
            {header.map((cell, index) => (
              <th key={index} className="whitespace-nowrap">
                {cell || "—"}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {body.map((row, rowIndex) => (
            <tr key={rowIndex}>
              {header.map((_, cellIndex) => (
                <td key={cellIndex} className="align-top text-[12px] text-ink-soft">
                  {row[cellIndex] ?? ""}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
