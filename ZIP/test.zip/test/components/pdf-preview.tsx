"use client";

import clsx from "clsx";
import { ChevronLeft, ChevronRight, Download, FileWarning, Loader2 } from "lucide-react";
import { useEffect, useState } from "react";
import type { Artifact } from "@/lib/types";

export function previewSrc(artifact: Artifact, page: number, dpi: number): string {
  return `${artifact.previewUrl ?? `/api/artifacts/${artifact.id}/preview`}?page=${page}&dpi=${dpi}`;
}

export function PdfPreview({
  artifact,
  className,
  initialPage = 1,
  initialDpi = 110,
  toolbar = true,
  maxHeight = "62vh",
  onPageChange
}: {
  artifact: Artifact;
  className?: string;
  initialPage?: number;
  initialDpi?: number;
  toolbar?: boolean;
  maxHeight?: string;
  onPageChange?: (page: number) => void;
}) {
  const total = artifact.pageCount ?? 1;
  const [page, setPage] = useState(Math.min(Math.max(initialPage, 1), total));
  const [dpi, setDpi] = useState(initialDpi);
  const [state, setState] = useState<"loading" | "ready" | "error">("loading");
  const [failure, setFailure] = useState<string | null>(null);

  useEffect(() => {
    setPage(Math.min(Math.max(initialPage, 1), total));
  }, [artifact.id, initialPage, total]);

  useEffect(() => {
    onPageChange?.(page);
  }, [page, onPageChange]);

  useEffect(() => {
    setState("loading");
    setFailure(null);
  }, [page, dpi, artifact.id]);

  const go = (next: number) => setPage(Math.min(Math.max(next, 1), total));

  if (artifact.locked) {
    return (
      <div className={clsx("flex flex-col items-center justify-center gap-2 px-6 py-14 text-center", className)}>
        <FileWarning className="size-5 text-warn" />
        <p className="text-[12.5px] font-medium text-ink">This document is password protected</p>
        <p className="max-w-[38ch] text-[11.5px] leading-[1.5] text-muted">
          Renders are only available after the password is supplied to the operation that opens it.
        </p>
      </div>
    );
  }

  return (
    <div className={clsx("flex min-w-0 flex-col", className)}>
      {toolbar ? (
        <div className="flex items-center gap-1.5 border-b border-line px-3 py-2">
          <button
            type="button"
            onClick={() => go(page - 1)}
            disabled={page <= 1}
            className="rounded-md p-1 text-muted transition hover:bg-canvas hover:text-ink disabled:opacity-35"
            aria-label="Previous page"
          >
            <ChevronLeft className="size-4" />
          </button>
          <span className="min-w-[86px] text-center text-[12px] tabular-nums text-ink-soft">
            Page <span className="font-medium text-ink">{page}</span> / {total}
          </span>
          <button
            type="button"
            onClick={() => go(page + 1)}
            disabled={page >= total}
            className="rounded-md p-1 text-muted transition hover:bg-canvas hover:text-ink disabled:opacity-35"
            aria-label="Next page"
          >
            <ChevronRight className="size-4" />
          </button>

          <div className="ml-auto flex items-center gap-1 rounded-md border border-line bg-surface-muted p-0.5">
            {[80, 110, 150].map((value) => (
              <button
                key={value}
                type="button"
                onClick={() => setDpi(value)}
                className={clsx(
                  "rounded px-1.5 py-0.5 text-[10.5px] font-medium tabular-nums transition",
                  dpi === value ? "bg-surface text-ink shadow-[0_1px_1px_rgba(19,32,26,0.08)]" : "text-faint hover:text-ink-soft"
                )}
                title={`Render at ${value} dpi`}
              >
                {value}
              </button>
            ))}
          </div>
          <a
            href={`${artifact.contentUrl}?download=1`}
            download={artifact.fileName}
            className="rounded-md p-1 text-muted transition hover:bg-canvas hover:text-ink"
            aria-label="Download PDF"
          >
            <Download className="size-3.5" />
          </a>
        </div>
      ) : null}

      <div className="scroll-thin relative flex flex-1 items-start justify-center overflow-auto bg-[#eef1ec] p-4" style={{ maxHeight }}>
        {state === "loading" ? (
          <div className="absolute inset-0 z-1 flex items-center justify-center bg-[#eef1ec]/70">
            <Loader2 className="size-4 animate-spin text-accent" />
          </div>
        ) : null}
        {state === "error" ? (
          <div className="flex max-w-[46ch] flex-col items-center gap-2 py-12 text-center">
            <FileWarning className="size-5 text-warn" />
            <p className="text-[12.5px] font-medium text-ink">This page could not be rendered</p>
            <p className="text-[11.5px] leading-[1.5] text-muted">{failure ?? "The engine returned no image for this page."}</p>
          </div>
        ) : (
          <img
            key={`${artifact.id}-${page}-${dpi}`}
            src={previewSrc(artifact, page, dpi)}
            alt={`${artifact.fileName} page ${page}`}
            onLoad={() => setState("ready")}
            onError={() => {
              setState("error");
              // The image request failed; the API explains why in its error envelope.
              fetch(previewSrc(artifact, page, dpi))
                .then(async (response) => {
                  const body = (await response.json().catch(() => null)) as { error?: { message?: string } } | null;
                  if (body?.error?.message) setFailure(body.error.message);
                })
                .catch(() => undefined);
            }}
            className="max-w-full rounded-[2px] bg-white paper-shadow"
            style={{ opacity: state === "ready" ? 1 : 0, transition: "opacity 120ms ease" }}
          />
        )}
      </div>
    </div>
  );
}

export function PageThumb({
  artifact,
  page,
  active,
  onClick
}: {
  artifact: Artifact;
  page: number;
  active?: boolean;
  onClick?: () => void;
}) {
  const [loaded, setLoaded] = useState(false);
  return (
    <button
      type="button"
      onClick={onClick}
      className={clsx(
        "group flex w-full flex-col gap-1.5 rounded-lg border p-1.5 text-left transition",
        active ? "border-accent bg-accent-soft/50" : "border-line bg-surface hover:border-line-strong"
      )}
    >
      <div className="relative flex aspect-[1/1.31] items-center justify-center overflow-hidden rounded bg-[#eef1ec]">
        {!loaded ? <Loader2 className="size-3.5 animate-spin text-faint" /> : null}
        <img
          src={previewSrc(artifact, page, 60)}
          alt={`Page ${page}`}
          loading="lazy"
          onLoad={() => setLoaded(true)}
          className="h-full w-full object-contain"
        />
      </div>
      <span className="px-0.5 text-[11px] font-medium tabular-nums text-muted">Page {page}</span>
    </button>
  );
}
