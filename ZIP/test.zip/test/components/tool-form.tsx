"use client";

import { useRef, useState } from "react";
import clsx from "clsx";
import { ChevronDown, FileText, Play, Upload } from "lucide-react";
import { useWorkspace } from "./workspace-provider";
import { useToast } from "./toast";
import { formatBytes } from "@/lib/format";
import { Card } from "./ui";

const ACCEPT_INFO: Record<string, { accept: string; label: string }> = {
  pdf: { accept: ".pdf,application/pdf", label: "PDF" },
  word: {
    accept: ".docx,.doc,.rtf,.odt,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/msword",
    label: "Word / DOCX"
  },
  sheet: {
    accept: ".xlsx,.xlsm,.xltx,.xls,.xlsb,.ods,.csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/csv",
    label: "Spreadsheet / Excel"
  },
  slides: {
    accept: ".pptx,.pptm,.potx,.odp,application/vnd.openxmlformats-officedocument.presentationml.presentation",
    label: "Presentation / PPTX"
  },
  email: {
    accept: ".eml,.msg,.mht,.mhtml,.mbox,.pst,.ics,.vcf,message/rfc822,application/vnd.ms-outlook,text/calendar,text/vcard",
    label: "Email / Message"
  },
  html: {
    accept: ".html,.htm,.xhtml,.epub,text/html,application/epub+zip",
    label: "HTML / EPUB"
  },
  text: {
    accept: ".txt,.md,.json,.xml,.css,text/plain",
    label: "Text document"
  },
  all: {
    accept: "*/*",
    label: "file"
  }
};

export function ConfigCard({
  title = "Configuration",
  description,
  children,
  footer,
  className
}: {
  title?: React.ReactNode;
  description?: React.ReactNode;
  children: React.ReactNode;
  footer?: React.ReactNode;
  className?: string;
}) {
  return (
    <Card className={clsx("overflow-hidden", className)}>
      <div className="border-b border-line px-4 py-3">
        <h2 className="text-[12.5px] font-semibold text-ink">{title}</h2>
        {description ? <p className="mt-0.5 text-[11.5px] leading-[1.45] text-muted">{description}</p> : null}
      </div>
      <div className="space-y-4 px-4 py-4">{children}</div>
      {footer ? <div className="border-t border-line bg-surface-muted/60 px-4 py-3">{footer}</div> : null}
    </Card>
  );
}

export function DocumentSelect({
  value,
  onChange,
  label = "Document",
  hint,
  include = "pdf",
  className,
  disabled
}: {
  value: string;
  onChange: (value: string) => void;
  label?: string;
  hint?: React.ReactNode;
  /** "pdf" keeps the PDF pickers; an engine kind filters to that kind; "all" shows everything. */
  include?: "pdf" | "all" | "word" | "sheet" | "slides" | "email" | "text" | "html";
  className?: string;
  disabled?: boolean;
}) {
  const { artifacts, pdfs, upload } = useWorkspace();
  const { notify } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);

  const acceptInfo = ACCEPT_INFO[include] ?? ACCEPT_INFO.pdf;

  const options =
    include === "pdf"
      ? pdfs
      : include === "all"
        ? artifacts
        : artifacts.filter((artifact) => artifact.kind === include);
  const selected = artifacts.find((artifact) => artifact.id === value) ?? null;

  const handleFiles = async (fileList: FileList | File[] | null) => {
    if (!fileList || fileList.length === 0 || disabled || uploading) return;
    const file = fileList[0];
    setUploading(true);
    setUploadError(null);
    try {
      const artifact = await upload(file);
      onChange(artifact.id);
      notify({
        title: `${file.name} uploaded`,
        description: artifact.pdfError
          ? artifact.pdfError
          : `${formatBytes(artifact.size)}${artifact.pageCount ? ` · ${artifact.pageCount} page${artifact.pageCount === 1 ? "" : "s"}` : ""}`
      });
    } catch (cause) {
      const msg = cause instanceof Error ? cause.message : "Upload failed";
      setUploadError(msg);
      notify({ title: "Upload failed", description: msg, tone: "error" });
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  // Repeated operations produce same-named derivations; disambiguate them by time
  // rather than showing three identical options.
  const nameCounts = new Map<string, number>();
  for (const option of options) nameCounts.set(option.fileName, (nameCounts.get(option.fileName) ?? 0) + 1);
  // …and by clock time, which a tester can match to what they just ran; the artifact id
  // says nothing to a reader.
  const labelFor = (artifact: (typeof options)[number]) =>
    (nameCounts.get(artifact.fileName) ?? 0) > 1
      ? `${artifact.fileName} · ${new Date(artifact.createdAt).toLocaleTimeString(undefined, {
          hour: "2-digit",
          minute: "2-digit",
          second: "2-digit"
        })}`
      : artifact.fileName;

  return (
    <div className={className}>
      <div className="mb-1.5 flex items-baseline justify-between">
        <label className="label mb-0" htmlFor={`doc-${label}`}>
          {label}
        </label>
        {hint ? <span className="text-[11px] text-faint">{hint}</span> : null}
      </div>

      {/* Drag & drop upload target */}
      <div
        onDragOver={(e) => {
          e.preventDefault();
          if (!disabled && !uploading) setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragging(false);
          handleFiles(e.dataTransfer.files);
        }}
        onClick={() => !disabled && !uploading && fileInputRef.current?.click()}
        className={clsx(
          "group relative flex cursor-pointer items-center justify-center gap-2 rounded-lg border border-dashed py-2 px-3 text-[11.5px] transition select-none",
          dragging
            ? "border-accent bg-accent-soft/80 text-accent font-medium shadow-sm ring-2 ring-accent/20"
            : "border-line-strong bg-surface hover:border-accent hover:bg-surface-muted/60 text-muted hover:text-ink",
          disabled && "opacity-50 cursor-not-allowed pointer-events-none"
        )}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept={acceptInfo.accept}
          className="hidden"
          disabled={disabled || uploading}
          onChange={(e) => handleFiles(e.target.files)}
        />
        {uploading ? (
          <>
            <span className="size-3.5 animate-spin rounded-full border-2 border-line-strong border-t-accent" />
            <span className="font-medium text-accent">Uploading {acceptInfo.label}…</span>
          </>
        ) : (
          <>
            <Upload className="size-3.5 text-accent transition-transform group-hover:-translate-y-0.5" />
            <span>
              Drop <span className="font-semibold text-ink">{acceptInfo.label}</span> here, or <span className="text-accent underline underline-offset-2">browse</span>
            </span>
          </>
        )}
      </div>

      {/* Existing documents dropdown */}
      <div className="relative mt-2">
        <span className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-faint">
          <FileText className="size-3.5" />
        </span>
        <select
          id={`doc-${label}`}
          className="input pl-8 pr-8 text-[12px]"
          value={value}
          disabled={disabled || uploading}
          onChange={(event) => onChange(event.target.value)}
        >
          {options.length === 0 ? <option value="">No {acceptInfo.label} in workspace</option> : null}
          {options.map((artifact) => (
            <option key={artifact.id} value={artifact.id}>
              {labelFor(artifact)}
              {artifact.pageCount ? ` (${artifact.pageCount} p)` : ""}
            </option>
          ))}
        </select>
        <ChevronDown className="pointer-events-none absolute right-2.5 top-1/2 size-3.5 -translate-y-1/2 text-faint" />
      </div>

      {uploadError ? (
        <p className="mt-1 text-[11px] text-danger">{uploadError}</p>
      ) : selected ? (
        <p className="mt-1.5 truncate text-[11px] text-faint">
          {formatBytes(selected.size)}
          {selected.pageCount ? ` · ${selected.pageCount} page${selected.pageCount === 1 ? "" : "s"}` : ""}
          {selected.encrypted ? " · encrypted" : ""}
          {selected.origin === "upload" ? " · uploaded" : selected.origin === "sample" ? " · sample" : ""}
        </p>
      ) : null}
    </div>
  );
}

export function RunBar({
  label = "Run",
  pending,
  disabled,
  hint,
  onRun,
  tone = "primary"
}: {
  label?: string;
  pending: boolean;
  disabled?: boolean;
  hint?: React.ReactNode;
  onRun: () => void;
  tone?: "primary" | "secondary";
}) {
  return (
    <div>
      <button
        type="button"
        onClick={onRun}
        disabled={pending || disabled}
        className={clsx("btn w-full", tone === "primary" ? "btn-primary" : "btn-secondary")}
      >
        {pending ? (
          <span className="size-3.5 animate-spin rounded-full border-2 border-white/40 border-t-white" />
        ) : (
          <Play className="size-3.5" />
        )}
        {pending ? "Running…" : label}
      </button>
      {hint ? <p className="mt-1.5 text-center text-[11px] leading-[1.4] text-faint">{hint}</p> : null}
    </div>
  );
}

export function SectionDivider({ label }: { label?: string }) {
  return (
    <div className="flex items-center gap-2 pt-0.5">
      {label ? <span className="section-label whitespace-nowrap">{label}</span> : null}
      <div className="h-px flex-1 bg-line" />
    </div>
  );
}

export function InlineFields({ children, columns = 2 }: { children: React.ReactNode; columns?: 2 | 3 }) {
  return <div className={clsx("grid gap-3", columns === 3 ? "grid-cols-3" : "grid-cols-2")}>{children}</div>;
}

/**
 * Single-document workbenches share the console's current document, so moving
 * between tools never silently changes the file a tester is working on.
 */
export function useDocumentSelection() {
  const { currentId, setCurrent } = useWorkspace();
  return [currentId ?? "", setCurrent] as const;
}
