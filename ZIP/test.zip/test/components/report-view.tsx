"use client";

import clsx from "clsx";
import { AlertTriangle, Info, ShieldAlert } from "lucide-react";
import { useMemo, useState } from "react";
import { titleCase } from "@/lib/format";
import { Callout, JsonBlock, Pill } from "./ui";

export function ReportSection({
  title,
  hint,
  actions,
  children,
  className
}: {
  title?: React.ReactNode;
  hint?: React.ReactNode;
  actions?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <section className={clsx("min-w-0", className)}>
      {title ? (
        <div className="mb-2.5 flex items-end justify-between gap-3">
          <div>
            <h3 className="text-[12px] font-semibold uppercase tracking-[0.06em] text-muted">{title}</h3>
            {hint ? <p className="mt-0.5 text-[11.5px] text-faint">{hint}</p> : null}
          </div>
          {actions}
        </div>
      ) : null}
      {children}
    </section>
  );
}

function isPrimitive(value: unknown): value is string | number | boolean | null {
  return value === null || ["string", "number", "boolean"].includes(typeof value);
}

function cellText(value: unknown, depth = 0): string {
  if (value === null || value === undefined) return "—";
  if (typeof value === "string") return value;
  if (typeof value === "number") return Number.isInteger(value) ? String(value) : value.toFixed(3);
  if (typeof value === "boolean") return value ? "yes" : "no";
  if (Array.isArray(value)) return value.map((item) => cellText(item, depth)).join(", ");
  // A nested record in a table cell used to arrive as raw JSON. Reading the engine's own
  // field names is the point of the report, so render them; the untouched object is still
  // one click away under "Show raw report".
  if (depth >= 1) return JSON.stringify(value);
  const pairs = Object.entries(value as Record<string, unknown>)
    .map(([key, item]) => `${titleCase(key)} ${cellText(item, depth + 1)}`)
    .join(" · ");
  return pairs.length > 120 ? `${pairs.slice(0, 119)}…` : pairs;
}

export function DataTable({
  columns,
  rows,
  empty,
  dense = false,
  maxHeight,
  rowTone
}: {
  columns: Array<{ key: string; label: string; align?: "left" | "right"; width?: string; mono?: boolean; nowrap?: boolean }>;
  rows: Array<Record<string, unknown>>;
  empty?: React.ReactNode;
  dense?: boolean;
  maxHeight?: number;
  rowTone?: (row: Record<string, unknown>) => string | undefined;
}) {
  if (rows.length === 0) {
    return <div className="rounded-lg border border-line bg-surface-muted px-3 py-6 text-center text-[12px] text-muted">{empty ?? "Nothing to show"}</div>;
  }
  return (
    <div className={clsx("overflow-auto rounded-lg border border-line", maxHeight && "scroll-thin")} style={maxHeight ? { maxHeight } : undefined}>
      <table className="table-base">
        <thead className="sticky top-0 z-[1]">
          <tr>
            {columns.map((column) => (
              <th key={column.key} style={{ width: column.width }} className={column.align === "right" ? "text-right" : undefined}>
                {column.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, index) => (
            <tr key={index} className={rowTone?.(row)}>
              {columns.map((column) => (
                <td
                  key={column.key}
                  className={clsx(
                    column.align === "right" && "text-right tabular-nums",
                    column.mono && "font-mono text-[11.5px]",
                    (column.nowrap || column.align === "right") && "whitespace-nowrap",
                    dense && "py-[7px]"
                  )}
                >
                  {cellText(row[column.key])}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function WarningsList({ warnings, title = "Warnings" }: { warnings: string[]; title?: string }) {
  if (warnings.length === 0) {
    return (
      <div className="rounded-lg border border-line bg-surface-muted px-3.5 py-5 text-center text-[12px] text-muted">
        No warnings were recorded for this run.
      </div>
    );
  }
  return (
    <ReportSection title={title} hint={`${warnings.length} item${warnings.length === 1 ? "" : "s"} the engine reported`}>
      <ul className="space-y-1.5">
        {warnings.map((warning, index) => (
          <li key={index} className="flex items-start gap-2 rounded-lg border border-[#f0dcba] bg-warn-soft px-3 py-2 text-[12px] leading-[1.5] text-[#7a470f]">
            <AlertTriangle className="mt-0.5 size-3.5 shrink-0" />
            <span>{warning}</span>
          </li>
        ))}
      </ul>
    </ReportSection>
  );
}

export function IssueTable({
  issues,
  emptyText = "No findings. The document satisfies every check in this profile."
}: {
  issues: Array<{ severity: string; code: string; message: string; objectNumber?: number }>;
  emptyText?: string;
}) {
  if (issues.length === 0) {
    return (
      <div className="rounded-lg border border-accent-line bg-accent-soft px-3.5 py-5 text-center text-[12.5px] text-accent-strong">{emptyText}</div>
    );
  }
  return (
    <div className="overflow-hidden rounded-lg border border-line">
      {issues.map((issue, index) => {
        const isError = issue.severity === "error";
        return (
          <div key={index} className={clsx("flex items-start gap-3 border-b border-line px-3.5 py-2.5 last:border-b-0", isError ? "bg-[#fdf9f8]" : "bg-surface")}>
            <span className="mt-0.5">
              {isError ? (
                <ShieldAlert className="size-4 text-danger" />
              ) : issue.severity === "warning" ? (
                <AlertTriangle className="size-4 text-warn" />
              ) : (
                <Info className="size-4 text-info" />
              )}
            </span>
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-mono text-[11px] text-faint">{issue.code}</span>
                <Pill tone={isError ? "danger" : issue.severity === "warning" ? "warn" : "info"}>{titleCase(issue.severity)}</Pill>
                {issue.objectNumber != null ? <span className="text-[11px] text-faint">object {issue.objectNumber}</span> : null}
              </div>
              <p className="mt-1 text-[12.5px] leading-[1.5] text-ink-soft">{issue.message}</p>
            </div>
          </div>
        );
      })}
    </div>
  );
}

export function Facts({ data, columns = 2 }: { data: Record<string, unknown>; columns?: 1 | 2 | 3 }) {
  const entries = Object.entries(data).filter(([, value]) => isPrimitive(value) || Array.isArray(value));
  return (
    <dl
      className={clsx(
        "grid gap-x-6 gap-y-3",
        columns === 1 ? "grid-cols-1" : columns === 3 ? "grid-cols-2 lg:grid-cols-3" : "grid-cols-2"
      )}
    >
      {entries.map(([key, value]) => {
        // A paragraph is not a fact: squeezed into a third of the width it becomes a
        // column of broken lines, so it takes the whole row and scrolls if it is long.
        const prose = typeof value === "string" && value.length > 140;
        return (
        <div key={key} className={clsx("min-w-0", prose && "col-span-full")}>
          <dt className="text-[10.5px] font-medium uppercase tracking-[0.06em] text-faint">{titleCase(key)}</dt>
          <dd
            className={clsx(
              "mt-0.5 break-words text-[13px] text-ink",
              prose && "scroll-thin max-h-[200px] overflow-auto rounded border border-line bg-surface-muted px-2.5 py-2 leading-[1.55]"
            )}
          >
            {Array.isArray(value) ? (
              value.length === 0 ? (
                <span className="text-faint">none</span>
              ) : (
                <span className="flex flex-wrap gap-1">
                  {value.slice(0, 12).map((item, index) => (
                    <span key={index} className="rounded bg-[#f1f4f0] px-1.5 py-0.5 font-mono text-[11px] text-ink-soft">
                      {cellText(item)}
                    </span>
                  ))}
                  {value.length > 12 ? <span className="text-[11px] text-faint">+{value.length - 12}</span> : null}
                </span>
              )
            ) : (
              cellText(value)
            )}
          </dd>
        </div>
        );
      })}
    </dl>
  );
}

/**
 * Fallback renderer: walks any engine report and presents it as sections,
 * fact grids and tables instead of raw JSON. Unknown shapes stay readable.
 */
export function GenericReport({ report, skipKeys = [] }: { report: unknown; skipKeys?: string[] }) {
  const [raw, setRaw] = useState(false);
  const skip = useMemo(() => new Set(skipKeys), [skipKeys]);

  if (!report || typeof report !== "object") {
    return <div className="text-[12.5px] text-muted">This run has no structured report.</div>;
  }

  const entries = Object.entries(report as Record<string, unknown>).filter(([key]) => !skip.has(key));
  const scalars = entries.filter(([, value]) => isPrimitive(value));
  const arrays = entries.filter(([, value]) => Array.isArray(value) && (value as unknown[]).length > 0);
  const objects = entries.filter(([, value]) => value && typeof value === "object" && !Array.isArray(value));

  return (
    <div className="space-y-5">
      {scalars.length > 0 ? <Facts data={Object.fromEntries(scalars)} columns={3} /> : null}

      {arrays.map(([key, value]) => {
        const list = value as unknown[];
        const allPrimitive = list.every(isPrimitive);
        if (allPrimitive) {
          return (
            <ReportSection key={key} title={titleCase(key)} hint={`${list.length} ${list.length === 1 ? "entry" : "entries"}`}>
              <div className="flex flex-wrap gap-1.5">
                {list.slice(0, 60).map((item, index) => (
                  <span key={index} className="rounded border border-line bg-surface-muted px-2 py-1 font-mono text-[11.5px] text-ink-soft">
                    {cellText(item)}
                  </span>
                ))}
              </div>
            </ReportSection>
          );
        }
        const objectsInList = list.filter((item): item is Record<string, unknown> => Boolean(item) && typeof item === "object");
        const keys = Array.from(new Set(objectsInList.flatMap((item) => Object.keys(item)))).slice(0, 8);
        return (
          <ReportSection key={key} title={titleCase(key)} hint={`${list.length} ${list.length === 1 ? "entry" : "entries"}`}>
            <DataTable
              columns={keys.map((column) => ({ key: column, label: titleCase(column), mono: keys.length > 4 }))}
              rows={objectsInList}
              maxHeight={340}
            />
          </ReportSection>
        );
      })}

      {objects.map(([key, value]) => (
        <ReportSection key={key} title={titleCase(key)}>
          <div className="rounded-lg border border-line bg-surface-muted px-3.5 py-3">
            <Facts data={value as Record<string, unknown>} columns={2} />
          </div>
        </ReportSection>
      ))}

      <div className="flex items-center gap-2 pt-1">
        <button
          type="button"
          onClick={() => setRaw((current) => !current)}
          className="text-[11.5px] font-medium text-muted underline decoration-line-strong underline-offset-2 hover:text-ink"
        >
          {raw ? "Hide raw report" : "Show raw report"}
        </button>
      </div>
      {raw ? <JsonBlock value={report} label="Engine report (JSON)" /> : null}
    </div>
  );
}

export function VerdictBanner({
  tone,
  title,
  children,
  action
}: {
  tone: "success" | "danger" | "warn" | "info";
  title: string;
  children?: React.ReactNode;
  action?: React.ReactNode;
}) {
  return (
    <Callout tone={tone} title={title} action={action}>
      {children}
    </Callout>
  );
}
