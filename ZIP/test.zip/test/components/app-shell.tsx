"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import clsx from "clsx";
import {
  ArrowLeftRight,
  Blocks,
  BookDown,
  BookOpen,
  Boxes,
  CalendarDays,
  ChevronDown,
  ClipboardList,
  FileCode2,
  FileDown,
  FileSearch,
  FileJson,
  FileSpreadsheet,
  FileStack,
  FileText,
  FormInput,
  GitCompare,
  Grid3x3,
  Inbox,
  KeyRound,
  Layers,
  Layers3,
  LayoutDashboard,
  ListTree,
  Lock,
  Menu,
  Package,
  Palette,
  PenLine,
  Plus,
  Mail,
  MessageSquare,
  Presentation,
  Settings2,
  Shapes,
  ScanText,
  ShieldCheck,
  Search,
  Sparkles,
  Type,
  Upload,
  UserRound,
  Wand2,
  X
} from "lucide-react";
import { useHashTab, HASH_EVENT } from "@/lib/use-hash-tab";
import { useWorkspace } from "./workspace-provider";
import { useToast } from "./toast";
import { formatBytes, formatNumber } from "@/lib/format";
import { Pill } from "./ui";
import { ENGINES, ENGINE_ICONS, engineForPath, type EngineId } from "@/lib/engines";

type NavItem = { href: string; label: string; icon: typeof FileSearch };
type NavGroup = { label: string; items: NavItem[] };

const NAV_BY_ENGINE: Record<EngineId, NavGroup[]> = {
  pdf: [
    {
      label: "Workspace",
      items: [
        { href: "/", label: "Overview", icon: LayoutDashboard },
        { href: "/library", label: "Library", icon: FileStack }
      ]
    },
    { label: "Build", items: [{ href: "/create", label: "Create documents", icon: Sparkles }] },
    {
      label: "Analyse",
      items: [
        { href: "/inspect", label: "Inspect & validate", icon: FileSearch },
        { href: "/extract", label: "Extract content", icon: ScanText },
        { href: "/convert", label: "Convert", icon: FileCode2 }
      ]
    },
    {
      label: "Organise",
      items: [
        { href: "/pages", label: "Pages & layout", icon: Layers },
        { href: "/structure", label: "Structure", icon: BookOpen }
      ]
    },
    {
      label: "Transform",
      items: [
        { href: "/edit", label: "Edit & repair", icon: Wand2 },
        { href: "/secure", label: "Security", icon: Lock },
        { href: "/compare", label: "Compare", icon: ArrowLeftRight }
      ]
    }
  ],
  words: [
    {
      label: "Workspace",
      items: [
        { href: "/", label: "Overview", icon: LayoutDashboard },
        { href: "/library", label: "Library", icon: FileStack }
      ]
    },
    {
      label: "Words",
      items: [
        { href: "/words#author", label: "Author & inspect", icon: BookDown },
        { href: "/words#convert", label: "Convert & extract", icon: FileCode2 },
        { href: "/words#edit", label: "Replace", icon: Wand2 },
        { href: "/words#fields", label: "Fields & properties", icon: BookOpen },
        { href: "/words#merge", label: "Fill & merge", icon: Sparkles },
        { href: "/words#compose", label: "Compose", icon: Layers },
        { href: "/words#review", label: "Review & fields", icon: MessageSquare },
        { href: "/words#graphics", label: "Drawings & chunks", icon: Shapes },
        { href: "/words#document", label: "Document ops", icon: Settings2 }
      ]
    }
  ],
  html: [
    {
      label: "Workspace",
      items: [
        { href: "/", label: "Overview", icon: LayoutDashboard },
        { href: "/library", label: "Library", icon: FileStack }
      ]
    },
    {
      label: "HTML",
      items: [
        { href: "/html#source", label: "Source & inspect", icon: FileCode2 },
        { href: "/html#convert", label: "Convert to formats", icon: ArrowLeftRight },
        { href: "/html#query", label: "Query & tables", icon: ScanText },
        { href: "/html#sanitize", label: "Sanitise", icon: Lock },
        { href: "/html#markdown", label: "Markdown bridge", icon: Type },
        { href: "/html#a11y", label: "Accessibility", icon: ShieldCheck },
        { href: "/html#forms", label: "Forms", icon: FormInput },
        { href: "/html#text", label: "Text extraction", icon: ScanText },
        { href: "/html#packages", label: "EPUB & MHTML", icon: Package },
        { href: "/html#css", label: "CSS cascade", icon: Palette }
      ]
    }
  ],
  slides: [
    {
      label: "Workspace",
      items: [
        { href: "/", label: "Overview", icon: LayoutDashboard },
        { href: "/library", label: "Library", icon: FileStack }
      ]
    },
    {
      label: "Slides",
      items: [
        { href: "/slides#deck", label: "Deck & export", icon: Presentation },
        { href: "/slides#author", label: "Author a deck", icon: Wand2 },
        { href: "/slides#structure", label: "Structure", icon: ListTree },
        { href: "/slides#text", label: "Find & replace", icon: Search },
        { href: "/slides#notes", label: "Notes & comments", icon: MessageSquare },
        { href: "/slides#arrange", label: "Arrange slides", icon: Layers3 },
        { href: "/slides#motion", label: "Transitions & animation", icon: Sparkles },
        { href: "/slides#theme", label: "Theme & masters", icon: Shapes },
        { href: "/slides#export", label: "Exporters", icon: FileDown },
        { href: "/slides#protect", label: "Protection", icon: KeyRound }
      ]
    }
  ],
  email: [
    {
      label: "Workspace",
      items: [
        { href: "/", label: "Overview", icon: LayoutDashboard },
        { href: "/library", label: "Library", icon: FileStack }
      ]
    },
    {
      label: "Email",
      items: [
        { href: "/email#message", label: "Message & render", icon: Mail },
        { href: "/email#attachments", label: "Attachments", icon: Boxes },
        { href: "/email#verify", label: "S/MIME verify", icon: Lock },
        { href: "/email#compose", label: "Compose & edit", icon: PenLine },
        { href: "/email#headers", label: "Header read", icon: Inbox },
        { href: "/email#storage", label: "MSG, MBOX & PST", icon: Boxes },
        { href: "/email#calendar", label: "Calendar", icon: CalendarDays },
        { href: "/email#contacts", label: "Contacts", icon: UserRound },
        { href: "/email#body", label: "Body & attachments", icon: ShieldCheck }
      ]
    }
  ],
  sheets: [
    {
      label: "Workspace",
      items: [
        { href: "/", label: "Overview", icon: LayoutDashboard },
        { href: "/library", label: "Library", icon: FileStack }
      ]
    },
    {
      label: "Sheets",
      items: [
        { href: "/sheets#workbook", label: "Workbook & export", icon: FileSpreadsheet },
        { href: "/sheets#convert", label: "Convert formats", icon: FileCode2 },
        { href: "/sheets#calculate", label: "Recalculate", icon: Wand2 },
        { href: "/sheets#structure", label: "Structure read", icon: ClipboardList },
        { href: "/sheets#cells", label: "Cells & ranges", icon: Grid3x3 },
        { href: "/sheets#sheets", label: "Worksheet ops", icon: FileStack },
        { href: "/sheets#text", label: "Find & replace", icon: Search },
        { href: "/sheets#formats", label: "CSV, JSON & HTML", icon: FileJson },
        { href: "/sheets#compare", label: "Compare & merge", icon: GitCompare }
      ]
    }
  ]
};



export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    setMobileOpen(false);
  }, [pathname]);

  return (
    <div className="min-h-screen">
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-[244px] flex-col border-r border-line bg-[#fbfcfa] lg:flex">
        <SidebarContent pathname={pathname} />
      </aside>

      {mobileOpen ? (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-ink/25" onClick={() => setMobileOpen(false)} />
          <aside className="absolute inset-y-0 left-0 flex w-[264px] flex-col border-r border-line bg-[#fbfcfa] shadow-pop">
            <button
              type="button"
              onClick={() => setMobileOpen(false)}
              className="absolute right-3 top-4 rounded-md p-1.5 text-muted hover:bg-canvas"
              aria-label="Close navigation"
            >
              <X className="size-4" />
            </button>
            <SidebarContent pathname={pathname} />
          </aside>
        </div>
      ) : null}

      <div className="flex min-h-screen flex-col lg:pl-[244px]">
        <TopBar onOpenMenu={() => setMobileOpen(true)} />
        <main className="mx-auto w-full max-w-[1280px] flex-1 px-5 py-7 sm:px-7 lg:px-8">{children}</main>
      </div>
    </div>
  );
}

function SidebarContent({ pathname }: { pathname: string }) {
  const { health, artifacts, engineRoutes } = useWorkspace();
  const [switcherOpen, setSwitcherOpen] = useState(false);
  // Which tab the workbench is on, so the sidebar can mark it. Tab changes rewrite the
  // hash through `useHashTab`, which announces itself because replaceState is silent.
  const [hash, setHash] = useState("");
  useEffect(() => {
    const read = () => setHash(window.location.hash.replace(/^#/, ""));
    read();
    window.addEventListener("hashchange", read);
    window.addEventListener(HASH_EVENT, read);
    return () => {
      window.removeEventListener("hashchange", read);
      window.removeEventListener(HASH_EVENT, read);
    };
  }, []);
  const engine = engineForPath(pathname);
  const groups = NAV_BY_ENGINE[engine.id];
  const EngineIcon = ENGINE_ICONS[engine.id];

  useEffect(() => {
    setSwitcherOpen(false);
  }, [pathname]);

  return (
    <>
      <Link href="/" className="flex items-center gap-2.5 px-5 pb-4 pt-5">
        <span className="flex size-8 items-center justify-center rounded-[9px] bg-accent text-[15px] font-semibold text-white shadow-[0_1px_2px_rgba(10,83,53,0.3)]">
          D
        </span>
        <span className="min-w-0">
          <span className="block text-[14px] font-semibold leading-4 tracking-[-0.015em] text-ink">Docuzen</span>
          <span className="block text-[11px] leading-4 text-faint">Engine console</span>
        </span>
      </Link>

      <div className="relative px-3 pb-4">
        <button
          type="button"
          onClick={() => setSwitcherOpen((open) => !open)}
          aria-expanded={switcherOpen}
          className="flex w-full items-center gap-2.5 rounded-[9px] border border-line bg-white px-2.5 py-2 text-left transition hover:border-[#cdd9d1]"
        >
          <span className="flex size-6 items-center justify-center rounded-md bg-[#eef4f0] text-accent">
            <EngineIcon className="size-3.5" />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block text-[12.5px] font-semibold leading-4 text-ink">{engine.label} engine</span>
            <span className="block truncate text-[10.5px] leading-3.5 text-faint">{engine.blurb}</span>
          </span>
          <ChevronDown className={clsx("size-3.5 shrink-0 text-faint transition", switcherOpen && "rotate-180")} />
        </button>

        {switcherOpen ? (
          <div className="absolute left-3 right-3 top-[calc(100%-6px)] z-50 overflow-hidden rounded-[10px] border border-line bg-white shadow-pop">
            {ENGINES.map((option) => {
              const OptionIcon = ENGINE_ICONS[option.id];
              return (
                <Link
                  key={option.id}
                  href={option.href}
                  className={clsx(
                    "flex items-center gap-2.5 px-2.5 py-2 text-[12px] transition",
                    option.id === engine.id ? "bg-[#eef4f0] font-medium text-ink" : "text-[#54645b] hover:bg-[#f4f6f3]"
                  )}
                >
                  <OptionIcon className="size-3.5 text-[#7d8b83]" />
                  <span className="flex-1">{option.label}</span>
                  <span className="font-mono text-[10px] text-faint">
                    {engineRoutes[option.id] ? `${engineRoutes[option.id]} routes` : ""}
                  </span>
                </Link>
              );
            })}
          </div>
        ) : null}
      </div>

      <nav className="scroll-thin flex-1 overflow-y-auto px-3 pb-4">
        {groups.map((group) => (
          <div key={group.label} className="mb-4">
            <div className="section-label px-2 pb-1.5 pt-1">{group.label}</div>
            <div className="space-y-0.5">
              {group.items.map((item) => {
                const Icon = item.icon;
                const [base, itemTab] = item.href.split("#");
                const onBase = base === "/" ? pathname === "/" : pathname === base || pathname.startsWith(`${base}/`);
                // Hash-addressed groups mark the tab the page is showing — the hash, or the
                // tab a bare path opens on. Path-only groups (PDF) mark by path.
                const defaultTab = group.items.find((entry) => entry.href.includes("#"))?.href.split("#")[1];
                const active = itemTab ? onBase && itemTab === (hash || defaultTab) : onBase;
                const className = clsx(
                  "relative flex h-[33px] items-center gap-2.5 rounded-[7px] px-2 text-[12.5px] transition",
                  active ? "bg-[#e9f1ec] font-medium text-ink" : "text-[#54645b] hover:bg-[#f1f4f0] hover:text-ink"
                );
                const content = (
                  <>
                    <Icon className={clsx("size-[15px]", active ? "text-accent" : "text-[#7d8b83]")} />
                    <span className="truncate">{item.label}</span>
                    {active ? <span className="absolute -left-3 h-4 w-[2px] rounded-r bg-accent" /> : null}
                  </>
                );
                // A fragment is not a route: Next's Link swallows the hash change, so the
                // workbench never hears about it. A plain anchor leaves it to the browser.
                return item.href.includes("#") ? (
                  <a key={item.href} href={item.href} className={className}>
                    {content}
                  </a>
                ) : (
                  <Link key={item.href} href={item.href} className={className}>
                    {content}
                  </Link>
                );
              })}
            </div>
          </div>
        ))}
      </nav>

      <div className="border-t border-line px-4 py-3.5">
        <div className="flex items-center gap-2">
          <span
            className={clsx("size-1.5 rounded-full", health ? "bg-accent" : "bg-danger")}
            aria-hidden
          />
          <span className="text-[11.5px] font-medium text-ink-soft">
            {health ? "Engine connected" : "Engine offline"}
          </span>
          {health ? <span className="ml-auto font-mono text-[10.5px] text-faint">v{health.engineVersion}</span> : null}
        </div>
        <p className="mt-0.5 truncate text-[11px] text-faint">
          {health ? `${formatNumber(artifacts.length)} artifact${artifacts.length === 1 ? "" : "s"} in workspace` : "Start the API on port 5080"}
        </p>
      </div>
    </>
  );
}

/**
 * What each workbench can actually open. The bar used to offer `.pdf` on every page,
 * so the Words or Sheets page invited an upload it would then have nothing to do with.
 */
const ACCEPT_BY_ENGINE: Record<EngineId, string> = {
  pdf: ".pdf,application/pdf",
  words: ".docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  html: ".html,.htm,.mht,.mhtml,.epub,text/html,multipart/related,application/epub+zip",
  slides: ".pptx,application/vnd.openxmlformats-officedocument.presentationml.presentation",
  email: ".eml,.msg,.mbox,.pst,.ics,.vcf,message/rfc822,application/vnd.ms-outlook,text/calendar,text/vcard",
  sheets:
    ".xlsx,.xls,.ods,.csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/csv"
};

function TopBar({ onOpenMenu }: { onOpenMenu: () => void }) {
  const { upload } = useWorkspace();
  const pathname = usePathname();
  const engine = engineForPath(pathname);
  const { notify } = useToast();
  const router = useRouter();
  const fileRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);

  async function handleFiles(files: FileList | null) {
    if (!files || files.length === 0) return;
    setBusy(true);
    try {
      for (const file of Array.from(files)) {
        const artifact = await upload(file);
        notify({
          title: `${file.name} added`,
          description: artifact.pdfError
            ? artifact.pdfError
            : `${formatBytes(artifact.size)}${artifact.pageCount ? ` · ${artifact.pageCount} page${artifact.pageCount === 1 ? "" : "s"}` : ""}`
        });
      }
      router.refresh();
    } catch (cause) {
      notify({ title: "Upload failed", description: cause instanceof Error ? cause.message : "Unknown error", tone: "error" });
    } finally {
      setBusy(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  }

  return (
    <header className="sticky top-0 z-30 border-b border-line bg-[#fbfcfa]/90 backdrop-blur-md">
      <div className="mx-auto flex h-14 w-full max-w-[1280px] items-center gap-3 px-5 sm:px-7 lg:px-8">
        <button
          type="button"
          onClick={onOpenMenu}
          className="rounded-md p-1.5 text-muted hover:bg-canvas lg:hidden"
          aria-label="Open navigation"
        >
          <Menu className="size-4.5" />
        </button>
        {engine.id === "pdf" ? <DocumentPicker /> : <EngineChip engine={engine} />}
        <div className="ml-auto flex items-center gap-2">
          <input
            ref={fileRef}
            type="file"
            accept={ACCEPT_BY_ENGINE[engine.id]}
            multiple
            className="hidden"
            onChange={(event) => handleFiles(event.target.files)}
          />
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            disabled={busy}
            className="btn btn-secondary btn-sm"
          >
            {busy ? <span className="size-3.5 animate-spin rounded-full border-2 border-line-strong border-t-accent" /> : <Upload className="size-3.5" />}
            Upload
          </button>
          {/* /create authors a PDF; on the other engines the workbench's own authoring
              tab is the way in, so the bar does not offer a PDF builder. */}
          {engine.id === "pdf" ? (
            <Link href="/create" className="btn btn-primary btn-sm">
              <Plus className="size-3.5" />
              New document
            </Link>
          ) : null}
        </div>
      </div>
    </header>
  );
}

/** Singular and plural count nouns; "10 Sheets" read like the product, not the files. */
const COUNT_NOUNS: Record<EngineId, [string, string]> = {
  pdf: ["document", "documents"],
  words: ["DOCX file", "DOCX files"],
  html: ["HTML file", "HTML files"],
  slides: ["deck", "decks"],
  email: ["message", "messages"],
  sheets: ["workbook", "workbooks"]
};

/** Names the engine the page belongs to and how much of its input is in the workspace. */
function EngineChip({ engine }: { engine: (typeof ENGINES)[number] }) {
  const { artifacts } = useWorkspace();
  const Icon = ENGINE_ICONS[engine.id];
  const count = artifacts.filter((artifact) => artifact.kind === engine.kind).length;
  const noun = COUNT_NOUNS[engine.id][count === 1 ? 0 : 1];
  return (
    <div className="flex min-w-0 items-center gap-2 rounded-md border border-line bg-surface px-2.5 py-1.5">
      <Icon className="size-4 shrink-0 text-muted" />
      <div className="min-w-0">
        <p className="truncate text-[12.5px] font-medium leading-tight text-ink">{engine.label} engine</p>
        <p className="truncate text-[10.5px] leading-tight text-faint">
          {count} {noun} in the workspace
        </p>
      </div>
    </div>
  );
}

function DocumentPicker() {
  const { pdfs, current, setCurrent, loading } = useWorkspace();
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function onPointerDown(event: MouseEvent) {
      if (ref.current && !ref.current.contains(event.target as Node)) setOpen(false);
    }
    function onKey(event: KeyboardEvent) {
      if (event.key === "Escape") setOpen(false);
    }
    document.addEventListener("mousedown", onPointerDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onPointerDown);
      document.removeEventListener("keydown", onKey);
    };
  }, []);

  const filtered = query.trim()
    ? pdfs.filter((pdf) => pdf.fileName.toLowerCase().includes(query.trim().toLowerCase()))
    : pdfs;

  return (
    <div ref={ref} className="relative min-w-0">
      <button
        type="button"
        onClick={() => setOpen((value) => !value)}
        className={clsx(
          "flex h-9 max-w-[420px] items-center gap-2 rounded-lg border px-2.5 text-left transition",
          open ? "border-accent-line bg-surface shadow-[0_0_0_3px_rgba(14,106,69,0.08)]" : "border-line bg-surface hover:border-line-strong"
        )}
      >
        <span className="flex size-5 shrink-0 items-center justify-center rounded bg-[#f1f4f0]">
          <FileText className="size-3 text-accent" />
        </span>
        <span className="min-w-0">
          <span className="block truncate text-[12.5px] font-medium leading-4 text-ink">
            {loading ? "Loading workspace…" : current ? current.fileName : "No document selected"}
          </span>
          <span className="block text-[10.5px] leading-3.5 text-faint">
            {current
              ? `${current.pageCount ?? "?"} page${current.pageCount === 1 ? "" : "s"} · ${formatBytes(current.size)}${current.encrypted ? " · encrypted" : ""}`
              : "Upload a PDF or restore the samples"}
          </span>
        </span>
        <ChevronDown className={clsx("ml-1 size-3.5 shrink-0 text-faint transition", open && "rotate-180")} />
      </button>

      {open ? (
        <div className="absolute left-0 top-[calc(100%+6px)] z-40 w-[360px] overflow-hidden rounded-xl border border-line bg-surface shadow-pop">
          <div className="border-b border-line p-2">
            <input
              autoFocus
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Search documents"
              className="h-8 w-full rounded-md border border-line bg-surface-muted px-2.5 text-[12.5px] outline-none placeholder:text-faint focus:border-accent-line focus:bg-surface"
            />
          </div>
          <div className="scroll-thin max-h-[300px] overflow-y-auto p-1.5">
            {filtered.length === 0 ? (
              <p className="px-2 py-6 text-center text-[12px] text-muted">No matching documents</p>
            ) : (
              filtered.map((pdf) => (
                <button
                  key={pdf.id}
                  type="button"
                  onClick={() => {
                    setCurrent(pdf.id);
                    setOpen(false);
                    setQuery("");
                  }}
                  className={clsx(
                    "flex w-full items-center gap-2.5 rounded-md px-2 py-1.5 text-left transition hover:bg-canvas",
                    pdf.id === current?.id && "bg-accent-soft/60"
                  )}
                >
                  <FileText className={clsx("size-3.5 shrink-0", pdf.id === current?.id ? "text-accent" : "text-faint")} />
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[12.5px] text-ink">{pdf.fileName}</span>
                    <span className="block text-[10.5px] text-faint">
                      {pdf.pageCount ?? "?"} {pdf.pageCount === 1 ? "page" : "pages"} · {formatBytes(pdf.size)}
                      {pdf.origin === "sample" ? " · sample" : ""}
                    </span>
                  </span>
                  {pdf.encrypted ? <Pill tone="warn">locked</Pill> : null}
                </button>
              ))
            )}
          </div>
          <div className="border-t border-line px-2 py-1.5">
            <Link
              href="/library"
              onClick={() => setOpen(false)}
              className="flex items-center gap-1.5 rounded-md px-2 py-1.5 text-[12px] font-medium text-accent-strong hover:bg-accent-soft"
            >
              <Blocks className="size-3.5" />
              Open the library
            </Link>
          </div>
        </div>
      ) : null}
    </div>
  );
}
