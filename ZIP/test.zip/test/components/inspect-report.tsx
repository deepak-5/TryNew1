"use client";

import clsx from "clsx";
import { Check, Minus } from "lucide-react";
import { formatBytes, formatNumber } from "@/lib/format";
import type { InspectionReport, ValidationReport } from "@/lib/types";
import { Callout, Pill } from "./ui";
import { DataTable, Facts, IssueTable, ReportSection, WarningsList } from "./report-view";

export function InspectionView({ report }: { report: InspectionReport }) {
  const flags = [
    { label: "Tagged structure tree", on: report.tagged },
    { label: "Linearized", on: report.linearized },
    { label: "Rebuilt cross-reference", on: report.reconstructed },
    { label: "Encrypted", on: report.encrypted },
    { label: "Form fields", on: report.formFields > 0, value: report.formFields },
    { label: "Embedded files", on: report.attachments > 0, value: report.attachments },
    { label: "Outline entries", on: report.outlineItems > 0, value: report.outlineItems },
    { label: "JavaScript / XFA", on: Boolean(report.scripts?.present) }
  ];

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        {[
          { label: "Pages", value: formatNumber(report.pages) },
          { label: "PDF version", value: report.version },
          { label: "Objects", value: formatNumber(report.objectCount) },
          { label: "File size", value: formatBytes(report.fileSize) }
        ].map((tile) => (
          <div key={tile.label} className="rounded-lg border border-line bg-surface-muted/60 px-3 py-2.5">
            <div className="text-[10.5px] font-medium uppercase tracking-[0.06em] text-faint">{tile.label}</div>
            <div className="mt-0.5 text-[17px] font-semibold leading-6 tabular-nums text-ink">{tile.value}</div>
          </div>
        ))}
      </div>

      <ReportSection title="Structure">
        <ul className="grid grid-cols-1 gap-1.5 sm:grid-cols-2">
          {flags.map((flag) => (
            <li
              key={flag.label}
              className={clsx(
                "flex items-center gap-2 rounded-md border px-2.5 py-1.5 text-[12px]",
                flag.on ? "border-accent-line bg-accent-soft/50 text-accent-strong" : "border-line bg-surface text-muted"
              )}
            >
              <span
                className={clsx(
                  "flex size-4 items-center justify-center rounded-full",
                  flag.on ? "bg-accent text-white" : "bg-[#eef1ee] text-faint"
                )}
              >
                {flag.on ? <Check className="size-2.5" strokeWidth={3} /> : <Minus className="size-2.5" />}
              </span>
              {flag.label}
              {flag.value != null ? <span className="ml-auto tabular-nums opacity-70">{flag.value}</span> : null}
            </li>
          ))}
        </ul>
      </ReportSection>

      <div className="grid gap-4 sm:grid-cols-2">
        <ReportSection title="Cross-reference">
          <Facts
            columns={1}
            data={{
              "Xref style": report.xrefStyle,
              "Header offset": `${report.headerOffset} bytes`,
              "Page size": report.pageDetails[0]?.size ?? "—",
              Fonts: report.fonts,
              Images: report.images
            }}
          />
        </ReportSection>
        <ReportSection title="Document info dictionary">
          {Object.keys(report.info).length === 0 ? (
            <p className="text-[12px] text-muted">No Info entries.</p>
          ) : (
            <div className="overflow-hidden rounded-lg border border-line">
              {Object.entries(report.info).map(([key, value]) => (
                <div key={key} className="flex gap-3 border-b border-line px-2.5 py-1.5 text-[12px] last:border-b-0">
                  <span className="w-[92px] shrink-0 text-faint">{key}</span>
                  <span className="min-w-0 break-words text-ink-soft">{value}</span>
                </div>
              ))}
            </div>
          )}
        </ReportSection>
      </div>

      {Object.keys(report.xmp).length > 0 ? (
        <ReportSection title="XMP properties" hint="Read from the metadata stream when one is present">
          <div className="flex flex-wrap gap-1.5">
            {Object.entries(report.xmp).map(([key, value]) => (
              <span key={key} className="rounded-md border border-line bg-surface-muted px-2 py-1 text-[11.5px]">
                <span className="text-faint">{key}</span>
                <span className="mx-1 text-line-strong">·</span>
                <span className="text-ink-soft">{value}</span>
              </span>
            ))}
          </div>
        </ReportSection>
      ) : null}

      {report.pageDetails.length > 0 ? (
        <ReportSection title="Pages" hint="Measured from the page tree and content streams">
          <DataTable
            dense
            columns={[
              { key: "number", label: "#", width: "44px" },
              { key: "size", label: "Size", nowrap: true },
              { key: "width", label: "Width pt", align: "right" },
              { key: "height", label: "Height pt", align: "right" },
              { key: "rotate", label: "Rotate", align: "right" },
              { key: "contentBytes", label: "Content", align: "right" },
              { key: "fonts", label: "Fonts", align: "right" },
              { key: "images", label: "Images", align: "right" },
              { key: "annotations", label: "Annots", align: "right" }
            ]}
            rows={report.pageDetails.map((page) => ({
              ...page,
              contentBytes: formatBytes(page.contentBytes)
            }))}
            maxHeight={280}
          />
        </ReportSection>
      ) : null}

      {report.fields.length > 0 ? (
        <ReportSection title="Form fields" hint={`${report.fields.length} terminal field${report.fields.length === 1 ? "" : "s"}`}>
          <DataTable
            dense
            columns={[
              { key: "name", label: "Name", mono: true },
              { key: "type", label: "Type" },
              { key: "value", label: "Value" },
              { key: "page", label: "Page", align: "right" }
            ]}
            rows={report.fields as unknown as Array<Record<string, unknown>>}
          />
        </ReportSection>
      ) : null}

      {report.scripts?.present ? (
        <Callout tone="warn" title="Active content present">
          {report.scripts.xfa ? "This document carries an XFA form. " : ""}
          {report.scripts.document_javascript ? "It runs document-level JavaScript. " : ""}
          {report.scripts.additional_actions > 0 ? `${report.scripts.additional_actions} additional-action entr${report.scripts.additional_actions === 1 ? "y" : "ies"}. ` : ""}
          {report.scripts.auto_launch ? "It requests auto-launch." : ""} Use Sanitize to remove it.
        </Callout>
      ) : null}

      <WarningsList warnings={report.warnings} />
    </div>
  );
}

export function ValidationView({ report }: { report: ValidationReport }) {
  const errors = report.issues.filter((issue) => issue.severity === "error");
  const warnings = report.issues.filter((issue) => issue.severity === "warning");

  const standardTitle =
    report.standard === "pdfa"
      ? `PDF/A-${report.pdfa?.level ?? ""}`
      : report.standard === "pdfx"
        ? `PDF/X · ${report.pdfx?.profile ?? ""}`
        : report.standard === "pdfua"
          ? `PDF/UA-${report.pdfua?.level ?? ""}`
          : "Structural checks";

  const detailEntries: Array<[string, unknown]> = [];
  if (report.pdfa) {
    detailEntries.push(
      ["Specification", report.pdfa.spec],
      ["Declared part", report.pdfa.declaredPart ?? "none"],
      ["Declared conformance", report.pdfa.declaredConformance ?? "none"],
      ["Output intent", report.pdfa.outputIntent ? "present" : "missing"],
      ["Checked subset", report.pdfa.checkedSubsetPasses ? "passes" : "fails"]
    );
  }
  if (report.pdfx) {
    detailEntries.push(
      ["Standard", report.pdfx.standard],
      ["Output intent", report.pdfx.outputIntent ? "present" : "missing"],
      ["Checked subset", report.pdfx.checkedSubsetPasses ? "passes" : "fails"]
    );
  }
  if (report.pdfua) {
    detailEntries.push(
      ["Specification", report.pdfua.spec],
      ["Tagged", report.pdfua.tagged ? "yes" : "no"],
      ["Structure elements", formatNumber(report.pdfua.structureElements)],
      ["Checked subset", report.pdfua.conformant ? "passes" : "fails"]
    );
  }

  return (
    <div className="space-y-5">
      <Callout tone={report.valid ? "success" : "danger"} title={`${standardTitle}: ${report.valid ? "passes" : "does not pass"}`}>
        {report.valid
          ? `The document satisfies every implemented ${standardTitle} check. This is a checked subset, not a formal certification.`
          : `${errors.length} error${errors.length === 1 ? "" : "s"} and ${warnings.length} warning${warnings.length === 1 ? "" : "s"} were found. ${
              report.pdfa?.verdict ?? report.pdfx?.verdict ?? report.pdfua?.verdict ?? ""
            }`}
      </Callout>

      <div className="flex flex-wrap items-center gap-2">
        <Pill tone="danger">{errors.length} error{errors.length === 1 ? "" : "s"}</Pill>
        <Pill tone="warn">{warnings.length} warning{warnings.length === 1 ? "" : "s"}</Pill>
        <Pill>{report.pages} page{report.pages === 1 ? "" : "s"} walked</Pill>
        {report.strict ? <Pill tone="info">strict</Pill> : null}
        <span className="text-[11px] text-faint">Not a certification — the engine reports its own bounded checks.</span>
      </div>

      {detailEntries.length > 0 ? (
        <ReportSection title="Profile detail">
          <div className="rounded-lg border border-line bg-surface-muted/50 px-3.5 py-3">
            <Facts columns={3} data={Object.fromEntries(detailEntries)} />
          </div>
        </ReportSection>
      ) : null}

      {report.pdfx && report.pdfx.limitations.length > 0 ? (
        <Callout tone="info" title="Known limits of this profile walk">
          <ul className="list-disc space-y-0.5 pl-4">
            {report.pdfx.limitations.map((limitation, index) => (
              <li key={index}>{limitation}</li>
            ))}
          </ul>
        </Callout>
      ) : null}

      <ReportSection title="Findings" hint={`${report.issues.length} check result${report.issues.length === 1 ? "" : "s"}`}>
        <IssueTable issues={report.issues} emptyText={`No findings. The document satisfies every ${standardTitle} check implemented by the engine.`} />
      </ReportSection>
    </div>
  );
}
