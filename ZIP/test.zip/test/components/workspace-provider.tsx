"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import { api } from "@/lib/api";
import type { Artifact, Health } from "@/lib/types";

interface WorkspaceValue {
  artifacts: Artifact[];
  pdfs: Artifact[];
  health: Health | null;
  /** Route counts per engine, read from the API's own endpoint table. */
  engineRoutes: Record<string, number>;
  loading: boolean;
  error: string | null;
  currentId: string | null;
  current: Artifact | null;
  setCurrent: (id: string) => void;
  refresh: () => Promise<Artifact[]>;
  upload: (file: File, password?: string) => Promise<Artifact>;
  remove: (id: string) => Promise<void>;
  restoreSamples: () => Promise<number>;
}

const WorkspaceContext = createContext<WorkspaceValue | null>(null);
const STORAGE_KEY = "docuzen.current-document";

export function WorkspaceProvider({ children }: { children: React.ReactNode }) {
  const [artifacts, setArtifacts] = useState<Artifact[]>([]);
  const [health, setHealth] = useState<Health | null>(null);
  const [engineRoutes, setEngineRoutes] = useState<Record<string, number>>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [currentId, setCurrentId] = useState<string | null>(null);
  const currentRef = useRef<string | null>(null);

  useEffect(() => {
    currentRef.current = currentId;
  }, [currentId]);

  const selectFallback = useCallback((list: Artifact[]) => {
    const pdfs = list
      .filter((artifact) => artifact.kind === "pdf")
      .sort((a, b) => (a.createdAt < b.createdAt ? -1 : 1));
    const stored = typeof window !== "undefined" ? window.localStorage.getItem(STORAGE_KEY) : null;
    const preferred = currentRef.current ?? stored;
    if (preferred && list.some((artifact) => artifact.id === preferred)) return;
    // Open on a seeded sample rather than whatever the engine wrote last, so a
    // fresh tester starts from a known document instead of a previous run's output.
    const sample = pdfs.find((artifact) => artifact.origin === "sample");
    setCurrentId(sample?.id ?? pdfs[0]?.id ?? null);
  }, []);

  const refresh = useCallback(async () => {
    try {
      const list = await api.listArtifacts();
      setArtifacts(list);
      setError(null);
      selectFallback(list);
      return list;
    } catch (cause) {
      // Background poll failures shouldn't wipe state
      return [];
    }
  }, [selectFallback]);

  // Periodically refresh artifacts so expired outputs (>5m) automatically disappear from UI
  useEffect(() => {
    const timer = setInterval(() => {
      refresh();
    }, 15000);
    return () => clearInterval(timer);
  }, [refresh]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [list, healthPayload, enginePayload] = await Promise.all([
          api.listArtifacts(),
          api.health(),
          // A missing catalogue must not fail the workspace; the labels then simply
          // omit the count instead of inventing one.
          api.engines().catch(() => null)
        ]);
        if (cancelled) return;
        setArtifacts(list);
        setHealth(healthPayload);
        if (enginePayload) {
          setEngineRoutes(
            Object.fromEntries(enginePayload.engines.map((engine) => [engine.id, engine.routes]))
          );
        }
        selectFallback(list);
      } catch (cause) {
        if (!cancelled) setError(cause instanceof Error ? cause.message : "The workspace could not be loaded");
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [selectFallback]);

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (currentId) window.localStorage.setItem(STORAGE_KEY, currentId);
    else window.localStorage.removeItem(STORAGE_KEY);
  }, [currentId]);

  const upload = useCallback(async (file: File, password?: string) => {
    const artifact = await api.upload(file, password);
    await refresh();
    setCurrentId(artifact.id);
    return artifact;
  }, [refresh]);

  const remove = useCallback(
    async (id: string) => {
      await api.deleteArtifact(id);
      const list = await refresh();
      if (id === currentRef.current) {
        const next = list.find((artifact) => artifact.kind === "pdf" && artifact.id !== id);
        setCurrentId(next ? next.id : null);
      }
    },
    [refresh]
  );

  const restoreSamples = useCallback(async () => {
    const response = await api.restoreSamples();
    await refresh();
    return response.created;
  }, [refresh]);

  const pdfs = useMemo(() => artifacts.filter((artifact) => artifact.kind === "pdf"), [artifacts]);
  const current = useMemo(() => artifacts.find((artifact) => artifact.id === currentId) ?? null, [artifacts, currentId]);

  const value = useMemo<WorkspaceValue>(
    () => ({
      artifacts,
      pdfs,
      health,
      engineRoutes,
      loading,
      error,
      currentId,
      current,
      setCurrent: setCurrentId,
      refresh,
      upload,
      remove,
      restoreSamples
    }),
    [artifacts, pdfs, health, engineRoutes, loading, error, currentId, current, refresh, upload, remove, restoreSamples]
  );

  return <WorkspaceContext.Provider value={value}>{children}</WorkspaceContext.Provider>;
}

export function useWorkspace(): WorkspaceValue {
  const value = useContext(WorkspaceContext);
  if (!value) throw new Error("useWorkspace must be used inside WorkspaceProvider");
  return value;
}
