# Docuzen engine console

Next.js App Router front end over the API in [`apps/api`](../api). Eighteen routes: the
PDF workbenches, one workbench per remaining engine, and the shared overview and library.

The console has no engine logic of its own. It picks an input, posts a request, and shows
what the engine returned — the report, the raster, the artifacts. It does not reshape a
document, guess a result or keep a second copy of anything the API can answer.

```sh
npm install
DOCUZEN_API_ORIGIN=http://127.0.0.1:5080 npm run dev   # http://localhost:3000
npx next build                                          # 18 routes
npx tsc --noEmit
```

## Talking to the API

`next.config.ts` rewrites `/api/*` to `DOCUZEN_API_ORIGIN` (default
`http://127.0.0.1:5080`). The browser only ever calls this origin, so the console works
behind a single preview host without exposing the API port. `lib/api.ts` is the one place
that sends requests; it leaves the content type to the browser for `FormData` (an upload
with `application/json` never had a multipart boundary) and turns every failure into an
`ApiError` carrying the engine's own message.

## Structure

| Path | What lives there |
|---|---|
| `app/<engine>/page.tsx` | One workbench per engine; tabs are local state addressed by hash |
| `app/page.tsx`, `app/library` | Overview, and every artifact in the workspace |
| `components/app-shell.tsx` | Sidebar (per-engine groups), engine-aware top bar |
| `components/result-panel.tsx` | Preview / File / Report / Warnings; opens on what the run produced |
| `components/report-view.tsx` | Generic report renderer — facts, tables, prose — used when a page has no custom view |
| `lib/api.ts`, `lib/engine-api.ts` | Request layer and the per-engine request shapes |
| `lib/engines.ts` | The six engine definitions: label, kind, route, blurb |
| `lib/use-engine-document.ts` | A workbench's picker: settles on a seeded sample, follows an upload |
| `lib/use-hash-tab.ts` | Keeps the tab and the URL hash in step, in both directions |

## Rules the UI follows

- **Only mapped routes are offered.** `GET /api/engines` is read from ASP.NET Core's own
  endpoint table, so a route count in the UI is a count of routes that exist. A tool that
  is not mapped has no button.
- **Refusals are shown as refusals.** A tagged PDF that will not take a stamp, a compose
  guest whose parts cannot be imported, an unsigned message: the engine's message is
  displayed, not replaced with an empty result or a friendly silence.
- **Read-only tools write nothing.** Their `artifacts` array is empty on purpose and the
  panel says so instead of hiding the outcome.
- **Pickers match the engine.** Each workbench lists only the kind it reads, and the top
  bar's upload accepts only what that engine can open.
- **Tabs are addressable.** `/words#compose`, `/html#query`, `/email#verify`,
  `/sheets#calculate` open the named tab; picking a tab rewrites the hash.

## Adding a workbench

1. Map the endpoint in `apps/api` and add its request shape to `lib/engine-api.ts`.
2. Add a tab (or a route) with a `ConfigCard` for inputs and a `ResultPanel` for output.
3. Give the result a `renderReport` when the generic renderer would not read well; leave it
   to `GenericReport` otherwise.
4. Drive it in a browser and judge the screenshot — a 200 is not evidence that the panel
   reads well.
