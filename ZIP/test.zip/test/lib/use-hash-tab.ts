"use client";

import { useEffect, useRef } from "react";

/** Fired when a tab rewrites the hash itself; `hashchange` does not fire for that. */
export const HASH_EVENT = "docuzen:hash";

/**
 * Keeps a workbench's tab and the URL hash in step, in both directions.
 *
 * Reading alone was not enough: the sidebar links address tabs by hash (`/words#compose`),
 * but clicking a tab left the hash pointing at the tab the page opened on, so a reload
 * went back there and the sidebar could not tell which tab was showing.
 *
 * Neither effect may depend on the `ids` array or the setter: pages pass literals, so
 * those change identity on every render, and a re-subscribed reader would overwrite the
 * tab the tester had just picked before the writer had updated the hash.
 */
export function useHashTab(ids: readonly string[], tab: string, onTab: (id: string) => void) {
  const idsRef = useRef(ids);
  const onTabRef = useRef(onTab);
  idsRef.current = ids;
  onTabRef.current = onTab;

  // URL → tab, on mount and whenever the location is navigated (a sidebar link).
  useEffect(() => {
    const apply = () => {
      const id = window.location.hash.replace(/^#/, "");
      if (id && idsRef.current.includes(id)) onTabRef.current(id);
    };
    apply();
    window.addEventListener("hashchange", apply);
    return () => window.removeEventListener("hashchange", apply);
  }, []);

  // tab → URL. Only a tab the tester changed is written: on the first commit the tab is
  // still the default, and writing it would overwrite the deep link above.
  const previous = useRef(tab);
  useEffect(() => {
    if (previous.current === tab) return;
    previous.current = tab;
    if (!idsRef.current.includes(tab)) return;
    const next = `#${tab}`;
    if (window.location.hash === next) return;
    window.history.replaceState(null, "", next);
    window.dispatchEvent(new Event(HASH_EVENT));
  }, [tab]);
}
