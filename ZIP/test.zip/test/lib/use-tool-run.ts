"use client";

import { useCallback, useState } from "react";
import { useWorkspace } from "@/components/workspace-provider";
import type { OperationResponse } from "./types";

export function useToolRun<TReport = Record<string, unknown>>() {
  const { refresh } = useWorkspace();
  const [result, setResult] = useState<OperationResponse<TReport> | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  const run = useCallback(
    async (operation: () => Promise<OperationResponse<TReport>>) => {
      setPending(true);
      setError(null);
      try {
        const response = await operation();
        setResult(response);
        // Keep the workspace list (and the document pickers) in step with what
        // the engine just produced. A stale list must never fail a good run.
        refresh().catch(() => undefined);
        return response;
      } catch (cause) {
        setError(cause instanceof Error ? cause.message : "The run failed");
        setResult(null);
        return null;
      } finally {
        setPending(false);
      }
    },
    [refresh]
  );

  const reset = useCallback(() => {
    setResult(null);
    setError(null);
  }, []);

  return { result, error, pending, run, reset };
}
