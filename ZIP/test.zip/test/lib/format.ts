export function formatBytes(bytes: number): string {
  if (!Number.isFinite(bytes)) return "—";
  if (bytes < 1024) return `${bytes} B`;
  const units = ["KB", "MB", "GB"];
  let value = bytes / 1024;
  let unit = 0;
  while (value >= 1024 && unit < units.length - 1) {
    value /= 1024;
    unit += 1;
  }
  return `${value < 10 ? value.toFixed(1) : Math.round(value)} ${units[unit]}`;
}

export function formatDate(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "—";
  const now = Date.now();
  const diff = now - date.getTime();
  if (diff < 60_000) return "just now";
  if (diff < 3_600_000) return `${Math.round(diff / 60_000)} min ago`;
  if (diff < 86_400_000) return `${Math.round(diff / 3_600_000)} h ago`;
  return date.toLocaleString(undefined, {
    day: "2-digit",
    month: "short",
    year: date.getFullYear() === new Date().getFullYear() ? undefined : "numeric",
    hour: "2-digit",
    minute: "2-digit"
  });
}

export function formatDuration(ms: number): string {
  if (ms < 1000) return `${ms} ms`;
  if (ms < 60_000) return `${(ms / 1000).toFixed(1)} s`;
  return `${Math.floor(ms / 60_000)}m ${Math.round((ms % 60_000) / 1000)}s`;
}

export function formatNumber(value: number): string {
  return new Intl.NumberFormat().format(value);
}

/**
 * "htmlBodyCharacters" and "has_vba_macros" both read as words in a label. Split
 * camelCase and acronym boundaries before capitalising, so report keys do not run
 * together in the facts grid.
 */
export function titleCase(value: string): string {
  return value
    .replace(/([a-z0-9])([A-Z])/g, "$1 $2")
    .replace(/([A-Z]+)([A-Z][a-z])/g, "$1 $2")
    .replace(/[-_]+/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .replace(/\b\w/g, (character) => character.toUpperCase());
}

export function pluralize(count: number, singular: string, plural?: string): string {
  return `${formatNumber(count)} ${count === 1 ? singular : plural ?? `${singular}s`}`;
}

export function truncate(value: string, length = 80): string {
  if (value.length <= length) return value;
  return `${value.slice(0, length - 1)}…`;
}

export function artifactTypeLabel(artifact: { kind: string; fileName: string; pdfVersion?: string; mediaType?: string }): string {
  if (artifact.kind === "pdf") return artifact.pdfVersion ? `PDF ${artifact.pdfVersion}` : "PDF";
  const extension = artifact.fileName.includes(".") ? artifact.fileName.split(".").pop()?.toUpperCase() : undefined;
  if (extension && extension.length <= 5) return extension;
  return artifact.kind === "image"
    ? "Image"
    : artifact.kind === "data"
      ? "Data"
      : artifact.kind === "word"
        ? "Document"
        : artifact.kind === "sheet"
          ? "Workbook"
          : artifact.kind === "slides"
            ? "Deck"
            : artifact.kind === "email"
              ? "Message"
              : "Text";
}
