import { engineTools } from "./api";
import type { OperationResponse } from "./types";

/**
 * One typed entry per engine route. The bodies mirror the request records in
 * `apps/api/Docuzen.Api/Endpoints/*Endpoints.cs`, so a renamed field breaks the type
 * check here instead of failing silently at run time.
 */

type Report = Record<string, unknown>;
type Result<T = Report> = Promise<OperationResponse<T>>;

export const words = {
  create: (body: { kind: "markdown" | "html" | "text"; content: string; title?: string; author?: string; fileName?: string }) =>
    engineTools.call("/api/words/create", body) as Result,
  inspect: (artifactId: string) => engineTools.call("/api/words/inspect", { artifactId }) as Result,
  extract: (body: { artifactId: string; format?: string }) => engineTools.call("/api/words/extract", body) as Result,
  convert: (body: { artifactId: string; to: string; page?: number; dpi?: number; strict?: boolean }) =>
    engineTools.call("/api/words/convert", body) as Result,
  replace: (body: { artifactId: string; find: string; replacement: string; headersAndFooters?: boolean }) =>
    engineTools.call("/api/words/replace", body) as Result,
  fill: (body: { artifactId: string; values: Record<string, string>; headersAndFooters?: boolean }) =>
    engineTools.call("/api/words/fill", body) as Result,
  mailMerge: (body: { artifactId: string; rows: Record<string, string>[]; cleanup?: string; table?: string }) =>
    engineTools.call("/api/words/mail-merge", body) as Result,
  // The engine's read action is called "read"; the console's third option used to be
  // labelled "list", which the API rejected. One name, both sides.
  revisions: (body: { artifactId: string; action: "read" | "accept" | "reject"; author?: string }) =>
    engineTools.call("/api/words/revisions", body) as Result,
  properties: (body: {
    artifactId: string;
    values?: {
      title?: string;
      subject?: string;
      creator?: string;
      description?: string;
      keywords?: string;
      category?: string;
    };
  }) => engineTools.call("/api/words/properties", body) as Result,
  fields: (path: "/api/words/bookmarks" | "/api/words/content-controls", body: { artifactId: string; action?: string; values?: Record<string, string>; lenient?: boolean }) =>
    engineTools.call(path, body) as Result,
  compose: (body: { targetId: string; sourceId: string; scope?: string; lenient?: boolean }) =>
    engineTools.call("/api/words/compose", body) as Result,

  /* the rest of the engine: review threads, fields, notes, drawings and package ops */
  comments: (body: {
    artifactId: string;
    action?: "read" | "add" | "resolve" | "reopen";
    author?: string;
    text?: string;
    paragraph?: number;
    lastParagraph?: number;
    id?: number;
  }) => engineTools.call("/api/words/comments", body) as Result,
  documentFields: (body: { artifactId: string; action?: "read" | "update"; lenient?: boolean }) =>
    engineTools.call("/api/words/fields", body) as Result,
  notes: (body: { artifactId: string }) => engineTools.call("/api/words/notes", body) as Result,
  graphics: (body: { artifactId: string }) => engineTools.call("/api/words/graphics", body) as Result,
  buildingBlocks: (body: { artifactId: string }) => engineTools.call("/api/words/building-blocks", body) as Result,
  chunks: (body: { artifactId: string; maxTokens?: number }) => engineTools.call("/api/words/chunks", body) as Result,
  watermark: (body: { artifactId: string; action?: "add" | "remove"; text?: string }) =>
    engineTools.call("/api/words/watermark", body) as Result,
  background: (body: { artifactId: string; color?: string }) => engineTools.call("/api/words/background", body) as Result,
  protection: (body: { artifactId: string; action?: "read" | "apply" | "remove"; type?: string; password?: string }) =>
    engineTools.call("/api/words/protection", body) as Result,
  macros: (body: { artifactId: string; action?: "read" | "remove" }) => engineTools.call("/api/words/macros", body) as Result,
  toc: (body: { artifactId: string; action?: "add" | "update"; maxLevel?: number; title?: string }) =>
    engineTools.call("/api/words/toc", body) as Result,
  hyphenate: (body: { artifactId: string; minWordLength?: number; minPrefix?: number; minSuffix?: number }) =>
    engineTools.call("/api/words/hyphenate", body) as Result,
  compareDocuments: (body: {
    leftId: string;
    rightId: string;
    author?: string;
    granularity?: "word" | "character";
    ignoreFormatting?: boolean;
    ignoreCaseChanges?: boolean;
  }) => engineTools.call("/api/words/compare", body) as Result,
  split: (body: { artifactId: string; mode?: "pages" | "range"; start?: number; end?: number }) =>
    engineTools.call("/api/words/split", body) as Result,
  saveAs: (body: { artifactId: string; format: string }) => engineTools.call("/api/words/save-as", body) as Result
};

export const html = {
  create: (body: { html: string; fileName?: string; title?: string }) => engineTools.call("/api/html/create", body) as Result,
  inspect: (body: { artifactId?: string; html?: string }) => engineTools.call("/api/html/inspect", body) as Result,
  convert: (body: {
    artifactId?: string;
    html?: string;
    to: string;
    page?: number;
    dpi?: number;
    pageSize?: string;
    margin?: number;
    landscape?: boolean;
    header?: string;
    footer?: string;
  }) => engineTools.call("/api/html/convert", body) as Result,
  query: (body: { artifactId?: string; html?: string; selector: string; mode?: string; attribute?: string }) =>
    engineTools.call("/api/html/query", body) as Result,
  table: (body: { artifactId?: string; html?: string; selector?: string; prefixText?: boolean }) =>
    engineTools.call("/api/html/table", body) as Result,
  sanitize: (body: { artifactId?: string; html?: string }) => engineTools.call("/api/html/sanitize", body) as Result,

  /* markdown, accessibility, forms, text, containers, cascade */
  markdown: (body: { artifactId?: string; html?: string; markdown?: string; action?: "to" | "from"; fileName?: string }) =>
    engineTools.call("/api/html/markdown", body) as Result,
  accessibility: (body: { artifactId?: string; html?: string; contrast?: boolean; severity?: string }) =>
    engineTools.call("/api/html/accessibility", body) as Result,
  forms: (body: {
    artifactId?: string;
    html?: string;
    action: "read" | "validate" | "fill" | "serialize";
    selector?: string;
    values?: Record<string, string>;
  }) => engineTools.call("/api/html/forms", body) as Result,
  text: (body: { artifactId?: string; html?: string; selector?: string; maxChars?: number }) =>
    engineTools.call("/api/html/text", body) as Result,
  epub: (body: { artifactId: string }) => engineTools.call("/api/html/epub", body) as Result,
  mhtml: (body: { artifactId?: string; html?: string; action: "read" | "save"; fileName?: string }) =>
    engineTools.call("/api/html/mhtml", body) as Result,
  standalone: (body: { artifactId?: string; html?: string; fileName?: string }) =>
    engineTools.call("/api/html/standalone", body) as Result,
  css: (body: { artifactId?: string; html?: string; selector?: string; extraCss?: string }) =>
    engineTools.call("/api/html/css", body) as Result
};

export const slides = {
  inspect: (artifactId: string) => engineTools.call("/api/slides/inspect", { artifactId }) as Result,
  convert: (body: { artifactId: string; to: string; slide?: number }) => engineTools.call("/api/slides/convert", body) as Result,

  /* authoring, structure, text, notes, comments, arrangement, motion, theme, export, protection */
  create: (body: {
    title?: string;
    author?: string;
    fileName?: string;
    size?: string;
    slides: Array<Record<string, unknown>>;
  }) => engineTools.call("/api/slides/create", body) as Result,
  read: (body: { artifactId: string }) => engineTools.call("/api/slides/read", body) as Result,
  text: (body: { artifactId: string; action: "find" | "replace"; find: string; replacement?: string; matchCase?: boolean }) =>
    engineTools.call("/api/slides/text", body) as Result,
  notes: (body: { artifactId: string; action: "read" | "write"; slide?: number; text?: string }) =>
    engineTools.call("/api/slides/notes", body) as Result,
  comments: (body: {
    artifactId: string;
    action: "read" | "add" | "update" | "remove";
    slide?: number;
    index?: number;
    author?: string;
    initials?: string;
    text?: string;
  }) => engineTools.call("/api/slides/comments", body) as Result,
  slideOps: (body: {
    artifactId: string;
    action: "read" | "add" | "clone" | "move" | "delete" | "hide" | "show" | "append";
    index?: number;
    to?: number;
    sourceIndex?: number;
    cloneMode?: string;
    layout?: string;
    sourceId?: string;
  }) => engineTools.call("/api/slides/slides", body) as Result,
  sections: (body: { artifactId: string; action: "read" | "add-section" | "add-show"; name?: string; slideIndexes?: number[] }) =>
    engineTools.call("/api/slides/sections", body) as Result,
  animations: (body: {
    artifactId: string;
    action: "read" | "add";
    slide?: number;
    shape?: number;
    effect?: string;
    trigger?: string;
    durationMs?: number;
  }) => engineTools.call("/api/slides/animations", body) as Result,
  theme: (body: { artifactId: string }) => engineTools.call("/api/slides/theme", body) as Result,
  transitions: (body: { artifactId: string; action: "read" | "set"; slide?: number; type?: string; advanceAfterSeconds?: number; speed?: string }) =>
    engineTools.call("/api/slides/transitions", body) as Result,
  export: (body: { artifactId: string; format: string; slide?: number }) => engineTools.call("/api/slides/export", body) as Result,
  protect: (body: { artifactId: string; action: "read" | "apply" | "remove" | "check" | "encrypt" | "decrypt"; password?: string }) =>
    engineTools.call("/api/slides/protect", body) as Result
};

export const email = {
  inspect: (artifactId: string) => engineTools.call("/api/email/inspect", { artifactId }) as Result,
  convert: (body: { artifactId: string; to: string }) => engineTools.call("/api/email/convert", body) as Result,
  attachments: (body: { artifactId: string; name?: string }) => engineTools.call("/api/email/attachments", body) as Result,
  verify: (artifactId: string) => engineTools.call("/api/email/verify", { artifactId }) as Result,

  /* compose, edit, header-only read, storage conversions, calendar, contacts, body safety */
  create: (body: {
    fileName?: string;
    from?: string;
    fromName?: string;
    to?: string[];
    cc?: string[];
    bcc?: string[];
    replyTo?: string;
    subject?: string;
    text?: string;
    html?: string;
    date?: string;
  }) => engineTools.call("/api/email/create", body) as Result,
  headers: (body: { artifactId: string; name?: string }) => engineTools.call("/api/email/headers", body) as Result,
  edit: (body: {
    artifactId: string;
    subject?: string;
    from?: string;
    to?: string;
    cc?: string;
    bcc?: string;
    date?: string;
    text?: string;
    html?: string;
    format?: "eml" | "msg";
  }) => engineTools.call("/api/email/edit", body) as Result,
  storage: (body: { artifactId: string; action: "to-msg" | "from-msg" | "read-mbox" | "write-mbox" | "read-pst"; index?: number }) =>
    engineTools.call("/api/email/storage", body) as Result,
  calendar: (body: { artifactId?: string; action: "read" | "write"; ics?: string; fileName?: string; maxOccurrences?: number }) =>
    engineTools.call("/api/email/calendar", body) as Result,
  contact: (body: { artifactId?: string; action: "read" | "write"; vcard?: string }) =>
    engineTools.call("/api/email/contact", body) as Result,
  sanitizeBody: (body: { artifactId: string; blockRemoteImages?: boolean }) =>
    engineTools.call("/api/email/sanitize", body) as Result,
  attachmentSafety: (body: { artifactId: string; name?: string }) =>
    engineTools.call("/api/email/attachment-safety", body) as Result
};

export const sheets = {
  inspect: (artifactId: string) => engineTools.call("/api/sheets/inspect", { artifactId }) as Result,
  convert: (body: { artifactId: string; to: string; sheet?: number }) => engineTools.call("/api/sheets/convert", body) as Result,
  export: (body: { artifactId: string; sheet?: number; gridLines?: boolean; header?: string; footer?: string }) =>
    engineTools.call("/api/sheets/export", body) as Result,
  calculate: (artifactId: string) => engineTools.call("/api/sheets/calculate", { artifactId }) as Result,

  /* structural read, cell editing, worksheet operations, search, exports and the comparer */
  read: (body: { artifactId: string; sheet?: number; maxRows?: number; maxColumns?: number }) =>
    engineTools.call("/api/sheets/read", body) as Result,
  cells: (body: {
    artifactId: string;
    action: "read" | "write" | "formula" | "value" | "clear" | "fill" | "merge" | "unmerge" | "comment" | "freeze";
    sheet?: number;
    range?: string;
    address?: string;
    formula?: string;
    value?: string;
    text?: string;
    author?: string;
    delimiter?: string;
    frozenRows?: number;
    frozenColumns?: number;
  }) => engineTools.call("/api/sheets/cells", body) as Result,
  sheetOps: (body: {
    artifactId: string;
    action: "add" | "rename" | "clone" | "move" | "remove";
    sheet?: number;
    name?: string;
    newName?: string;
    targetIndex?: number;
  }) => engineTools.call("/api/sheets/sheets", body) as Result,
  text: (body: {
    artifactId: string;
    action: "find" | "replace";
    find: string;
    replace?: string;
    target?: "values" | "formulas" | "comments" | "all";
    matchCase?: boolean;
    useRegex?: boolean;
    sheet?: number;
  }) => engineTools.call("/api/sheets/text", body) as Result,
  formats: (body: { artifactId: string; to: "csv" | "json" | "html" | "print"; sheet?: number; formulas?: boolean; styles?: boolean }) =>
    engineTools.call("/api/sheets/formats", body) as Result,
  workbookOps: (body: { artifactId: string; otherArtifactId?: string; action: "compare" | "merge" | "split" }) =>
    engineTools.call("/api/sheets/workbook", body) as Result
};

/** Tiny RFC 4180-ish reader for the merge and CSV textareas. */
export function parseCsv(text: string): Record<string, string>[] {
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = "";
  let quoted = false;
  for (let index = 0; index < text.length; index++) {
    const char = text[index];
    if (quoted) {
      if (char === '"' && text[index + 1] === '"') {
        cell += '"';
        index++;
      } else if (char === '"') {
        quoted = false;
      } else {
        cell += char;
      }
      continue;
    }
    if (char === '"') quoted = true;
    else if (char === ",") {
      row.push(cell);
      cell = "";
    } else if (char === "\n") {
      row.push(cell);
      rows.push(row);
      row = [];
      cell = "";
    } else if (char !== "\r") cell += char;
  }
  if (cell.length > 0 || row.length > 0) {
    row.push(cell);
    rows.push(row);
  }
  const [header, ...body] = rows.filter((entry) => entry.some((value) => value.trim().length > 0));
  if (!header) return [];
  return body.map((entry) => {
    const record: Record<string, string> = {};
    header.forEach((name, index) => {
      record[name.trim()] = (entry[index] ?? "").trim();
    });
    return record;
  });
}
