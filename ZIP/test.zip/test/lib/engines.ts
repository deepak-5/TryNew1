export type EngineId = "pdf" | "words" | "html" | "slides" | "email" | "sheets";

export interface EngineDefinition {
  id: EngineId;
  label: string;
  /** Route that hosts the engine's workbench. */
  href: string;
  /** Artifact kind this engine reads. */
  kind: string;
  version?: string;
  blurb: string;
  card: string;
}

export const ENGINES: EngineDefinition[] = [
  {
    id: "pdf",
    label: "PDF",
    href: "/",
    kind: "pdf",
    blurb: "Layout, pages, structure, security and comparison",
    card: "Thirteen workbenches over the PDF engine: author, inspect, extract, convert, arrange, tag, edit, sign and compare."
  },
  {
    id: "words",
    label: "Words",
    href: "/words",
    kind: "word",
    blurb: "DOCX authoring, conversion and content editing",
    card: "Author from text, Markdown or HTML, convert to PDF/PNG/SVG, then edit text, fill tokens, merge records and settle revisions."
  },
  {
    id: "html",
    label: "HTML",
    href: "/html",
    kind: "html",
    blurb: "Offline HTML → PDF, images, DOCX and PPTX",
    card: "Parse and inspect markup, query selectors, export tables, sanitise and render through the engine's own CSS layout pass."
  },
  {
    id: "slides",
    label: "Slides",
    href: "/slides",
    kind: "slides",
    blurb: "PPTX inspection and deck export",
    card: "Read the deck's parts and slide geometry, then export the whole deck to PDF or HTML, or one slide to SVG."
  },
  {
    id: "email",
    label: "Email",
    href: "/email",
    kind: "email",
    blurb: "MIME inspection, rendering and S/MIME verification",
    card: "Read headers, bodies and attachment parts, render the message to PDF or MHTML, extract attachments and verify CMS signatures."
  },
  {
    id: "sheets",
    label: "Sheets",
    href: "/sheets",
    kind: "sheet",
    blurb: "Workbook inspection, calculation and print export",
    card: "Inspect worksheets, recalculate through the engine's evaluator, convert between formats and print a sheet to PDF or PNG."
  }
];


import { BookDown, FileCode2, FileSpreadsheet, FileText, Mail, Presentation } from "lucide-react";

export const ENGINE_ICONS: Record<EngineId, typeof FileText> = {
  pdf: FileText,
  words: BookDown,
  html: FileCode2,
  slides: Presentation,
  email: Mail,
  sheets: FileSpreadsheet
};

export function engineForPath(pathname: string): EngineDefinition {
  if (pathname.startsWith("/words")) return ENGINES[1];
  if (pathname.startsWith("/html")) return ENGINES[2];
  if (pathname.startsWith("/slides")) return ENGINES[3];
  if (pathname.startsWith("/email")) return ENGINES[4];
  if (pathname.startsWith("/sheets")) return ENGINES[5];
  return ENGINES[0];
}

/** Kind chips shown in the library and artifact rows. */
export const KIND_LABELS: Record<string, string> = {
  pdf: "PDF",
  image: "Image",
  text: "Text",
  html: "HTML",
  data: "Data",
  word: "DOCX",
  sheet: "Sheet",
  slides: "Deck",
  email: "Email"
};
