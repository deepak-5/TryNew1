"use client";

import { useEffect, useRef, useState } from "react";
import { useWorkspace } from "@/components/workspace-provider";

/**
 * Selection for an engine workbench. Starts on the workspace's current document when
 * it is the right kind, otherwise on the first artifact of that kind (the seeded
 * sample). It settles once, so a later refresh never steals the tester's choice.
 */
export function useEngineDocument(kind: string) {
  const { currentId, artifacts } = useWorkspace();
  const [id, setId] = useState("");
  const settled = useRef(false);

  useEffect(() => {
    const matches = (value: string | null | undefined, expected: string) =>
      !!value && artifacts.some((artifact) => artifact.id === value && artifact.kind === expected);

    // The workspace's current document changes only on a deliberate act — an upload or
    // opening a result — so following it is safe even after the first choice settled.
    // Run outputs do not touch it, which is what kept the earlier version from working.
    if (matches(currentId, kind)) {
      setId(currentId as string);
      settled.current = true;
      return;
    }
    // If the currently selected document was purged or no longer exists, reset settled
    if (id && !artifacts.some((artifact) => artifact.id === id)) {
      settled.current = false;
    }

    if (settled.current) return;
    // Prefer a seeded sample: it is the one input every workbench can actually run
    // against, and derived files of the same kind would otherwise win on name order.
    const first =
      artifacts.find((artifact) => artifact.kind === kind && artifact.origin === "sample") ??
      artifacts.find((artifact) => artifact.kind === kind);
    if (first) {
      setId(first.id);
      settled.current = true;
    }
  }, [artifacts, currentId, kind]);

  return [id, setId] as const;
}
