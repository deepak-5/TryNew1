export interface EngineRouteCount {
  id: string;
  label: string;
  kind: string;
  routes: number;
  operations: number;
  paths: string[];
}

export type ArtifactKind = "pdf" | "image" | "text" | "data" | "html" | "word" | "sheet" | "slides" | "email";

export interface Artifact {
  id: string;
  fileName: string;
  kind: ArtifactKind;
  mediaType?: string;
  origin: string;
  operation?: string;
  parentId?: string;
  size: number;
  sha256: string;
  createdAt: string;
  pageCount?: number;
  pdfVersion?: string;
  encrypted: boolean;
  locked: boolean;
  /** The catalog carries /StructTreeRoot or /MarkInfo: stamping and page scaling refuse. */
  tagged: boolean;
  pdfError?: string;
  hasReport: boolean;
  warnings: string[];
  contentUrl: string;
  previewUrl?: string;
  reportUrl?: string;
}

export interface OperationResponse<TReport = Record<string, unknown>> {
  ok: true;
  artifacts: Artifact[];
  report: TReport;
  warnings: string[];
  elapsedMs: number;
}

export interface Health {
  ok: boolean;
  status: string;
  product: string;
  engineVersion: string;
  apiVersion?: string;
  runtime: string;
  os: string;
  workspace: { root: string; artifacts: number; limit: number; pdfs: number };
  serverTime: string;
}

export interface Capability {
  id: string;
  area: string;
  title: string;
  endpoint: string;
  summary: string;
  bound: string;
}

export interface CapabilityArea {
  id: string;
  title: string;
  summary: string;
  capabilities: Capability[];
}

export interface Capabilities {
  ok: boolean;
  product: string;
  engineVersion: string;
  areas: CapabilityArea[];
  formats?: Record<string, string[]>;
  requestedLimit?: { maxUploadBytes: number };
}

export interface Issue {
  severity: "error" | "warning" | "note";
  code: string;
  message: string;
  objectNumber?: number;
}

export interface InspectionReport {
  path: string;
  fileSize: number;
  version: string;
  pages: number;
  encrypted: boolean;
  locked?: boolean;
  xrefStyle: string;
  reconstructed: boolean;
  linearized: boolean;
  objectCount: number;
  headerOffset: number;
  tagged: boolean;
  outlineItems: number;
  formFields: number;
  fields: Array<{ name: string; type: string; value?: unknown; page?: number | null }>;
  attachments: number;
  fonts: number;
  images: number;
  info: Record<string, string>;
  xmp: Record<string, string>;
  pageDetails: Array<{
    number: number;
    width: number;
    height: number;
    rotate: number;
    size: string;
    contentBytes: number;
    fonts: number;
    images: number;
    annotations: number;
  }>;
  warnings: string[];
  scripts?: { xfa: boolean; document_javascript: boolean; additional_actions: number; auto_launch: boolean; present: boolean };
}

export interface ValidationReport {
  standard: string;
  pages: number;
  valid: boolean;
  strict: boolean;
  errors: number;
  warnings: number;
  issues: Issue[];
  pdfa?: {
    level: string;
    spec: string;
    conformant: boolean;
    checkedSubsetPasses: boolean;
    verdict: string;
    declaredPart?: string;
    declaredConformance?: string;
    outputIntent: boolean;
    errors: number;
    warnings: number;
  };
  pdfx?: {
    profile: string;
    standard: string;
    checkedSubsetPasses: boolean;
    verdict: string;
    outputIntent: boolean;
    errors: number;
    warnings: number;
    limitations: string[];
  };
  pdfua?: {
    level: string;
    spec: string;
    conformant: boolean;
    verdict: string;
    tagged: boolean;
    structureElements: number;
    errors: number;
    warnings: number;
  };
}

export interface TextReport {
  pages: Array<{
    page: number;
    characters: number;
    text: string;
    runs?: Array<{ x: number; y: number; fontSize: number; font: string; text: string }> | null;
  }>;
  text: string;
  characters: number;
  pageCount: number;
  warnings: string[];
  note?: string;
}

export interface TablesReport {
  format: string;
  count: number;
  tables: Array<{
    page: number;
    tableIndex: number;
    ruled: boolean;
    rows: number;
    columns: number;
    continuation: boolean;
    markdown: string;
  }>;
}

export interface PiiReport {
  findings: Array<{
    page: number;
    kind: string;
    masked: string;
    bounds: { left: number; bottom: number; right: number; top: number };
  }>;
  count: number;
  byKind: Record<string, number>;
  warnings: string[];
  note?: string;
}

export interface ImagesReport {
  images: Array<{
    page: number;
    placement: number;
    objectNumber: number;
    label: string;
    pixelWidth: number;
    pixelHeight: number;
    colourSpace?: string;
    bitsPerComponent: number;
    filter?: string;
    format: string;
    mimeType?: string;
    encodedBytes: number;
    widthPoints: number;
    heightPoints: number;
    dpiX: number;
    dpiY: number;
    masked: boolean;
  }>;
  warnings: string[];
}

export interface ConvertReport {
  format: string;
  formatName: string;
  pages: number[];
  files: Array<{ name: string; page?: number; bytes: number }>;
  totalBytes: number;
  docxMode?: string;
  layout: boolean;
  dpi?: number;
  scale: number;
  warnings?: string[];
  note?: string;
}

export interface CompareReport {
  before: { id: string; fileName: string; pages?: number };
  after: { id: string; fileName: string; pages?: number };
  text: {
    beforePages: number;
    afterPages: number;
    changedPages: number;
    identical: boolean;
    pages: Array<{
      page: number;
      beforeExists: boolean;
      afterExists: boolean;
      changed: boolean;
      removed: string[];
      added: string[];
      visualChanged?: boolean;
    }>;
  };
  visual?: {
    mode: string;
    pages: number;
    changedPages: number;
    additions: number;
    deletions: number;
    moves: number;
    similarity: number;
    identical: boolean;
    changes: Array<{
      id: number;
      type: string;
      risk: string;
      beforePage: number;
      afterPage: number;
      deletedText: string;
      addedText: string;
      note: string;
    }>;
    changesTruncated: boolean;
  } | null;
  warnings: string[];
  note?: string;
}

export interface MetadataReport {
  info: Record<string, string>;
  xmp: Record<string, string>;
  hasXmp: boolean;
  version: string;
  pages: number;
  standardKeys: string[];
}

export interface FormField {
  name: string;
  type: string;
  value?: unknown;
  defaultValue?: unknown;
  page?: number | null;
  rect?: number[] | null;
  maxLength?: number | null;
  signed: boolean;
  options: Array<{ label: string; value: string }>;
  flags: { readOnly: boolean; required: boolean; multiline: boolean; multiSelect: boolean; noExport: boolean };
}

export interface FieldsResponse {
  count: number;
  fields: FormField[];
  warnings: string[];
  hasXfa: boolean;
  hasSignatureValue: boolean;
  hasDocMdp: boolean;
}

export interface AnnotationList {
  count: number;
  annotations: Array<{
    page: number;
    type: string;
    rect: number[];
    contents?: string;
    author?: string;
    color?: string;
    opacity?: number;
    uri?: string;
    destPage?: number;
    fileAttachment?: string;
  }>;
  warnings: string[];
}

export interface AttachmentList {
  count: number;
  attachments: Array<{ name: string; size: number; description?: string; mimeType?: string; created?: string }>;
}

export interface Bookmark {
  title: string;
  page: number;
  uri?: string;
  color?: string;
  open: boolean;
  children: Bookmark[];
}
