import type {
  Artifact,
  AttachmentList,
  Bookmark,
  Capabilities,
  CompareReport,
  EngineRouteCount,
  ConvertReport,
  FieldsResponse,
  Health,
  ImagesReport,
  InspectionReport,
  MetadataReport,
  AnnotationList,
  OperationResponse,
  PiiReport,
  TablesReport,
  TextReport,
  ValidationReport
} from "./types";

export class ApiError extends Error {
  status: number;
  code: string;

  constructor(message: string, status: number, code: string) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.code = code;
  }
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  let response: Response;
  try {
    // A FormData body must keep the browser's own multipart content type: setting
    // application/json drops the boundary the server needs to read the file.
    const isForm = typeof FormData !== "undefined" && init?.body instanceof FormData;
    response = await fetch(path, {
      ...init,
      headers: {
        ...(init?.body && !isForm ? { "content-type": "application/json" } : {}),
        ...(init?.headers ?? {})
      },
      cache: "no-store"
    });
  } catch {
    throw new ApiError("The Docuzen API is not reachable. Start it on port 5080 and try again.", 0, "offline");
  }

  const text = await response.text();
  let payload: unknown = null;
  if (text) {
    try {
      payload = JSON.parse(text);
    } catch {
      payload = null;
    }
  }

  if (!response.ok) {
    const error = (payload as { error?: { message?: string; code?: string } } | null)?.error;
    throw new ApiError(error?.message ?? `Request failed with ${response.status}`, response.status, error?.code ?? "error");
  }

  return payload as T;
}

export const api = {
  health: () => request<Health>("/api/health"),
  capabilities: () => request<Capabilities>("/api/capabilities"),
  engines: () => request<{ engines: EngineRouteCount[] }>("/api/engines"),

  listArtifacts: async (): Promise<Artifact[]> => {
    const data = await request<{ artifacts: Artifact[] }>("/api/artifacts");
    return data.artifacts;
  },
  getArtifact: async (id: string): Promise<Artifact> => {
    const data = await request<{ artifact: Artifact }>(`/api/artifacts/${id}`);
    return data.artifact;
  },
  upload: async (file: File, password?: string): Promise<Artifact> => {
    const body = new FormData();
    body.append("file", file);
    if (password) body.append("password", password);
    const response = await request<{ artifact: Artifact }>("/api/artifacts", { method: "POST", body });
    return response.artifact;
  },
  deleteArtifact: (id: string) => request<{ ok: boolean }>(`/api/artifacts/${id}`, { method: "DELETE" }),
  restoreSamples: () => request<{ created: number; artifacts: Artifact[] }>("/api/samples/restore", { method: "POST" }),
  report: (id: string) => request<Record<string, unknown>>(`/api/artifacts/${id}/report`),
  textContent: async (artifact: Artifact): Promise<string> => {
    const response = await fetch(artifact.contentUrl, { cache: "no-store" });
    if (!response.ok) throw new ApiError("The artifact content could not be read", response.status, "content");
    return response.text();
  },
  metadata: (id: string, password?: string) =>
    request<{ metadata: MetadataReport }>(`/api/artifacts/${id}/metadata${password ? `?password=${encodeURIComponent(password)}` : ""}`),
  bookmarks: (id: string, password?: string) =>
    request<{ bookmarks: Bookmark[]; json: string; count: number }>(
      `/api/artifacts/${id}/bookmarks${password ? `?password=${encodeURIComponent(password)}` : ""}`
    ),
  annotations: (id: string, password?: string) =>
    request<AnnotationList>(`/api/artifacts/${id}/annotations${password ? `?password=${encodeURIComponent(password)}` : ""}`),
  attachments: (id: string, password?: string) =>
    request<AttachmentList>(`/api/artifacts/${id}/attachments${password ? `?password=${encodeURIComponent(password)}` : ""}`),
  fields: (id: string, password?: string) =>
    request<FieldsResponse>(`/api/artifacts/${id}/form${password ? `?password=${encodeURIComponent(password)}` : ""}`),
  images: (id: string, pages?: string, password?: string) => {
    const query = new URLSearchParams();
    if (pages) query.set("pages", pages);
    if (password) query.set("password", password);
    const suffix = query.toString() ? `?${query.toString()}` : "";
    return request<ImagesReport>(`/api/artifacts/${id}/images${suffix}`);
  }
};

export type ToolResult<T> = OperationResponse<T>;

/**
 * The engine routes share one envelope (`OperationResponse`), so the UI posts to them
 * through a single call rather than a hand-written wrapper per workbench.
 */
export const engineTools = {
  call: <T = Record<string, unknown>>(path: string, body: Record<string, unknown> = {}) =>
    request<OperationResponse<T>>(path, { method: "POST", body: JSON.stringify(body) })
};

export const tools = {
  inspect: (body: { artifactId: string; details?: boolean; checkPdfA?: boolean; password?: string }) =>
    request<OperationResponse<InspectionReport>>("/api/tools/inspect", { method: "POST", body: JSON.stringify(body) }),
  validate: (body: { artifactId: string; standard: string; level?: string; profile?: string; part?: string; strict?: boolean; password?: string }) =>
    request<OperationResponse<ValidationReport>>("/api/tools/validate", { method: "POST", body: JSON.stringify(body) }),
  pdfa: (body: { artifactId: string; level: string; password?: string }) =>
    request<OperationResponse<Record<string, unknown>>>("/api/tools/pdfa", { method: "POST", body: JSON.stringify(body) }),
  text: (body: { artifactId: string; pages?: string; layout?: boolean; password?: string }) =>
    request<OperationResponse<TextReport>>("/api/tools/text", { method: "POST", body: JSON.stringify(body) }),
  tables: (body: { artifactId: string; pages?: string; format?: string; borderless?: boolean; password?: string }) =>
    request<OperationResponse<TablesReport>>("/api/tools/tables", { method: "POST", body: JSON.stringify(body) }),
  pii: (body: { artifactId: string; pages?: string; password?: string }) =>
    request<OperationResponse<PiiReport>>("/api/tools/pii", { method: "POST", body: JSON.stringify(body) }),
  convert: (body: {
    artifactId: string;
    format: string;
    pages?: string;
    dpi?: number;
    scale?: number;
    layout?: boolean;
    docxDpi?: number;
    docxMode?: string;
    includeImages?: boolean;
    jpegQuality?: number;
    oneFilePerPage?: boolean;
    password?: string;
  }) => request<OperationResponse<ConvertReport>>("/api/tools/convert", { method: "POST", body: JSON.stringify(body) }),
  extractImages: (body: { artifactId: string; pages?: string; password?: string }) =>
    request<OperationResponse<{ count: number; files: unknown[]; warnings: string[] }>>("/api/tools/extract-images", {
      method: "POST",
      body: JSON.stringify(body)
    }),
  merge: (body: { artifactIds: string[]; outline?: boolean; password?: string }) =>
    request<OperationResponse<Record<string, unknown>>>("/api/tools/pages/merge", { method: "POST", body: JSON.stringify(body) }),
  extractPages: (body: { artifactId: string; pages: string; password?: string }) =>
    request<OperationResponse<Record<string, unknown>>>("/api/tools/pages/extract", { method: "POST", body: JSON.stringify(body) }),
  split: (body: { artifactId: string; pages?: string; each?: number; password?: string }) =>
    request<OperationResponse<Record<string, unknown>>>("/api/tools/pages/split", { method: "POST", body: JSON.stringify(body) }),
  rotate: (body: { artifactId: string; pages?: string; angle: number; password?: string }) =>
    request<OperationResponse<Record<string, unknown>>>("/api/tools/pages/rotate", { method: "POST", body: JSON.stringify(body) }),
  insert: (body: { artifactId: string; at?: number; pageSize?: string; width?: number; height?: number; password?: string }) =>
    request<OperationResponse<Record<string, unknown>>>("/api/tools/pages/insert", { method: "POST", body: JSON.stringify(body) }),
  pageOp: (op: string, body: { artifactId: string; page?: number; destination?: number; factor?: number; password?: string }) =>
    request<OperationResponse<Record<string, unknown>>>(`/api/tools/pages/${op}`, { method: "POST", body: JSON.stringify(body) }),
  crop: (body: { artifactId: string; pages?: string; box?: string; rect?: number[]; margins?: number[]; password?: string }) =>
    request<OperationResponse<Record<string, unknown>>>("/api/tools/pages/crop", { method: "POST", body: JSON.stringify(body) }),
  impose: (body: {
    artifactId: string;
    nUp: number;
    layout?: string;
    sheetSize?: string;
    landscape?: boolean;
    margin?: number[];
    gutter?: number;
    trimMarks?: boolean;
    foldMarks?: boolean;
    pages?: string;
    password?: string;
  }) => request<OperationResponse<Record<string, unknown>>>("/api/tools/pages/impose", { method: "POST", body: JSON.stringify(body) }),
  stamp: (body: {
    artifactId: string;
    pages?: string;
    text?: string;
    imageArtifactId?: string;
    x?: number;
    y?: number;
    fontSize?: number;
    color?: string;
    opacity?: number;
    angle?: number;
    center?: boolean;
    multiline?: boolean;
    maxWidth?: number;
    align?: string;
    width?: number;
    height?: number;
    password?: string;
  }) => request<OperationResponse<Record<string, unknown>>>("/api/tools/pages/stamp", { method: "POST", body: JSON.stringify(body) }),
  replace: (body: {
    artifactId: string;
    find: string;
    replace: string;
    regex?: boolean;
    ignoreCase?: boolean;
    pages?: string;
    color?: string;
    password?: string;
  }) => request<OperationResponse<Record<string, unknown>>>("/api/tools/replace", { method: "POST", body: JSON.stringify(body) }),
  redact: (body: {
    artifactId: string;
    find: string;
    mode?: "find";
    regex?: boolean;
    ignoreCase?: boolean;
    pages?: string;
    color?: string;
    overlayText?: string;
    password?: string;
  }) => request<OperationResponse<Record<string, unknown>>>("/api/tools/redact", { method: "POST", body: JSON.stringify(body) }),
  redactRegions: (body: {
    artifactId: string;
    regions?: Array<{ page?: number; x: number; y: number; width: number; height: number }>;
    pii?: boolean;
    dpi?: number;
    color?: string;
    dryRun?: boolean;
    allowRenderWarnings?: boolean;
    pages?: string;
    password?: string;
  }) => request<OperationResponse<Record<string, unknown>>>("/api/tools/redact-regions", { method: "POST", body: JSON.stringify(body) }),
  sanitize: (body: { artifactId: string; removeMetadata?: boolean; dryRun?: boolean; password?: string }) =>
    request<OperationResponse<Record<string, unknown>>>("/api/tools/sanitize", { method: "POST", body: JSON.stringify(body) }),
  optimize: (body: { artifactId: string; maxImageDpi?: number; jpegQuality?: number; password?: string }) =>
    request<OperationResponse<Record<string, unknown>>>("/api/tools/optimize", { method: "POST", body: JSON.stringify(body) }),
  linearize: (body: { artifactId: string; password?: string }) =>
    request<OperationResponse<Record<string, unknown>>>("/api/tools/linearize", { method: "POST", body: JSON.stringify(body) }),
  repair: (body: { artifactId: string; password?: string }) =>
    request<OperationResponse<Record<string, unknown>>>("/api/tools/repair", { method: "POST", body: JSON.stringify(body) }),
  metadataWrite: (body: { artifactId: string; set: Record<string, string>; dropXmp?: boolean; incremental?: boolean; password?: string }) =>
    request<OperationResponse<Record<string, unknown>>>("/api/tools/metadata", { method: "POST", body: JSON.stringify(body) }),
  bookmarksWrite: (body: {
    artifactId: string;
    action: "add" | "import" | "clear";
    title?: string;
    page?: number;
    uri?: string;
    color?: string;
    json?: string;
    password?: string;
  }) => request<OperationResponse<Record<string, unknown>>>("/api/tools/bookmarks", { method: "POST", body: JSON.stringify(body) }),
  annotationsWrite: (body: {
    artifactId: string;
    type: string;
    page: number;
    rect: number[];
    text?: string;
    uri?: string;
    destPage?: number;
    author?: string;
    color?: string;
    opacity?: number;
    incremental?: boolean;
    password?: string;
  }) => request<OperationResponse<Record<string, unknown>>>("/api/tools/annotations", { method: "POST", body: JSON.stringify(body) }),
  attachmentsWrite: (body: {
    artifactId: string;
    action: "add" | "remove" | "clear" | "extract";
    name?: string;
    description?: string;
    mimeType?: string;
    sourceArtifactId?: string;
    dataBase64?: string;
    removeName?: string;
    password?: string;
  }) => request<OperationResponse<Record<string, unknown>>>("/api/tools/attachments", { method: "POST", body: JSON.stringify(body) }),
  formFieldCreate: (body: {
    artifactId: string;
    action?: "add" | "remove";
    name: string;
    type?: string;
    page?: number;
    rect?: number[];
    defaultValue?: string;
    options?: string[];
    multiline?: boolean;
    readOnly?: boolean;
    required?: boolean;
    password?: string;
  }) => request<OperationResponse<Record<string, unknown>>>("/api/tools/form/fields", { method: "POST", body: JSON.stringify(body) }),
  formFill: (body: { artifactId: string; values: Record<string, string>; flatten?: boolean; incremental?: boolean; password?: string }) =>
    request<OperationResponse<Record<string, unknown>>>("/api/tools/form", { method: "POST", body: JSON.stringify(body) }),
  encrypt: (body: {
    artifactId: string;
    userPassword?: string;
    ownerPassword?: string;
    algorithm?: string;
    permissions?: string[];
    encryptMetadata?: boolean;
    password?: string;
  }) => request<OperationResponse<Record<string, unknown>>>("/api/tools/encrypt", { method: "POST", body: JSON.stringify(body) }),
  decrypt: (body: { artifactId: string; password?: string }) =>
    request<OperationResponse<Record<string, unknown>>>("/api/tools/decrypt", { method: "POST", body: JSON.stringify(body) }),
  sign: (body: {
    artifactId: string;
    certificateMode?: "generate" | "pfx";
    pfxBase64?: string;
    pfxPassword?: string;
    subject?: string;
    validityDays?: number;
    page?: number;
    rect?: number[];
    reason?: string;
    location?: string;
    contact?: string;
    signerName?: string;
    hashAlgorithm?: string;
    docMdp?: number;
    pades?: boolean;
    password?: string;
  }) => request<OperationResponse<Record<string, unknown>>>("/api/tools/sign", { method: "POST", body: JSON.stringify(body) }),
  verify: (body: { artifactId: string; trustBase64?: string[]; password?: string }) =>
    request<OperationResponse<Record<string, unknown>>>("/api/tools/verify-signatures", { method: "POST", body: JSON.stringify(body) }),
  compare: (body: { beforeId: string; afterId: string; visual?: boolean; mode?: string; dpi?: number; threshold?: number; onlyChangedPages?: boolean }) =>
    request<OperationResponse<CompareReport>>("/api/tools/compare", { method: "POST", body: JSON.stringify(body) }),
  createHtml: (body: {
    html: string;
    pageSize?: string;
    landscape?: boolean;
    margins?: number[];
    fontSize?: number;
    title?: string;
    author?: string;
    subject?: string;
    keywords?: string;
    header?: string;
    footer?: string;
    css?: string;
    fileName?: string;
  }) => request<OperationResponse<Record<string, unknown>>>("/api/create/html", { method: "POST", body: JSON.stringify(body) }),
  createBarcode: (body: { text: string; type?: string; moduleWidth?: number; height?: number; x?: number; y?: number; label?: boolean }) =>
    request<OperationResponse<Record<string, unknown>>>("/api/create/barcode", { method: "POST", body: JSON.stringify(body) }),
  conformance: (body: { artifactId: string; profile?: string; part?: string; password?: string }) =>
    request<OperationResponse<Record<string, unknown>>>("/api/tools/conformance", { method: "POST", body: JSON.stringify(body) }),
  destinations: (body: { artifactId: string; password?: string }) =>
    request<OperationResponse<Record<string, unknown>>>("/api/tools/destinations", { method: "POST", body: JSON.stringify(body) })
};
